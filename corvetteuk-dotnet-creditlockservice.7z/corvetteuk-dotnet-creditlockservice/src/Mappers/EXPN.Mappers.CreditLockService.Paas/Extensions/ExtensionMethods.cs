﻿using System.Collections.Generic;
using System.Linq;

namespace EXPN.Mappers.CreditLockService.Paas.Extensions
{
    public static class ExtensionMethods
    {
        public static bool AreMatchingStringPropertiesSame<TLeft, TRight>(TLeft lhs, TRight rhs, IEnumerable<string> exclusionList = null)
        {
            var allLeft = typeof(TLeft).GetProperties().ToDictionary(p => p.Name);

            var allRight = typeof(TRight).GetProperties().ToDictionary(p => p.Name);

            if (exclusionList != null)
            {
                allLeft = allLeft.Where(x => !exclusionList.Contains(x.Key)).ToDictionary(x => x.Key, x => x.Value);
                allRight = allRight.Where(x => !exclusionList.Contains(x.Key)).ToDictionary(x => x.Key, x => x.Value);
            }

            return allLeft.Keys.Intersect(allRight.Keys).All(
                name => Equals(allLeft[name].GetValue(lhs)?.ToString().ToLower() ?? string.Empty, allRight[name].GetValue(rhs)?.ToString().ToLower() ?? string.Empty));
        }
    }
}