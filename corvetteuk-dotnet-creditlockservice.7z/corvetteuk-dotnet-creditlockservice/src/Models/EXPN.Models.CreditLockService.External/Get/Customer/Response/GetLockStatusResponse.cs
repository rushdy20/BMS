﻿namespace EXPN.Models.CreditLockService.External.Get.Customer.Response
{
    public class GetLockStatusResponse
    {
        public string LockStatus { get; set; }
    }
}