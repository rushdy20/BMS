﻿namespace EXPN.Models.CreditLockService.Internal.Post.Request
{
    public class PostActivateInstantAlertRequest
    {
        public string CustomerId { get; set; }

        public string CustomerRef { get; set; }
    }
}