﻿using AutoMapper;
using EXPN.Mappers.CreditLockService.Internal;
using FluentAssertions;
using System.Collections.Generic;
using Xunit;
using ExternalModel = EXPN.Models.CreditLockService.External.Delete.Request;
using InternalModel = EXPN.Models.CreditLockService.Internal.Delete.Request;

namespace EXPN.UnitTest.CreditLockService.Mappers.Internal
{
    public class DeleteEventBodyToDeleteCustomerProfileTests
    {
        private readonly MapperConfiguration _mapperConfiguration;

        public DeleteEventBodyToDeleteCustomerProfileTests()
        {
            _mapperConfiguration = new MapperConfiguration(
                cfg => { cfg.AddProfile<DeleteEventBodyToDeleteCustomerProfile>(); });
        }

        [Fact]
        public void ModelProfile_AssertConfiguration_IsValid()
        {
            _mapperConfiguration.AssertConfigurationIsValid();
        }

        public static IEnumerable<object[]> MappingData()
        {
            yield return new object[]
            {
                null,
                null
            };

            yield return new object[]
            {
                new ExternalModel.DeleteEventBody(),
                new InternalModel.DeleteCustomerRequest()
            };

            yield return new object[]
            {
                new ExternalModel.DeleteEventBody
                {
                    CustomerNumber ="123456789",
                    IdpRefId ="IdpRefId",
                    TenantId="TenenetId",
                    CustomerId ="test"
                },
                new InternalModel.DeleteCustomerRequest
                {
                    CustomerNumber ="123456789",
                    IdpRefId ="IdpRefId",
                    TenantId="TenenetId",
                    CustomerId="test"
                }
            };

            yield return new object[]
            {
               new ExternalModel.DeleteEventBody
               {
                   CustomerNumber =string.Empty,
                   IdpRefId =string.Empty,
                   TenantId=string.Empty
               },
               new InternalModel.DeleteCustomerRequest
               {
                   CustomerNumber =string.Empty,
                   IdpRefId =string.Empty,
                   TenantId=string.Empty
               }
            };
        }

        [Theory]
        [MemberData(nameof(MappingData))]
        public void ExternalModelProfile_ExampleInput_MapsCorrectly(ExternalModel.DeleteEventBody input, InternalModel.DeleteCustomerRequest expected)
        {
            var mapper = _mapperConfiguration.CreateMapper();
            var result = mapper.Map<InternalModel.DeleteCustomerRequest>(input);
            result.Should().BeEquivalentTo(expected);
        }
    }
}