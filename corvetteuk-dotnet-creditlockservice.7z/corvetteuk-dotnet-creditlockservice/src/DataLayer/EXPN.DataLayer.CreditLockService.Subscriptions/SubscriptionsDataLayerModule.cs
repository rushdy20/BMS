﻿using Experian.HttpClient.Services.Subscriptions;
using Microsoft.Extensions.DependencyInjection;
using System.Diagnostics.CodeAnalysis;

namespace EXPN.DataLayer.CreditLockService.Subscriptions;

[ExcludeFromCodeCoverage]
public static class DataLayerModule
{
    public static IServiceCollection AddSubscriptionsDataLayerModule(this IServiceCollection services)
    {
        services.AddSubscriptionsClient();

        services.AddScoped<ISubscriptionsClientProxy, SubscriptionsClientProxy>();

        return services;
    }
}