﻿using AutoMapper;
using Experian.AWS.Logging.Extensions;
using EXPN.BusinessLayer.CreditLockService.Constants;
using EXPN.DataLayer.CreditLockService.Paas.HttpClient;
using EXPN.Models.CreditLockService.Internal.Get.Response;
using EXPN.Models.CreditLockService.Internal.Put.Request;
using EXPN.Models.CreditLockService.Internal.Put.Response;
using Microsoft.Extensions.Logging;
using System;
using PaaSRequest = EXPN.Models.CreditLockService.Paas.PutLockStatus.Request;

namespace EXPN.BusinessLayer.CreditLockService.Commands
{
    public class PutLockStatusCommand<TRequest, TResponse> : ICommand<TRequest, TResponse>
        where TRequest : PutLockStatusRequest
        where TResponse : PutLockStatusResponse
    {
        private readonly ICreditLockPaasClient _creditLockPaasClient;
        private readonly ILogger<PutLockStatusCommand<TRequest, TResponse>> _logger;
        private readonly IMapper _mapper;

        public string Id => "LOCK-PUT";

        public PutLockStatusCommand(ICreditLockPaasClient creditLockPaasClient,
            ILogger<PutLockStatusCommand<TRequest, TResponse>> logger,
            IMapper mapper)
        {
            _creditLockPaasClient = creditLockPaasClient ?? throw new ArgumentNullException(nameof(creditLockPaasClient));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        }

        public TResponse Execute(TRequest request, GetResponseCustomerProfile customerProfile)
        {
            _logger.LogAsInformation(LogEventNames.PutLockStatusCommand.Execute.Enter);

            if (request == null)
                throw new ArgumentNullException(nameof(request));

            if (customerProfile == null)
                throw new ArgumentNullException(nameof(customerProfile));

            if (string.IsNullOrWhiteSpace(request.CustomerId))
                throw new ArgumentException($"{nameof(request.CustomerId)} cannot be null or whitespace", nameof(request));
            
            var paasPutLockStatusRequest = _mapper.Map<PaaSRequest.PutLockStatusRequest>(request);

            paasPutLockStatusRequest.CustomerRef = customerProfile.CustomerRef;

            _creditLockPaasClient.PutLockStatus(paasPutLockStatusRequest).Wait();
            
            _logger.LogAsInformation(LogEventNames.PutLockStatusCommand.Execute.Exit);

            return (TResponse) new PutLockStatusResponse
            {
                LockStatus = paasPutLockStatusRequest.Status
            };
        }
    }
}