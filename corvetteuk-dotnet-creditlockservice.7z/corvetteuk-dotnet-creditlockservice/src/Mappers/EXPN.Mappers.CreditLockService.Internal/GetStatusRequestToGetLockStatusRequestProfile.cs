﻿using System.Diagnostics.CodeAnalysis;
using AutoMapper;
using InternalModel = EXPN.Models.CreditLockService.Internal.Get.Request;
using ExternalModel = EXPN.Models.CreditLockService.External.Get.Customer.Request;

namespace EXPN.Mappers.CreditLockService.Internal
{
    [ExcludeFromCodeCoverage]
    public class GetStatusRequestToGetLockStatusRequestProfile : Profile
  {
      public GetStatusRequestToGetLockStatusRequestProfile()
      {
          CreateMap<ExternalModel.GetStatusRequest, InternalModel.GetCustomerRequest>();
      }
  }
}
