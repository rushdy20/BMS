﻿using System;
using Microsoft.Extensions.Caching.Memory;

namespace EXPN.IntegrationTest.CreditLockService.Utility
{
    public class MockMemoryCache : IMemoryCache
    {
        private bool _disposedValue;

        public bool TryGetValue(object key, out object value)
        {
            value = "Test Auth Token";
            return true;
        }

        public ICacheEntry CreateEntry(object key)
        {
            throw new NotImplementedException();
        }

        public void Remove(object key)
        {
            throw new NotImplementedException();
        }

        protected virtual void Dispose(bool disposing)
        {
            if (_disposedValue) 
                return;

            if (disposing)
            {
                // Do nothing
            }

            _disposedValue = true;
        }

        public void Dispose()
        {
            // Do not change this code. Put cleanup code in 'Dispose(bool disposing)' method
            Dispose(disposing: true);
            GC.SuppressFinalize(this);
        }
    }
}