using AutoMapper;
using Experian.AWS.Logging.Extensions;
using Experian.ResponseModels;
using EXPN.BusinessLayer.CreditLockService;
using EXPN.BusinessLayer.CreditLockService.Exceptions;
using EXPN.Controllers.CreditLockService.Constants;
using EXPN.Controllers.CreditLockService.DateTime;
using EXPN.Controllers.CreditLockService.Messaging;
using EXPN.DataLayer.CreditLockService.Common.Exceptions;
using EXPN.Models.CreditLockService.External.Post.Request;
using EXPN.Models.CreditLockService.Internal;
using EXPN.Models.CreditLockService.Internal.Post.Request;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using LogEventNames = EXPN.Controllers.CreditLockService.Constants.LogEventNames;

namespace EXPN.Controllers.CreditLockService
{
    [ApiController]
    [Route("internal/instantalerts")]
    public class InternalInstantAlertsController : AuditControllerBase
    {
        private readonly ILogger<InternalInstantAlertsController> _logger;
        private readonly ICreditLockServiceCustomerManager _customerManager;
        private readonly IMapper _mapper;

        private const string LogContext = "Context";
        private const int DownstreamMaintenanceStatusCode = 561;
        private const int DownstreamBadResponseStatusCode = 562;
        private const int DownstreamAuthenticationExceptionStatusCode = 563;

        public InternalInstantAlertsController(
            ILogger<InternalInstantAlertsController> logger,
            IMessaging messaging,
            IDateTime dateTime,
            IMapper mapper,
            ICreditLockServiceCustomerManager customerManager) : base(messaging, dateTime)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
            _customerManager = customerManager ?? throw new ArgumentNullException(nameof(customerManager));
        }

        [HttpPost]
        [Route("activate")]
        [ProducesResponseType(typeof(StatusCodeResult), (int)HttpStatusCode.NoContent)]
        [ProducesResponseType(typeof(StatusCodeResult), (int)HttpStatusCode.NotFound)]
        [ProducesResponseType(typeof(StatusCodeResult), (int)HttpStatusCode.Conflict)]
        public async Task<IActionResult> ActivateAsync(PostRequest postRequest)
        {
            const string requestType = "ACTIVATE_INSTANTALERTS";

            try
            {
                _logger.LogAsInformation(LogEventNames.InternalInstantAlertsController.Activate.Invoked);

                if (!ModelState.IsValid)
                {
                    _logger.LogAsWarning(LogEventNames.InternalInstantAlertsController.Activate.ModelStateFailed);

                    await RaiseEvent(requestType, (int)HttpStatusCode.BadRequest, "Bad Request");

                    return new ErrorResponseBuilder()
                        .WithStatusCode(HttpStatusCode.BadRequest)
                        .WithModelStateDictionary(ModelState)
                        .Build();
                }

                await _customerManager.ActivateAsync(_mapper.Map<CustomerRequest>(postRequest));

                await _customerManager.ActivateInstantAlert(_mapper.Map<PostActivateInstantAlertRequest>(postRequest));

                await RaiseEvent(requestType, (int)HttpStatusCode.NoContent, "Success");

                _logger.LogAsInformation(LogEventNames.InternalInstantAlertsController.Activate.Complete);

                return new ApiResult(HttpStatusCode.NoContent, null);
            }
            catch (OktaTokenNullException ex)
            {
                _logger.LogAsError(LogEventNames.InternalInstantAlertsController.Activate.OktaTokenNullException,
                    new Dictionary<string, object> { { LogContext, new { ErrorMessage = ex.Message, Exception = ex } } });

                await RaiseEvent(requestType, (int)HttpStatusCode.BadGateway, "Bad Gateway");

                return new ErrorResponseBuilder()
                    .WithStatusCode(HttpStatusCode.BadGateway)
                    .Build();
            }
            catch (OktaException ex)
            {
                _logger.LogAsError(LogEventNames.InternalInstantAlertsController.Activate.OktaTokenException,
                    new Dictionary<string, object> { { LogContext, new { ErrorMessage = ex.Message, Exception = ex } } });

                await RaiseEvent(requestType, (int)HttpStatusCode.BadGateway, "Bad Gateway");

                return new ErrorResponseBuilder()
                    .WithStatusCode(HttpStatusCode.BadGateway)
                    .Build();
            }
            catch (CustomerProfileNotFoundException ex)
            {
                _logger.LogAsError(LogEventNames.InternalInstantAlertsController.Activate.CustomerProfileNotFoundException,
                    new Dictionary<string, object> { { LogContext, new { ErrorMessage = ex.Message, Exception = ex } } });

                await RaiseEvent(requestType, (int)HttpStatusCode.NotFound, "Corvette Customer Profile is not found");

                return new ErrorResponseBuilder()
                    .WithStatusCode(HttpStatusCode.NotFound)
                    .Build();
            }
            catch (CustomerPostRequestConflictException)
            {
                _logger.LogAsInformation(LogEventNames.InternalInstantAlertsController.Activate.CustomerConflict);

                await RaiseEvent(requestType, (int)HttpStatusCode.Conflict, "Conflict - customer waiting to be pinned or pinning in process");

                return new ErrorResponseBuilder()
                    .WithStatusCode(HttpStatusCode.Conflict)
                    .Build();
            }
            catch (DownstreamMaintenanceException)
            {
                _logger.LogAsInformation(LogEventNames.InternalInstantAlertsController.Activate.DownstreamMaintenanceException);

                await RaiseEvent(requestType, DownstreamMaintenanceStatusCode, "Downstream Service Unavailable - mainframe down for scheduled maintenance");

                return new ErrorResponseBuilder()
                    .WithStatusCode(DownstreamMaintenanceStatusCode)
                    .Build();
            }

            catch (HttpServiceRequestException ex)
            {
                _logger.LogAsError(LogEventNames.InternalInstantAlertsController.Activate.HttpServiceRequestException,
                    new Dictionary<string, object>
                    {
                        {
                            LogContext, new { ErrorMessage = ex.Message, Exception = ex.GetBaseException() }
                        }
                    });

                await RaiseEvent(requestType, (int)HttpStatusCode.InternalServerError, "Internal Server Error");

                return new ErrorResponseBuilder()
                    .WithStatusCode(HttpStatusCode.InternalServerError)
                    .Build();
            }
            catch (ServiceTaskCanceledException ex)
            {
                _logger.LogAsError(LogEventNames.InternalInstantAlertsController.Activate.ServiceTaskCanceledException,
                    new Dictionary<string, object> { { LogContext, new { ErrorMessage = ex.Message, Exception = ex } } });

                await RaiseEvent(requestType, MessageConstants.DownstreamTimeoutStatusCode, MessageConstants.DownstreamTimeout);

                return new ErrorResponseBuilder()
                    .WithStatusCode(MessageConstants.DownstreamTimeoutStatusCode)
                    .Build();
            }
            catch (ServiceUnavailableException ex)
            {
                _logger.LogAsError(LogEventNames.InternalInstantAlertsController.Activate.ServiceUnavailableException,
                    new Dictionary<string, object> { { LogContext, new { ErrorMessage = ex.Message, Exception = ex } } });

                await RaiseEvent(requestType, (int)HttpStatusCode.ServiceUnavailable, "Service Unavailable");

                return new ErrorResponseBuilder()
                    .WithStatusCode(HttpStatusCode.ServiceUnavailable)
                    .Build();
            }
            catch (DownstreamBadResponseException ex)
            {
                _logger.LogAsError(LogEventNames.InternalInstantAlertsController.Activate.DownstreamBadResponse,
                    new Dictionary<string, object> { { LogContext, new { ErrorMessage = ex.Message, Exception = ex } } });

                await RaiseEvent(requestType, DownstreamBadResponseStatusCode, "Downstream Bad Request");

                return new ErrorResponseBuilder()
                    .WithStatusCode(DownstreamBadResponseStatusCode)
                    .Build();
            }
            catch (SyncCustomerPinningException)
            {
                _logger.LogAsInformation(LogEventNames.InternalInstantAlertsController.Activate.SyncCustomerPinningException);

                await RaiseEvent(requestType, (int)HttpStatusCode.Conflict, "Conflict - customer waiting to be pinned or pinning in process");

                return new ErrorResponseBuilder()
                    .WithStatusCode(HttpStatusCode.Conflict)
                    .Build();
            }
            catch (DownstreamAuthenticationException)
            {
                _logger.LogAsError(LogEventNames.InternalInstantAlertsController.Activate.DownstreamAuthenticationException);

                await RaiseEvent(requestType, DownstreamAuthenticationExceptionStatusCode, MessageConstants.DownstreamAuthenticationFailed);

                return new ErrorResponseBuilder()
                    .WithStatusCode(DownstreamAuthenticationExceptionStatusCode)
                    .Build();
            }
            catch (CustomerNotFoundException ex)
            {
                _logger.LogAsError(LogEventNames.InternalInstantAlertsController.Activate.CustomerNotFoundException,
                    new Dictionary<string, object>
                        { { LogContext, new { ErrorMessage = ex.Message, Exception = ex } } });

                await RaiseEvent(requestType, (int)HttpStatusCode.NotFound, "VIP Customer is Not Found");

                return new ErrorResponseBuilder()
                    .WithStatusCode(HttpStatusCode.NotFound)
                    .Build();
            }
            catch (Exception ex)
            {
                _logger.LogAsError(LogEventNames.InternalInstantAlertsController.Activate.UnhandledException,
                    new Dictionary<string, object> { { LogContext, new { Exception = ex } } });

                await RaiseEvent(requestType, (int)HttpStatusCode.InternalServerError, "Internal Server Error");

                return new ErrorResponseBuilder()
                    .WithStatusCode((int)HttpStatusCode.InternalServerError)
                    .Build();
            }
        }

        [HttpPost]
        [Route("deactivate")]
        [ProducesResponseType(typeof(StatusCodeResult), (int)HttpStatusCode.NoContent)]
        [ProducesResponseType(typeof(StatusCodeResult), (int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> DeactivateAsync(PostRequest postRequest)
        {
            const string requestType = "DEACTIVATE_INSTANTALERTS";
            
            try
            {
                _logger.LogAsInformation(LogEventNames.InternalInstantAlertsController.Deactivate.Invoked);

                if (!ModelState.IsValid)
                {
                    _logger.LogAsWarning(LogEventNames.InternalInstantAlertsController.Deactivate.ModelStateFailed);

                    await RaiseEvent(requestType, (int)HttpStatusCode.BadRequest, "Bad Request");

                    return new ErrorResponseBuilder()
                        .WithStatusCode(HttpStatusCode.BadRequest)
                        .WithModelStateDictionary(ModelState)
                        .Build();
                }

                await _customerManager.DeactivateInstantAlert(_mapper.Map<PostDeactivateInstantAlertRequest>(postRequest));

                await RaiseEvent(requestType, (int)HttpStatusCode.NoContent, "Success");

                _logger.LogAsInformation(LogEventNames.InternalInstantAlertsController.Deactivate.Complete);

                return new ApiResult(HttpStatusCode.NoContent, null);
            }
            catch (OktaTokenNullException ex)
            {
                _logger.LogAsError(LogEventNames.InternalInstantAlertsController.Deactivate.OktaTokenNullException,
                    new Dictionary<string, object> { { LogContext, new { ErrorMessage = ex.Message, Exception = ex } } });

                await RaiseEvent(requestType, (int)HttpStatusCode.BadGateway, "Bad Gateway");

                return new ErrorResponseBuilder()
                    .WithStatusCode(HttpStatusCode.BadGateway)
                    .Build();
            }
            catch (OktaException ex)
            {
                _logger.LogAsError(LogEventNames.InternalInstantAlertsController.Deactivate.OktaTokenException,
                    new Dictionary<string, object> { { LogContext, new { ErrorMessage = ex.Message, Exception = ex } } });

                await RaiseEvent(requestType, (int)HttpStatusCode.BadGateway, "Bad Gateway");

                return new ErrorResponseBuilder()
                    .WithStatusCode(HttpStatusCode.BadGateway)
                    .Build();
            }
            catch (CustomerProfileNotFoundException ex)
            {
                _logger.LogAsError(LogEventNames.InternalInstantAlertsController.Deactivate.CustomerProfileNotFoundException,
                    new Dictionary<string, object> { { LogContext, new { ErrorMessage = ex.Message, Exception = ex } } });

                await RaiseEvent(requestType, (int)HttpStatusCode.InternalServerError, "Internal Server Error");

                return new ErrorResponseBuilder()
                    .WithStatusCode(HttpStatusCode.InternalServerError)
                    .Build();
            }
            catch (CustomerNotFoundException)
            {
                _logger.LogAsInformation(LogEventNames.InternalInstantAlertsController.Deactivate.CustomerNotFoundException);

                await RaiseEvent(requestType, (int)HttpStatusCode.NoContent, "VIP Customer is Not Found");

                return new ApiResult(HttpStatusCode.NoContent, null);
            }
            catch (DownstreamMaintenanceException)
            {
                _logger.LogAsInformation(LogEventNames.InternalInstantAlertsController.Deactivate.DownstreamMaintenanceException);

                await RaiseEvent(requestType, DownstreamMaintenanceStatusCode, "Downstream Service Unavailable - mainframe down for scheduled maintenance");

                return new ErrorResponseBuilder()
                    .WithStatusCode(DownstreamMaintenanceStatusCode)
                    .Build();
            }
            catch (HttpServiceRequestException ex)
            {
                _logger.LogAsError(LogEventNames.InternalInstantAlertsController.Deactivate.HttpServiceRequestException,
                    new Dictionary<string, object>
                    {
                        {
                            LogContext, new { ErrorMessage = ex.Message, Exception = ex.GetBaseException() }
                        }
                    });

                await RaiseEvent(requestType, (int)HttpStatusCode.InternalServerError, "Internal Server Error");

                return new ErrorResponseBuilder()
                    .WithStatusCode(HttpStatusCode.InternalServerError)
                    .Build();
            }
            catch (ServiceTaskCanceledException ex)
            {
                _logger.LogAsError(LogEventNames.InternalInstantAlertsController.Deactivate.ServiceTaskCanceledException,
                    new Dictionary<string, object> { { LogContext, new { ErrorMessage = ex.Message, Exception = ex } } });

                await RaiseEvent(requestType, MessageConstants.DownstreamTimeoutStatusCode, MessageConstants.DownstreamTimeout);

                return new ErrorResponseBuilder()
                    .WithStatusCode(MessageConstants.DownstreamTimeoutStatusCode)
                    .Build();
            }
            catch (ServiceUnavailableException ex)
            {
                _logger.LogAsError(LogEventNames.InternalInstantAlertsController.Deactivate.ServiceUnavailableException,
                    new Dictionary<string, object> { { LogContext, new { ErrorMessage = ex.Message, Exception = ex } } });

                await RaiseEvent(requestType, (int)HttpStatusCode.ServiceUnavailable, "Service Unavailable");

                return new ErrorResponseBuilder()
                    .WithStatusCode(HttpStatusCode.ServiceUnavailable)
                    .Build();
            }
            catch (DownstreamBadResponseException ex)
            {
                _logger.LogAsError(LogEventNames.InternalInstantAlertsController.Deactivate.DownstreamBadResponse,
                    new Dictionary<string, object> { { LogContext, new { ErrorMessage = ex.Message, Exception = ex } } });

                await RaiseEvent(requestType, DownstreamBadResponseStatusCode, "Downstream Bad Request");

                return new ErrorResponseBuilder()
                    .WithStatusCode(DownstreamBadResponseStatusCode)
                    .Build();
            }
            catch (DownstreamAuthenticationException)
            {
                _logger.LogAsError(LogEventNames.InternalCreditLockController.Deactivate.DownstreamAuthenticationException);

                await RaiseEvent(requestType, DownstreamAuthenticationExceptionStatusCode, MessageConstants.DownstreamAuthenticationFailed);

                return new ErrorResponseBuilder()
                    .WithStatusCode(DownstreamAuthenticationExceptionStatusCode)
                    .Build();
            }
            catch (Exception ex)
            {
                _logger.LogAsError(LogEventNames.InternalInstantAlertsController.Deactivate.UnhandledException,
                    new Dictionary<string, object> { { LogContext, new { Exception = ex } } });

                await RaiseEvent(requestType, (int)HttpStatusCode.InternalServerError, "Internal Server Error");

                return new ErrorResponseBuilder()
                    .WithStatusCode((int)HttpStatusCode.InternalServerError)
                    .Build();
            }
        }
    }
}