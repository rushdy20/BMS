﻿namespace EXPN.Controllers.CreditLockService.DateTime
{
    public interface IDateTime
    {
        System.DateTime Now { get; }
    }
}