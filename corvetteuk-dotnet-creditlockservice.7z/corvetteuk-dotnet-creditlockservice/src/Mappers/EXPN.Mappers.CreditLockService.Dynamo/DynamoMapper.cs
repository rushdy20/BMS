using AutoMapper;

namespace EXPN.Mappers.CreditLockService.Dynamo
{
    public class DynamoMapper : Profile
    {
        public DynamoMapper()
        {

        }
    }
}
