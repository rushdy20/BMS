using AutoMapper;
using Experian.AWS.Logging.Extensions;
using Experian.ResponseModels;
using EXPN.BusinessLayer.CreditLockService;
using EXPN.BusinessLayer.CreditLockService.Exceptions;
using EXPN.Controllers.CreditLockService.Constants;
using EXPN.Controllers.CreditLockService.DateTime;
using EXPN.Controllers.CreditLockService.Messaging;
using EXPN.DataLayer.CreditLockService.Common.Exceptions;
using EXPN.Models.CreditLockService.External.Get.Customer.Request;
using EXPN.Models.CreditLockService.External.Put.Request;
using EXPN.Models.CreditLockService.Internal.Put.Request;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using ExternalModel = EXPN.Models.CreditLockService.External.Get.Customer.Response;
using InternalModel = EXPN.Models.CreditLockService.Internal;

namespace EXPN.Controllers.CreditLockService;

[ApiController]
[Route("api/creditlock")]
public class ExternalController : AuditControllerBase
{
    private readonly ILogger<ExternalController> _logger;
    private readonly IMapper _mapper;
    private readonly ICreditLockServiceCustomerManager _creditLockServiceCustomerManager;
    private readonly IBenefitChecker _benefitChecker;

    private const string LogContext = "Context";
    private const int DownstreamMaintenanceStatusCode = 561;
    private const int DownstreamAuthenticationExceptionStatusCode = 563;

    public ExternalController(
        ILogger<ExternalController> logger,
        IMapper mapper,
        ICreditLockServiceCustomerManager creditLockServiceCustomerManager,
        IMessaging messaging,
        IDateTime dateTime,
        IBenefitChecker benefitChecker) :
        base(messaging, dateTime)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        _creditLockServiceCustomerManager = creditLockServiceCustomerManager ?? throw new ArgumentNullException(nameof(creditLockServiceCustomerManager));
        _benefitChecker = benefitChecker ?? throw new ArgumentNullException(nameof(benefitChecker));
    }

    [HttpGet]
    [ProducesResponseType(typeof(ExternalModel.GetLockStatusResponse), (int)HttpStatusCode.OK)]
    [ProducesResponseType(typeof(ErrorResponseBody), (int)HttpStatusCode.BadRequest)]
    [ProducesResponseType(typeof(StatusCodeResult), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(StatusCodeResult), (int)HttpStatusCode.InternalServerError)]
    [ProducesResponseType(typeof(StatusCodeResult), (int)HttpStatusCode.ServiceUnavailable)]
    public async Task<IActionResult> Get(GetStatusRequest request)
    {
        const string requestType = "GET_CREDITLOCK";
        try
        {
            _logger.LogAsInformation(LogEventNames.ExternalController.Get.Invoked);

            if (!ModelState.IsValid)
            {
                _logger.LogAsInformation(LogEventNames.ExternalController.Get.ModelStateFailed);

                return new ErrorResponseBuilder()
                    .WithStatusCode(HttpStatusCode.BadRequest)
                    .WithModelStateDictionary(ModelState)
                    .Build();
            }

            await _benefitChecker.EnsureValidBenefitAsync();

            var internalResponse = await _creditLockServiceCustomerManager.GetCustomerAsync(
                _mapper.Map<InternalModel.Get.Request.GetCustomerRequest>(request)
            );

            var externalResponse = _mapper.Map<ExternalModel.GetLockStatusResponse>(internalResponse);

            _logger.LogAsInformation(LogEventNames.ExternalController.Get.Complete);

            return new ApiResult(HttpStatusCode.OK, externalResponse);
        }
        catch (NoBenefitException ex)
        {
            _logger.LogAsWarning(LogEventNames.ExternalController.Get.BenefitCheckFail,
                new Dictionary<string, object> { { "context", new { Exception = (Exception)ex } } });

            return new ErrorResponseBuilder()
                .WithStatusCode(HttpStatusCode.Forbidden)
                .WithMessage(ex.Message)
                .Build();

        }
        catch (BenefitsInvalidOperationException ex)
        {
            _logger.LogAsWarning(LogEventNames.ExternalController.Get.BenefitsInvalidOperationException,
                new Dictionary<string, object> { { "context", new { Exception = (Exception)ex } } });

            return new ErrorResponseBuilder()
                .WithStatusCode(HttpStatusCode.InternalServerError)
                .WithMessage(ex.Message)
                .Build();
        }
        catch (DownstreamMaintenanceException)
        {
            _logger.LogAsInformation(LogEventNames.ExternalController.Get.DownstreamMaintenanceException);

            return new ErrorResponseBuilder()
                .WithStatusCode(DownstreamMaintenanceStatusCode)
                .Build();
        }

        catch (CustomerNotFoundException ex)
        {
            _logger.LogAsError(LogEventNames.ExternalController.Get.CustomerNotFoundException,
                new Dictionary<string, object>
                    { { LogContext, new { ErrorMessage = ex.Message, Exception = ex } } });

            return new ErrorResponseBuilder()
                .WithStatusCode(HttpStatusCode.NotFound)
                .Build();
        }
        catch (OktaTokenNullException ex)
        {
            _logger.LogAsError(LogEventNames.ExternalController.Get.OktaTokenNullException,
                new Dictionary<string, object>
                    { { LogContext, new { ErrorMessage = ex.Message, Exception = ex } } });

            return new ErrorResponseBuilder()
                .WithStatusCode(HttpStatusCode.BadGateway)
                .Build();
        }
        catch (HttpServiceRequestException ex)
        {
            _logger.LogAsError(LogEventNames.ExternalController.Get.HttpServiceRequestException,
                new Dictionary<string, object>
                {
                    {LogContext, new {ErrorMessage = ex.Message, Exception = ex.GetBaseException()}}
                });

            return new ErrorResponseBuilder()
                .WithStatusCode(HttpStatusCode.InternalServerError)
                .Build();
        }
        catch (ServiceTaskCanceledException ex)
        {
            _logger.LogAsError(LogEventNames.ExternalController.Get.ServiceTaskCanceledException,
                new Dictionary<string, object>
                    { { LogContext, new { ErrorMessage = ex.Message, Exception = ex } } });

            return new ErrorResponseBuilder()
                .WithStatusCode(MessageConstants.DownstreamTimeoutStatusCode)
                .Build();
        }
        catch (ServiceUnavailableException ex)
        {
            _logger.LogAsError(LogEventNames.ExternalController.Get.ServiceUnavailableException,
                new Dictionary<string, object>
                    { { LogContext, new { ErrorMessage = ex.Message, Exception = ex } } });

            return new ErrorResponseBuilder()
                .WithStatusCode(HttpStatusCode.ServiceUnavailable)
                .Build();
        }
        catch (OktaException ex)
        {
            _logger.LogAsError(LogEventNames.ExternalController.Get.OktaTokenException,
                new Dictionary<string, object>
                    { { LogContext, new { ErrorMessage = ex.Message, Exception = ex } } });

            return new ErrorResponseBuilder()
                .WithStatusCode(HttpStatusCode.BadGateway)
                .Build();
        }
        catch (AutoMapperMappingException ex)
        {
            _logger.LogAsError(LogEventNames.ExternalController.Get.AutoMapperMappingException,
                new Dictionary<string, object> { { LogContext, new { ErrorMessage = ex.InnerException?.Message, Exception = ex.InnerException } } });

            return new ErrorResponseBuilder()
                .WithStatusCode(HttpStatusCode.InternalServerError)
                .WithMessage(ex.InnerException?.Message)
                .Build();
        }
        catch (DownstreamAuthenticationException)
        {
            _logger.LogAsError(LogEventNames.ExternalController.Get.DownstreamAuthenticationException);

            await RaiseEvent(requestType, DownstreamAuthenticationExceptionStatusCode, MessageConstants.DownstreamAuthenticationFailed);

            return new ErrorResponseBuilder()
                .WithStatusCode(DownstreamAuthenticationExceptionStatusCode)
                .Build();
        }
        catch (Exception ex)
        {
            _logger.LogAsError(LogEventNames.ExternalController.Get.UnhandledException,
                new Dictionary<string, object> { { LogContext, new { Exception = ex } } });

            return new ErrorResponseBuilder()
                .WithStatusCode(HttpStatusCode.InternalServerError)
                .Build();
        }
    }

    [HttpPut]
    [ProducesResponseType(typeof(StatusCodeResult), (int)HttpStatusCode.NoContent)]
    [ProducesResponseType(typeof(ErrorResponseBody), (int)HttpStatusCode.BadRequest)]
    [ProducesResponseType(typeof(StatusCodeResult), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(StatusCodeResult), (int)HttpStatusCode.InternalServerError)]
    [ProducesResponseType(typeof(StatusCodeResult), (int)HttpStatusCode.ServiceUnavailable)]
    public async Task<IActionResult> PutAsync(PutStatusRequest request)
    {
        try
        {
            _logger.LogAsInformation(LogEventNames.ExternalController.Put.Invoked);

            if (!ModelState.IsValid)
            {
                _logger.LogAsInformation(LogEventNames.ExternalController.Put.ModelStateFailed);

                await RaiseEvent("SET_LOCK", (int)HttpStatusCode.BadRequest, "Bad Request");

                return new ErrorResponseBuilder()
                    .WithStatusCode(HttpStatusCode.BadRequest)
                    .WithModelStateDictionary(ModelState)
                    .Build();
            }

            await _benefitChecker.EnsureValidBenefitAsync();

            var internalRequest = _mapper.Map<PutLockStatusRequest>(request);

            _mapper.Map(request.Body, internalRequest);

            await _creditLockServiceCustomerManager.PutLockStatus(internalRequest);

            await RaiseEvent($"SET_LOCK_{request.Body.Status}", (int)HttpStatusCode.NoContent, "Success");

            _logger.LogAsInformation(LogEventNames.ExternalController.Put.Complete);

            return new ApiResult(HttpStatusCode.NoContent, null);
        }
        catch (NoBenefitException ex)
        {
            _logger.LogAsWarning(LogEventNames.ExternalController.Put.BenefitCheckFail,
                new Dictionary<string, object> { { "context", new { Exception = (Exception)ex } } });

            await RaiseEvent($"SET_LOCK_{request.Body.Status}", (int)HttpStatusCode.Forbidden, "Benefit could not be fulfilled");

            return new ErrorResponseBuilder()
                .WithStatusCode(HttpStatusCode.Forbidden)
                .WithMessage(ex.Message)
                .Build();
        }
        catch (BenefitsInvalidOperationException ex)
        {
            _logger.LogAsWarning(LogEventNames.ExternalController.Put.BenefitsInvalidOperationException,
                new Dictionary<string, object> { { "context", new { Exception = (Exception)ex } } });

            await RaiseEvent($"SET_LOCK_{request.Body.Status}", (int)HttpStatusCode.InternalServerError, "Upstream service subscriptions returned no data.");

            return new ErrorResponseBuilder()
                .WithStatusCode(HttpStatusCode.InternalServerError)
                .WithMessage(ex.Message)
                .Build();
        }
        catch (DownstreamMaintenanceException)
        {
            _logger.LogAsInformation(LogEventNames.ExternalController.Put.DownstreamMaintenanceException);

            await RaiseEvent($"SET_LOCK_{request.Body.Status}", DownstreamMaintenanceStatusCode, "Downstream Service Unavailable - mainframe down for scheduled maintenance");

            return new ErrorResponseBuilder()
                .WithStatusCode(DownstreamMaintenanceStatusCode)
                .Build();
        }
        catch (OktaTokenNullException ex)
        {
            _logger.LogAsError(LogEventNames.ExternalController.Put.OktaTokenNullException,
                new Dictionary<string, object> { { LogContext, new { ErrorMessage = ex.Message, Exception = ex } } });

            await RaiseEvent($"SET_LOCK_{request.Body.Status}", (int)HttpStatusCode.BadGateway, "Bad Gateway");

            return new ErrorResponseBuilder()
                .WithStatusCode(HttpStatusCode.BadGateway)
                .Build();
        }
        catch (OktaException ex)
        {
            _logger.LogAsError(LogEventNames.ExternalController.Put.OktaTokenException,
                new Dictionary<string, object> { { LogContext, new { ErrorMessage = ex.Message, Exception = ex } } });

            await RaiseEvent($"SET_LOCK_{request.Body.Status}", (int)HttpStatusCode.BadGateway, "Bad Gateway");

            return new ErrorResponseBuilder()
                .WithStatusCode(HttpStatusCode.BadGateway)
                .Build();
        }
        catch (HttpServiceRequestException ex)
        {
            _logger.LogAsError(LogEventNames.ExternalController.Put.HttpServiceRequestException,
                new Dictionary<string, object>
                {
                    {
                        LogContext, new { ErrorMessage = ex.Message, Exception = ex.GetBaseException() }
                    }
                });

            await RaiseEvent($"SET_LOCK_{request.Body.Status}", (int)HttpStatusCode.InternalServerError, "Internal Server Error");

            return new ErrorResponseBuilder()
                .WithStatusCode(HttpStatusCode.InternalServerError)
                .Build();
        }
        catch (ServiceTaskCanceledException ex)
        {
            _logger.LogAsError(LogEventNames.ExternalController.Put.ServiceTaskCanceledException,
                new Dictionary<string, object>
                    { { LogContext, new { ErrorMessage = ex.Message, Exception = ex } } });

            await RaiseEvent($"SET_LOCK_{request.Body.Status}", MessageConstants.DownstreamTimeoutStatusCode, MessageConstants.DownstreamTimeout);

            return new ErrorResponseBuilder()
                .WithStatusCode(MessageConstants.DownstreamTimeoutStatusCode)
                .Build();
        }
        catch (ServiceUnavailableException ex)
        {
            _logger.LogAsError(LogEventNames.ExternalController.Put.ServiceUnavailableException,
                new Dictionary<string, object>
                    { { LogContext, new { ErrorMessage = ex.Message, Exception = ex } } });

            await RaiseEvent($"SET_LOCK_{request.Body.Status}", (int)HttpStatusCode.ServiceUnavailable, "Service Unavailable");

            return new ErrorResponseBuilder()
                .WithStatusCode(HttpStatusCode.ServiceUnavailable)
                .Build();
        }
        catch (CustomerNotFoundException ex)
        {
            _logger.LogAsError(LogEventNames.ExternalController.Put.CustomerNotFoundException,
                new Dictionary<string, object>
                    { { LogContext, new { ErrorMessage = ex.Message, Exception = ex } } });

            await RaiseEvent($"SET_LOCK_{request.Body.Status}", (int)HttpStatusCode.NotFound, "VIP Customer is Not Found");

            return new ErrorResponseBuilder()
                .WithStatusCode(HttpStatusCode.NotFound)
                .Build();
        }
        catch (SyncCustomerPinningException)
        {
            _logger.LogAsInformation(LogEventNames.ExternalController.Put.SyncCustomerPinningException);

            await RaiseEvent($"SET_LOCK_{request.Body.Status}", (int)HttpStatusCode.Conflict, "Conflict - customer waiting to be pinned or pinning in process");

            return new ErrorResponseBuilder()
                .WithStatusCode(HttpStatusCode.Conflict)
                .Build();
        }
        catch (DownstreamAuthenticationException)
        {
            _logger.LogAsError(LogEventNames.ExternalController.Put.DownstreamAuthenticationException);

            await RaiseEvent($"SET_LOCK_{request.Body.Status}", DownstreamAuthenticationExceptionStatusCode, MessageConstants.DownstreamAuthenticationFailed);

            return new ErrorResponseBuilder()
                .WithStatusCode(DownstreamAuthenticationExceptionStatusCode)
                .Build();
        }
        catch (Exception ex)
        {
            _logger.LogAsError(LogEventNames.ExternalController.Put.UnhandledException,
                new Dictionary<string, object> { { LogContext, new { Exception = ex } } });

            await RaiseEvent($"SET_LOCK_{request.Body.Status}", (int)HttpStatusCode.InternalServerError, "Internal Server Error");

            return new ErrorResponseBuilder()
                .WithStatusCode(HttpStatusCode.InternalServerError)
                .Build();
        }
    }


    [HttpPut]
    [Route("cs")]
    [ProducesResponseType(typeof(StatusCodeResult), (int)HttpStatusCode.NoContent)]
    [ProducesResponseType(typeof(ErrorResponseBody), (int)HttpStatusCode.BadRequest)]
    [ProducesResponseType(typeof(StatusCodeResult), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(StatusCodeResult), (int)HttpStatusCode.InternalServerError)]
    [ProducesResponseType(typeof(StatusCodeResult), (int)HttpStatusCode.ServiceUnavailable)]
    public async Task<IActionResult> PutAgentAsync(PutStatusAgentRequest request)
    {
        try
        {
            _logger.LogAsInformation(LogEventNames.ExternalController.PutAgent.Invoked);

            if (!ModelState.IsValid)
            {
                _logger.LogAsInformation(LogEventNames.ExternalController.PutAgent.ModelStateFailed);

                await RaiseEvent("AGENT_SET_LOCK", (int)HttpStatusCode.BadRequest, "Bad Request", string.IsNullOrWhiteSpace(request.Body.SalesforceUserId) ? null : request.Body.SalesforceUserId);

                return new ErrorResponseBuilder()
                    .WithStatusCode(HttpStatusCode.BadRequest)
                    .WithModelStateDictionary(ModelState)
                    .Build();
            }

            await _benefitChecker.EnsureValidBenefitAsync();

            var internalRequest = _mapper.Map<PutLockStatusRequest>(request);

            _mapper.Map(request.Body, internalRequest);

            await _creditLockServiceCustomerManager.PutLockStatus(internalRequest);

            await RaiseEvent($"AGENT_SET_LOCK_{request.Body.Status}", (int)HttpStatusCode.NoContent, "Success", request.Body.SalesforceUserId);

            _logger.LogAsInformation(LogEventNames.ExternalController.PutAgent.Complete);

            return new ApiResult(HttpStatusCode.NoContent, null);
        }
        catch (NoBenefitException ex)
        {
            _logger.LogAsWarning(LogEventNames.ExternalController.PutAgent.BenefitCheckFail,
                new Dictionary<string, object> { { "context", new { Exception = (Exception)ex } } });

            await RaiseEvent($"AGENT_SET_LOCK_{request.Body.Status}", (int)HttpStatusCode.Forbidden, "Benefit could not be fulfilled", request.Body.SalesforceUserId);

            return new ErrorResponseBuilder()
                .WithStatusCode(HttpStatusCode.Forbidden)
                .WithMessage(ex.Message)
                .Build();
        }
        catch (BenefitsInvalidOperationException ex)
        {
            _logger.LogAsWarning(LogEventNames.ExternalController.PutAgent.BenefitsInvalidOperationException,
                new Dictionary<string, object> { { "context", new { Exception = (Exception)ex } } });

            await RaiseEvent($"AGENT_SET_LOCK_{request.Body.Status}", (int)HttpStatusCode.InternalServerError, "Upstream service subscriptions returned no data.", request.Body.SalesforceUserId);

            return new ErrorResponseBuilder()
                .WithStatusCode(HttpStatusCode.InternalServerError)
                .WithMessage(ex.Message)
                .Build();
        }
        catch (DownstreamMaintenanceException)
        {
            _logger.LogAsInformation(LogEventNames.ExternalController.PutAgent.DownstreamMaintenanceException);

            await RaiseEvent($"AGENT_SET_LOCK_{request.Body.Status}", DownstreamMaintenanceStatusCode, "Downstream Service Unavailable - mainframe down for scheduled maintenance", request.Body.SalesforceUserId);

            return new ErrorResponseBuilder()
                .WithStatusCode(DownstreamMaintenanceStatusCode)
                .Build();
        }
        catch (OktaTokenNullException ex)
        {
            _logger.LogAsError(LogEventNames.ExternalController.PutAgent.OktaTokenNullException,
                new Dictionary<string, object> { { LogContext, new { ErrorMessage = ex.Message, Exception = ex } } });

            await RaiseEvent($"AGENT_SET_LOCK_{request.Body.Status}", (int)HttpStatusCode.BadGateway, "Bad Gateway", request.Body.SalesforceUserId);

            return new ErrorResponseBuilder()
                .WithStatusCode(HttpStatusCode.BadGateway)
                .Build();
        }
        catch (OktaException ex)
        {
            _logger.LogAsError(LogEventNames.ExternalController.PutAgent.OktaTokenException,
                new Dictionary<string, object> { { LogContext, new { ErrorMessage = ex.Message, Exception = ex } } });

            await RaiseEvent($"AGENT_SET_LOCK_{request.Body.Status}", (int)HttpStatusCode.BadGateway, "Bad Gateway", request.Body.SalesforceUserId);

            return new ErrorResponseBuilder()
                .WithStatusCode(HttpStatusCode.BadGateway)
                .Build();
        }
        catch (HttpServiceRequestException ex)
        {
            _logger.LogAsError(LogEventNames.ExternalController.PutAgent.HttpServiceRequestException,
                new Dictionary<string, object>
                {
                    {
                        LogContext, new {ErrorMessage = ex.Message, Exception = ex.GetBaseException()}
                    }
                });

            await RaiseEvent($"AGENT_SET_LOCK_{request.Body.Status}", (int)HttpStatusCode.InternalServerError, "Internal Server Error", request.Body.SalesforceUserId);

            return new ErrorResponseBuilder()
                .WithStatusCode(HttpStatusCode.InternalServerError)
                .Build();
        }
        catch (ServiceTaskCanceledException ex)
        {
            _logger.LogAsError(LogEventNames.ExternalController.PutAgent.ServiceTaskCanceledException,
                new Dictionary<string, object>
                    {{LogContext, new {ErrorMessage = ex.Message, Exception = ex}}});

            await RaiseEvent($"AGENT_SET_LOCK_{request.Body.Status}", MessageConstants.DownstreamTimeoutStatusCode, MessageConstants.DownstreamTimeout, request.Body.SalesforceUserId);

            return new ErrorResponseBuilder()
                .WithStatusCode(MessageConstants.DownstreamTimeoutStatusCode)
                .Build();
        }
        catch (ServiceUnavailableException ex)
        {
            _logger.LogAsError(LogEventNames.ExternalController.PutAgent.ServiceUnavailableException,
                new Dictionary<string, object>
                    {{LogContext, new {ErrorMessage = ex.Message, Exception = ex}}});

            await RaiseEvent($"AGENT_SET_LOCK_{request.Body.Status}", (int)HttpStatusCode.ServiceUnavailable, "Service Unavailable", request.Body.SalesforceUserId);

            return new ErrorResponseBuilder()
                .WithStatusCode(HttpStatusCode.ServiceUnavailable)
                .Build();
        }
        catch (CustomerNotFoundException ex)
        {
            _logger.LogAsError(LogEventNames.ExternalController.PutAgent.CustomerNotFoundException,
                new Dictionary<string, object>
                    {{LogContext, new {ErrorMessage = ex.Message, Exception = ex}}});

            await RaiseEvent($"AGENT_SET_LOCK_{request.Body.Status}", (int)HttpStatusCode.NotFound, "VIP Customer is Not Found", request.Body.SalesforceUserId);

            return new ErrorResponseBuilder()
                .WithStatusCode(HttpStatusCode.NotFound)
                .Build();
        }
        catch (SyncCustomerPinningException)
        {
            _logger.LogAsInformation(LogEventNames.ExternalController.PutAgent.SyncCustomerPinningException);

            await RaiseEvent($"AGENT_SET_LOCK_{request.Body.Status}", (int)HttpStatusCode.Conflict, "Conflict - customer waiting to be pinned or pinning in process", request.Body.SalesforceUserId);

            return new ErrorResponseBuilder()
                .WithStatusCode(HttpStatusCode.Conflict)
                .Build();
        }
        catch (DownstreamAuthenticationException)
        {
            _logger.LogAsError(LogEventNames.ExternalController.PutAgent.DownstreamAuthenticationException);

            await RaiseEvent($"AGENT_SET_LOCK_{request.Body.Status}", DownstreamAuthenticationExceptionStatusCode, MessageConstants.DownstreamAuthenticationFailed, request.Body.SalesforceUserId);

            return new ErrorResponseBuilder()
                .WithStatusCode(DownstreamAuthenticationExceptionStatusCode)
                .Build();
        }
        catch (Exception ex)
        {
            _logger.LogAsError(LogEventNames.ExternalController.PutAgent.UnhandledException,
                new Dictionary<string, object> { { LogContext, new { Exception = ex } } });

            await RaiseEvent($"AGENT_SET_LOCK_{request.Body.Status}", (int)HttpStatusCode.InternalServerError, "Internal Server Error", request.Body.SalesforceUserId);

            return new ErrorResponseBuilder()
                .WithStatusCode(HttpStatusCode.InternalServerError)
                .Build();
        }
    }
}