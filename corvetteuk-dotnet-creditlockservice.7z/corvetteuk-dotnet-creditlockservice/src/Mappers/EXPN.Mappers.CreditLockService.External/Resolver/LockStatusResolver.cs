﻿using System;
using System.Linq;
using AutoMapper;
using EXPN.Models.CreditLockService.External.Get.Customer.Response;
using InternalModel = EXPN.Models.CreditLockService.Internal.Get.Response;

namespace EXPN.Mappers.CreditLockService.External.Resolver
{
    public class LockStatusResolver : IValueResolver<InternalModel.GetCustomerResponse, GetLockStatusResponse, string>
    {
        private const string LockStatusOn = "ON";
        private const string LockStatusOnPinningProblemIndicator = "ON_PINNING_PROBLEM";
        private const string LockStatusOnUpdatingIndicator = "ON_AND_UPDATING";
        private const string LockStatusOff = "OFF";
        private const string LockStatusOffPinningProblemIndicator = "OFF_PINNING_PROBLEM";
        private const string LockStatusOffUpdatingIndicator = "OFF_AND_UPDATING";

        private const string LockStatusIndicatorOn = "Y";
        private const string LockStatusIndicatorOff = "N";

        private static readonly string[] PinningInProgressIndicators = { "0", "1", "2", "N" };
        private static readonly string[] PinningCompletedIndicators = { "3", "4" };
        private static readonly string[] PinningProblemsIndicators = { "D", "P", "E" };

        public string Resolve(InternalModel.GetCustomerResponse source, GetLockStatusResponse destination, string destMember, ResolutionContext context)
        {
            if (source == null)
                throw new ArgumentNullException(nameof(source));

            if (string.IsNullOrWhiteSpace(source.LockStatus))
                throw new InvalidOperationException("Lock Status cannot be null, empty or whitespace");

            if (!(string.Equals(source.LockStatus, LockStatusIndicatorOn) || string.Equals(source.LockStatus, LockStatusIndicatorOff)))
                throw new InvalidOperationException("Lock Status is an unrecognized value");

            var validPinStatuses = PinningInProgressIndicators.Concat(PinningCompletedIndicators)
                .Concat(PinningProblemsIndicators).ToArray();

            if (source.Addresses == null)
                throw new InvalidOperationException("Addresses cannot be null");

            if (!source.Addresses.Any())
                throw new InvalidOperationException("Addresses cannot be empty");

            if (!source.Addresses.All(a => validPinStatuses.Contains(a.PinStatus)))
            {
                throw new InvalidOperationException("Addresses contain one or more Pin Statuses with an unrecognized value");
            }

            if (source.LockStatus.Equals(LockStatusIndicatorOn, StringComparison.OrdinalIgnoreCase))
            {
                if (source.Addresses.All(a => PinningCompletedIndicators.Contains(a.PinStatus)))
                {
                    return LockStatusOn;
                }

                return source.Addresses.Any(a => PinningProblemsIndicators.Contains(a.PinStatus, StringComparer.CurrentCultureIgnoreCase)) ? LockStatusOnPinningProblemIndicator : LockStatusOnUpdatingIndicator;
            }

            if (source.Addresses.All(a => PinningCompletedIndicators.Contains(a.PinStatus)))
            {
                return LockStatusOff;
            }

            return source.Addresses.Any(a => PinningProblemsIndicators.Contains(a.PinStatus, StringComparer.CurrentCultureIgnoreCase)) ? LockStatusOffPinningProblemIndicator : LockStatusOffUpdatingIndicator;
        }
    }
}