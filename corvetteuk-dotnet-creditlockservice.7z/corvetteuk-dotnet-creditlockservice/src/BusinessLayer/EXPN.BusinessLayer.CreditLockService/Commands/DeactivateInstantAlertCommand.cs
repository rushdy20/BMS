﻿using AutoMapper;
using Experian.AWS.Logging.Extensions;
using EXPN.BusinessLayer.CreditLockService.Constants;
using EXPN.DataLayer.CreditLockService.Customers;
using EXPN.DataLayer.CreditLockService.Paas.HttpClient;
using EXPN.Models.CreditLockService.Internal.Get.Response;
using EXPN.Models.CreditLockService.Internal.Post.Request;
using EXPN.Models.CreditLockService.Internal.Post.Response;
using EXPN.Models.CreditLockService.Paas.PutAlertStatus.Request;
using EXPN.Models.CreditLockService.Paas.PutLockStatus.Request;
using Microsoft.Extensions.Logging;
using System;

namespace EXPN.BusinessLayer.CreditLockService.Commands
{
    public class DeactivateInstantAlertCommand<TRequest, TResponse> : ICommand<TRequest, TResponse>
        where TRequest : PostDeactivateInstantAlertRequest
        where TResponse : PostDeactivateInstantAlertResponse
    {
        private readonly ICreditLockPaasClient _creditLockPaasClient;
        private readonly ILogger<DeactivateInstantAlertCommand<TRequest, TResponse>> _logger;
        private readonly IMapper _mapper;

        public DeactivateInstantAlertCommand(
            ICreditLockPaasClient creditLockPaasClient,
            ILogger<DeactivateInstantAlertCommand<TRequest, TResponse>> logger,
            IMapper mapper)
        {
            _creditLockPaasClient = creditLockPaasClient ?? throw new ArgumentNullException(nameof(creditLockPaasClient));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        }

        public string Id => "DEACTIVATE-INSTANT-ALERT";

        public TResponse Execute(TRequest request, GetResponseCustomerProfile customerProfile)
        {
            _logger.LogAsInformation(LogEventNames.DeactivateInstantAlertCommand.Execute.Enter);

            if (request == null)
                throw new ArgumentNullException(nameof(request));

            if (customerProfile == null)
                throw new ArgumentNullException(nameof(customerProfile));

            if (string.IsNullOrWhiteSpace(request.CustomerId))
                throw new ArgumentException($"{nameof(request.CustomerId)} cannot be null or whitespace", nameof(request));

            var paasPutAlertStatusRequest = _mapper.Map<PutAlertStatusRequest>(customerProfile);

            _creditLockPaasClient.PutAlertStatus(paasPutAlertStatusRequest).Wait();

            _logger.LogAsInformation(LogEventNames.DeactivateInstantAlertCommand.Execute.Exit);

            return (TResponse) new PostDeactivateInstantAlertResponse
            {
                LockStatus = paasPutAlertStatusRequest.Status
            };
        }
    }
}