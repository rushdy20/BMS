﻿namespace EXPN.Models.CreditLockService.Internal.Get.Response
{
    public class GetResponsePaasCustomerName
    {
        public string Title { get; set; }
        public string FirstName { get; set; }
        public string OtherName { get; set; }
        public string LastName { get; set; }
        public string Suffix { get; set; }
    }
}