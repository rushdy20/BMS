﻿using System.Diagnostics.CodeAnalysis;

namespace EXPN.Controllers.CreditLockService.DateTime
{
    [ExcludeFromCodeCoverage]
    public class UtcDateTime : IDateTime
    {
        public System.DateTime Now => System.DateTime.UtcNow;
    }
}