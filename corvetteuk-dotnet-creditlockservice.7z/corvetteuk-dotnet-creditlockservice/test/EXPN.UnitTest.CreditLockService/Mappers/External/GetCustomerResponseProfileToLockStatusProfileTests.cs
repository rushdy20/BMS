﻿using System.Collections.Generic;
using AutoMapper;
using EXPN.Mappers.CreditLockService.External;
using EXPN.Models.CreditLockService.Internal.Get.Response;
using FluentAssertions;
using Xunit;
using ExternalModel = EXPN.Models.CreditLockService.External.Get.Customer.Response;

namespace EXPN.UnitTest.CreditLockService.Mappers.External
{
   public class GetCustomerResponseProfileToLockStatusProfileTests
    {
        private readonly MapperConfiguration _mapperConfiguration;

        public GetCustomerResponseProfileToLockStatusProfileTests()
        {
            _mapperConfiguration = new MapperConfiguration(
                cfg => { cfg.AddProfile<GetCustomerResponseProfileToLockStatusProfile>(); });
        }

        [Fact]
        public void ModelProfile_AssertConfiguration_IsValid()
        {
            _mapperConfiguration.AssertConfigurationIsValid();
        }

        public static IEnumerable<object[]> MappingData()
        {
           yield return new object[]
           {
                new GetCustomerResponse
                {
                    LockStatus = "N",
                    Addresses = new List<GetResponsePaasAddressResponse>
                    {
                        new GetResponsePaasAddressResponse
                        {
                            PinStatus = "3"
                        }
                    }
                },
                new ExternalModel.GetLockStatusResponse
                {
                    LockStatus = "OFF"
                }
           };

           yield return new object[]
           {
               new GetCustomerResponse
               {
                   LockStatus = "N",
                   Addresses = new List<GetResponsePaasAddressResponse>
                   {
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "3"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "3"
                       }

                   }
               },
               new ExternalModel.GetLockStatusResponse
               {
                   LockStatus = "OFF"
               }
           };

           yield return new object[]
           {
               new GetCustomerResponse
               {
                   LockStatus = "N",
                   Addresses = new List<GetResponsePaasAddressResponse>
                   {
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "3"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "3"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "3"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "3"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "3"
                       }
                   }
               },
               new ExternalModel.GetLockStatusResponse
               {
                   LockStatus = "OFF"
               }
           };

           yield return new object[]
           {
               new GetCustomerResponse
               {
                   LockStatus = "N",
                   Addresses = new List<GetResponsePaasAddressResponse>
                   {
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "3"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "4"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "3"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "4"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "4"
                       }
                   }
               },
               new ExternalModel.GetLockStatusResponse
               {
                   LockStatus = "OFF"
               }
           };

           yield return new object[]
           {
               new GetCustomerResponse
               {
                   LockStatus = "N",
                   Addresses = new List<GetResponsePaasAddressResponse>
                   {
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "4"
                       }
                   }
               },
               new ExternalModel.GetLockStatusResponse
               {
                   LockStatus = "OFF"
               }
           };

           yield return new object[]
           {
               new GetCustomerResponse
               {
                   LockStatus = "N",
                   Addresses = new List<GetResponsePaasAddressResponse>
                   {
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "4"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "4"
                       }
                   }
               },
               new ExternalModel.GetLockStatusResponse
               {
                   LockStatus = "OFF"
               }
           };

           yield return new object[]
           {
               new GetCustomerResponse
               {
                   LockStatus = "N",
                   Addresses = new List<GetResponsePaasAddressResponse>
                   {
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "4"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "3"
                       }
                   }
               },
               new ExternalModel.GetLockStatusResponse
               {
                   LockStatus = "OFF"
               }
           };

           yield return new object[]
           {
               new GetCustomerResponse
               {
                   LockStatus = "N",
                   Addresses = new List<GetResponsePaasAddressResponse>
                   {
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "1"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "3"
                       }
                   }
               },
               new ExternalModel.GetLockStatusResponse
               {
                   LockStatus = "OFF_AND_UPDATING"
               }
           };

           yield return new object[]
           {
               new GetCustomerResponse
               {
                   LockStatus = "N",
                   Addresses = new List<GetResponsePaasAddressResponse>
                   {
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "4"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "3"
                       }
                   }
               },
               new ExternalModel.GetLockStatusResponse
               {
                   LockStatus = "OFF"
               }
           };

           yield return new object[]
           {
               new GetCustomerResponse
               {
                   LockStatus = "N",
                   Addresses = new List<GetResponsePaasAddressResponse>
                   {
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "4"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "1"
                       }
                   }
               },
               new ExternalModel.GetLockStatusResponse
               {
                   LockStatus = "OFF_AND_UPDATING"
               }
           };

           yield return new object[]
           {
               new GetCustomerResponse
               {
                   LockStatus = "N",
                   Addresses = new List<GetResponsePaasAddressResponse>
                   {
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "1"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "3"
                       }
                   }
               },
               new ExternalModel.GetLockStatusResponse
               {
                   LockStatus = "OFF_AND_UPDATING"
               }
           };

           yield return new object[]
           {
               new GetCustomerResponse
               {
                   LockStatus = "N",
                   Addresses = new List<GetResponsePaasAddressResponse>
                   {
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "D"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "D"
                       }
                   }
               },
               new ExternalModel.GetLockStatusResponse
               {
                   LockStatus = "OFF_PINNING_PROBLEM"
               }
           };

           yield return new object[]
           {
               new GetCustomerResponse
               {
                   LockStatus = "N",
                   Addresses = new List<GetResponsePaasAddressResponse>
                   {
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "P"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "E"
                       }
                   }
               },
               new ExternalModel.GetLockStatusResponse
               {
                   LockStatus = "OFF_PINNING_PROBLEM"
               }
           };

           yield return new object[]
           {
               new GetCustomerResponse
               {
                   LockStatus = "N",
                   Addresses = new List<GetResponsePaasAddressResponse>
                   {
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "4"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "D"
                       }
                   }
               },
               new ExternalModel.GetLockStatusResponse
               {
                   LockStatus = "OFF_PINNING_PROBLEM"
               }
           };

           yield return new object[]
           {
               new GetCustomerResponse
               {
                   LockStatus = "N",
                   Addresses = new List<GetResponsePaasAddressResponse>
                   {
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "4"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "E"
                       }
                   }
               },
               new ExternalModel.GetLockStatusResponse
               {
                   LockStatus = "OFF_PINNING_PROBLEM"
               }
           };

           yield return new object[]
           {
               new GetCustomerResponse
               {
                   LockStatus = "N",
                   Addresses = new List<GetResponsePaasAddressResponse>
                   {
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "3"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "4"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "4"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "4"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "D"
                       }
                   }
               },
               new ExternalModel.GetLockStatusResponse
               {
                   LockStatus = "OFF_PINNING_PROBLEM"
               }
           };

           yield return new object[]
           {
               new GetCustomerResponse
               {
                   LockStatus = "N",
                   Addresses = new List<GetResponsePaasAddressResponse>
                   {
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "N"
                       }
                   }
               },
               new ExternalModel.GetLockStatusResponse
               {
                   LockStatus = "OFF_AND_UPDATING"
               }
           };

           yield return new object[]
           {
               new GetCustomerResponse
               {
                   LockStatus = "N",
                   Addresses = new List<GetResponsePaasAddressResponse>
                   {
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "0"
                       }
                   }
               },
               new ExternalModel.GetLockStatusResponse
               {
                   LockStatus = "OFF_AND_UPDATING"
               }
           };

           yield return new object[]
           {
               new GetCustomerResponse
               {
                   LockStatus = "N",
                   Addresses = new List<GetResponsePaasAddressResponse>
                   {
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "2"
                       }
                   }
               },
               new ExternalModel.GetLockStatusResponse
               {
                   LockStatus = "OFF_AND_UPDATING"
               }
           };

           yield return new object[]
           {
               new GetCustomerResponse
               {
                   LockStatus = "N",
                   Addresses = new List<GetResponsePaasAddressResponse>
                   {
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "0"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "4"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "4"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "4"
                       }
                   }
               },
               new ExternalModel.GetLockStatusResponse
               {
                   LockStatus = "OFF_AND_UPDATING"
               }
           };

           yield return new object[]
           {
               new GetCustomerResponse
               {
                   LockStatus = "Y",
                   Addresses = new List<GetResponsePaasAddressResponse>
                   {
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "0"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "3"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "4"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "3"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "N"
                       }
                   }
               },
               new ExternalModel.GetLockStatusResponse
               {
                   LockStatus = "ON_AND_UPDATING"
               }
           };

           yield return new object[]
           {
               new GetCustomerResponse
               {
                   LockStatus = "Y",
                   Addresses = new List<GetResponsePaasAddressResponse>
                   {
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "0"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "4"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "4"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "4"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "2"
                       }
                   }
               },
               new ExternalModel.GetLockStatusResponse
               {
                   LockStatus = "ON_AND_UPDATING"
               }
           };

            yield return new object[]
            {
                new GetCustomerResponse
                {
                    LockStatus = "Y",
                    Addresses = new List<GetResponsePaasAddressResponse>
                    {
                        new GetResponsePaasAddressResponse
                        {
                            PinStatus = "3"
                        }
                    }
                },
                new ExternalModel.GetLockStatusResponse
                {
                    LockStatus = "ON"
                }
            };

            yield return new object[]
            {
               new GetCustomerResponse
               {
                   LockStatus = "Y",
                   Addresses = new List<GetResponsePaasAddressResponse>
                   {
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "3"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "3"
                       }
                   }
               },
               new ExternalModel.GetLockStatusResponse
               {
                   LockStatus = "ON"
               }
            };

            yield return new object[]
            {
               new GetCustomerResponse
               {
                   LockStatus = "Y",
                   Addresses = new List<GetResponsePaasAddressResponse>
                   {
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "3"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "3"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "3"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "3"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "3"
                       }
                   }
               },
               new ExternalModel.GetLockStatusResponse
               {
                   LockStatus = "ON"
               }
            };

            yield return new object[]
            {
               new GetCustomerResponse
               {
                   LockStatus = "Y",
                   Addresses = new List<GetResponsePaasAddressResponse>
                   {
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "3"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "4"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "3"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "4"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "4"
                       }
                   }
               },
               new ExternalModel.GetLockStatusResponse
               {
                   LockStatus = "ON"
               }
            };

            yield return new object[]
            {
               new GetCustomerResponse
               {
                   LockStatus = "Y",
                   Addresses = new List<GetResponsePaasAddressResponse>
                   {
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "4"
                       }
                   }
               },
               new ExternalModel.GetLockStatusResponse
               {
                   LockStatus = "ON"
               }
            };

            yield return new object[]
            {
                new GetCustomerResponse
                {
                    LockStatus = "Y",
                    Addresses = new List<GetResponsePaasAddressResponse>
                    {
                        new GetResponsePaasAddressResponse
                        {
                            PinStatus = "3"
                        }
                    }
                },
                new ExternalModel.GetLockStatusResponse
                {
                    LockStatus = "ON"
                }
            };

            yield return new object[]
            {
               new GetCustomerResponse
               {
                   LockStatus = "Y",
                   Addresses = new List<GetResponsePaasAddressResponse>
                   {
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "3"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "3"
                       }

                   }
               },
               new ExternalModel.GetLockStatusResponse
               {
                   LockStatus = "ON"
               }
            };

            yield return new object[]
            {
               new GetCustomerResponse
               {
                   LockStatus = "Y",
                   Addresses = new List<GetResponsePaasAddressResponse>
                   {
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "3"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "3"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "3"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "3"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "3"
                       }
                   }
               },
               new ExternalModel.GetLockStatusResponse
               {
                   LockStatus = "ON"
               }
            };

            yield return new object[]
            {
               new GetCustomerResponse
               {
                   LockStatus = "Y",
                   Addresses = new List<GetResponsePaasAddressResponse>
                   {
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "3"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "4"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "3"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "4"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "4"
                       }
                   }
               },
               new ExternalModel.GetLockStatusResponse
               {
                   LockStatus = "ON"
               }
            };

            yield return new object[]
            {
               new GetCustomerResponse
               {
                   LockStatus = "Y",
                   Addresses = new List<GetResponsePaasAddressResponse>
                   {
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "4"
                       }
                   }
               },
               new ExternalModel.GetLockStatusResponse
               {
                   LockStatus = "ON"
               }
            };

            yield return new object[]
            {
               new GetCustomerResponse
               {
                   LockStatus = "Y",
                   Addresses = new List<GetResponsePaasAddressResponse>
                   {
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "4"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "4"
                       }
                   }
               },
               new ExternalModel.GetLockStatusResponse
               {
                   LockStatus = "ON"
               }
            };

            yield return new object[]
            {
               new GetCustomerResponse
               {
                   LockStatus = "Y",
                   Addresses = new List<GetResponsePaasAddressResponse>
                   {
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "4"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "3"
                       }
                   }
               },
               new ExternalModel.GetLockStatusResponse
               {
                   LockStatus = "ON"
               }
            };

            yield return new object[]
            {
               new GetCustomerResponse
               {
                   LockStatus = "Y",
                   Addresses = new List<GetResponsePaasAddressResponse>
                   {
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "1"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "3"
                       }
                   }
               },
               new ExternalModel.GetLockStatusResponse
               {
                   LockStatus = "ON_AND_UPDATING"
               }
            };

            yield return new object[]
            {
               new GetCustomerResponse
               {
                   LockStatus = "Y",
                   Addresses = new List<GetResponsePaasAddressResponse>
                   {
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "4"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "4"
                       }
                   }
               },
               new ExternalModel.GetLockStatusResponse
               {
                   LockStatus = "ON"
               }
            };

            yield return new object[]
            {
               new GetCustomerResponse
               {
                   LockStatus = "Y",
                   Addresses = new List<GetResponsePaasAddressResponse>
                   {
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "4"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "3"
                       }
                   }
               },
               new ExternalModel.GetLockStatusResponse
               {
                   LockStatus = "ON"
               }
            };

            yield return new object[]
            {
               new GetCustomerResponse
               {
                   LockStatus = "Y",
                   Addresses = new List<GetResponsePaasAddressResponse>
                   {
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "1"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "3"
                       }
                   }
               },
               new ExternalModel.GetLockStatusResponse
               {
                   LockStatus = "ON_AND_UPDATING"
               }
            };

            yield return new object[]
            {
               new GetCustomerResponse
               {
                   LockStatus = "Y",
                   Addresses = new List<GetResponsePaasAddressResponse>
                   {
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "4"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "3"
                       }
                   }
               },
               new ExternalModel.GetLockStatusResponse
               {
                   LockStatus = "ON"
               }
            };

            yield return new object[] 
            {
               new GetCustomerResponse
               {
                   LockStatus = "Y",
                   Addresses = new List<GetResponsePaasAddressResponse>
                   {
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "D"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "D"
                       }
                   }
               },
               new ExternalModel.GetLockStatusResponse
               {
                   LockStatus = "ON_PINNING_PROBLEM"
               }
            };

            yield return new object[]
            {
               new GetCustomerResponse
               {
                   LockStatus = "Y",
                   Addresses = new List<GetResponsePaasAddressResponse>
                   {
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "P"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "E"
                       }
                   }
               },
               new ExternalModel.GetLockStatusResponse
               {
                   LockStatus = "ON_PINNING_PROBLEM"
               }
            };

            yield return new object[]
            {
               new GetCustomerResponse
               {
                   LockStatus = "Y",
                   Addresses = new List<GetResponsePaasAddressResponse>
                   {
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "4"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "D"
                       }
                   }
               },
               new ExternalModel.GetLockStatusResponse
               {
                   LockStatus = "ON_PINNING_PROBLEM"
               }
            };

            yield return new object[]
            {
               new GetCustomerResponse
               {
                   LockStatus = "Y",
                   Addresses = new List<GetResponsePaasAddressResponse>
                   {
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "4"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "E"
                       }
                   }
               },
               new ExternalModel.GetLockStatusResponse
               {
                   LockStatus = "ON_PINNING_PROBLEM"
               }
            };

            yield return new object[]
            {
               new GetCustomerResponse
               {
                   LockStatus = "Y",
                   Addresses = new List<GetResponsePaasAddressResponse>
                   {
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "3"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "4"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "4"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "4"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "D"
                       }
                   }
               },
               new ExternalModel.GetLockStatusResponse
               {
                   LockStatus = "ON_PINNING_PROBLEM"
               }
            };

            yield return new object[]
            {
               new GetCustomerResponse
               {
                   LockStatus = "Y",
                   Addresses = new List<GetResponsePaasAddressResponse>
                   {
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "N"
                       }
                   }
               },
               new ExternalModel.GetLockStatusResponse
               {
                   LockStatus = "ON_AND_UPDATING"
               }
            };

            yield return new object[]
            {
               new GetCustomerResponse
               {
                   LockStatus = "Y",
                   Addresses = new List<GetResponsePaasAddressResponse>
                   {
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "0"
                       }
                   }
               },
               new ExternalModel.GetLockStatusResponse
               {
                   LockStatus = "ON_AND_UPDATING"
               }
            };

            yield return new object[]
            {
               new GetCustomerResponse
               {
                   LockStatus = "Y",
                   Addresses = new List<GetResponsePaasAddressResponse>
                   {
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "2"
                       }
                   }
               },
               new ExternalModel.GetLockStatusResponse
               {
                   LockStatus = "ON_AND_UPDATING"
               }
            };

            yield return new object[]
            {
               new GetCustomerResponse
               {
                   LockStatus = "Y",
                   Addresses = new List<GetResponsePaasAddressResponse>
                   {
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "0"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "4"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "4"
                       },
                       new GetResponsePaasAddressResponse
                       {
                           PinStatus = "4"
                       }
                   }
               },
               new ExternalModel.GetLockStatusResponse
               {
                   LockStatus = "ON_AND_UPDATING"
               }
            };
        }

        [Theory]
        [MemberData(nameof(MappingData))]
        public void ExternalModelProfile_ExampleInput_MapsCorrectly(GetCustomerResponse input, ExternalModel.GetLockStatusResponse expected)
        {
            var mapper = _mapperConfiguration.CreateMapper();
            var result = mapper.Map<ExternalModel.GetLockStatusResponse>(input);

            result.Should().BeEquivalentTo(expected);
        }
    }
}