﻿using System.Diagnostics.CodeAnalysis;
using EXPN.Models.CreditLockService.Internal.Get.Response;
using EXPN.Models.CreditLockService.Paas.Post.Request;

namespace EXPN.Models.CreditLockService.Internal.Post.Response
{
    [ExcludeFromCodeCoverage]
    public class PostCustomerResponse
    {
        public GetResponseCustomerProfile CustomerProfile { get; set; }
        public PostCustomerRequest PaaSRequest { get; set; }
    }
}