﻿using AutoMapper;
using EXPN.BusinessLayer.CreditLockService.Commands;
using EXPN.BusinessLayer.CreditLockService.Constants;
using EXPN.DataLayer.CreditLockService.Paas.HttpClient;
using EXPN.Models.CreditLockService.Internal.Get.Response;
using EXPN.Models.CreditLockService.Internal.Post.Request;
using EXPN.Models.CreditLockService.Internal.Post.Response;
using EXPN.Models.CreditLockService.Paas.PutAlertStatus.Request;
using FluentAssertions;
using Microsoft.Extensions.Logging;
using NSubstitute;
using NSubstitute.ExceptionExtensions;
using System;
using System.Collections.Generic;
using Xunit;

namespace EXPN.UnitTest.CreditLockService.BusinessLayer.Commands
{
    public class DeactivateInstantAlertCommandTests
    {
        private readonly ICreditLockPaasClient _creditLockPaaSClient;
        private readonly ILogger<DeactivateInstantAlertCommand<PostDeactivateInstantAlertRequest, PostDeactivateInstantAlertResponse>> _logger;
        private readonly IMapper _mapper;

        private readonly ICommand<PostDeactivateInstantAlertRequest, PostDeactivateInstantAlertResponse> _deactivateInstantAlertCommand;
        public DeactivateInstantAlertCommandTests()
        {
            _creditLockPaaSClient = Substitute.For<ICreditLockPaasClient>();
            _logger = Substitute.For<ILogger<DeactivateInstantAlertCommand<PostDeactivateInstantAlertRequest, PostDeactivateInstantAlertResponse>>>();
            _mapper = Substitute.For<IMapper>();

            _deactivateInstantAlertCommand = new DeactivateInstantAlertCommand<PostDeactivateInstantAlertRequest, PostDeactivateInstantAlertResponse>(_creditLockPaaSClient,_logger,_mapper);
        }

        public class Constructor
        {
            public static IEnumerable<object[]> NullParameters()
            {
                yield return new object[]
                {
                    null,
                    Substitute.For<ILogger<DeactivateInstantAlertCommand<PostDeactivateInstantAlertRequest, PostDeactivateInstantAlertResponse>>>(),
                    Substitute.For<IMapper>(),
                    "creditLockPaasClient"
                };

                yield return new object[]
                {
                    Substitute.For<ICreditLockPaasClient>(),
                    null,
                    Substitute.For<IMapper>(),
                    "logger"
                };

                yield return new object[]
                {
                    Substitute.For<ICreditLockPaasClient>(),
                    Substitute.For<ILogger<DeactivateInstantAlertCommand<PostDeactivateInstantAlertRequest, PostDeactivateInstantAlertResponse>>>(),
                    null,
                    "mapper"
                };
            }

            [Theory]
            [MemberData(nameof(NullParameters))]
            public void NullRequiredConstructorParameter_ThrowsArgumentNullException(
                ICreditLockPaasClient paasHttpClient,
                ILogger<DeactivateInstantAlertCommand<PostDeactivateInstantAlertRequest, PostDeactivateInstantAlertResponse>> logger,
                IMapper mapper,
                string expectedErrorParameter)
            {
                Action action = () => {
                    new DeactivateInstantAlertCommand<PostDeactivateInstantAlertRequest, PostDeactivateInstantAlertResponse>(paasHttpClient, logger, mapper);
                };

                action.Should().Throw<ArgumentNullException>()
                    .Where(x => x.ParamName == expectedErrorParameter);
            }

            [Fact]
            public void Id_IsCorrect()
            {
                new DeactivateInstantAlertCommand<PostDeactivateInstantAlertRequest, PostDeactivateInstantAlertResponse>(
                    Substitute.For<ICreditLockPaasClient>(),
                    Substitute.For<ILogger<DeactivateInstantAlertCommand<PostDeactivateInstantAlertRequest, PostDeactivateInstantAlertResponse>>>(),
                    Substitute.For<IMapper>()).Id.Should().Be("DEACTIVATE-INSTANT-ALERT");
            }
        }

        public class Execute : DeactivateInstantAlertCommandTests
        {
            public static IEnumerable<object[]> LogInformationMessages()
            {
                yield return new object[]
                {
                    LogEventNames.DeactivateInstantAlertCommand.Execute.Enter
                };

                yield return new object[]
                {
                    LogEventNames.DeactivateInstantAlertCommand.Execute.Exit
                };
            }

            [Theory]
            [MemberData(nameof(LogInformationMessages))]
            public void HappyPathInformationLogged(string loggerMessage)
            {
                const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

                var getResponseCustomerProfile = new GetResponseCustomerProfile
                {
                    CustomerId = customerId,
                    IconRef = "ABC"
                };

                var paasPutLockStatusRequest = new Models.CreditLockService.Paas.PutLockStatus.Request.PutLockStatusRequest
                {
                    CustomerRef = "ABC",
                    Status = "Y"
                };

                var postDeactivateInstantAlertRequest = new PostDeactivateInstantAlertRequest
                {
                    CustomerId = customerId
                };

                var putAlertStatusRequest = new PutAlertStatusRequest
                {
                    CustomerRef = "ABC"
                };

                _mapper.Map<Models.CreditLockService.Paas.PutLockStatus.Request.PutLockStatusRequest>(getResponseCustomerProfile)
                    .Returns(paasPutLockStatusRequest);

                _mapper.Map<PutAlertStatusRequest>(getResponseCustomerProfile)
                    .Returns(putAlertStatusRequest);

                _deactivateInstantAlertCommand.Execute(postDeactivateInstantAlertRequest, getResponseCustomerProfile);

                _mapper.Received().Map<PutAlertStatusRequest>(getResponseCustomerProfile);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(loggerMessage)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public void ExecutePutLockStatusRequestNull_ThrowsArgumentNullException()
            {
                Action action = () => { _deactivateInstantAlertCommand.Execute(null, null); };

                action.Should().Throw<ArgumentNullException>()
                    .Where(x => x.ParamName == "request");
            }

            [Fact]
            public void ExecutePutLockStatusCustomerProfileNull_ThrowsArgumentNullException()
            {
                Action action = () => { _deactivateInstantAlertCommand.Execute(new PostDeactivateInstantAlertRequest(), null); };

                action.Should().Throw<ArgumentNullException>()
                    .Where(x => x.ParamName == "customerProfile");
            }

            [Theory]
            [InlineData(null)]
            [InlineData("")]
            [InlineData("     ")]
            public void ExecutePutLockRequestInvalidCustomerId_ThrowsArgumentException(string customerId)
            {
                var postDeactivateInstantAlertRequest = new PostDeactivateInstantAlertRequest
                {
                    CustomerId = customerId
                };

                var getResponseCustomerProfile = new GetResponseCustomerProfile
                {
                    CustomerId = customerId,
                    IconRef = "ABC"
                };

                Action action = () =>
                {
                    _deactivateInstantAlertCommand.Execute(postDeactivateInstantAlertRequest, getResponseCustomerProfile);
                };

                action.Should().Throw<ArgumentException>()
                    .Where(x => x.Message == "CustomerId cannot be null or whitespace (Parameter 'request')");
            }

            [Fact]
            public void ValidRequest_Execute_HappyPath_Success()
            {
                const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

                var getResponseCustomerProfile = new GetResponseCustomerProfile
                {
                    CustomerId = customerId,
                    IconRef = "ABC",
                };

                var paasPutLockStatusRequest = new Models.CreditLockService.Paas.PutLockStatus.Request.PutLockStatusRequest
                {
                    CustomerRef = "ABC",
                    Status = "Y"
                };

                var postDeactivateInstantAlertRequest = new PostDeactivateInstantAlertRequest
                {
                    CustomerId = customerId
                };

                var putAlertStatusRequest = new PutAlertStatusRequest
                {
                    CustomerRef = "ABC",
                    Status = "Y"
                };

                _mapper.Map<Models.CreditLockService.Paas.PutLockStatus.Request.PutLockStatusRequest>(getResponseCustomerProfile)
                    .Returns(paasPutLockStatusRequest);

                _mapper.Map<PutAlertStatusRequest>(getResponseCustomerProfile)
                    .Returns(putAlertStatusRequest);

                var response = _deactivateInstantAlertCommand.Execute(postDeactivateInstantAlertRequest, getResponseCustomerProfile);

                response.LockStatus.Should().Be(paasPutLockStatusRequest.Status);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.DeactivateInstantAlertCommand.Execute.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.DeactivateInstantAlertCommand.Execute.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public void ValidRequest_Execute_ClientThrowsOutofMemoryException_Fails()
            {
                const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

                var expectedEx = new OutOfMemoryException("Test Exception Message");

                var getResponseCustomerProfile = new GetResponseCustomerProfile
                {
                    CustomerId = customerId,
                    IconRef = "ABC"
                };

                var putAlertStatus = new PutAlertStatusRequest
                {
                    CustomerRef = "ABC",
                    Status = "N"
                };

                var postDeactivateInstantAlertRequest = new PostDeactivateInstantAlertRequest
                {
                    CustomerId = customerId
                };

                _mapper.Map<PutAlertStatusRequest>(getResponseCustomerProfile)
                    .Returns(putAlertStatus);

                _creditLockPaaSClient.PutAlertStatus(putAlertStatus)
                    .Throws(expectedEx);

                Action action = () =>
                {
                    _deactivateInstantAlertCommand.Execute(postDeactivateInstantAlertRequest, getResponseCustomerProfile);
                };

                action.Should().Throw<OutOfMemoryException>()
                    .Where(x => x.Message == expectedEx.Message);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.DeactivateInstantAlertCommand.Execute.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.DeactivateInstantAlertCommand.Execute.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }
        }
    }
}