﻿namespace EXPN.DataLayer.CreditLockService.Subscriptions.Constants;

public struct LogEventNames
{
    public struct SubscriptionClientProxy
    {
        public struct GetSubscriptionsAsync
        {
            public const string Start = "GetSubscriptionAsync_Start";
        }
    }
}