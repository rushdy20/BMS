﻿using Experian.HttpClient.Services.Subscriptions.Internal.GET;
using Experian.HttpClient.Services.Subscriptions.Models.Internal;
using EXPN.DataLayer.CreditLockService.Common.Exceptions;
using EXPN.DataLayer.CreditLockService.Subscriptions;
using EXPN.DataLayer.CreditLockService.Subscriptions.Constants;
using FluentAssertions;
using Microsoft.Extensions.Logging;
using NSubstitute;
using NSubstitute.ExceptionExtensions;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;

namespace EXPN.UnitTest.CreditLockService.DataLayer.Subscriptions;

public class SubscriptionsClientProxyTests
{
    private readonly ILogger<SubscriptionsClientProxy> _logger;
    private readonly IGetSubscription _subscriptionsClient;
    private readonly SubscriptionsClientProxy _subscriptionsServiceHttpProxy;

    public SubscriptionsClientProxyTests()
    {
        _logger = Substitute.For<ILogger<SubscriptionsClientProxy>>();
        _subscriptionsClient = Substitute.For<IGetSubscription>();
        _subscriptionsServiceHttpProxy = new SubscriptionsClientProxy(_logger, _subscriptionsClient);
    }

    public class Constructor
    {
        public static IEnumerable<object[]> NullParameters()
        {
            yield return new object[]
            {
                null,
                Substitute.For<IGetSubscription>(),
                "logger"
            };

            yield return new object[]
            {
                Substitute.For<ILogger<SubscriptionsClientProxy>>(),
                null,
                "getSubscription"
            };
        }

        [Theory]
        [MemberData(nameof(NullParameters))]
        public void NullRequiredConstructorParameter_ThrowsArgumentNullException(
            ILogger<SubscriptionsClientProxy> logger,
            IGetSubscription subscriptionsClient,
            string expectedErrorParameter)
        {
            var action = () =>
            {
                var unused = new SubscriptionsClientProxy(logger, subscriptionsClient);
            };

            action.Should().Throw<ArgumentNullException>()
                .Where(x => x.ParamName == expectedErrorParameter);
        }
    }

    public class GetSubscriptionsAsync : SubscriptionsClientProxyTests
    {
        [Fact]
        public void GetSubscriptionsAsync_NullResponse_BenefitsInvalidOperationException()
        {
            _subscriptionsClient.GetAsync().Returns((Subscription)null);

            var action = async () => { await _subscriptionsServiceHttpProxy.GetSubscriptionsAsync(); };

            action.Should().Throw<BenefitsInvalidOperationException>()
                .Which.Message.Should().Be("Upstream service subscriptions returned no data.");
        }

        [Fact]
        public async Task GetSubscriptionsAsync_HappyPath_Success()
        {
            var expectedSubscription = new Subscription
            {
                Benefits = new[]
                {
                    new Benefit
                    {
                        Id = "B001"
                    }
                }
            };

            _subscriptionsClient.GetAsync().Returns(expectedSubscription);

            var result = await _subscriptionsServiceHttpProxy.GetSubscriptionsAsync();

            result.Should().BeEquivalentTo(expectedSubscription);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(x => x.ContainsValue(LogEventNames.SubscriptionClientProxy.GetSubscriptionsAsync.Start)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public Task GetSubscriptionsAsync_ThrowsOutofMemoryException_Success()
        {
            _subscriptionsClient.GetAsync()
                .Throws(new OutOfMemoryException("Test Message"));

            var task = async () =>
            {
                await _subscriptionsServiceHttpProxy.GetSubscriptionsAsync();
            };

            task.Should()
                .Throw<OutOfMemoryException>()
                .WithMessage("Test Message");

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(x => x.ContainsValue(LogEventNames.SubscriptionClientProxy.GetSubscriptionsAsync.Start)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            return Task.CompletedTask;
        }
    }
}