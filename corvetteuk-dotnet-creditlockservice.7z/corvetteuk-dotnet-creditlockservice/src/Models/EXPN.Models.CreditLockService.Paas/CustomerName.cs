﻿namespace EXPN.Models.CreditLockService.Paas
{
    public class CustomerName
    {
        public string Title { get; set; }
        public string FirstName { get; set; }
        public string OtherName { get; set; }
        public string LastName { get; set; }
        public string Suffix { get; set; }
    }
}