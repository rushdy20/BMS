﻿using System;
using System.Runtime.Serialization;

namespace EXPN.BusinessLayer.CreditLockService.Exceptions;

[Serializable]
public class NoBenefitException : Exception
{
    public string BenefitsRequested
    {
        get => Data[nameof(BenefitsRequested)] as string;
        set => Data[nameof(BenefitsRequested)] = value;
    }

    public NoBenefitException(string message, string benefitsRequested) : base(message)
    {
        BenefitsRequested = benefitsRequested;
    }

    protected NoBenefitException(SerializationInfo info, StreamingContext context) : base(info, context)
    {
    }
}