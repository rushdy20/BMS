﻿using System.Diagnostics.CodeAnalysis;
using AutoMapper;
using EXPN.Models.CreditLockService.Internal.Post.Request;
using EXPN.Models.CreditLockService.Paas.PutAlertStatus.Request;

namespace EXPN.Mappers.CreditLockService.Paas
{
    [ExcludeFromCodeCoverage]
    public class PostActivateInstantAlertRequestToPutAlertStatusRequestProfiler :Profile
    {
        public PostActivateInstantAlertRequestToPutAlertStatusRequestProfiler()
        {
            CreateMap<PostActivateInstantAlertRequest, PutAlertStatusRequest>(MemberList.None)
                .ForMember(d => d.CustomerRef, m => m.MapFrom(s => s.CustomerRef))
                .ForMember(d => d.Status, m => m.MapFrom(s => "Y"));
        }
    }
}