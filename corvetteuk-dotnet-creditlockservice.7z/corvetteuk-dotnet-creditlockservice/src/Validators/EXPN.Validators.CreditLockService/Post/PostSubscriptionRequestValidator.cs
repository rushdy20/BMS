﻿using System;
using EXPN.Models.CreditLockService.External.Post.Request;
using FluentValidation;

namespace EXPN.Validators.CreditLockService.Post
{
    public class PostSubscriptionRequestValidator : AbstractValidator<PostRequest>
    {
        public PostSubscriptionRequestValidator()
        {
            RuleFor(x => x)
                .NotNull()
                .WithName(nameof(PostRequest))
                .DependentRules(() =>
                {
                    RuleFor(instance => instance.CustomerId)
                        .Cascade(CascadeMode.StopOnFirstFailure)
                        .NotEmpty()
                        .Must(x => Guid.TryParse(x, out _))
                        .WithMessage("'CustomerId' is not in valid format");
                });
        }
    }
}