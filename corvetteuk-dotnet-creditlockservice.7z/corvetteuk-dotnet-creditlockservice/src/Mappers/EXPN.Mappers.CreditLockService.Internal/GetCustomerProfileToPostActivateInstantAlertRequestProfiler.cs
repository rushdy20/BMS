﻿using System.Diagnostics.CodeAnalysis;
using AutoMapper;
using EXPN.Models.CreditLockService.Internal.Get.Response;
using EXPN.Models.CreditLockService.Internal.Post.Request;

namespace EXPN.Mappers.CreditLockService.Internal
{
    [ExcludeFromCodeCoverage]
    public class GetCustomerProfileToPostActivateInstantAlertRequestProfiler : Profile
    {
        public GetCustomerProfileToPostActivateInstantAlertRequestProfiler()
        {
            CreateMap<GetResponseCustomerProfile, PostActivateInstantAlertRequest>()
                .ForMember(d => d.CustomerRef, m => m.MapFrom(s => s.CustomerRef));
        }
    }
}
