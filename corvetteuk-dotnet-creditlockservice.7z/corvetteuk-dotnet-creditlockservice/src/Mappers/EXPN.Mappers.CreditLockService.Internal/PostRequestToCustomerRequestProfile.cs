﻿using AutoMapper;
using EXPN.Models.CreditLockService.Internal;
using System.Diagnostics.CodeAnalysis;
using EXPN.Models.CreditLockService.External.Post.Request;

namespace EXPN.Mappers.CreditLockService.Internal
{
    [ExcludeFromCodeCoverage]
    public class PostRequestToCustomerRequestProfile : Profile
    {
        public PostRequestToCustomerRequestProfile()
        {
            CreateMap<PostRequest, CustomerRequest>();
        }
    }
}