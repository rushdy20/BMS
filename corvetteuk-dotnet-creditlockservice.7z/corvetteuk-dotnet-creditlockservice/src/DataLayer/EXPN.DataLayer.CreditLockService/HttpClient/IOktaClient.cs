﻿using System.Threading.Tasks;

namespace EXPN.DataLayer.CreditLockService.Paas.HttpClient
{
    public interface IOktaClient
    {
        Task<string> GetAuthTokenAsync(bool refreshToken = false);
    }
}