﻿using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace EXPN.UnitTest.CreditLockService.DataLayer.Paas.Helper
{
    public class FakeHttpMessagesHandler : DelegatingHandler
    {
        private readonly HttpResponseMessage[] _fakeResponses;
        private int _currentIndex;

        public FakeHttpMessagesHandler(HttpResponseMessage[] responseMessages)
        {
            _fakeResponses = responseMessages;
        }

        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            var response = await Task.FromResult(_fakeResponses[_currentIndex]);
            _currentIndex++;
            return response;
        }
    }
}