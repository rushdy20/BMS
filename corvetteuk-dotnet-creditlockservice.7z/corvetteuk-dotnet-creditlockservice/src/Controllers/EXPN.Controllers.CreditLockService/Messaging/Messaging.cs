﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Amazon.SimpleNotificationService;
using Experian.AWS.Logging.Extensions;
using Experian.Events.MessageBuilder;
using EXPN.Controllers.CreditLockService.Constants;
using Microsoft.Extensions.Logging;

namespace EXPN.Controllers.CreditLockService.Messaging
{
    public class Messaging : IMessaging
    {
        private readonly IAmazonSimpleNotificationService _sns;
        private readonly IMessageBuilder _messageBuilder;
        private readonly ITopicRetriever _topicRetriever;
        private readonly ILogger<Messaging> _logger;

        public Messaging(IAmazonSimpleNotificationService sns, IMessageBuilder messageBuilder, ITopicRetriever topicRetriever, ILogger<Messaging> logger)
        {
            _sns = sns ?? throw new ArgumentNullException(nameof(sns));
            _messageBuilder = messageBuilder ?? throw new ArgumentNullException(nameof(messageBuilder));
            _topicRetriever = topicRetriever ?? throw new ArgumentNullException(nameof(topicRetriever));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public async Task PublishEventAsync(string eventName, CreditLockEventContent creditLockEventContent)
        {
            if (string.IsNullOrWhiteSpace(eventName))
                throw new ArgumentException($"{nameof(eventName)} cannot be null or whitespace", nameof(eventName));

            if (creditLockEventContent == null)
                throw new ArgumentNullException(nameof(creditLockEventContent));

            await PublishEvent(eventName, creditLockEventContent);
        }

        private async Task PublishEvent(string eventName, CreditLockEventContent creditLockEventContent)
        {
            _logger.LogAsInformation(LogEventNames.Messaging.PublishEventAsync.Enter);

            var eventMessage = await _messageBuilder.Build(creditLockEventContent);

            if (string.IsNullOrWhiteSpace(eventMessage))
                throw new InvalidOperationException($"{nameof(eventMessage)} cannot be null or whitespace");

            var response = await _sns.PublishAsync(_topicRetriever.GetTopicPhysicalId(eventName), eventMessage);

            _logger.LogAsInformation(LogEventNames.Messaging.PublishEventAsync.Exit,
                new Dictionary<string, object>
                {
                    { "Context", new { eventName, response?.HttpStatusCode, response?.MessageId } }
                });
        }
    }
}