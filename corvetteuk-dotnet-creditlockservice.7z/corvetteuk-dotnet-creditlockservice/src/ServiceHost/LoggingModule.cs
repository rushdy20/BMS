using System;
using System.Diagnostics.CodeAnalysis;
using Experian.AWS.Logging;
using Experian.AWS.Logging.ChannelLoggerToKinesis;
using Experian.AWS.Logging.FargateServiceAdapter;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace EXPN.ServiceHost.CreditLockService
{
    [ExcludeFromCodeCoverage]
    public static class LoggingModule
    {
        public static IServiceCollection AddLoggingModule(this IServiceCollection services, IConfigurationRoot config)
        {
            var isLocal = config.GetValue("Environment", string.Empty).Equals("local", StringComparison.OrdinalIgnoreCase);

            if (isLocal)
            {
                services.AddLogging(builder =>
                {
                    builder.SetMinimumLevel(LogLevel.Information);
                    builder.AddConsole();
                });
            }
            else
            {

                services.AddSingleton<LoggingChannel>();
                services.AddSingleton<ILoggerProvider, ChannelLogger>();

                services.AddLogging(builder =>
                {
                    builder.SetMinimumLevel(LogLevel.Information);
                    services.AddSingleton<ILogAdapter>(sp => RequestHeaderAdapter.ForStandardTokenHeaders(sp.GetService<IHttpContextAccessor>()));
                    services.AddSingleton<ILogAdapter, FargateServiceAdapter>();
                });

                services.AddHostedService<ChannelBatchedToKinesisService>();
            }

            return services;
        }
    }
}