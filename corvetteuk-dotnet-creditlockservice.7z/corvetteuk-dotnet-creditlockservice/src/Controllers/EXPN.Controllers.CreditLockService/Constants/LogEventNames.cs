using System.Diagnostics.CodeAnalysis;

namespace EXPN.Controllers.CreditLockService.Constants
{
    [ExcludeFromCodeCoverage]
    public struct LogEventNames
    {
        public struct ExternalController
        {
            internal struct Get
            {
                public const string Invoked = "ExternalController_Get_Invoked";
                public const string ModelStateFailed = "ExternalController_Get_ModelStateFailed";
                public const string Complete = "ExternalController_Get_Complete";
                public const string UnhandledException = "ExternalController_Get_UnhandledException";
                public const string DownstreamMaintenanceException = "ExternalController_Get_DownstreamMaintenanceException";
                public const string CustomerNotFoundException = "ExternalController_Get_CustomerNotFoundException";
                public const string OktaTokenNullException = "ExternalController_Get_OktaTokenNullException";
                public const string OktaTokenException = "ExternalController_Get_OktaTokenException";
                public const string ServiceUnavailableException = "ExternalController_Get_ServiceUnavailableException";
                public const string HttpServiceRequestException = "ExternalController_Get_HttpServiceRequestException";
                public const string ServiceTaskCanceledException = "ExternalController_Get_ServiceTaskCanceledException";
                public const string AutoMapperMappingException = "ExternalController_Get_AutoMapperMappingException";
                public const string DownstreamAuthenticationException = "ExternalController_Get_DownstreamAuthenticationException";
                public const string BenefitCheckFail = "ExternalController_Get_BenefitCheckFailed";
                public const string BenefitsInvalidOperationException = "ExternalController_Get_BenefitsInvalidOperationException";
            }

            internal struct Put
            {
                public const string Invoked = "ExternalController_Put_Invoked";
                public const string ModelStateFailed = "ExternalController_Put_ModelStateFailed";
                public const string Complete = "ExternalController_Put_Complete";
                public const string RequestBodyNullException = "ExternalController_Put_RequestBodyNullException";
                public const string DownstreamMaintenanceException = "ExternalController_Put_DownstreamMaintenanceException";
                public const string UnhandledException = "ExternalController_Put_UnhandledException";
                public const string OktaTokenNullException = "ExternalController_Put_OktaTokenNullException";
                public const string OktaTokenException = "ExternalController_Put_OktaTokenException";
                public const string ServiceUnavailableException = "ExternalController_Put_ServiceUnavailableException";
                public const string HttpServiceRequestException = "ExternalController_Put_HttpServiceRequestException";
                public const string ServiceTaskCanceledException = "ExternalController_Put_ServiceTaskCanceledException";
                public const string CustomerNotFoundException = "ExternalController_Put_CustomerNotFoundException";
                public const string SyncCustomerPinningException = "ExternalController_Put_SyncCustomerPinningException";
                public const string DownstreamAuthenticationException = "ExternalController_Put_DownstreamAuthenticationException";
                public const string BenefitCheckFail = "ExternalController_Put_BenefitCheckFailed";
                public const string BenefitsInvalidOperationException = "ExternalController_Put_BenefitsInvalidOperationException";
            }

            internal struct PutAgent
            {
                public const string Invoked = "ExternalController_PutAgent_Invoked";
                public const string ModelStateFailed = "ExternalController_PutAgent_ModelStateFailed";
                public const string Complete = "ExternalController_PutAgent_Complete";
                public const string RequestBodyNullException = "ExternalController_PutAgent_RequestBodyNullException";
                public const string DownstreamMaintenanceException = "ExternalController_PutAgent_DownstreamMaintenanceException";
                public const string UnhandledException = "ExternalController_PutAgent_UnhandledException";
                public const string OktaTokenNullException = "ExternalController_PutAgent_OktaTokenNullException";
                public const string OktaTokenException = "ExternalController_PutAgent_OktaTokenException";
                public const string ServiceUnavailableException = "ExternalController_PutAgent_ServiceUnavailableException";
                public const string HttpServiceRequestException = "ExternalController_PutAgent_HttpServiceRequestException";
                public const string ServiceTaskCanceledException = "ExternalController_PutAgent_ServiceTaskCanceledException";
                public const string CustomerNotFoundException = "ExternalController_PutAgent_CustomerNotFoundException";
                public const string SyncCustomerPinningException = "ExternalController_PutAgent_SyncCustomerPinningException";
                public const string DownstreamAuthenticationException = "ExternalController_PutAgent_DownstreamAuthenticationException";
                public const string BenefitCheckFail = "ExternalController_PutAgent_BenefitCheckFailed";
                public const string BenefitsInvalidOperationException = "ExternalController_PutAgent_BenefitsInvalidOperationException";
            }
        }

        public struct InternalCreditLockController
        {
            internal struct CustomerUpdate
            {
                public const string Invoked = "InternalCreditLockController_CustomerUpdate_Invoked";
                public const string Complete = "InternalCreditLockController_CustomerUpdate_Complete";
                public const string ModelStateFailed = "InternalCreditLockController_CustomerUpdate_ModelStateFailed";
                public const string UnhandledException = "InternalCreditLockController_CustomerUpdate_UnhandledException";
                public const string OktaTokenNullException = "InternalCreditLockController_CustomerUpdate_OktaTokenNullException";
                public const string DownstreamMaintenanceException = "InternalCreditLockController_CustomerUpdate_DownstreamMaintenanceException";
                public const string HttpServiceRequestException = "InternalCreditLockController_CustomerUpdate_HttpServiceRequestException";
                public const string ServiceUnavailableException = "InternalCreditLockController_CustomerUpdate_ServiceUnavailableException";
                public const string ServiceTaskCanceledException = "InternalCreditLockController_CustomerUpdate_ServiceTaskCanceledException";
                public const string OktaTokenException = "InternalCreditLockController_CustomerUpdate_OktaTokenException";
                public const string DownstreamBadResponse = "InternalCreditLockController_CustomerUpdate_DownstreamBadResponse";
                public const string CustomerProfileNotFoundException = "InternalCreditLockController_CustomerUpdate_CustomerProfileNotFoundException";
                public const string CustomerNotFoundException = "InternalCreditLockController_CustomerUpdate_CustomerNotFoundException";
                public const string SyncCustomerPinningException = "InternalCreditLockController_CustomerUpdate_SyncCustomerPinningException";
                public const string DownstreamAuthenticationException = "InternalCreditLockController_CustomerUpdate_DownstreamAuthenticationException";
            }

            internal struct Activate
            {
                public const string Invoked = "InternalCreditLockController_Activate_Invoked";
                public const string Complete = "InternalCreditLockController_Activate_Complete";
                public const string ModelStateFailed = "InternalCreditLockController_Activate_ModelStateFailed";
                public const string UnhandledException = "InternalCreditLockController_Activate_UnhandledException";
                public const string CustomerProfileNotFoundException = "InternalCreditLockController_Activate_CustomerProfileNotFoundException";
                public const string OktaTokenNullException = "InternalCreditLockController_Activate_OktaTokenNullException";
                public const string DownstreamMaintenanceException = "InternalCreditLockController_Activate_DownstreamMaintenanceException";
                public const string HttpServiceRequestException = "InternalCreditLockController_Activate_HttpServiceRequestException";
                public const string ServiceUnavailableException = "InternalCreditLockController_Activate_ServiceUnavailableException";
                public const string ServiceTaskCanceledException = "InternalCreditLockController_Activate_ServiceTaskCanceledException";
                public const string OktaTokenException = "InternalCreditLockController_Activate_OktaTokenException";
                public const string DownstreamBadResponse = "InternalCreditLockController_Activate_DownstreamBadResponse";
                public const string SyncCustomerPinningException = "InternalCreditLockController_Activate_SyncCustomerPinningException";
                public const string DownstreamAuthenticationException = "InternalCreditLockController_Activate_DownstreamAuthenticationException";
            }

            internal struct Deactivate
            {
                public const string Invoked = "InternalCreditLockController_Deactivate_Invoked";
                public const string Complete = "InternalCreditLockController_Deactivate_Complete";
                public const string ModelStateFailed = "InternalCreditLockController_Deactivate_ModelStateFailed";
                public const string CustomerProfileNotFoundException = "InternalCreditLockController_Deactivate_CustomerProfileNotFoundException";
                public const string CustomerNotFoundException = "InternalCreditLockController_Deactivate_CustomerNotFoundException";
                public const string OktaTokenNullException = "InternalCreditLockController_Deactivate_OktaTokenNullException";
                public const string DownstreamMaintenanceException = "InternalCreditLockController_Deactivate_DownstreamMaintenanceException";
                public const string HttpServiceRequestException = "InternalCreditLockController_Deactivate_HttpServiceRequestException";
                public const string ServiceUnavailableException = "InternalCreditLockController_Deactivate_ServiceUnavailableException";
                public const string ServiceTaskCanceledException = "InternalCreditLockController_Deactivate_ServiceTaskCanceledException";
                public const string OktaTokenException = "InternalCreditLockController_Deactivate_OktaTokenException";
                public const string UnhandledException = "InternalCreditLockController_Deactivate_UnhandledException";
                public const string DownstreamAuthenticationException = "InternalCreditLockController_Deactivate_DownstreamAuthenticationException";
            }

            internal struct CustomerDelete
            {
                public const string Invoked = "InternalCreditLockController_CustomerDelete_Invoked";
                public const string Complete = "InternalCreditLockController_CustomerDelete_Complete";
                public const string ModelStateFailed = "InternalCreditLockController_CustomerDelete_ModelStateFailed";
                public const string UnhandledException = "InternalCreditLockController_CustomerDelete_UnhandledException";
                public const string DownstreamMaintenanceException = "InternalCreditLockController_CustomerDelete_DownstreamMaintenanceException";
                public const string HttpServiceRequestException = "InternalCreditLockController_CustomerDelete_HttpServiceRequestException";
                public const string ServiceUnavailableException = "InternalCreditLockController_CustomerDelete_ServiceUnavailableException";
                public const string ServiceTaskCanceledException = "InternalCreditLockController_CustomerDelete_ServiceTaskCanceledException";
                public const string CustomerNotFoundException = "InternalCreditLockController_CustomerDelete_CustomerNotFoundException";
                public const string CustomerProfileNotFoundException = "InternalCreditLockController_CustomerDelete_CustomerProfileNotFoundException";
                public const string OktaTokenNullException = "InternalCreditLockController_CustomerDelete_OktaTokenNullException";
                public const string OktaTokenException = "InternalCreditLockController_CustomerDelete_OktaTokenException";
                public const string DownstreamAuthenticationException = "InternalCreditLockController_CustomerDelete_DownstreamAuthenticationException";
            }
        }

        public struct InternalInstantAlertsController
        {
            internal struct Activate
            {
                public const string Invoked = "InternalInstantAlertsController_Activate_Invoked";
                public const string Complete = "InternalInstantAlertsController_Activate_Complete";
                public const string ModelStateFailed = "InternalInstantAlertsController_Activate_ModelStateFailed";
                public const string OktaTokenNullException = "InternalInstantAlertsController_Activate_OktaTokenNullException";
                public const string DownstreamMaintenanceException = "InternalInstantAlertsController_Activate_DownstreamMaintenanceException";
                public const string HttpServiceRequestException = "InternalInstantAlertsController_Activate_HttpServiceRequestException";
                public const string ServiceUnavailableException = "InternalInstantAlertsController_Activate_ServiceUnavailableException";
                public const string ServiceTaskCanceledException = "InternalInstantAlertsController_Activate_ServiceTaskCanceledException";
                public const string OktaTokenException = "InternalInstantAlertsController_Activate_OktaTokenException";
                public const string DownstreamBadResponse = "InternalInstantAlertsController_Activate_DownstreamBadResponse";
                public const string UnhandledException = "InternalInstantAlertsController_Activate_UnhandledException";
                public const string CustomerProfileNotFoundException = "InternalInstantAlertsController_Activate_CustomerProfileNotFoundException";
                public const string CustomerConflict = "InternalInstantAlertsController_Activate_CustomerConflict";
                public const string SyncCustomerPinningException = "InternalInstantAlertsController_Activate_SyncCustomerPinningException";
                public const string DownstreamAuthenticationException = "InternalInstantAlertsController_Activate_DownstreamAuthenticationException";
                public const string CustomerNotFoundException = "InternalInstantAlertsController_Activate_CustomerNotFoundException";
            }

            internal struct Deactivate
            {
                public const string Invoked = "InternalInstantAlertsController_Deactivate_Invoked";
                public const string Complete = "InternalInstantAlertsController_Deactivate_Complete";
                public const string ModelStateFailed = "InternalInstantAlertsController_Deactivate_ModelStateFailed";
                public const string OktaTokenNullException = "InternalInstantAlertsController_Deactivate_OktaTokenNullException";
                public const string DownstreamMaintenanceException = "InternalInstantAlertsController_Deactivate_DownstreamMaintenanceException";
                public const string HttpServiceRequestException = "InternalInstantAlertsController_Deactivate_HttpServiceRequestException";
                public const string ServiceUnavailableException = "InternalInstantAlertsController_Deactivate_ServiceUnavailableException";
                public const string ServiceTaskCanceledException = "InternalInstantAlertsController_Deactivate_ServiceTaskCanceledException";
                public const string OktaTokenException = "InternalInstantAlertsController_Deactivate_OktaTokenException";
                public const string DownstreamBadResponse = "InternalInstantAlertsController_Deactivate_DownstreamBadResponse";
                public const string UnhandledException = "InternalInstantAlertsController_Deactivate_UnhandledException";
                public const string CustomerProfileNotFoundException = "InternalInstantAlertsController_Deactivate_CustomerProfileNotFoundException";
                public const string CustomerNotFoundException = "InternalInstantAlertsController_Deactivate_CustomerNotFoundException";
                public const string DownstreamAuthenticationException = "InternalInstantAlertsController_Deactivate_DownstreamAuthenticationException";
            }
        }

        public struct Messaging
        {
            public struct PublishEventAsync
            {
                public const string Enter = "Messaging_PublishEventAsync_Enter";
                public const string Exit = "Messaging_PublishEventAsync_Exit";
            }
        }
    }
}