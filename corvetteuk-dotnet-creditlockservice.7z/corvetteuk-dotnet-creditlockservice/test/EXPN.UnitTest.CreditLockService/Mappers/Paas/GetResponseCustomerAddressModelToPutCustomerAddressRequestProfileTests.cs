﻿using System;
using System.Collections.Generic;
using AutoMapper;
using EXPN.Mappers.CreditLockService.Paas;
using EXPN.Models.CreditLockService.Internal.Get.Response;
using EXPN.Models.CreditLockService.Paas.Put.Request;
using FluentAssertions;
using Xunit;

namespace EXPN.UnitTest.CreditLockService.Mappers.Paas
{
    public class GetResponseCustomerAddressModelToPutCustomerAddressRequestProfileTests
    {
        private readonly MapperConfiguration _mapperConfiguration;

        public GetResponseCustomerAddressModelToPutCustomerAddressRequestProfileTests()
        {
            _mapperConfiguration = new MapperConfiguration(
                cfg => { cfg.AddProfile<GetResponseCustomerAddressModelToPutCustomerAddressRequestProfile>(); });
        }

        [Fact]
        public void ModelProfile_AssertConfiguration_IsValid()
        {
            _mapperConfiguration.AssertConfigurationIsValid();
        }

        public static IEnumerable<object[]> MappingData()
        {
            yield return new object[]
            {
                null,
                null
            };

            yield return new object[]
            {
                new GetResponseCustomerAddressModel(),
                new PutCustomerAddressRequest()
            };

            yield return new object[]
            {
                new GetResponseCustomerAddressModel
                {
                    Abroad = false,
                    AddressType = "C",
                    County = "county",
                    Country = "country",
                    City = "city",
                    District = "district",
                    Flat = "flat",
                    HouseName = "houseName",
                    HouseNumber = "houseNumber",
                    PostCode = "postcode",
                    Street = "street",
                    IsVerified = true,
                    FromDt = new DateTime(2010, 12, 31),
                    LastUpdatedDt = new DateTime(2021, 4, 30),
                    ToDt = null,
                    Manual = false
                },
                new PutCustomerAddressRequest
                {
                    County = "county",
                    District = "district",
                    HouseName = "houseName",
                    HouseNumber = "houseNumber",
                    Flat = "flat",
                    Postcode = "postcode",
                    Town = "city",
                    Street = "street",
                    IsCurrent = true
                }
            };
        }

        [Theory]
        [MemberData(nameof(MappingData))]
        public void InternalModelProfile_ExampleInput_MapsCorrectly(GetResponseCustomerAddressModel input, PutCustomerAddressRequest expected)
        {
            var mapper = _mapperConfiguration.CreateMapper();
            var result = mapper.Map<PutCustomerAddressRequest>(input);

            result.Should().BeEquivalentTo(expected);
        }
    }
}