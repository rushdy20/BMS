using AutoMapper;
using Experian.ResponseModels;
using EXPN.BusinessLayer.CreditLockService;
using EXPN.BusinessLayer.CreditLockService.Exceptions;
using EXPN.Controllers.CreditLockService;
using EXPN.Controllers.CreditLockService.Constants;
using EXPN.Controllers.CreditLockService.DateTime;
using EXPN.Controllers.CreditLockService.Messaging;
using EXPN.DataLayer.CreditLockService.Common.Exceptions;
using EXPN.Models.CreditLockService.External.Post.Request;
using EXPN.Models.CreditLockService.Internal;
using EXPN.Models.CreditLockService.Internal.Post.Request;
using FluentAssertions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using NSubstitute;
using NSubstitute.ExceptionExtensions;
using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using Xunit;
using LogEventNames = EXPN.Controllers.CreditLockService.Constants.LogEventNames;

namespace EXPN.UnitTest.CreditLockService.Controllers
{
    public class InternalInstantAlertsControllerTests
    {
        private readonly ILogger<InternalInstantAlertsController> _logger;
        private readonly ICreditLockServiceCustomerManager _customerManager;
        private readonly IMessaging _messaging;
        private readonly IMapper _mapper;

        private readonly InternalInstantAlertsController _internalController;

        private const int DownstreamMaintenanceStatusCode = 561;
        private const int DownstreamBadResponseStatusCode = 562;

        private const string EventName = "auditCreditLockRequest";

        public InternalInstantAlertsControllerTests()
        {
            _logger = Substitute.For<ILogger<InternalInstantAlertsController>>();
            _customerManager = Substitute.For<ICreditLockServiceCustomerManager>();
            _messaging = Substitute.For<IMessaging>();
            _mapper = Substitute.For<IMapper>();

            var dateTime = Substitute.For<IDateTime>();
            dateTime.Now.Returns(new DateTime(2020, 12, 31, 23, 59, 59, 987));

            _internalController = new InternalInstantAlertsController(_logger, _messaging, dateTime, _mapper, _customerManager);
        }

        public static IEnumerable<object[]> NullParameters()
        {
            yield return new object[]
            {
                null,
                Substitute.For<ICreditLockServiceCustomerManager>(),
                Substitute.For<IMessaging>(),
                Substitute.For<IDateTime>(),
                Substitute.For<IMapper>(),
                "logger"
            };

            yield return new object[]
            {
                Substitute.For<ILogger<InternalInstantAlertsController>>(),
                null,
                Substitute.For<IMessaging>(),
                Substitute.For<IDateTime>(),
                Substitute.For<IMapper>(),
                "customerManager"
            };

            yield return new object[]
            {
                Substitute.For<ILogger<InternalInstantAlertsController>>(),
                Substitute.For<ICreditLockServiceCustomerManager>(),
                null,
                Substitute.For<IDateTime>(),
                Substitute.For<IMapper>(),
                "messaging"
            };

            yield return new object[]
            {
                Substitute.For<ILogger<InternalInstantAlertsController>>(),
                Substitute.For<ICreditLockServiceCustomerManager>(),
                Substitute.For<IMessaging>(),
                null,
                Substitute.For<IMapper>(),
                "dateTime"
            };

            yield return new object[]
            {
                Substitute.For<ILogger<InternalInstantAlertsController>>(),
                Substitute.For<ICreditLockServiceCustomerManager>(),
                Substitute.For<IMessaging>(),
                Substitute.For<IDateTime>(),
                null,
                "mapper"
            };
        }

        [Theory]
        [MemberData(nameof(NullParameters))]
        public void Constructor_RequiredParameterNull_ThrowsArgumentNullException(
            ILogger<InternalInstantAlertsController> logger,
            ICreditLockServiceCustomerManager customerManager,
            IMessaging messaging,
            IDateTime dateTime,
            IMapper mapper,
            string expectedErrorParameter)
        {
            var action = () =>
            {
                var unused = new InternalInstantAlertsController(logger, messaging, dateTime, mapper, customerManager);
            };

            action.Should().Throw<ArgumentNullException>()
                .Where(x => x.ParamName == expectedErrorParameter);
        }

        public class PostActivateAsync : InternalInstantAlertsControllerTests
        {
            public static IEnumerable<object[]> LogInformationMessages()
            {
                yield return new object[]
                {
                    LogEventNames.InternalInstantAlertsController.Activate.Invoked
                };

                yield return new object[]
                {
                    LogEventNames.InternalInstantAlertsController.Activate.Complete
                };
            }

            [Theory]
            [MemberData(nameof(LogInformationMessages))]
            public async Task HappyPathInformationLogged(string information)
            {
                await _internalController.ActivateAsync(new PostRequest());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(information)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PostRequest_ModelStateInvalid_ReturnStatusBadRequest()
            {
                var request = new PostRequest
                {
                    CustomerId = "Not a Valid customer id"
                };

                var customerRequest = new CustomerRequest
                {
                    CustomerId = "Not a Valid customer id"
                };

                _internalController.ModelState.AddModelError("Test", "TestError");

                var response = await _internalController.ActivateAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.BadRequest);

                _mapper.DidNotReceive().Map<CustomerRequest>(request);
                _mapper.DidNotReceive().Map<PostActivateInstantAlertRequest>(request);

                await _customerManager.DidNotReceive().ActivateAsync(customerRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "400"
                    && x.ResponseStatusDescription == "Bad Request"
                    && x.RequestType == "ACTIVATE_INSTANTALERTS"
                    && x.RequestDt == new DateTime(2020, 12, 31, 23, 59, 59, 987)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task ActivateRequest_Valid_ReturnSuccessNoContent()
            {
                var request = new PostRequest
                {
                    CustomerId = "Valid customer id"
                };

                var customerRequest = new CustomerRequest
                {
                    CustomerId = "Valid customer id"
                };

                var postActivateInstantAlertRequest = new PostActivateInstantAlertRequest
                {
                    CustomerId = "Valid customer id"
                };

                _mapper.Map<CustomerRequest>(request)
                    .Returns(customerRequest);

                _mapper.Map<PostActivateInstantAlertRequest>(request)
                    .Returns(postActivateInstantAlertRequest);

                var response = await _internalController.ActivateAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.NoContent);

                _mapper.Received(1).Map<CustomerRequest>(request);

                _mapper.Received(1).Map<PostActivateInstantAlertRequest>(request);

                await _customerManager.Received(1).ActivateAsync(customerRequest);

                await _customerManager.Received(1).ActivateInstantAlert(postActivateInstantAlertRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "204"
                    && x.ResponseStatusDescription == "Success"
                    && x.RequestType == "ACTIVATE_INSTANTALERTS"
                    && x.RequestDt == new DateTime(2020, 12, 31, 23, 59, 59, 987)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PostActivate_Exception_ReturnStatusInternalServerError()
            {
                const string customerId = "4a1f51c5-e902-4efb-8366-816e29e788e7";

                var postInstantAlertsRequest = new PostRequest
                {
                    CustomerId = customerId
                };

                var customerRequest = new CustomerRequest
                {
                    CustomerId = customerId
                };

                var postActivateInstantAlertRequest = new PostActivateInstantAlertRequest
                {
                    CustomerId = "Valid customer id"
                };

                _mapper.Map<CustomerRequest>(postInstantAlertsRequest)
                    .Returns(customerRequest);

                _mapper.Map<PostActivateInstantAlertRequest>(postInstantAlertsRequest)
                    .Returns(postActivateInstantAlertRequest);

                _customerManager.ActivateAsync(customerRequest)
                    .Throws(new Exception());

                var response = await _internalController.ActivateAsync(postInstantAlertsRequest) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.InternalServerError);

                _mapper.Received(1).Map<CustomerRequest>(postInstantAlertsRequest);

                await _customerManager.Received(1).ActivateAsync(customerRequest);

                await _customerManager.DidNotReceive().ActivateInstantAlert(postActivateInstantAlertRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "500"
                    && x.ResponseStatusDescription == "Internal Server Error"
                    && x.RequestType == "ACTIVATE_INSTANTALERTS"
                    && x.RequestDt == new DateTime(2020, 12, 31, 23, 59, 59, 987)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                   Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.OktaTokenNullException)), null,
                   Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.CustomerConflict)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.DownstreamBadResponse)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.SyncCustomerPinningException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                   Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.CustomerNotFoundException)), null,
                   Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PostActivate_CustomerNotFoundException_ReturnStatusNotFoundError()
            {
                const string customerId = "4a1f51c5-e902-4efb-8366-816e29e788e7";

                var postInstantAlertsRequest = new PostRequest
                {
                    CustomerId = customerId
                };

                var customerRequest = new CustomerRequest
                {
                    CustomerId = customerId
                };

                var postActivateInstantAlertRequest = new PostActivateInstantAlertRequest
                {
                    CustomerId = "Valid customer id"
                };

                _mapper.Map<CustomerRequest>(postInstantAlertsRequest)
                    .Returns(customerRequest);

                _customerManager.ActivateAsync(customerRequest)
                    .Throws(new CustomerProfileNotFoundException());

                var response = await _internalController.ActivateAsync(postInstantAlertsRequest) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.NotFound);

                await _customerManager.Received(1).ActivateAsync(customerRequest);

                await _customerManager.DidNotReceive().ActivateInstantAlert(postActivateInstantAlertRequest);

                _mapper.Received(1).Map<CustomerRequest>(postInstantAlertsRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "404"
                    && x.ResponseStatusDescription == "Corvette Customer Profile is not found"
                    && x.RequestType == "ACTIVATE_INSTANTALERTS"
                    && x.RequestDt == new DateTime(2020, 12, 31, 23, 59, 59, 987)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                   Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.OktaTokenNullException)), null,
                   Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.CustomerConflict)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.DownstreamBadResponse)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.SyncCustomerPinningException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                   Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.CustomerNotFoundException)), null,
                   Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PostActivate_OktaTokenNullException_ReturnStatusBadGateway()
            {
                const string customerId = "4a1f51c5-e902-4efb-8366-816e29e788e7";

                var postInstantAlertsRequest = new PostRequest
                {
                    CustomerId = customerId
                };

                var customerRequest = new CustomerRequest
                {
                    CustomerId = customerId
                };

                var postActivateInstantAlertRequest = new PostActivateInstantAlertRequest
                {
                    CustomerId = "Valid customer id"
                };

                _mapper.Map<CustomerRequest>(postInstantAlertsRequest)
                    .Returns(customerRequest);

                _customerManager.ActivateAsync(customerRequest)
                    .Throws(new OktaTokenNullException());

                var response = await _internalController.ActivateAsync(postInstantAlertsRequest) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.BadGateway);

                _mapper.Received(1).Map<CustomerRequest>(postInstantAlertsRequest);

                await _customerManager.Received(1).ActivateAsync(customerRequest);

                await _customerManager.DidNotReceive().ActivateInstantAlert(postActivateInstantAlertRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "502"
                    && x.ResponseStatusDescription == "Bad Gateway"
                    && x.RequestType == "ACTIVATE_INSTANTALERTS"
                    && x.RequestDt == new DateTime(2020, 12, 31, 23, 59, 59, 987)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.CustomerConflict)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.DownstreamBadResponse)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.SyncCustomerPinningException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                   Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.CustomerNotFoundException)), null,
                   Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PostActivate_CustomerPostRequestConflictException_ReturnStatusConflict()
            {
                const string customerId = "4a1f51c5-e902-4efb-8366-816e29e788e7";

                var postInstantAlertsRequest = new PostRequest
                {
                    CustomerId = customerId
                };

                var customerRequest = new CustomerRequest
                {
                    CustomerId = customerId
                };

                var postActivateInstantAlertRequest = new PostActivateInstantAlertRequest
                {
                    CustomerId = "Valid customer id"
                };

                _mapper.Map<CustomerRequest>(postInstantAlertsRequest)
                    .Returns(customerRequest);

                _customerManager.ActivateAsync(customerRequest)
                    .Throws(new CustomerPostRequestConflictException());

                var response = await _internalController.ActivateAsync(postInstantAlertsRequest) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.Conflict);

                await _customerManager.Received(1).ActivateAsync(customerRequest);

                await _customerManager.DidNotReceive().ActivateInstantAlert(postActivateInstantAlertRequest);

                _mapper.Received(1).Map<CustomerRequest>(postInstantAlertsRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "409"
                    && x.ResponseStatusDescription == "Conflict - customer waiting to be pinned or pinning in process"
                    && x.RequestType == "ACTIVATE_INSTANTALERTS"
                    && x.RequestDt == new DateTime(2020, 12, 31, 23, 59, 59, 987)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.CustomerConflict)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.DownstreamBadResponse)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.SyncCustomerPinningException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                   Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.CustomerNotFoundException)), null,
                   Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PostActivate_DownstreamMaintenanceException_ReturnStatus561()
            {
                const string customerId = "4a1f51c5-e902-4efb-8366-816e29e788e7";

                var postInstantAlertsRequest = new PostRequest
                {
                    CustomerId = customerId
                };

                var customerRequest = new CustomerRequest
                {
                    CustomerId = customerId
                };

                var postActivateInstantAlertRequest = new PostActivateInstantAlertRequest
                {
                    CustomerId = "Valid customer id"
                };

                _mapper.Map<CustomerRequest>(postInstantAlertsRequest)
                    .Returns(customerRequest);

                _customerManager.ActivateAsync(customerRequest)
                    .Throws(new DownstreamMaintenanceException());

                var response = await _internalController.ActivateAsync(postInstantAlertsRequest) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be(DownstreamMaintenanceStatusCode);

                await _customerManager.Received(1).ActivateAsync(customerRequest);

                await _customerManager.DidNotReceive().ActivateInstantAlert(postActivateInstantAlertRequest);

                _mapper.Received(1).Map<CustomerRequest>(postInstantAlertsRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "561"
                    && x.ResponseStatusDescription == "Downstream Service Unavailable - mainframe down for scheduled maintenance"
                    && x.RequestType == "ACTIVATE_INSTANTALERTS"
                    && x.RequestDt == new DateTime(2020, 12, 31, 23, 59, 59, 987)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.CustomerConflict)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.DownstreamBadResponse)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.SyncCustomerPinningException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                   Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.CustomerNotFoundException)), null,
                   Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PostActivate_GatewayTimeoutException_ReturnStatusInternalServerError()
            {
                const string customerId = "4a1f51c5-e902-4efb-8366-816e29e788e7";

                var postInstantAlertsRequest = new PostRequest
                {
                    CustomerId = customerId
                };

                var customerRequest = new CustomerRequest
                {
                    CustomerId = customerId
                };

                var postActivateInstantAlertRequest = new PostActivateInstantAlertRequest
                {
                    CustomerId = "Valid customer id"
                };

                _mapper.Map<CustomerRequest>(postInstantAlertsRequest)
                    .Returns(customerRequest);

                _customerManager.ActivateAsync(customerRequest)
                    .Throws(new HttpServiceRequestException());

                var response = await _internalController.ActivateAsync(postInstantAlertsRequest) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.InternalServerError);

                await _customerManager.Received(1).ActivateAsync(customerRequest);

                await _customerManager.DidNotReceive().ActivateInstantAlert(postActivateInstantAlertRequest);

                _mapper.Received(1).Map<CustomerRequest>(postInstantAlertsRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "500"
                    && x.ResponseStatusDescription == "Internal Server Error"
                    && x.RequestType == "ACTIVATE_INSTANTALERTS"
                    && x.RequestDt == new DateTime(2020, 12, 31, 23, 59, 59, 987)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.CustomerConflict)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.DownstreamBadResponse)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.SyncCustomerPinningException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                   Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.CustomerNotFoundException)), null,
                   Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PostActivate_ServiceUnavailableException_ReturnStatusServiceUnavailable()
            {
                const string customerId = "4a1f51c5-e902-4efb-8366-816e29e788e7";

                var postInstantAlertsRequest = new PostRequest
                {
                    CustomerId = customerId
                };

                var customerRequest = new CustomerRequest
                {
                    CustomerId = customerId
                };

                var postActivateInstantAlertRequest = new PostActivateInstantAlertRequest
                {
                    CustomerId = "Valid customer id"
                };

                _mapper.Map<CustomerRequest>(postInstantAlertsRequest)
                    .Returns(customerRequest);

                _customerManager.ActivateAsync(customerRequest)
                    .Throws(new ServiceUnavailableException());

                var response = await _internalController.ActivateAsync(postInstantAlertsRequest) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.ServiceUnavailable);

                await _customerManager.Received(1).ActivateAsync(customerRequest);

                await _customerManager.DidNotReceive().ActivateInstantAlert(postActivateInstantAlertRequest);

                _mapper.Received(1).Map<CustomerRequest>(postInstantAlertsRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "503"
                    && x.ResponseStatusDescription == "Service Unavailable"
                    && x.RequestType == "ACTIVATE_INSTANTALERTS"
                    && x.RequestDt == new DateTime(2020, 12, 31, 23, 59, 59, 987)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.CustomerConflict)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.DownstreamBadResponse)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.SyncCustomerPinningException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                   Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.CustomerNotFoundException)), null,
                   Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PostActivate_OktaException_ReturnStatusBadGateway()
            {
                const string customerId = "4a1f51c5-e902-4efb-8366-816e29e788e7";

                var postInstantAlertsRequest = new PostRequest
                {
                    CustomerId = customerId
                };

                var customerRequest = new CustomerRequest
                {
                    CustomerId = customerId
                };

                var postActivateInstantAlertRequest = new PostActivateInstantAlertRequest
                {
                    CustomerId = "Valid customer id"
                };

                _mapper.Map<CustomerRequest>(postInstantAlertsRequest)
                    .Returns(customerRequest);

                _customerManager.ActivateAsync(customerRequest)
                    .Throws(new OktaException());

                var response = await _internalController.ActivateAsync(postInstantAlertsRequest) as ObjectResult;

                response?.StatusCode.Should().Be((int)HttpStatusCode.BadGateway);

                await _customerManager.Received(1).ActivateAsync(customerRequest);

                await _customerManager.DidNotReceive().ActivateInstantAlert(postActivateInstantAlertRequest);

                _mapper.Received(1).Map<CustomerRequest>(postInstantAlertsRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "502"
                    && x.ResponseStatusDescription == "Bad Gateway"
                    && x.RequestType == "ACTIVATE_INSTANTALERTS"
                    && x.RequestDt == new DateTime(2020, 12, 31, 23, 59, 59, 987)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.DownstreamBadResponse)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.SyncCustomerPinningException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                   Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.CustomerNotFoundException)), null,
                   Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PostActivate_DownstreamBadResponse_ReturnStatus562()
            {
                const string customerId = "4a1f51c5-e902-4efb-8366-816e29e788e7";

                var postInstantAlertsRequest = new PostRequest
                {
                    CustomerId = customerId
                };

                var postActivateInstantAlertRequest = new PostActivateInstantAlertRequest
                {
                    CustomerId = "Valid customer id"
                };

                var customerRequest = new CustomerRequest
                {
                    CustomerId = customerId
                };

                _mapper.Map<CustomerRequest>(postInstantAlertsRequest)
                    .Returns(customerRequest);

                _customerManager.ActivateAsync(customerRequest)
                    .Throws(new DownstreamBadResponseException());

                var response = await _internalController.ActivateAsync(postInstantAlertsRequest) as ObjectResult;

                response?.StatusCode.Should().Be(DownstreamBadResponseStatusCode);

                await _customerManager.Received(1).ActivateAsync(customerRequest);

                await _customerManager.DidNotReceive().ActivateInstantAlert(postActivateInstantAlertRequest);

                _mapper.Received(1).Map<CustomerRequest>(postInstantAlertsRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "562"
                    && x.ResponseStatusDescription == "Downstream Bad Request"
                    && x.RequestType == "ACTIVATE_INSTANTALERTS"
                    && x.RequestDt == new DateTime(2020, 12, 31, 23, 59, 59, 987)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.DownstreamBadResponse)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.SyncCustomerPinningException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                   Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.CustomerNotFoundException)), null,
                   Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PostActivate_ServiceTaskCanceledException_ReturnStatusCode()
            {
                const string customerId = "4a1f51c5-e902-4efb-8366-816e29e788e7";

                var postInstantAlertsRequest = new PostRequest
                {
                    CustomerId = customerId
                };

                var customerRequest = new CustomerRequest
                {
                    CustomerId = customerId
                };

                var postActivateInstantAlertRequest = new PostActivateInstantAlertRequest
                {
                    CustomerId = "Valid customer id"
                };

                _mapper.Map<CustomerRequest>(postInstantAlertsRequest)
                    .Returns(customerRequest);

                _customerManager.ActivateAsync(customerRequest)
                    .Throws(new ServiceTaskCanceledException());

                var response = await _internalController.ActivateAsync(postInstantAlertsRequest) as ObjectResult;

                response?.StatusCode.Should().Be(564);

                await _customerManager.Received(1).ActivateAsync(customerRequest);

                _mapper.Received(1).Map<CustomerRequest>(postInstantAlertsRequest);

                await _customerManager.DidNotReceive().ActivateInstantAlert(postActivateInstantAlertRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "564"
                    && x.ResponseStatusDescription == MessageConstants.DownstreamTimeout
                    && x.RequestType == "ACTIVATE_INSTANTALERTS"
                    && x.RequestDt == new DateTime(2020, 12, 31, 23, 59, 59, 987)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.DownstreamBadResponse)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.SyncCustomerPinningException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                   Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.CustomerNotFoundException)), null,
                   Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PostActivate_SyncCustomerPinningException_Return409()
            {
                const string customerId = "4a1f51c5-e902-4efb-8366-816e29e788e7";

                var postInstantAlertsRequest = new PostRequest
                {
                    CustomerId = customerId
                };

                var customerRequest = new CustomerRequest
                {
                    CustomerId = customerId
                };

                var postActivateInstantAlertRequest = new PostActivateInstantAlertRequest
                {
                    CustomerId = "Valid customer id"
                };

                _mapper.Map<CustomerRequest>(postInstantAlertsRequest)
                    .Returns(customerRequest);

                _customerManager.ActivateAsync(customerRequest)
                    .Throws(new SyncCustomerPinningException());

                var response = await _internalController.ActivateAsync(postInstantAlertsRequest) as ObjectResult;

                response?.StatusCode.Should().Be((int)HttpStatusCode.Conflict);

                await _customerManager.Received(1).ActivateAsync(customerRequest);

                _mapper.Received(1).Map<CustomerRequest>(postInstantAlertsRequest);

                await _customerManager.DidNotReceive().ActivateInstantAlert(postActivateInstantAlertRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "409"
                    && x.ResponseStatusDescription == "Conflict - customer waiting to be pinned or pinning in process"
                    && x.RequestType == "ACTIVATE_INSTANTALERTS"
                    && x.RequestDt == new DateTime(2020, 12, 31, 23, 59, 59, 987)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.SyncCustomerPinningException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.DownstreamBadResponse)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                   Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.CustomerNotFoundException)), null,
                   Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PostActivate_DownstreamAuthenticationException_Return563()
            {
                const string customerId = "4a1f51c5-e902-4efb-8366-816e29e788e7";

                var postInstantAlertsRequest = new PostRequest
                {
                    CustomerId = customerId
                };

                var customerRequest = new CustomerRequest
                {
                    CustomerId = customerId
                };

                var postActivateInstantAlertRequest = new PostActivateInstantAlertRequest
                {
                    CustomerId = "Valid customer id"
                };

                _mapper.Map<CustomerRequest>(postInstantAlertsRequest)
                    .Returns(customerRequest);

                _customerManager.ActivateAsync(customerRequest)
                    .Throws(new DownstreamAuthenticationException());

                var response = await _internalController.ActivateAsync(postInstantAlertsRequest) as ObjectResult;

                response?.StatusCode.Should().Be(563);

                await _customerManager.Received(1).ActivateAsync(customerRequest);

                _mapper.Received(1).Map<CustomerRequest>(postInstantAlertsRequest);

                await _customerManager.DidNotReceive().ActivateInstantAlert(postActivateInstantAlertRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "563"
                    && x.ResponseStatusDescription == "Downstream Service Authentication Failed"
                    && x.RequestType == "ACTIVATE_INSTANTALERTS"
                    && x.RequestDt == new DateTime(2020, 12, 31, 23, 59, 59, 987)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.DownstreamAuthenticationException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.DownstreamBadResponse)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                   Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.SyncCustomerPinningException)), null,
                   Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                   Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.CustomerNotFoundException)), null,
                   Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PostActivate_CustomerNotFoundException_ReturnNotFound()
            {
                const string customerId = "4a1f51c5-e902-4efb-8366-816e29e788e7";

                var postInstantAlertsRequest = new PostRequest
                {
                    CustomerId = customerId
                };

                var customerRequest = new CustomerRequest
                {
                    CustomerId = customerId
                };

                var postActivateInstantAlertRequest = new PostActivateInstantAlertRequest
                {
                    CustomerId = "Valid customer id"
                };

                _mapper.Map<CustomerRequest>(postInstantAlertsRequest)
                    .Returns(customerRequest);

                _customerManager.ActivateAsync(customerRequest)
                    .Throws(new CustomerNotFoundException());

                var response = await _internalController.ActivateAsync(postInstantAlertsRequest) as ObjectResult;

                response?.StatusCode.Should().Be(404);

                await _customerManager.Received(1).ActivateAsync(customerRequest);

                _mapper.Received(1).Map<CustomerRequest>(postInstantAlertsRequest);

                await _customerManager.DidNotReceive().ActivateInstantAlert(postActivateInstantAlertRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "404"
                    && x.ResponseStatusDescription == "VIP Customer is Not Found"
                    && x.RequestType == "ACTIVATE_INSTANTALERTS"
                    && x.RequestDt == new DateTime(2020, 12, 31, 23, 59, 59, 987)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.CustomerNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.DownstreamBadResponse)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                   Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Activate.SyncCustomerPinningException)), null,
                   Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }
        }

        public class PostDeactivateAsync : InternalInstantAlertsControllerTests
        {
            public static IEnumerable<object[]> LogInformationMessages()
            {
                yield return new object[]
                {
                    LogEventNames.InternalInstantAlertsController.Deactivate.Invoked
                };

                yield return new object[]
                {
                    LogEventNames.InternalInstantAlertsController.Deactivate.Complete
                };
            }

            [Theory]
            [MemberData(nameof(LogInformationMessages))]
            public async Task HappyPathInformationLogged(string information)
            {
                await _internalController.DeactivateAsync(new PostRequest());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(information)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task DeactivateRequest_ModelStateInvalid_ReturnStatusBadRequest()
            {
                var request = new PostRequest
                {
                    CustomerId = "Not a Valid customer id"
                };

                _internalController.ModelState.AddModelError("Test", "TestError");

                var response = await _internalController.DeactivateAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.BadRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "400"
                    && x.ResponseStatusDescription == "Bad Request"
                    && x.RequestType == "DEACTIVATE_INSTANTALERTS"
                    && x.RequestDt == new DateTime(2020, 12, 31, 23, 59, 59, 987)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.CustomerNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                   Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.OktaTokenNullException)), null,
                   Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.DownstreamBadResponse)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task DeactivateRequest_Valid_ReturnSuccessNoContent()
            {
                var request = new PostRequest
                {
                    CustomerId = "Valid customer id"
                };

                var postDeactivateInstantAlertRequest = new PostDeactivateInstantAlertRequest
                {
                    CustomerId = "Valid customer id"
                };

                _mapper.Map<PostDeactivateInstantAlertRequest>(request)
                    .Returns(postDeactivateInstantAlertRequest);

                var response = await _internalController.DeactivateAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.NoContent);

                _mapper.Received(1).Map<PostDeactivateInstantAlertRequest>(request);

                await _customerManager.Received(1).DeactivateInstantAlert(postDeactivateInstantAlertRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "204"
                    && x.ResponseStatusDescription == "Success"
                    && x.RequestType == "DEACTIVATE_INSTANTALERTS"
                    && x.RequestDt == new DateTime(2020, 12, 31, 23, 59, 59, 987)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.CustomerNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                   Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.OktaTokenNullException)), null,
                   Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.DownstreamBadResponse)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task DeactivateRequest_Exception_ReturnStatusInternalServerError()
            {
                var request = new PostRequest
                {
                    CustomerId = "4a1f51c5-e902-4efb-8366-816e29e788e7"
                };

                var postDeactivateInstantAlertRequest = new PostDeactivateInstantAlertRequest
                {
                    CustomerId = "4a1f51c5-e902-4efb-8366-816e29e788e7"
                };

                _mapper.Map<PostDeactivateInstantAlertRequest>(request)
                    .Returns(postDeactivateInstantAlertRequest);

                _customerManager.DeactivateInstantAlert(postDeactivateInstantAlertRequest)
                    .Throws(new Exception());

                var response = await _internalController.DeactivateAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.InternalServerError);

                _mapper.Received(1).Map<PostDeactivateInstantAlertRequest>(request);

                await _customerManager.Received(1).DeactivateInstantAlert(postDeactivateInstantAlertRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "500"
                    && x.ResponseStatusDescription == "Internal Server Error"
                    && x.RequestType == "DEACTIVATE_INSTANTALERTS"
                    && x.RequestDt == new DateTime(2020, 12, 31, 23, 59, 59, 987)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.CustomerNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                   Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.OktaTokenNullException)), null,
                   Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.DownstreamBadResponse)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task DeactivateRequest_CustomerNotFoundException_ReturnStatusNotFoundError()
            {
                var request = new PostRequest
                {
                    CustomerId = "4a1f51c5-e902-4efb-8366-816e29e788e7"
                };

                var postDeactivateInstantAlertRequest = new PostDeactivateInstantAlertRequest
                {
                    CustomerId = "4a1f51c5-e902-4efb-8366-816e29e788e7"
                };

                _mapper.Map<PostDeactivateInstantAlertRequest>(request)
                    .Returns(postDeactivateInstantAlertRequest);

                _customerManager.DeactivateInstantAlert(postDeactivateInstantAlertRequest)
                    .Throws(new CustomerNotFoundException());

                var response = await _internalController.DeactivateAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.NoContent);

                await _customerManager.Received(1).DeactivateInstantAlert(postDeactivateInstantAlertRequest);

                _mapper.Received(1).Map<PostDeactivateInstantAlertRequest>(request);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "204"
                    && x.ResponseStatusDescription == "VIP Customer is Not Found"
                    && x.RequestType == "DEACTIVATE_INSTANTALERTS"
                    && x.RequestDt == new DateTime(2020, 12, 31, 23, 59, 59, 987)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.CustomerNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                   Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.OktaTokenNullException)), null,
                   Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.DownstreamBadResponse)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task DeactivateRequest_OktaTokenNullException_ReturnStatusBadGateway()
            {
                var request = new PostRequest
                {
                    CustomerId = "4a1f51c5-e902-4efb-8366-816e29e788e7"
                };

                var postDeactivateInstantAlertRequest = new PostDeactivateInstantAlertRequest
                {
                    CustomerId = "4a1f51c5-e902-4efb-8366-816e29e788e7"
                };

                _mapper.Map<PostDeactivateInstantAlertRequest>(request)
                    .Returns(postDeactivateInstantAlertRequest);

                _customerManager.DeactivateInstantAlert(postDeactivateInstantAlertRequest)
                    .Throws(new OktaTokenNullException());

                var response = await _internalController.DeactivateAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.BadGateway);

                _mapper.Received(1).Map<PostDeactivateInstantAlertRequest>(request);

                await _customerManager.Received(1).DeactivateInstantAlert(postDeactivateInstantAlertRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "502"
                    && x.ResponseStatusDescription == "Bad Gateway"
                    && x.RequestType == "DEACTIVATE_INSTANTALERTS"
                    && x.RequestDt == new DateTime(2020, 12, 31, 23, 59, 59, 987)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                     Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.DownstreamMaintenanceException)), null,
                     Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.DownstreamBadResponse)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task DeactivateRequest_DownstreamMaintenanceException_ReturnStatus561()
            {
                var request = new PostRequest
                {
                    CustomerId = "4a1f51c5-e902-4efb-8366-816e29e788e7"
                };

                var postDeactivateInstantAlertRequest = new PostDeactivateInstantAlertRequest
                {
                    CustomerId = "4a1f51c5-e902-4efb-8366-816e29e788e7"
                };

                _mapper.Map<PostDeactivateInstantAlertRequest>(request)
                    .Returns(postDeactivateInstantAlertRequest);

                _customerManager.DeactivateInstantAlert(postDeactivateInstantAlertRequest)
                    .Throws(new DownstreamMaintenanceException());

                var response = await _internalController.DeactivateAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be(DownstreamMaintenanceStatusCode);

                await _customerManager.Received(1).DeactivateInstantAlert(postDeactivateInstantAlertRequest);

                _mapper.Received(1).Map<PostDeactivateInstantAlertRequest>(request);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "561"
                    && x.ResponseStatusDescription == "Downstream Service Unavailable - mainframe down for scheduled maintenance"
                    && x.RequestType == "DEACTIVATE_INSTANTALERTS"
                    && x.RequestDt == new DateTime(2020, 12, 31, 23, 59, 59, 987)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.DownstreamBadResponse)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task DeactivateRequest_GatewayTimeoutException_ReturnStatusInternalServerError()
            {
                var request = new PostRequest
                {
                    CustomerId = "4a1f51c5-e902-4efb-8366-816e29e788e7"
                };

                var postDeactivateInstantAlertRequest = new PostDeactivateInstantAlertRequest
                {
                    CustomerId = "4a1f51c5-e902-4efb-8366-816e29e788e7"
                };

                _mapper.Map<PostDeactivateInstantAlertRequest>(request)
                    .Returns(postDeactivateInstantAlertRequest);

                _customerManager.DeactivateInstantAlert(postDeactivateInstantAlertRequest)
                    .Throws(new HttpServiceRequestException());

                var response = await _internalController.DeactivateAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.InternalServerError);

                await _customerManager.Received(1).DeactivateInstantAlert(postDeactivateInstantAlertRequest);

                _mapper.Received(1).Map<PostDeactivateInstantAlertRequest>(request);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "500"
                    && x.ResponseStatusDescription == "Internal Server Error"
                    && x.RequestType == "DEACTIVATE_INSTANTALERTS"
                    && x.RequestDt == new DateTime(2020, 12, 31, 23, 59, 59, 987)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.DownstreamBadResponse)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task DeactivateRequest_ServiceUnavailableException_ReturnStatusServiceUnavailable()
            {
                var request = new PostRequest
                {
                    CustomerId = "4a1f51c5-e902-4efb-8366-816e29e788e7"
                };

                var postDeactivateInstantAlertRequest = new PostDeactivateInstantAlertRequest
                {
                    CustomerId = "4a1f51c5-e902-4efb-8366-816e29e788e7"
                };

                _mapper.Map<PostDeactivateInstantAlertRequest>(request)
                    .Returns(postDeactivateInstantAlertRequest);

                _customerManager.DeactivateInstantAlert(postDeactivateInstantAlertRequest)
                    .Throws(new ServiceUnavailableException());

                var response = await _internalController.DeactivateAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.ServiceUnavailable);

                await _customerManager.Received(1).DeactivateInstantAlert(postDeactivateInstantAlertRequest);

                _mapper.Received(1).Map<PostDeactivateInstantAlertRequest>(request);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "503"
                    && x.ResponseStatusDescription == "Service Unavailable"
                    && x.RequestType == "DEACTIVATE_INSTANTALERTS"
                    && x.RequestDt == new DateTime(2020, 12, 31, 23, 59, 59, 987)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                     Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.DownstreamMaintenanceException)), null,
                     Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.DownstreamBadResponse)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task DeactivateRequest_OktaException_ReturnStatusBadGateway()
            {
                var request = new PostRequest
                {
                    CustomerId = "4a1f51c5-e902-4efb-8366-816e29e788e7"
                };

                var postDeactivateInstantAlertRequest = new PostDeactivateInstantAlertRequest
                {
                    CustomerId = "4a1f51c5-e902-4efb-8366-816e29e788e7"
                };

                _mapper.Map<PostDeactivateInstantAlertRequest>(request)
                    .Returns(postDeactivateInstantAlertRequest);

                _customerManager.DeactivateInstantAlert(postDeactivateInstantAlertRequest)
                    .Throws(new OktaException());

                var response = await _internalController.DeactivateAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.BadGateway);

                await _customerManager.Received(1).DeactivateInstantAlert(postDeactivateInstantAlertRequest);

                _mapper.Received(1).Map<PostDeactivateInstantAlertRequest>(request);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "502"
                    && x.ResponseStatusDescription == "Bad Gateway"
                    && x.RequestType == "DEACTIVATE_INSTANTALERTS"
                    && x.RequestDt == new DateTime(2020, 12, 31, 23, 59, 59, 987)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                     Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.DownstreamMaintenanceException)), null,
                     Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.DownstreamBadResponse)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task DeactivateRequest_DownstreamBadResponse_ReturnStatus562()
            {
                var request = new PostRequest
                {
                    CustomerId = "4a1f51c5-e902-4efb-8366-816e29e788e7"
                };

                var postDeactivateInstantAlertRequest = new PostDeactivateInstantAlertRequest
                {
                    CustomerId = "4a1f51c5-e902-4efb-8366-816e29e788e7"
                };

                _mapper.Map<PostDeactivateInstantAlertRequest>(request)
                    .Returns(postDeactivateInstantAlertRequest);

                _customerManager.DeactivateInstantAlert(postDeactivateInstantAlertRequest)
                    .Throws(new DownstreamBadResponseException());

                var response = await _internalController.DeactivateAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be(DownstreamBadResponseStatusCode);

                await _customerManager.Received(1).DeactivateInstantAlert(postDeactivateInstantAlertRequest);

                _mapper.Received(1).Map<PostDeactivateInstantAlertRequest>(request);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "562"
                    && x.ResponseStatusDescription == "Downstream Bad Request"
                    && x.RequestType == "DEACTIVATE_INSTANTALERTS"
                    && x.RequestDt == new DateTime(2020, 12, 31, 23, 59, 59, 987)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                     Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.DownstreamMaintenanceException)), null,
                     Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.DownstreamBadResponse)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task DeactivateRequest_ServiceTaskCanceledException_ReturnStatusCode564()
            {
                var request = new PostRequest
                {
                    CustomerId = "4a1f51c5-e902-4efb-8366-816e29e788e7"
                };

                var postDeactivateInstantAlertRequest = new PostDeactivateInstantAlertRequest
                {
                    CustomerId = "4a1f51c5-e902-4efb-8366-816e29e788e7"
                };

                _mapper.Map<PostDeactivateInstantAlertRequest>(request)
                    .Returns(postDeactivateInstantAlertRequest);

                _customerManager.DeactivateInstantAlert(postDeactivateInstantAlertRequest)
                    .Throws(new ServiceTaskCanceledException());

                var response = await _internalController.DeactivateAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be(564);

                await _customerManager.Received(1).DeactivateInstantAlert(postDeactivateInstantAlertRequest);

                _mapper.Received(1).Map<PostDeactivateInstantAlertRequest>(request);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "564"
                    && x.ResponseStatusDescription == MessageConstants.DownstreamTimeout
                    && x.RequestType == "DEACTIVATE_INSTANTALERTS"
                    && x.RequestDt == new DateTime(2020, 12, 31, 23, 59, 59, 987)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                     Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.DownstreamMaintenanceException)), null,
                     Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
                
                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.DownstreamBadResponse)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }
            
            [Fact]
            public async Task DeactivateRequest_CustomerProfileNotFoundException_ReturnStatusNotFoundError()
            {
                var request = new PostRequest
                {
                    CustomerId = "4a1f51c5-e902-4efb-8366-816e29e788e7"
                };

                var postDeactivateInstantAlertRequest = new PostDeactivateInstantAlertRequest
                {
                    CustomerId = "4a1f51c5-e902-4efb-8366-816e29e788e7"
                };

                _mapper.Map<PostDeactivateInstantAlertRequest>(request)
                    .Returns(postDeactivateInstantAlertRequest);

                _customerManager.DeactivateInstantAlert(postDeactivateInstantAlertRequest)
                    .Throws(new CustomerProfileNotFoundException());

                var response = await _internalController.DeactivateAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.InternalServerError);

                await _customerManager.Received(1).DeactivateInstantAlert(postDeactivateInstantAlertRequest);

                _mapper.Received(1).Map<PostDeactivateInstantAlertRequest>(request);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "500"
                    && x.ResponseStatusDescription == "Internal Server Error"
                    && x.RequestType == "DEACTIVATE_INSTANTALERTS"
                    && x.RequestDt == new DateTime(2020, 12, 31, 23, 59, 59, 987)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                     Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.DownstreamMaintenanceException)), null,
                     Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.DownstreamBadResponse)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task DeactivateRequest_HttpServiceRequestException_ReturnInternalServerError()
            {
                var request = new PostRequest
                {
                    CustomerId = "4a1f51c5-e902-4efb-8366-816e29e788e7"
                };

                var postDeactivateInstantAlertRequest = new PostDeactivateInstantAlertRequest
                {
                    CustomerId = "4a1f51c5-e902-4efb-8366-816e29e788e7"
                };

                _mapper.Map<PostDeactivateInstantAlertRequest>(request)
                    .Returns(postDeactivateInstantAlertRequest);

                _customerManager.DeactivateInstantAlert(postDeactivateInstantAlertRequest)
                    .Throws(new HttpServiceRequestException());

                var response = await _internalController.DeactivateAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.InternalServerError);

                await _customerManager.Received(1).DeactivateInstantAlert(postDeactivateInstantAlertRequest);

                _mapper.Received(1).Map<PostDeactivateInstantAlertRequest>(request);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "500"
                    && x.ResponseStatusDescription == "Internal Server Error"
                    && x.RequestType == "DEACTIVATE_INSTANTALERTS"
                    && x.RequestDt == new DateTime(2020, 12, 31, 23, 59, 59, 987)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                     Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.DownstreamMaintenanceException)), null,
                     Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalInstantAlertsController.Deactivate.DownstreamBadResponse)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }
        }
    }
}