﻿using Experian.AWS.Logging.Extensions;
using EXPN.DataLayer.CreditLockService.Common.Exceptions;
using EXPN.DataLayer.CreditLockService.Paas.Constants;
using EXPN.DataLayer.CreditLockService.Paas.Extension;
using EXPN.Models.CreditLockService.Paas;
using EXPN.Models.CreditLockService.Paas.Delete.Request;
using EXPN.Models.CreditLockService.Paas.Get.Request;
using EXPN.Models.CreditLockService.Paas.Get.Response;
using EXPN.Models.CreditLockService.Paas.Post.Request;
using EXPN.Models.CreditLockService.Paas.Put.Request;
using EXPN.Models.CreditLockService.Paas.PutAlertStatus.Request;
using EXPN.Models.CreditLockService.Paas.PutLockStatus.Request;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;


namespace EXPN.DataLayer.CreditLockService.Paas.HttpClient
{
    public class CreditLockPaasClient : ICreditLockPaasClient
    {
        private readonly System.Net.Http.HttpClient _httpClient;
        private readonly ILogger<CreditLockPaasClient> _logger;
        private readonly IOktaClient _oktaClient;
        private readonly OktaAuthCredentials _oktaAuthCredentials;

        private const string CustomerPaasEndPoint = "customer";
        private const string LockPaasEndPoint = "lock";
        private const string ECSClientId = "ECS";
        private const string AlertPaaSEndPoint = "Alerts";

        private const int MaxRetryCount = 2;

        public CreditLockPaasClient(System.Net.Http.HttpClient httpClient,
            ILogger<CreditLockPaasClient> logger, IOktaClient oktaClient,
            IOptions<OktaAuthCredentials> oktaAuthCredentials)
        {
            _httpClient = httpClient ?? throw new ArgumentNullException(nameof(httpClient));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _oktaClient = oktaClient ?? throw new ArgumentNullException(nameof(oktaClient));

            if (oktaAuthCredentials == null)
                throw new ArgumentNullException(nameof(oktaAuthCredentials));

            _oktaAuthCredentials = oktaAuthCredentials.Value ?? throw new ArgumentException($"{nameof(oktaAuthCredentials.Value)} cannot be null", nameof(oktaAuthCredentials));
        }

        public async Task<GetCustomerResponse> GetPaasCustomerAsync(GetCustomerRequest getCustomerRequest)
        {
            _logger.LogAsInformation(LogEventNames.CreditLockPaasClient.Get.Enter);

            if (getCustomerRequest == null)
                throw new ArgumentNullException(nameof(getCustomerRequest));

            if (string.IsNullOrWhiteSpace(getCustomerRequest.CustomerRef))
                throw new ArgumentException($"{nameof(getCustomerRequest.CustomerRef)} cannot be null or whitespace", nameof(getCustomerRequest));

            _logger.LogAsInformation(LogEventNames.CreditLockPaasClient.Get.SendRequest);

            var getPaasEndPoint = $"{CustomerPaasEndPoint}/{ECSClientId}/{getCustomerRequest.CustomerRef}";
            var responseMessage = await SendRequest(getPaasEndPoint, string.Empty, HttpMethod.Get, false, getCustomerRequest.CustomerId);

            if (responseMessage.StatusCode == HttpStatusCode.Forbidden)
            {
                _logger.LogAsInformation(LogEventNames.CreditLockPaasClient.Get.SendRequestRegenToken);
                responseMessage = await SendRequest(getPaasEndPoint, string.Empty, HttpMethod.Get, true, getCustomerRequest.CustomerId);
            }

            if (responseMessage.StatusCode != HttpStatusCode.OK)
            {
                var extraData = new Dictionary<string, object>
                {
                    {LogEventKeys.CustomerId, getCustomerRequest.CustomerRef},
                    {
                        LogEventKeys.Context, new Dictionary<string, object>
                        {
                            {LogEventKeys.StatusCode, responseMessage.StatusCode},
                            {LogEventKeys.Content, responseMessage.Content}
                        }
                    }
                };

                _logger.LogAsWarning(LogEventNames.CreditLockPaasClient.Get.ResponseInvalidStatusCode, extraData);

                responseMessage.StatusCode.CheckForCommonError();
            }

            var response = JsonConvert.DeserializeObject<PaasResponseData>(await responseMessage.Content.ReadAsStringAsync());

            if (response?.Data == null)
            {
                var extraData = new Dictionary<string, object>
                {
                    {LogEventKeys.CustomerId, getCustomerRequest.CustomerRef},
                    {
                        LogEventKeys.Context, new Dictionary<string, object>
                        {
                            {LogEventKeys.StatusCode, responseMessage.StatusCode},
                            {LogEventKeys.Content, responseMessage.Content}
                        }
                    }
                };

                _logger.LogAsWarning(LogEventNames.CreditLockPaasClient.Get.InvalidResponse, extraData);

                throw new CustomerGetRequestException();
            }

            _logger.LogAsInformation(LogEventNames.CreditLockPaasClient.Get.Exit);

            return response.Data.FirstOrDefault();
        }

        public async Task Post(PostCustomerRequest postCustomerRequest)
        {
            _logger.LogAsInformation(LogEventNames.CreditLockPaasClient.Post.Enter);

            if (postCustomerRequest == null)
                throw new ArgumentNullException(nameof(postCustomerRequest));

            _logger.LogAsInformation(LogEventNames.CreditLockPaasClient.Post.SendRequest);
            var responseMessage = await SendRequest(CustomerPaasEndPoint, JsonConvert.SerializeObject(postCustomerRequest), HttpMethod.Post, false, postCustomerRequest.CustomerId);

            if (responseMessage.StatusCode == HttpStatusCode.Forbidden)
            {
                _logger.LogAsInformation(LogEventNames.CreditLockPaasClient.Post.SendRequestRegenToken);
                responseMessage = await SendRequest(CustomerPaasEndPoint, JsonConvert.SerializeObject(postCustomerRequest), HttpMethod.Post, true, postCustomerRequest.CustomerId);
            }

            if (responseMessage.StatusCode != HttpStatusCode.NoContent)
            {
                var extraData = new Dictionary<string, object>
                {
                    {LogEventKeys.CustomerId, postCustomerRequest.CustomerId},
                    {
                        LogEventKeys.Context, new Dictionary<string, object>
                        {
                            {LogEventKeys.StatusCode, responseMessage.StatusCode},
                            {LogEventKeys.Content, responseMessage.Content}
                        }
                    }
                };

                _logger.LogAsWarning(LogEventNames.CreditLockPaasClient.Post.ResponseInvalidStatusCode, extraData);

                responseMessage.StatusCode.CheckForCommonError();
            }

            _logger.LogAsInformation(LogEventNames.CreditLockPaasClient.Post.Exit);
        }

        public async Task Put(PutCustomerRequest putCustomerRequest)
        {
            _logger.LogAsInformation(LogEventNames.CreditLockPaasClient.Put.Enter);

            if (putCustomerRequest == null)
                throw new ArgumentNullException(nameof(putCustomerRequest));

            _logger.LogAsInformation(LogEventNames.CreditLockPaasClient.Put.SendRequest);

            var responseMessage = await SendRequest(CustomerPaasEndPoint, JsonConvert.SerializeObject(putCustomerRequest), HttpMethod.Put, false, putCustomerRequest.CustomerId);

            if (responseMessage.StatusCode == HttpStatusCode.Forbidden)
            {
                _logger.LogAsInformation(LogEventNames.CreditLockPaasClient.Put.SendRequestRegenToken);
                responseMessage = await SendRequest(CustomerPaasEndPoint, JsonConvert.SerializeObject(putCustomerRequest), HttpMethod.Put, true, putCustomerRequest.CustomerId);
            }

            if (responseMessage.StatusCode != HttpStatusCode.NoContent)
            {
                var extraData = new Dictionary<string, object>
                {
                    {LogEventKeys.CustomerId, putCustomerRequest.CustomerId},
                    {
                        LogEventKeys.Context, new Dictionary<string, object>
                        {
                            {LogEventKeys.StatusCode, responseMessage.StatusCode},
                            {LogEventKeys.Content, responseMessage.Content}
                        }
                    }
                };

                _logger.LogAsWarning(LogEventNames.CreditLockPaasClient.Put.ResponseInvalidStatusCode, extraData);

                responseMessage.StatusCode.CheckForCommonError();
            }

            _logger.LogAsInformation(LogEventNames.CreditLockPaasClient.Put.Exit);
        }

        public async Task Delete(DeleteCustomerRequest deleteCustomerRequest)
        {
            _logger.LogAsInformation(LogEventNames.CreditLockPaasClient.Delete.Enter);

            if (deleteCustomerRequest == null)
                throw new ArgumentNullException(nameof(deleteCustomerRequest));

            if (string.IsNullOrWhiteSpace(deleteCustomerRequest.CustomerRef))
                throw new ArgumentNullException(nameof(deleteCustomerRequest.CustomerRef));

            var deleteCustomerEndpoint = $"{CustomerPaasEndPoint}/{ECSClientId}/{deleteCustomerRequest.CustomerRef}";

            _logger.LogAsInformation(LogEventNames.CreditLockPaasClient.Delete.SendRequest);

            var responseMessage = await SendRequest(deleteCustomerEndpoint, string.Empty, HttpMethod.Delete, false, deleteCustomerRequest.CustomerId);

            if (responseMessage.StatusCode == HttpStatusCode.Forbidden)
            {
                _logger.LogAsInformation(LogEventNames.CreditLockPaasClient.Delete.SendRequestRegenToken);
                responseMessage = await SendRequest(deleteCustomerEndpoint, string.Empty, HttpMethod.Delete, true, deleteCustomerRequest.CustomerId);
            }

            if (responseMessage.StatusCode != HttpStatusCode.NoContent)
            {
                var extraData = new Dictionary<string, object>
                {
                    {LogEventKeys.IconRef, deleteCustomerRequest.CustomerRef},
                    {
                        LogEventKeys.Context, new Dictionary<string, object>
                        {
                            {LogEventKeys.StatusCode, responseMessage.StatusCode},
                            {LogEventKeys.Content, responseMessage.Content}
                        }
                    }
                };

                _logger.LogAsWarning(LogEventNames.CreditLockPaasClient.Delete.ResponseInvalidStatusCode, extraData);

                responseMessage.StatusCode.CheckForCommonError();
            }

            _logger.LogAsInformation(LogEventNames.CreditLockPaasClient.Delete.Exit);
        }

        public async Task PutLockStatus(PutLockStatusRequest putLockStatusRequest)
        {
            _logger.LogAsInformation(LogEventNames.CreditLockPaasClient.PutLockStatus.Enter);

            if (putLockStatusRequest == null)
                throw new ArgumentNullException(nameof(putLockStatusRequest));

            _logger.LogAsInformation(LogEventNames.CreditLockPaasClient.PutLockStatus.SendRequest);

            var putLockStatusPaasEndPoint = $"{LockPaasEndPoint}/{ECSClientId}/{putLockStatusRequest.CustomerRef}";

            var json = JsonConvert.SerializeObject(putLockStatusRequest);
            var responseMessage = await SendRequest(putLockStatusPaasEndPoint, json, HttpMethod.Put, false, putLockStatusRequest.CustomerId);

            if (responseMessage.StatusCode == HttpStatusCode.Forbidden)
            {
                _logger.LogAsInformation(LogEventNames.CreditLockPaasClient.PutLockStatus.SendRequestRegenToken);
                responseMessage = await SendRequest(putLockStatusPaasEndPoint, json, HttpMethod.Put, true, putLockStatusRequest.CustomerId);
            }

            if (responseMessage.StatusCode != HttpStatusCode.NoContent)
            {
                var extraData = new Dictionary<string, object>
                {
                    {LogEventKeys.IconRef, putLockStatusRequest.CustomerRef},
                    {
                        LogEventKeys.Context, new Dictionary<string, object>
                        {
                            {LogEventKeys.StatusCode, responseMessage.StatusCode},
                            {LogEventKeys.Content, responseMessage.Content}
                        }
                    }
                };

                _logger.LogAsWarning(LogEventNames.CreditLockPaasClient.PutLockStatus.ResponseInvalidStatusCode, extraData);

                responseMessage.StatusCode.CheckForCommonError();
            }

            _logger.LogAsInformation(LogEventNames.CreditLockPaasClient.PutLockStatus.Exit);
        }

        public async Task PutAlertStatus(PutAlertStatusRequest putAlertStatusRequest)
        {
            _logger.LogAsInformation(LogEventNames.CreditLockPaasClient.PostAlertStatus.Enter);

            if (putAlertStatusRequest == null)
                throw new ArgumentNullException(nameof(putAlertStatusRequest));

            _logger.LogAsInformation(LogEventNames.CreditLockPaasClient.PostAlertStatus.SendRequest);

            var postAlertStatusPaasEndPoint = $"{AlertPaaSEndPoint}/{ECSClientId}/{putAlertStatusRequest.CustomerRef}";

            var json = JsonConvert.SerializeObject(putAlertStatusRequest);
            var responseMessage = await SendRequest(postAlertStatusPaasEndPoint, json, HttpMethod.Put, false, putAlertStatusRequest.CustomerId);

            if (responseMessage.StatusCode == HttpStatusCode.Forbidden)
            {
                _logger.LogAsInformation(LogEventNames.CreditLockPaasClient.PostAlertStatus.SendRequestRegenToken);
                responseMessage = await SendRequest(postAlertStatusPaasEndPoint, json, HttpMethod.Put, true, putAlertStatusRequest.CustomerId);
            }

            if (responseMessage.StatusCode != HttpStatusCode.NoContent)
            {
                var extraData = new Dictionary<string, object>
                {
                    {LogEventKeys.IconRef, putAlertStatusRequest.CustomerRef},
                    {
                        LogEventKeys.Context, new Dictionary<string, object>
                        {
                            {LogEventKeys.StatusCode, responseMessage.StatusCode},
                            {LogEventKeys.Content, responseMessage.Content}
                        }
                    }
                };

                _logger.LogAsWarning(LogEventNames.CreditLockPaasClient.PostAlertStatus.ResponseInvalidStatusCode, extraData);

                responseMessage.StatusCode.CheckForCommonError();
            }

            _logger.LogAsInformation(LogEventNames.CreditLockPaasClient.PostAlertStatus.Exit);
        }

        private async Task<HttpResponseMessage> SendRequest(string paasEndPoint, string jsonStringContent, HttpMethod httpMethod, bool refreshToken, string customerId)
        {
            _logger.LogAsInformation(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Enter);

            var oktaToken = await _oktaClient.GetAuthTokenAsync(refreshToken);

            if (string.IsNullOrWhiteSpace(oktaToken))
                throw new OktaTokenNullException($"{nameof(oktaToken)} cannot be null or whitespace");

            var currentRetry = 0;

            for (;;)
            {
                try
                {
                    var requestMessage = new HttpRequestMessage
                    {
                        RequestUri = new Uri($"{_oktaAuthCredentials.ServiceEndpoint}/{paasEndPoint}"),
                        Content = new StringContent(jsonStringContent, Encoding.UTF8, "application/json"),
                        Method = httpMethod,
                        Headers = { Authorization = new AuthenticationHeaderValue("Bearer", oktaToken) }
                    };

                    requestMessage.Headers.Add("x-customerId", customerId);

                    return await _httpClient.SendAsync(requestMessage);
                }
                catch (HttpRequestException e)
                {
                    _logger.LogAsInformation(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry);

                    currentRetry++;

                    if (currentRetry > MaxRetryCount || !IsTransient(e))
                    {
                        _logger.LogAsWarning(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException);

                        throw new HttpServiceRequestException($"PaaS Service not reached: {e.GetBaseException().Message}",
                            e.GetBaseException());
                    }

                    await Task.Delay(100);

                    _logger.LogAsInformation(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry);
                }
                catch (TaskCanceledException e)
                {
                    _logger.LogAsWarning(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException);

                    throw new ServiceTaskCanceledException(
                        $"PaaS Service Task Canceled: {e.GetBaseException().Message}");
                }
            }
        }

        private static bool IsTransient(Exception ex)
        {
            return ex is HttpRequestException && ex.GetBaseException() is IOException;
        }
    }
}