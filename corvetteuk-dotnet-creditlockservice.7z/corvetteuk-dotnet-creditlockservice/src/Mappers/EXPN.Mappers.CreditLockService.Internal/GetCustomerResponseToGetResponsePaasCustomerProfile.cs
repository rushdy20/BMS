﻿using AutoMapper;
using EXPN.Models.CreditLockService.Paas.Get.Response;
using GetCustomerResponse = EXPN.Models.CreditLockService.Internal.Get.Response.GetCustomerResponse;
using GetResponsePaasAddressResponse = EXPN.Models.CreditLockService.Internal.Get.Response.GetResponsePaasAddressResponse;
using GetResponsePaasCustomerName = EXPN.Models.CreditLockService.Internal.Get.Response.GetResponsePaasCustomerName;

namespace EXPN.Mappers.CreditLockService.Internal
{
    public class GetCustomerResponseToGetResponsePaasCustomerProfile : Profile
    {
        public GetCustomerResponseToGetResponsePaasCustomerProfile()
        {
            AllowNullCollections = true;

            CreateMap<Models.CreditLockService.Paas.Get.Response.GetCustomerResponse, GetCustomerResponse>(MemberList.None)
                .ForMember(d => d.Addresses, m => m.MapFrom(s => s.Addresses))
                .ForMember(d => d.AlertsStatus, m => m.MapFrom(s => s.AlertsStatus))
                .ForMember(d => d.ClientId, m => m.MapFrom(s => s.ClientId))
                .ForMember(d => d.CustomerId, m => m.MapFrom(s => s.CustomerId))
                .ForMember(d => d.Dob, m => m.MapFrom(s => s.DateOfBirth))
                .ForMember(d => d.LockStatus, m => m.MapFrom(s => s.LockStatus))
                .ForMember(d => d.CustomerName, m => m.MapFrom(s => s.Name));

            CreateMap<PaasCustomerName, GetResponsePaasCustomerName>(MemberList.None)
                .ForMember(d => d.FirstName, m => m.MapFrom(s => s.Forename))
                .ForMember(d => d.LastName, m => m.MapFrom(s => s.Surname))
                .ForMember(d => d.OtherName, m => m.MapFrom(s => s.MiddleName))
                .ForMember(d => d.Suffix, m => m.MapFrom(s => s.Suffix))
                .ForMember(d => d.Title, m => m.MapFrom(s => s.Title));

            CreateMap<AddressResponse, GetResponsePaasAddressResponse>(MemberList.None);
        }
    }
}