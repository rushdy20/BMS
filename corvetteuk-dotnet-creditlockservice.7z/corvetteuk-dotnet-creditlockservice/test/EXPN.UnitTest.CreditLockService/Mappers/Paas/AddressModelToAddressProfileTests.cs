﻿using AutoMapper;
using EXPN.Mappers.CreditLockService.Paas;
using EXPN.Models.CreditLockService.Internal.Get.Response;
using EXPN.Models.CreditLockService.Paas;
using FluentAssertions;
using System;
using System.Collections.Generic;
using Xunit;

namespace EXPN.UnitTest.CreditLockService.Mappers.Paas
{
    public class AddressModelToAddressProfileTests
    {
        private readonly MapperConfiguration _mapperConfiguration;

        public AddressModelToAddressProfileTests()
        {
            _mapperConfiguration = new MapperConfiguration(
                cfg =>
                {
                    cfg.AddProfile<AddressModelToAddressProfile>();
                });
        }

        [Fact]
        public void ModelProfile_AssertConfiguration_IsValid()
        {
            _mapperConfiguration.AssertConfigurationIsValid();
        }

        public static IEnumerable<object[]> MappingData()
        {
            yield return new object[]
            {
                null,
                null
            };

            yield return new object[]
            {
                new GetResponseCustomerAddressModel(),
                new Address()
            };

            yield return new object[]
            {
                new GetResponseCustomerAddressModel
                {
                    Abroad = false,
                    AddressType = "AT",
                    City = "city",
                    Country = "country",
                    County = "county",
                    District = "district",
                    Flat = "flat",
                    FromDt = new DateTime(2010, 12, 31),
                    HouseName = "housename",
                    HouseNumber = "housenumber",
                    IsVerified = false,
                    LastUpdatedDt = new DateTime(2020, 9,30),
                    Manual = false,
                    PostCode = "postcode",
                    Street = "street",
                    ToDt = null
                },
                new Address
                {
                    County = "county",
                    Street = "street",
                    Flat = "flat",
                    HouseName = "housename",
                    HouseNumber = "housenumber",
                    Postcode = "postcode",
                    Town = "city",
                    District = "district"
                }
            };

            yield return new object[]
            {
                new GetResponseCustomerAddressModel
                {
                    Abroad = false,
                    AddressType = "c",
                    City = "city",
                    Country = "country",
                    County = "county",
                    District = "district",
                    Flat = "flat",
                    FromDt = new DateTime(2010, 12, 31),
                    HouseName = "housename",
                    HouseNumber = "housenumber",
                    IsCurrent = true,
                    IsVerified = false,
                    LastUpdatedDt = new DateTime(2020, 9,30),
                    Manual = false,
                    PostCode = "postcode",
                    Street = "street",
                    ToDt = null
                },
                new Address
                {
                    County = "county",
                    Street = "street",
                    Flat = "flat",
                    HouseName = "housename",
                    HouseNumber = "housenumber",
                    IsCurrent = true,
                    Postcode = "postcode",
                    Town = "city",
                    District = "district"
                }
            };

            yield return new object[]
            {
                new GetResponseCustomerAddressModel
                {
                    Abroad = false,
                    AddressType = "C",
                    City = "city",
                    Country = "country",
                    County = "county",
                    District = "district",
                    Flat = "flat",
                    FromDt = new DateTime(2010, 12, 31),
                    HouseName = "housename",
                    HouseNumber = "housenumber",
                    IsCurrent = true,
                    IsVerified = false,
                    LastUpdatedDt = new DateTime(2020, 9,30),
                    Manual = false,
                    PostCode = "postcode",
                    Street = "street",
                    ToDt = null
                },
                new Address
                {
                    County = "county",
                    Street = "street",
                    Flat = "flat",
                    HouseName = "housename",
                    HouseNumber = "housenumber",
                    IsCurrent = true,
                    Postcode = "postcode",
                    Town = "city",
                    District = "district"
                }
            };
        }

        [Theory]
        [MemberData(nameof(MappingData))]
        public void ExternalModelProfile_ExampleInput_MapsCorrectly(GetResponseCustomerAddressModel input, Address expected)
        {
            var mapper = _mapperConfiguration.CreateMapper();
            var result = mapper.Map<Address>(input);

            result.Should().BeEquivalentTo(expected);
        }
    }
}
