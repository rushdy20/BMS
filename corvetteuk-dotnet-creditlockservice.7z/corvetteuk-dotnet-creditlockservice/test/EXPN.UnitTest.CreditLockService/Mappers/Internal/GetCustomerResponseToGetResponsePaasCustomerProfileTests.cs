﻿using AutoMapper;
using EXPN.Mappers.CreditLockService.Internal;
using EXPN.Models.CreditLockService.Internal.Get.Response;
using EXPN.Models.CreditLockService.Paas.Get.Response;
using FluentAssertions;
using System;
using System.Collections.Generic;
using Xunit;
using GetCustomerResponse = EXPN.Models.CreditLockService.Internal.Get.Response.GetCustomerResponse;

namespace EXPN.UnitTest.CreditLockService.Mappers.Internal
{
    public class GetCustomerResponseToGetResponsePaasCustomerProfileTests
    {
        private readonly MapperConfiguration _mapperConfiguration;

        public GetCustomerResponseToGetResponsePaasCustomerProfileTests()
        {
            _mapperConfiguration = new MapperConfiguration(
                cfg => { cfg.AddProfile<GetCustomerResponseToGetResponsePaasCustomerProfile>(); });
        }

        [Fact]
        public void ModelProfile_AssertConfiguration_IsValid()
        {
            _mapperConfiguration.AssertConfigurationIsValid();
        }

        public static IEnumerable<object[]> MappingData()
        {
            yield return new object[]
            {
                null,
                null
            };

            yield return new object[]
            {
                new Models.CreditLockService.Paas.Get.Response.GetCustomerResponse(),
                new GetCustomerResponse()
            };

            yield return new object[]
            {
                new Models.CreditLockService.Paas.Get.Response.GetCustomerResponse
                {
                    Addresses = new AddressResponse[] {}
                },
                new GetCustomerResponse
                {
                    Addresses = new List<GetResponsePaasAddressResponse>()
                }
            };

            yield return new object[]
            {
                new Models.CreditLockService.Paas.Get.Response.GetCustomerResponse
                {
                    Addresses = new[]
                    {
                        new AddressResponse()
                    }
                },
                new GetCustomerResponse
                {
                    Addresses = new List<GetResponsePaasAddressResponse>
                    {
                        new GetResponsePaasAddressResponse()
                    }
                }
            };

            yield return new object[]
            {
                new Models.CreditLockService.Paas.Get.Response.GetCustomerResponse
                {
                    Addresses = new[]
                    {
                        new AddressResponse
                        {
                            County = "county",
                            Din = "din",
                            Flat = "flat",
                            HouseName = "houseName",
                            HouseNumber = "houseNumber",
                            PinErrorCode = "pinErrorCode",
                            PinStatus = "pinStatus",
                            Postcode = "postcode",
                            Street = "street",
                            Town = "town"
                        }
                    }
                },
                new GetCustomerResponse
                {
                    Addresses = new List<GetResponsePaasAddressResponse>
                    {
                        new GetResponsePaasAddressResponse
                        {
                            County = "county",
                            Din = "din",
                            Flat = "flat",
                            HouseName = "houseName",
                            HouseNumber = "houseNumber",
                            PinErrorCode = "pinErrorCode",
                            PinStatus = "pinStatus",
                            Postcode = "postcode",
                            Street = "street",
                            Town = "town"
                        }
                    }
                }
            };

            yield return new object[]
            {
                new Models.CreditLockService.Paas.Get.Response.GetCustomerResponse
                {
                    Addresses = new[]
                    {
                        new AddressResponse
                        {
                            County = "county1",
                            Din = "din1",
                            Flat = "flat1",
                            HouseName = "houseName1",
                            HouseNumber = "houseNumber1",
                            PinErrorCode = "pinErrorCode1",
                            PinStatus = "pinStatus1",
                            Postcode = "postcode1",
                            Street = "street1",
                            Town = "town1"
                        },
                        new AddressResponse
                        {
                            County = "county2",
                            Din = "din2",
                            Flat = "flat2",
                            HouseName = "houseName2",
                            HouseNumber = "houseNumber2",
                            PinErrorCode = "pinErrorCode2",
                            PinStatus = "pinStatus2",
                            Postcode = "postcode2",
                            Street = "street2",
                            Town = "town2"
                        },
                        new AddressResponse
                        {
                            County = "county3",
                            Din = "din3",
                            Flat = "flat3",
                            HouseName = "houseName3",
                            HouseNumber = "houseNumber3",
                            PinErrorCode = "pinErrorCode3",
                            PinStatus = "pinStatus3",
                            Postcode = "postcode3",
                            Street = "street3",
                            Town = "town3"
                        }
                    }
                },
                new GetCustomerResponse
                {
                    Addresses = new List<GetResponsePaasAddressResponse>
                    {
                        new GetResponsePaasAddressResponse
                        {
                            County = "county1",
                            Din = "din1",
                            Flat = "flat1",
                            HouseName = "houseName1",
                            HouseNumber = "houseNumber1",
                            PinErrorCode = "pinErrorCode1",
                            PinStatus = "pinStatus1",
                            Postcode = "postcode1",
                            Street = "street1",
                            Town = "town1"
                        },
                        new GetResponsePaasAddressResponse
                        {
                            County = "county2",
                            Din = "din2",
                            Flat = "flat2",
                            HouseName = "houseName2",
                            HouseNumber = "houseNumber2",
                            PinErrorCode = "pinErrorCode2",
                            PinStatus = "pinStatus2",
                            Postcode = "postcode2",
                            Street = "street2",
                            Town = "town2"
                        },
                        new GetResponsePaasAddressResponse
                        {
                            County = "county3",
                            Din = "din3",
                            Flat = "flat3",
                            HouseName = "houseName3",
                            HouseNumber = "houseNumber3",
                            PinErrorCode = "pinErrorCode3",
                            PinStatus = "pinStatus3",
                            Postcode = "postcode3",
                            Street = "street3",
                            Town = "town3"
                        }
                    }
                }
            };

            yield return new object[]
            {
                new Models.CreditLockService.Paas.Get.Response.GetCustomerResponse
                {
                    Name = new PaasCustomerName()
                },
                new GetCustomerResponse
                {
                    CustomerName = new GetResponsePaasCustomerName()
                }
            };

            yield return new object[]
            {
                new Models.CreditLockService.Paas.Get.Response.GetCustomerResponse
                {
                    Name = new PaasCustomerName()
                    {
                        Forename = "firstName",
                        Surname = "lastName",
                        MiddleName = "otherName",
                        Suffix = "suffix",
                        Title = "title"
                    }
                },
                new GetCustomerResponse
                {
                    CustomerName = new GetResponsePaasCustomerName
                    {
                        FirstName = "firstName",
                        LastName = "lastName",
                        OtherName = "otherName",
                        Suffix = "suffix",
                        Title = "title"
                    }
                }
            };

            yield return new object[]
            {
                new Models.CreditLockService.Paas.Get.Response.GetCustomerResponse
                {
                    AlertsStatus = "alertStatus",
                    ClientId = "clientId",
                    CustomerId = "customerId",
                    DateOfBirth = new DateTime(1990, 12, 31),
                    LockStatus = "lockStatus",
                    Name = new PaasCustomerName()
                    {
                        Forename = "firstName",
                        Surname = "lastName",
                        MiddleName = "otherName",
                        Suffix = "suffix",
                        Title = "title"
                    },
                    Addresses = new[]
                    {
                        new AddressResponse
                        {
                            County = "county1",
                            Din = "din1",
                            Flat = "flat1",
                            HouseName = "houseName1",
                            HouseNumber = "houseNumber1",
                            PinErrorCode = "pinErrorCode1",
                            PinStatus = "pinStatus1",
                            Postcode = "postcode1",
                            Street = "street1",
                            Town = "town1"
                        },
                        new AddressResponse
                        {
                            County = "county2",
                            Din = "din2",
                            Flat = "flat2",
                            HouseName = "houseName2",
                            HouseNumber = "houseNumber2",
                            PinErrorCode = "pinErrorCode2",
                            PinStatus = "pinStatus2",
                            Postcode = "postcode2",
                            Street = "street2",
                            Town = "town2"
                        },
                        new AddressResponse
                        {
                            County = "county3",
                            Din = "din3",
                            Flat = "flat3",
                            HouseName = "houseName3",
                            HouseNumber = "houseNumber3",
                            PinErrorCode = "pinErrorCode3",
                            PinStatus = "pinStatus3",
                            Postcode = "postcode3",
                            Street = "street3",
                            Town = "town3"
                        }
                    }
                },
                new GetCustomerResponse
                {                    
                    AlertsStatus = "alertStatus",
                    ClientId = "clientId",
                    CustomerId = "customerId",
                    Dob = new DateTime(1990, 12, 31),
                    LockStatus = "lockStatus",
                    CustomerName = new GetResponsePaasCustomerName
                    {
                        FirstName = "firstName",
                        LastName = "lastName",
                        OtherName = "otherName",
                        Suffix = "suffix",
                        Title = "title"
                    },
                    Addresses = new List<GetResponsePaasAddressResponse>
                    {
                        new GetResponsePaasAddressResponse
                        {
                            County = "county1",
                            Din = "din1",
                            Flat = "flat1",
                            HouseName = "houseName1",
                            HouseNumber = "houseNumber1",
                            PinErrorCode = "pinErrorCode1",
                            PinStatus = "pinStatus1",
                            Postcode = "postcode1",
                            Street = "street1",
                            Town = "town1"
                        },
                        new GetResponsePaasAddressResponse
                        {
                            County = "county2",
                            Din = "din2",
                            Flat = "flat2",
                            HouseName = "houseName2",
                            HouseNumber = "houseNumber2",
                            PinErrorCode = "pinErrorCode2",
                            PinStatus = "pinStatus2",
                            Postcode = "postcode2",
                            Street = "street2",
                            Town = "town2"
                        },
                        new GetResponsePaasAddressResponse
                        {
                            County = "county3",
                            Din = "din3",
                            Flat = "flat3",
                            HouseName = "houseName3",
                            HouseNumber = "houseNumber3",
                            PinErrorCode = "pinErrorCode3",
                            PinStatus = "pinStatus3",
                            Postcode = "postcode3",
                            Street = "street3",
                            Town = "town3"
                        }
                    }
                }
            };
        }
        
        [Theory]
        [MemberData(nameof(MappingData))]
        public void ExternalModelProfile_ExampleInput_MapsCorrectly(Models.CreditLockService.Paas.Get.Response.GetCustomerResponse input, GetCustomerResponse expected)
        {
            var mapper = _mapperConfiguration.CreateMapper();
            var result = mapper.Map<GetCustomerResponse>(input);

            result.Should().BeEquivalentTo(expected);
        }
    }
}