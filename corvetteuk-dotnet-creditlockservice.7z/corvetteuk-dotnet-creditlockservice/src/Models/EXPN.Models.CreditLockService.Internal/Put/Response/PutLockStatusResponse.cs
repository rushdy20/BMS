﻿namespace EXPN.Models.CreditLockService.Internal.Put.Response
{
    public class PutLockStatusResponse
    {
        public string LockStatus { get; set; }
    }
}