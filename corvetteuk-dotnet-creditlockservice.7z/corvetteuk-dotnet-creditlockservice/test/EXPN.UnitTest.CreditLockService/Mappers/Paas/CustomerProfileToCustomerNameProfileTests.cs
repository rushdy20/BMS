﻿using System.Collections.Generic;
using AutoMapper;
using EXPN.Mappers.CreditLockService.Paas;
using EXPN.Models.CreditLockService.Internal.Get.Response;
using EXPN.Models.CreditLockService.Paas;
using FluentAssertions;
using Xunit;

namespace EXPN.UnitTest.CreditLockService.Mappers.Paas
{
    public class CustomerProfileToCustomerNameProfileTests
    {
        private readonly MapperConfiguration _mapperConfiguration;

        public CustomerProfileToCustomerNameProfileTests()
        {
            _mapperConfiguration = new MapperConfiguration(
                cfg =>
                {
                    cfg.AddProfile<CustomerProfileToCustomerNameProfile>();
                });
        }

        [Fact]
        public void ModelProfile_AssertConfiguration_IsValid()
        {
            _mapperConfiguration.AssertConfigurationIsValid();
        }

        public static IEnumerable<object[]> MappingData()
        {
            yield return new object[]
            {
                null,
                null
            };

            yield return new object[]
            {
                new GetResponseCustomerProfile(),
                new CustomerName(), 
            };

            yield return new object[]
            {
                new GetResponseCustomerProfile
                {
                    CustomerId = "A1234",
                    CorrelationId = "XYZ",
                    DOB = "2000-12-31",
                    FirstName = "FirstName",
                    MiddleName = "MiddleName",
                    Title = "Title",
                    LastName = "LastName"
                },
                new CustomerName
                {
                    FirstName = "FirstName",
                    LastName = "LastName",
                    OtherName = "MiddleName",
                    Title = "Title"
                }
            };
        }

        [Theory]
        [MemberData(nameof(MappingData))]
        public void ExternalModelProfile_ExampleInput_MapsCorrectly(GetResponseCustomerProfile input, CustomerName expected)
        {
            var mapper = _mapperConfiguration.CreateMapper();
            var result = mapper.Map<CustomerName>(input);

            result.Should().BeEquivalentTo(expected);
        }
    }
}
