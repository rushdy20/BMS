﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace EXPN.Models.CreditLockService.Internal.Get.Response
{
    [ExcludeFromCodeCoverage]
    public class GetResponseCustomerAddressModel
    {
        public string AddressType { get; set; }

        public string City { get; set; }

        public string Country { get; set; }

        public string County { get; set; }

        public string District { get; set; }

        public string Flat { get; set; }

        public string HouseNumber { get; set; }

        public string HouseName { get; set; }

        public bool IsVerified { get; set; }

        public bool Manual { get; set; }

        public bool Abroad { get; set; }

        public string PostCode { get; set; }

        public string Street { get; set; }

        public DateTime LastUpdatedDt { get; set; }

        public DateTime FromDt { get; set; }

        public DateTime? ToDt { get; set; }

        public bool IsCurrent { get; set; }
    }
}