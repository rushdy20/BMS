﻿using System;
using System.Collections.Generic;
using EXPN.BusinessLayer.CreditLockService.Extension;
using EXPN.Models.CreditLockService.Paas;
using EXPN.Models.CreditLockService.Paas.Put.Request;
using FluentAssertions;
using Xunit;

namespace EXPN.UnitTest.CreditLockService.BusinessLayer.Extenstion
{
    public class SyncCustomerExtenstionTests
    {
        public static IEnumerable<object[]> TestParameters()
        {
            yield return new object[]
            {
                new PutCustomerRequest(),
                false
            };

            yield return new object[]
            {
                new PutCustomerRequest
                {
                    IconRef = "abc",
                    ClientId = "ECS",
                    CustomerId = "ABC"
                },
                false
            };

            yield return new object[]
            {
                new PutCustomerRequest
                {
                    IconRef = "abc",
                    ClientId = "ECS",
                    CustomerId = "ABC",
                    Dob = new DateTime(1999,03,25)
                },
                true
            };

            yield return new object[]
            {
                new PutCustomerRequest
                {
                    IconRef = "abc",
                    ClientId = "ECS",
                    CustomerId = "ABC",
                    Name = new CustomerName
                    {
                        FirstName = "TestName"
                    }
                },
                true
            };

            yield return new object[]
            {
                new PutCustomerRequest
                {
                    IconRef = "abc",
                    ClientId = "ECS",
                    CustomerId = "ABC",
                    Name = new CustomerName
                    {
                        LastName = "TestName"
                    }
                },
                true
            };

            yield return new object[]
            {
                new PutCustomerRequest
                {
                    IconRef = "abc",
                    ClientId = "ECS",
                    CustomerId = "ABC",
                    Name = new CustomerName
                    {
                        Title = "Mr"
                    }
                },
                true
            };

            yield return new object[]
            {
                new PutCustomerRequest
                {
                    IconRef = "abc",
                    ClientId = "ECS",
                    CustomerId = "ABC",
                    Name = new CustomerName
                    {
                        OtherName = "TestName"
                    }
                },
                true
            };

            yield return new object[]
            {
                new PutCustomerRequest
                {
                    IconRef = "abc",
                    ClientId = "ECS",
                    CustomerId = "ABC",
                    AddressesToAdd = new List<PutCustomerAddressRequest>()
                },
                false
            };

            yield return new object[]
            {
                new PutCustomerRequest
                {
                    IconRef = "abc",
                    ClientId = "ECS",
                    CustomerId = "ABC",
                    AddressesToAdd = new List<PutCustomerAddressRequest>
                    {
                        new PutCustomerAddressRequest()
                    }
                },
                true
            };

            yield return new object[]
            {
                new PutCustomerRequest
                {
                    IconRef = "abc",
                    ClientId = "ECS",
                    CustomerId = "ABC",
                    AddressesToDelete = new List<string>()
                },
                false
            };

            yield return new object[]
            {
                new PutCustomerRequest
                {
                    IconRef = "abc",
                    ClientId = "ECS",
                    CustomerId = "ABC",
                    AddressesToDelete = new List<string>{"12345"}
                },
                true
            };
        }

        [Theory]
        [MemberData(nameof(TestParameters))]
        public void IsCustomerDetailsChanged(PutCustomerRequest putCustomerRequest,bool expected)
        {
          var isChanged =  putCustomerRequest.IsChanged();

          isChanged.Should().Be(expected);
        }
    }
}