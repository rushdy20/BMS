﻿using AutoMapper;
using EXPN.Mappers.CreditLockService.Paas;
using EXPN.Models.CreditLockService.Internal.Get.Response;
using EXPN.Models.CreditLockService.Paas.PutAlertStatus.Request;
using FluentAssertions;
using System.Collections.Generic;
using Xunit;

namespace EXPN.UnitTest.CreditLockService.Mappers.Paas
{
    public class CustomerProfileToPutAlertStatusRequestProfileTests
    {
        private readonly MapperConfiguration _mapperConfiguration;

        public CustomerProfileToPutAlertStatusRequestProfileTests()
        {
            _mapperConfiguration = new MapperConfiguration(
                cfg => { cfg.AddProfile<CustomerProfileToPutAlertStatusRequestProfile>(); });
        }

        [Fact]
        public void ModelProfile_AssertConfiguration_IsValid()
        {
            _mapperConfiguration.AssertConfigurationIsValid();
        }

        public static IEnumerable<object[]> MappingData()
        {
            yield return new object[]
            {
                null,
                null
            };
            yield return new object[]
            {
                new GetResponseCustomerProfile(),
                new PutAlertStatusRequest
                {
                    Status = "N"
                }
            };

            yield return new object[]
            {
                new GetResponseCustomerProfile
                {
                    CustomerId = "CustomerId",
                    CustomerRef = "CustomerRef"
                },
                new PutAlertStatusRequest
                {
                    CustomerId = "CustomerId",
                    CustomerRef = "CustomerRef",
                    Status = "N"
                }
            };

        }

        [Theory]
        [MemberData(nameof(MappingData))]
        public void CustomerProfileToPutAlertStatusRequestProfile_ExampleInput_MapsCorrectly(GetResponseCustomerProfile input, PutAlertStatusRequest expected)
        {
            var mapper = _mapperConfiguration.CreateMapper();
            var result = mapper.Map<PutAlertStatusRequest>(input);

            result.Should().BeEquivalentTo(expected);
        }
    }
}