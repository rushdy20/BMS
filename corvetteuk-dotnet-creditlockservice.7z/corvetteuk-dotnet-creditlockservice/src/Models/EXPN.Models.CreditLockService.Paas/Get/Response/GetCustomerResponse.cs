﻿using System;

namespace EXPN.Models.CreditLockService.Paas.Get.Response
{
    public class GetCustomerResponse
    {
        public string ClientId { get; set; }
        public string CustomerId { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public PaasCustomerName Name { get; set; }
        public string IconRef { get; set; }
        public string LockStatus { get; set; }
        public string AlertsStatus { get; set; }
        public AddressResponse[] Addresses { get; set; }
    }
}