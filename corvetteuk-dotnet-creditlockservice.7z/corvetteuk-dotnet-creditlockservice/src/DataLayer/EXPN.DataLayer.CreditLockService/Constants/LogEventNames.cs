﻿namespace EXPN.DataLayer.CreditLockService.Paas.Constants
{
    public struct LogEventNames
    {
        public struct OktaClient
        {
            public struct GetAuthTokenAsync
            {
                public const string RemoveOktaTokenFromMemoryCache = "OktaClient_GetAuthTokenAsync_RemoveOktaTokenFromMemoryCache";
                public const string RetrievedOktaTokenFromMemoryCache = "OktaClient_GetAuthTokenAsync_RetrievedOktaTokenFromMemoryCache";
                public const string AuthRequestSuccess = "OktaClient_GetAuthTokenAsync_AuthRequestSuccess";
                public const string AuthRequestFail = "OktaClient_GetAuthTokenAsync_AuthRequestFail";
                public const string AddOktaTokenToMemoryCache = "OktaClient_GetAuthTokenAsync_AddOktaTokenToMemoryCache";
                public const string FailedToStoreOktaTokenInMemoryCache = "OktaClient_GetAuthTokenAsync_FailedToStoreOktaTokenInMemoryCache";
                public const string OktaTokenFromInMemoryCache = "OktaClient_GetAuthTokenAsync_OktaTokenFromInMemoryCache";
            }
        }

        public struct CreditLockPaasClient
        {
            public struct Get
            {
                public const string Enter = "CreditLockPaasClient_Get_Enter";
                public const string SendRequest = "CreditLockPaasClient_Get_SendRequest";
                public const string SendRequestRegenToken = "CreditLockPaasClient_Get_SendRequestRegenToken";
                public const string ResponseInvalidStatusCode = "CreditLockPaasClient_Get_ResponseInvalidStatusCode";
                public const string Exit = "CreditLockPaasClient_Get_Exit";
                public const string InvalidResponse = "CreditLockPaasClient_Get_InvalidResponse";
            }

            public struct Post
            {
                public const string Enter = "CreditLockPaasClient_Post_Enter";
                public const string SendRequest = "CreditLockPaasClient_Post_SendRequest";
                public const string SendRequestRegenToken = "CreditLockPaasClient_Post_SendRequestRegenToken";
                public const string ResponseConflictStatusCode = "CreditLockPaasClient_Post_ResponseConflictStatusCode";
                public const string ResponseInvalidStatusCode = "CreditLockPaasClient_Post_ResponseInvalidStatusCode";
                public const string Exit = "CreditLockPaasClient_Post_Exit";
                public const string ResponseInternalServerErrorStatusCode = "CreditLockPaasClient_Post_InternalServerErrorStatusCode";
                public const string ServiceServiceUnavailableStatusCode = "CreditLockPaasClient_Post_ServiceUnavailableStatusCode";

            }

            public struct Put
            {
                public const string Enter = "CreditLockPaasClient_Put_Enter";
                public const string SendRequest = "CreditLockPaasClient_Put_SendRequest";
                public const string SendRequestRegenToken = "CreditLockPaasClient_Put_SendRequestRegenToken";
                public const string ResponseInvalidStatusCode = "CreditLockPaasClient_Put_ResponseInvalidStatusCode";
                public const string Exit = "CreditLockPaasClient_Put_Exit";
            }

            public struct Delete
            {
                public const string Enter = "CreditLockPaasClient_Delete_Enter";
                public const string SendRequest = "CreditLockPaasClient_Delete_SendRequest";
                public const string SendRequestRegenToken = "CreditLockPaasClient_Delete_SendRequestRegenToken";
                public const string ResponseInvalidStatusCode = "CreditLockPaasClient_Delete_ResponseInvalidStatusCode";
                public const string Exit = "CreditLockPaasClient_Delete_Exit";
            }

            public struct PutLockStatus
            {
                public const string Enter = "CreditLockPaasClient_PutLockStatus_Enter";
                public const string SendRequest = "CreditLockPaasClient_PutLockStatus_SendRequest";
                public const string SendRequestRegenToken = "CreditLockPaasClient_PutLockStatus_SendRequestRegenToken";
                public const string ResponseInvalidStatusCode = "CreditLockPaasClient_PutLockStatus_ResponseInvalidStatusCode";
                public const string Exit = "CreditLockPaasClient_PutLockStatus_Exit";
            }

            public struct PostAlertStatus
            {
                public const string Enter = "CreditLockPaasClient_PostAlertStatus_Enter";
                public const string SendRequest = "CreditLockPaasClient_PostAlertStatus_SendRequest";
                public const string SendRequestRegenToken = "CreditLockPaasClient_PostAlertStatus_SendRequestRegenToken";
                public const string ResponseInvalidStatusCode = "CreditLockPaasClient_PostAlertStatus_ResponseInvalidStatusCode";
                public const string Exit = "CreditLockPaasClient_PostAlertStatus_Exit";
            }

            public struct SendRequestToPaaS
            {
                public const string Enter = "CreditLockPaasClient_SendRequestToPaaS_Enter";
                public const string CheckRetry = "CreditLockPaasClient_SendRequestToPaaS_CheckRetry";
                public const string Retry = "CreditLockPaasClient_SendRequestToPaaS_Retry";
                public const string HttpRequestException = "CreditLockPaasClient_SendRequestToPaaS_HttpRequestException";
                public const string TaskCanceledException = "CreditLockPaasClient_SendRequestToPaaS_TaskCanceledException";
            }
        }
    }
}