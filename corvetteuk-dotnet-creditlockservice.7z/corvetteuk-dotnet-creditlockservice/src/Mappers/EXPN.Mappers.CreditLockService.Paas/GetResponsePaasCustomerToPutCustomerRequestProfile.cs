﻿using AutoMapper;
using EXPN.Mappers.CreditLockService.Paas.Actions;
using EXPN.Mappers.CreditLockService.Paas.Resolvers;
using EXPN.Models.CreditLockService.Internal.Get.Response;
using EXPN.Models.CreditLockService.Paas.Put.Request;
using System;
using System.Collections.Generic;

namespace EXPN.Mappers.CreditLockService.Paas
{
    public class GetResponsePaasCustomerToPutCustomerRequestProfile : Profile
    {
        public GetResponsePaasCustomerToPutCustomerRequestProfile()
        {
            AllowNullDestinationValues = true;
            AllowNullCollections = true;

            CreateMap<GetCustomerResponse, PutCustomerRequest>(MemberList.None)
                .ForMember(d => d.ClientId, m => m.UseDestinationValue())
                .ForMember(d => d.CustomerId, m => m.UseDestinationValue())
                .ForMember(d => d.Dob, m => m.MapFrom<DateToNullableDateResolver, DateTime>(s => s.Dob))
                .ForMember(d => d.Name, m => m.MapFrom<PutRequestCustomerNameResolver, GetResponsePaasCustomerName>(s => s.CustomerName))
                .ForMember(d => d.AddressesToAdd, m => m.MapFrom<PutRequestAddAddressResolver, IEnumerable<GetResponsePaasAddressResponse>>(s => s.Addresses))
                .ForMember(d => d.AddressesToDelete, m => m.MapFrom<PutRequestDeleteAddressResolver, IEnumerable<GetResponsePaasAddressResponse>>(s => s.Addresses))
                .AfterMap<SetPutCustomerRequestToNullIfNoChangesAction>();
        }
    }
}