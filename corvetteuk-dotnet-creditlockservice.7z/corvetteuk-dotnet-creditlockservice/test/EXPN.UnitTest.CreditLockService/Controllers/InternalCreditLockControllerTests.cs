using AutoMapper;
using Experian.ResponseModels;
using EXPN.BusinessLayer.CreditLockService;
using EXPN.BusinessLayer.CreditLockService.Exceptions;
using EXPN.Controllers.CreditLockService;
using EXPN.Controllers.CreditLockService.Constants;
using EXPN.Controllers.CreditLockService.DateTime;
using EXPN.Controllers.CreditLockService.Messaging;
using EXPN.DataLayer.CreditLockService.Common.Exceptions;
using EXPN.Models.CreditLockService.External.Delete.Request;
using EXPN.Models.CreditLockService.External.Post.Request;
using EXPN.Models.CreditLockService.Internal;
using EXPN.Models.CreditLockService.Internal.Put.Request;
using FluentAssertions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using NSubstitute;
using NSubstitute.ExceptionExtensions;
using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using Xunit;
using LogEventNames = EXPN.Controllers.CreditLockService.Constants.LogEventNames;

namespace EXPN.UnitTest.CreditLockService.Controllers
{
    public class InternalCreditLockControllerTests
    {
        private readonly ILogger<InternalCreditLockController> _logger;
        private readonly ICreditLockServiceCustomerManager _customerManager;
        private readonly IMessaging _messaging;
        private readonly IDateTime _dateTime;
        private readonly IMapper _mapper;

        private readonly InternalCreditLockController _internalController;

        private const int DownstreamMaintenanceStatusCode = 561;
        private const int DownstreamBadResponseStatusCode = 562;

        private const string EventName = "auditCreditLockRequest";

        public InternalCreditLockControllerTests()
        {
            _logger = Substitute.For<ILogger<InternalCreditLockController>>();
            _customerManager = Substitute.For<ICreditLockServiceCustomerManager>();
            _messaging = Substitute.For<IMessaging>();
            _dateTime = Substitute.For<IDateTime>();
            _mapper = Substitute.For<IMapper>();

            _dateTime.Now.Returns(new DateTime(2000, 12, 31, 23, 59, 59, 123));

            _internalController = new InternalCreditLockController(_logger, _customerManager, _messaging, _dateTime, _mapper);
        }

        public static IEnumerable<object[]> NullParameters()
        {
            yield return new object[]
            {
                null,
                Substitute.For<ICreditLockServiceCustomerManager>(),
                Substitute.For<IMessaging>(),
                Substitute.For<IDateTime>(),
                Substitute.For<IMapper>(),
                "logger"
            };

            yield return new object[]
            {
                Substitute.For<ILogger<InternalCreditLockController>>(),
                null,
                Substitute.For<IMessaging>(),
                Substitute.For<IDateTime>(),
                Substitute.For<IMapper>(),
                "customerManager"
            };

            yield return new object[]
            {
                Substitute.For<ILogger<InternalCreditLockController>>(),
                Substitute.For<ICreditLockServiceCustomerManager>(),
                null,
                Substitute.For<IDateTime>(),
                Substitute.For<IMapper>(),
                "messaging"
            };

            yield return new object[]
            {
                Substitute.For<ILogger<InternalCreditLockController>>(),
                Substitute.For<ICreditLockServiceCustomerManager>(),
                Substitute.For<IMessaging>(),
                null,
                Substitute.For<IMapper>(),
                "dateTime"
            };

            yield return new object[]
            {
                Substitute.For<ILogger<InternalCreditLockController>>(),
                Substitute.For<ICreditLockServiceCustomerManager>(),
                Substitute.For<IMessaging>(),
                Substitute.For<IDateTime>(),
                null,
                "mapper"
            };
        }

        [Theory]
        [MemberData(nameof(NullParameters))]
        public void Constructor_RequiredParameterNull_ThrowsArgumentNullException(
            ILogger<InternalCreditLockController> logger,
            ICreditLockServiceCustomerManager customerManager,
            IMessaging messaging,
            IDateTime dateTime,
            IMapper mapper,
            string expectedErrorParameter)
        {
            Action action = () =>
            {
                new InternalCreditLockController(logger, customerManager, messaging, dateTime, mapper);
            };

            action.Should().Throw<ArgumentNullException>()
                .Where(x => x.ParamName == expectedErrorParameter);
        }

        public class PostActivateAsync : InternalCreditLockControllerTests
        {
            [Fact]
            public async Task PostRequest_HappyPath_Success()
            {
                var customerId = "customerId";

                var postRequest = new PostRequest
                {
                    CustomerId = customerId
                };

                var customerRequest = new CustomerRequest
                {
                    CustomerId = customerId
                };

                _mapper.Map<CustomerRequest>(postRequest)
                    .Returns(customerRequest);

                var putLockStatusRequest = new PutLockStatusRequest
                {
                    CustomerId = customerId
                };

                _mapper.Map<PutLockStatusRequest>(postRequest)
                    .Returns(putLockStatusRequest);

                var requestDt = new DateTime(2020, 12, 31, 23, 59, 30, 987);

                _dateTime.Now.Returns(requestDt);

                var response = await _internalController.ActivateAsync(postRequest) as ObjectResult;

                response.Should().BeOfType<ApiResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.NoContent);

                _mapper.Received(1).Map<CustomerRequest>(postRequest);

                await _customerManager.Received(1).ActivateAsync(customerRequest);

                _mapper.Received(1).Map<PutLockStatusRequest>(postRequest);

                await _customerManager.Received(1).PutLockStatus(putLockStatusRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "204"
                    && x.ResponseStatusDescription == "Success"
                    && x.RequestType == "ACTIVATE_CREDITLOCK"
                    && x.RequestDt == requestDt
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.Invoked)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.Complete)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.DownstreamBadResponse)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.SyncCustomerPinningException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PostRequest_ModelStateInvalid_ReturnStatusBadRequest()
            {
                var request = new PostRequest
                {
                    CustomerId = "Not a Valid customer id"
                };

                _internalController.ModelState.AddModelError("Test", "TestError");

                var requestDt = new DateTime(2020, 12, 31, 23, 59, 45, 987);

                _dateTime.Now.Returns(requestDt);

                var response = await _internalController.ActivateAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.BadRequest);

                _mapper.DidNotReceive().Map<CustomerRequest>(request);

                await _customerManager.DidNotReceive().ActivateAsync(Arg.Any<CustomerRequest>());

                _mapper.DidNotReceive().Map<PutLockStatusRequest>(Arg.Any<PostRequest>());

                await _customerManager.DidNotReceive().PutLockStatus(Arg.Any<PutLockStatusRequest>());

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "400"
                    && x.ResponseStatusDescription == "Bad Request"
                    && x.RequestType == "ACTIVATE_CREDITLOCK"
                    && x.RequestDt == requestDt
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                   Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.OktaTokenNullException)), null,
                   Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.DownstreamBadResponse)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.SyncCustomerPinningException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PostActivate_Exception_ReturnStatusInternalServerError()
            {
                const string customerId = "4a1f51c5-e902-4efb-8366-816e29e788e7";

                var postSubscriptionRequest = new PostRequest
                {
                    CustomerId = customerId
                };

                var customerRequest = new CustomerRequest
                {
                    CustomerId = customerId
                };

                _mapper.Map<CustomerRequest>(postSubscriptionRequest)
                    .Returns(customerRequest);

                _customerManager.ActivateAsync(customerRequest)
                    .Throws(new OutOfMemoryException());

                var requestDt = new DateTime(2020, 12, 31, 23, 59, 45, 987);

                _dateTime.Now.Returns(requestDt);

                var response = await _internalController.ActivateAsync(postSubscriptionRequest) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.InternalServerError);

                _mapper.Received(1).Map<CustomerRequest>(postSubscriptionRequest);

                await _customerManager.Received(1).ActivateAsync(customerRequest);

                _mapper.DidNotReceive().Map<PutLockStatusRequest>(Arg.Any<PostRequest>());

                await _customerManager.DidNotReceive().PutLockStatus(Arg.Any<PutLockStatusRequest>());

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "500"
                    && x.ResponseStatusDescription == "Internal Server Error"
                    && x.RequestType == "ACTIVATE_CREDITLOCK"
                    && x.RequestDt == requestDt
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                   Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.OktaTokenNullException)), null,
                   Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.DownstreamBadResponse)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.SyncCustomerPinningException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PostActivate_CustomerNotFoundException_ReturnStatusNotFoundError()
            {
                const string customerId = "4a1f51c5-e902-4efb-8366-816e29e788e7";

                var postSubscriptionRequest = new PostRequest
                {
                    CustomerId = customerId
                };

                var customerRequest = new CustomerRequest
                {
                    CustomerId = customerId
                };

                _mapper.Map<CustomerRequest>(postSubscriptionRequest)
                    .Returns(customerRequest);

                _customerManager.ActivateAsync(customerRequest)
                    .Throws(new CustomerProfileNotFoundException());

                var requestDt = new DateTime(2020, 12, 31, 23, 59, 45, 987);

                _dateTime.Now.Returns(requestDt);

                var response = await _internalController.ActivateAsync(postSubscriptionRequest) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.NotFound);

                await _customerManager.Received(1).ActivateAsync(customerRequest);

                _mapper.Received(1).Map<CustomerRequest>(postSubscriptionRequest);

                _mapper.DidNotReceive().Map<PutLockStatusRequest>(Arg.Any<PostRequest>());

                await _customerManager.DidNotReceive().PutLockStatus(Arg.Any<PutLockStatusRequest>());

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "404"
                    && x.ResponseStatusDescription == "Corvette Customer Profile is not found"
                    && x.RequestType == "ACTIVATE_CREDITLOCK"
                    && x.RequestDt == requestDt
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                   Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.OktaTokenNullException)), null,
                   Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.DownstreamBadResponse)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.SyncCustomerPinningException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PostActivate_DownstreamAuthenticationException_ReturnStatus563()
            {
                const string customerId = "4a1f51c5-e902-4efb-8366-816e29e788e7";

                var postSubscriptionRequest = new PostRequest
                {
                    CustomerId = customerId
                };

                var customerRequest = new CustomerRequest
                {
                    CustomerId = customerId
                };

                _mapper.Map<CustomerRequest>(postSubscriptionRequest)
                    .Returns(customerRequest);

                _customerManager.ActivateAsync(customerRequest)
                    .Throws(new DownstreamAuthenticationException());

                var requestDt = new DateTime(2020, 12, 31, 23, 59, 45, 987);

                _dateTime.Now.Returns(requestDt);

                var response = await _internalController.ActivateAsync(postSubscriptionRequest) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be(563);

                await _customerManager.Received(1).ActivateAsync(customerRequest);

                _mapper.Received(1).Map<CustomerRequest>(postSubscriptionRequest);

                _mapper.DidNotReceive().Map<PutLockStatusRequest>(Arg.Any<PostRequest>());

                await _customerManager.DidNotReceive().PutLockStatus(Arg.Any<PutLockStatusRequest>());

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "563"
                    && x.ResponseStatusDescription == "Downstream Service Authentication Failed"
                    && x.RequestType == "ACTIVATE_CREDITLOCK"
                    && x.RequestDt == requestDt
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.DownstreamAuthenticationException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                   Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.OktaTokenNullException)), null,
                   Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.DownstreamBadResponse)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.SyncCustomerPinningException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PostActivate_OktaTokenNullException_ReturnBadGatewayError()
            {
                const string customerId = "4a1f51c5-e902-4efb-8366-816e29e788e7";

                var postSubscriptionRequest = new PostRequest
                {
                    CustomerId = customerId
                };

                var customerRequest = new CustomerRequest
                {
                    CustomerId = customerId
                };

                _mapper.Map<CustomerRequest>(postSubscriptionRequest)
                    .Returns(customerRequest);

                _customerManager.ActivateAsync(customerRequest)
                    .Throws(new OktaTokenNullException());

                var requestDt = new DateTime(2020, 7, 23, 21, 59, 30, 987);

                _dateTime.Now.Returns(requestDt);

                var response = await _internalController.ActivateAsync(postSubscriptionRequest) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.BadGateway);

                _mapper.Received(1).Map<CustomerRequest>(postSubscriptionRequest);

                await _customerManager.Received(1).ActivateAsync(customerRequest);

                _mapper.DidNotReceive().Map<PutLockStatusRequest>(Arg.Any<PostRequest>());

                await _customerManager.DidNotReceive().PutLockStatus(Arg.Any<PutLockStatusRequest>());

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "502"
                    && x.ResponseStatusDescription == "Bad Gateway"
                    && x.RequestType == "ACTIVATE_CREDITLOCK"
                    && x.RequestDt == requestDt
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.DownstreamBadResponse)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.SyncCustomerPinningException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PostActivate_InternalServerError_ReturnStatus561()
            {
                const string customerId = "4a1f51c5-e902-4efb-8366-816e29e788e7";

                var postSubscriptionRequest = new PostRequest
                {
                    CustomerId = customerId
                };

                var customerRequest = new CustomerRequest
                {
                    CustomerId = customerId
                };

                _mapper.Map<CustomerRequest>(postSubscriptionRequest)
                    .Returns(customerRequest);

                _customerManager.ActivateAsync(customerRequest)
                    .Throws(new DownstreamMaintenanceException());

                var requestDt = new DateTime(2020, 12, 31, 23, 59, 45, 987);

                _dateTime.Now.Returns(requestDt);

                var response = await _internalController.ActivateAsync(postSubscriptionRequest) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be(561);

                await _customerManager.Received(1).ActivateAsync(customerRequest);

                _mapper.Received(1).Map<CustomerRequest>(postSubscriptionRequest);

                _mapper.DidNotReceive().Map<PutLockStatusRequest>(Arg.Any<PostRequest>());

                await _customerManager.DidNotReceive().PutLockStatus(Arg.Any<PutLockStatusRequest>());

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "561"
                    && x.ResponseStatusDescription == "Downstream Service Unavailable - mainframe down for scheduled maintenance"
                    && x.RequestType == "ACTIVATE_CREDITLOCK"
                    && x.RequestDt == requestDt
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.DownstreamBadResponse)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.SyncCustomerPinningException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PostActivate_GatewayTimeoutException_ReturnStatus500()
            {
                const string customerId = "4a1f51c5-e902-4efb-8366-816e29e788e7";

                var postSubscriptionRequest = new PostRequest
                {
                    CustomerId = customerId
                };

                var customerRequest = new CustomerRequest
                {
                    CustomerId = customerId
                };

                _mapper.Map<CustomerRequest>(postSubscriptionRequest)
                    .Returns(customerRequest);

                _customerManager.ActivateAsync(customerRequest)
                    .Throws(new HttpServiceRequestException());

                var requestDt = new DateTime(2020, 12, 31, 23, 59, 45, 987);

                _dateTime.Now.Returns(requestDt);

                var response = await _internalController.ActivateAsync(postSubscriptionRequest) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.InternalServerError);

                await _customerManager.Received(1).ActivateAsync(customerRequest);

                _mapper.Received(1).Map<CustomerRequest>(postSubscriptionRequest);

                _mapper.DidNotReceive().Map<PutLockStatusRequest>(Arg.Any<PostRequest>());

                await _customerManager.DidNotReceive().PutLockStatus(Arg.Any<PutLockStatusRequest>());

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "500"
                    && x.ResponseStatusDescription == "Internal Server Error"
                    && x.RequestType == "ACTIVATE_CREDITLOCK"
                    && x.RequestDt == requestDt
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.DownstreamBadResponse)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.SyncCustomerPinningException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PostActivate_ServiceUnavailableException_ReturnStatus503()
            {
                const string customerId = "4a1f51c5-e902-4efb-8366-816e29e788e7";

                var postSubscriptionRequest = new PostRequest
                {
                    CustomerId = customerId
                };

                var customerRequest = new CustomerRequest
                {
                    CustomerId = customerId
                };

                _mapper.Map<CustomerRequest>(postSubscriptionRequest)
                    .Returns(customerRequest);

                _customerManager.ActivateAsync(customerRequest)
                    .Throws(new ServiceUnavailableException());

                var requestDt = new DateTime(2020, 12, 31, 23, 59, 45, 987);

                _dateTime.Now.Returns(requestDt);

                var response = await _internalController.ActivateAsync(postSubscriptionRequest) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.ServiceUnavailable);

                await _customerManager.Received(1).ActivateAsync(customerRequest);

                _mapper.Received(1).Map<CustomerRequest>(postSubscriptionRequest);

                _mapper.DidNotReceive().Map<PutLockStatusRequest>(Arg.Any<PostRequest>());

                await _customerManager.DidNotReceive().PutLockStatus(Arg.Any<PutLockStatusRequest>());

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "503"
                    && x.ResponseStatusDescription == "Service Unavailable"
                    && x.RequestType == "ACTIVATE_CREDITLOCK"
                    && x.RequestDt == requestDt
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.DownstreamBadResponse)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.SyncCustomerPinningException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PostActivate_OktaException_ReturnStatus502()
            {
                const string customerId = "4a1f51c5-e902-4efb-8366-816e29e788e7";

                var postSubscriptionRequest = new PostRequest
                {
                    CustomerId = customerId
                };

                var customerRequest = new CustomerRequest
                {
                    CustomerId = customerId
                };

                _mapper.Map<CustomerRequest>(postSubscriptionRequest)
                    .Returns(customerRequest);

                _customerManager.ActivateAsync(customerRequest)
                    .Throws(new OktaException());

                var requestDt = new DateTime(2020, 12, 31, 23, 59, 30, 987);

                _dateTime.Now.Returns(requestDt);

                var response = await _internalController.ActivateAsync(postSubscriptionRequest) as ObjectResult;

                response?.StatusCode.Should().Be(502);

                await _customerManager.Received(1).ActivateAsync(customerRequest);

                _mapper.Received(1).Map<CustomerRequest>(postSubscriptionRequest);

                _mapper.DidNotReceive().Map<PutLockStatusRequest>(Arg.Any<PostRequest>());

                await _customerManager.DidNotReceive().PutLockStatus(Arg.Any<PutLockStatusRequest>());

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "502"
                    && x.ResponseStatusDescription == "Bad Gateway"
                    && x.RequestType == "ACTIVATE_CREDITLOCK"
                    && x.RequestDt == requestDt
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.DownstreamBadResponse)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.SyncCustomerPinningException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PostActivate_DownstreamBadResponse_ReturnStatus562()
            {
                const string customerId = "4a1f51c5-e902-4efb-8366-816e29e788e7";

                var postSubscriptionRequest = new PostRequest
                {
                    CustomerId = customerId
                };

                var customerRequest = new CustomerRequest
                {
                    CustomerId = customerId
                };

                _mapper.Map<CustomerRequest>(postSubscriptionRequest)
                    .Returns(customerRequest);

                _customerManager.ActivateAsync(customerRequest)
                    .Throws(new DownstreamBadResponseException());

                var requestDt = new DateTime(2020, 12, 31, 23, 59, 45, 987);

                _dateTime.Now.Returns(requestDt);

                var response = await _internalController.ActivateAsync(postSubscriptionRequest) as ObjectResult;

                response?.StatusCode.Should().Be(562);

                await _customerManager.Received(1).ActivateAsync(customerRequest);

                _mapper.Received(1).Map<CustomerRequest>(postSubscriptionRequest);

                _mapper.DidNotReceive().Map<PutLockStatusRequest>(Arg.Any<PostRequest>());

                await _customerManager.DidNotReceive().PutLockStatus(Arg.Any<PutLockStatusRequest>());

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "562"
                    && x.ResponseStatusDescription == "Downstream Bad Request"
                    && x.RequestType == "ACTIVATE_CREDITLOCK"
                    && x.RequestDt == requestDt
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.DownstreamBadResponse)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.SyncCustomerPinningException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

            }

            [Fact]
            public async Task PostActivate_ServiceTaskCanceledException_ReturnStatusCode564()
            {
                const string customerId = "4a1f51c5-e902-4efb-8366-816e29e788e7";

                var postSubscriptionRequest = new PostRequest
                {
                    CustomerId = customerId
                };

                var customerRequest = new CustomerRequest
                {
                    CustomerId = customerId
                };

                _mapper.Map<CustomerRequest>(postSubscriptionRequest)
                    .Returns(customerRequest);

                _customerManager.ActivateAsync(customerRequest)
                    .Throws(new ServiceTaskCanceledException());

                var requestDt = new DateTime(2020, 12, 31, 23, 59, 45, 987);

                _dateTime.Now.Returns(requestDt);

                var response = await _internalController.ActivateAsync(postSubscriptionRequest) as ObjectResult;

                response?.StatusCode.Should().Be(564);

                await _customerManager.Received(1).ActivateAsync(customerRequest);

                _mapper.Received(1).Map<CustomerRequest>(postSubscriptionRequest);

                _mapper.DidNotReceive().Map<PutLockStatusRequest>(Arg.Any<PostRequest>());

                await _customerManager.DidNotReceive().PutLockStatus(Arg.Any<PutLockStatusRequest>());

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "564"
                    && x.ResponseStatusDescription == MessageConstants.DownstreamTimeout
                    && x.RequestType == "ACTIVATE_CREDITLOCK"
                    && x.RequestDt == requestDt
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.DownstreamBadResponse)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.SyncCustomerPinningException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PostActivate_CustomerNotFoundException_ReturnNotFound()
            {
                const string customerId = "4a1f51c5-e902-4efb-8366-816e29e788e7";

                var postRequest = new PostRequest
                {
                    CustomerId = customerId
                };

                var customerRequest = new CustomerRequest
                {
                    CustomerId = customerId
                };

                _mapper.Map<CustomerRequest>(postRequest)
                    .Returns(customerRequest);

                var putLockStatusRequest = new PutLockStatusRequest
                {
                    CustomerId = customerId
                };

                _mapper.Map<PutLockStatusRequest>(postRequest)
                    .Returns(putLockStatusRequest);

                _customerManager.PutLockStatus(putLockStatusRequest)
                    .Throws<CustomerNotFoundException>();

                var requestDt = new DateTime(2020, 12, 31, 23, 59, 45, 987);

                _dateTime.Now.Returns(requestDt);

                var response = await _internalController.ActivateAsync(postRequest) as ObjectResult;

                response?.StatusCode.Should().Be((int)HttpStatusCode.InternalServerError);

                await _customerManager.Received(1).ActivateAsync(customerRequest);

                _mapper.Received(1).Map<CustomerRequest>(postRequest);

                _mapper.Received(1).Map<PutLockStatusRequest>(postRequest);

                await _customerManager.Received(1).PutLockStatus(putLockStatusRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "500"
                    && x.ResponseStatusDescription == "Internal Server Error"
                    && x.RequestType == "ACTIVATE_CREDITLOCK"
                    && x.RequestDt == requestDt
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.DownstreamBadResponse)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.SyncCustomerPinningException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PostActivate_SyncCustomerPinningException_ReturnConflict()
            {
                const string customerId = "4a1f51c5-e902-4efb-8366-816e29e788e7";

                var postRequest = new PostRequest
                {
                    CustomerId = customerId
                };

                var customerRequest = new CustomerRequest
                {
                    CustomerId = customerId
                };

                _mapper.Map<CustomerRequest>(postRequest)
                    .Returns(customerRequest);

                var putLockStatusRequest = new PutLockStatusRequest
                {
                    CustomerId = customerId
                };

                _mapper.Map<PutLockStatusRequest>(postRequest)
                    .Returns(putLockStatusRequest);

                _customerManager.PutLockStatus(putLockStatusRequest)
                    .Throws<SyncCustomerPinningException>();

                var requestDt = new DateTime(2020, 12, 31, 23, 59, 45, 987);

                _dateTime.Now.Returns(requestDt);

                var response = await _internalController.ActivateAsync(postRequest) as ObjectResult;

                response?.StatusCode.Should().Be((int)HttpStatusCode.Conflict);

                await _customerManager.Received(1).ActivateAsync(customerRequest);

                _mapper.Received(1).Map<CustomerRequest>(postRequest);

                _mapper.Received(1).Map<PutLockStatusRequest>(postRequest);

                await _customerManager.Received(1).PutLockStatus(putLockStatusRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "409"
                    && x.ResponseStatusDescription == "Conflict - customer waiting to be pinned or pinning in process"
                    && x.RequestType == "ACTIVATE_CREDITLOCK"
                    && x.RequestDt == requestDt
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.DownstreamBadResponse)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Activate.SyncCustomerPinningException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }
        }

        public class PostDeactivateAsync : InternalCreditLockControllerTests
        {
            public static IEnumerable<object[]> LogInformationMessages()
            {
                yield return new object[]
                {
                    LogEventNames.InternalCreditLockController.Deactivate.Invoked
                };

                yield return new object[]
                {
                    LogEventNames.InternalCreditLockController.Deactivate.Complete
                };
            }

            [Theory]
            [MemberData(nameof(LogInformationMessages))]
            public async Task HappyPathInformationLogged(string information)
            {
                await _internalController.DeactivateAsync(new PostRequest());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(information)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task DeactivateRequest_ModelStateInvalid_ReturnStatusBadRequest()
            {
                var request = new PostRequest
                {
                    CustomerId = "Not a Valid customer id"
                };

                _internalController.ModelState.AddModelError("Test", "TestError");

                var requestDt = new DateTime(2020, 12, 31, 23, 59, 45, 987);

                _dateTime.Now.Returns(requestDt);

                var response = await _internalController.DeactivateAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.BadRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "400"
                    && x.ResponseStatusDescription == "Bad Request"
                    && x.RequestType == "DEACTIVATE_CREDITLOCK"
                    && x.RequestDt == requestDt
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task DeactivateRequest_Valid_ReturnSuccessNoContent()
            {
                var request = new PostRequest
                {
                    CustomerId = "Valid customer id"
                };

                var putLockStatusRequest = new PutLockStatusRequest
                {
                    CustomerId = request.CustomerId,
                    LockStatus = false
                };

                var requestDt = new DateTime(2020, 12, 31, 23, 59, 45, 987);

                _dateTime.Now.Returns(requestDt);

                _mapper.Map<PutLockStatusRequest>(request)
                    .Returns(putLockStatusRequest);

                var response = await _internalController.DeactivateAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.NoContent);

                _mapper.Received(1).Map<PutLockStatusRequest>(request);

                await _customerManager.Received(1).PutLockStatus(putLockStatusRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "204"
                    && x.ResponseStatusDescription == "Success"
                    && x.RequestType == "DEACTIVATE_CREDITLOCK"
                    && x.RequestDt == requestDt
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.CustomerNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task DeactivateRequest_ThrowsCustomerProfileNotFoundException_ReturnsStatusInternalServerError()
            {
                var request = new PostRequest
                {
                    CustomerId = "Valid customer id"
                };

                var putLockStatusRequest = new PutLockStatusRequest
                {
                    CustomerId = request.CustomerId,
                    LockStatus = false
                };

                var requestDt = new DateTime(2020, 12, 31, 23, 59, 45, 987);

                _dateTime.Now.Returns(requestDt);

                _mapper.Map<PutLockStatusRequest>(request)
                    .Returns(putLockStatusRequest);

                _customerManager.PutLockStatus(putLockStatusRequest)
                    .Throws<CustomerProfileNotFoundException>();

                var response = await _internalController.DeactivateAsync(request);

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.InternalServerError);

                _mapper.Received(1).Map<PutLockStatusRequest>(request);

                await _customerManager.Received(1).PutLockStatus(putLockStatusRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "500"
                    && x.ResponseStatusDescription == "Internal Server Error"
                    && x.RequestType == "DEACTIVATE_CREDITLOCK"
                    && x.RequestDt == requestDt
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.CustomerNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task DeactivateRequest_ThrowsCustomerNotFoundException_ReturnsStatusNotFound()
            {
                var request = new PostRequest
                {
                    CustomerId = "Valid customer id"
                };

                var putLockStatusRequest = new PutLockStatusRequest
                {
                    CustomerId = request.CustomerId,
                    LockStatus = false
                };

                _mapper.Map<PutLockStatusRequest>(request)
                    .Returns(putLockStatusRequest);

                _customerManager.PutLockStatus(putLockStatusRequest)
                    .Throws<CustomerNotFoundException>();

                var requestDt = new DateTime(2020, 12, 31, 23, 59, 45, 987);

                _dateTime.Now.Returns(requestDt);

                var response = await _internalController.DeactivateAsync(request);

                response.Should().BeOfType<ApiResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.NoContent);

                _mapper.Received(1).Map<PutLockStatusRequest>(request);

                await _customerManager.Received(1).PutLockStatus(putLockStatusRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "204"
                    && x.ResponseStatusDescription == "VIP Customer is Not Found"
                    && x.RequestType == "DEACTIVATE_CREDITLOCK"
                    && x.RequestDt == requestDt
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.CustomerNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task DeactivateRequest_ThrowsOktaTokenNullException_ReturnsBadGateway()
            {
                var request = new PostRequest
                {
                    CustomerId = "Valid customer id"
                };

                var putLockStatusRequest = new PutLockStatusRequest
                {
                    CustomerId = request.CustomerId,
                    LockStatus = false
                };

                _mapper.Map<PutLockStatusRequest>(request)
                    .Returns(putLockStatusRequest);

                _customerManager.PutLockStatus(putLockStatusRequest)
                    .Throws<OktaTokenNullException>();

                var requestDt = new DateTime(2020, 12, 31, 23, 59, 45, 987);

                _dateTime.Now.Returns(requestDt);

                var response = await _internalController.DeactivateAsync(request);

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.BadGateway);

                _mapper.Received(1).Map<PutLockStatusRequest>(request);

                await _customerManager.Received(1).PutLockStatus(putLockStatusRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "502"
                    && x.ResponseStatusDescription == "Bad Gateway"
                    && x.RequestType == "DEACTIVATE_CREDITLOCK"
                    && x.RequestDt == requestDt
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.CustomerNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task DeactivateRequest_ThrowsOktaException_ReturnsBadGateway()
            {
                var request = new PostRequest
                {
                    CustomerId = "Valid customer id"
                };

                var putLockStatusRequest = new PutLockStatusRequest
                {
                    CustomerId = request.CustomerId,
                    LockStatus = false
                };

                _mapper.Map<PutLockStatusRequest>(request)
                    .Returns(putLockStatusRequest);

                _customerManager.PutLockStatus(putLockStatusRequest)
                    .Throws<OktaException>();

                var requestDt = new DateTime(2020, 12, 31, 23, 59, 45, 987);

                _dateTime.Now.Returns(requestDt);

                var response = await _internalController.DeactivateAsync(request);

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.BadGateway);

                _mapper.Received(1).Map<PutLockStatusRequest>(request);

                await _customerManager.Received(1).PutLockStatus(putLockStatusRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "502"
                    && x.ResponseStatusDescription == "Bad Gateway"
                    && x.RequestType == "DEACTIVATE_CREDITLOCK"
                    && x.RequestDt == requestDt
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.CustomerNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task DeactivateRequest_ThrowsHttpServiceRequestException_ReturnsInternalServerError()
            {
                var request = new PostRequest
                {
                    CustomerId = "Valid customer id"
                };

                var putLockStatusRequest = new PutLockStatusRequest
                {
                    CustomerId = request.CustomerId,
                    LockStatus = false
                };

                _mapper.Map<PutLockStatusRequest>(request)
                    .Returns(putLockStatusRequest);

                _customerManager.PutLockStatus(putLockStatusRequest)
                    .Throws<HttpServiceRequestException>();

                var requestDt = new DateTime(2020, 12, 31, 23, 59, 45, 987);

                _dateTime.Now.Returns(requestDt);

                var response = await _internalController.DeactivateAsync(request);

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.InternalServerError);

                _mapper.Received(1).Map<PutLockStatusRequest>(request);

                await _customerManager.Received(1).PutLockStatus(putLockStatusRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "500"
                    && x.ResponseStatusDescription == "Internal Server Error"
                    && x.RequestType == "DEACTIVATE_CREDITLOCK"
                    && x.RequestDt == requestDt
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.CustomerNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task DeactivateRequest_ThrowsHttpServiceTaskCanceledException_ReturnsStatusCode564()
            {
                var request = new PostRequest
                {
                    CustomerId = "Valid customer id"
                };

                var putLockStatusRequest = new PutLockStatusRequest
                {
                    CustomerId = request.CustomerId,
                    LockStatus = false
                };

                var requestDt = new DateTime(2020, 12, 31, 23, 59, 45, 987);

                _dateTime.Now.Returns(requestDt);

                _mapper.Map<PutLockStatusRequest>(request)
                    .Returns(putLockStatusRequest);

                _customerManager.PutLockStatus(putLockStatusRequest)
                    .Throws<ServiceTaskCanceledException>();

                var response = await _internalController.DeactivateAsync(request);

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be(564);

                _mapper.Received(1).Map<PutLockStatusRequest>(request);

                await _customerManager.Received(1).PutLockStatus(putLockStatusRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "564"
                    && x.ResponseStatusDescription == MessageConstants.DownstreamTimeout
                    && x.RequestType == "DEACTIVATE_CREDITLOCK"
                    && x.RequestDt == requestDt
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.CustomerNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task DeactivateRequest_ThrowsServiceUnavailableException_ReturnsServiceUnavailable()
            {
                var request = new PostRequest
                {
                    CustomerId = "Valid customer id"
                };

                var putLockStatusRequest = new PutLockStatusRequest
                {
                    CustomerId = request.CustomerId,
                    LockStatus = false
                };

                _mapper.Map<PutLockStatusRequest>(request)
                    .Returns(putLockStatusRequest);

                _customerManager.PutLockStatus(putLockStatusRequest)
                    .Throws<ServiceUnavailableException>();

                var requestDt = new DateTime(2020, 12, 31, 23, 59, 45, 987);

                _dateTime.Now.Returns(requestDt);

                var response = await _internalController.DeactivateAsync(request);

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.ServiceUnavailable);

                _mapper.Received(1).Map<PutLockStatusRequest>(request);

                await _customerManager.Received(1).PutLockStatus(putLockStatusRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "503"
                    && x.ResponseStatusDescription == "Service Unavailable"
                    && x.RequestType == "DEACTIVATE_CREDITLOCK"
                    && x.RequestDt == requestDt
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.CustomerNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task DeactivateRequest_ThrowsDownstreamMaintenanceException_Returns561()
            {
                var request = new PostRequest
                {
                    CustomerId = "Valid customer id"
                };

                var putLockStatusRequest = new PutLockStatusRequest
                {
                    CustomerId = request.CustomerId,
                    LockStatus = false
                };

                _mapper.Map<PutLockStatusRequest>(request)
                    .Returns(putLockStatusRequest);

                _customerManager.PutLockStatus(putLockStatusRequest)
                    .Throws<DownstreamMaintenanceException>();

                var requestDt = new DateTime(2020, 12, 31, 23, 59, 45, 987);

                _dateTime.Now.Returns(requestDt);

                var response = await _internalController.DeactivateAsync(request);

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be(561);

                _mapper.Received(1).Map<PutLockStatusRequest>(request);

                await _customerManager.Received(1).PutLockStatus(putLockStatusRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "561"
                    && x.ResponseStatusDescription == "Downstream Service Unavailable - mainframe down for scheduled maintenance"
                    && x.RequestType == "DEACTIVATE_CREDITLOCK"
                    && x.RequestDt == requestDt
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.CustomerNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task DeactivateRequest_ThrowsException_ReturnsInternalServerError()
            {
                var postRequest = new PostRequest
                {
                    CustomerId = "Valid customer id"
                };

                var putLockStatusRequest = new PutLockStatusRequest
                {
                    CustomerId = postRequest.CustomerId,
                    LockStatus = false
                };

                var requestDt = new DateTime(2020, 12, 31, 23, 59, 45, 987);

                _dateTime.Now.Returns(requestDt);

                _mapper.Map<PutLockStatusRequest>(postRequest)
                    .Returns(putLockStatusRequest);

                _customerManager.PutLockStatus(putLockStatusRequest)
                    .Throws<InvalidOperationException>();

                var response = await _internalController.DeactivateAsync(postRequest);

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.InternalServerError);

                _mapper.Received(1).Map<PutLockStatusRequest>(postRequest);

                await _customerManager.Received(1).PutLockStatus(putLockStatusRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "500"
                    && x.ResponseStatusDescription == "Internal Server Error"
                    && x.RequestType == "DEACTIVATE_CREDITLOCK"
                    && x.RequestDt == requestDt
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.CustomerNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task DeactivateRequest_DownstreamAuthenticationException_ReturnsStatusCode563()
            {
                var postRequest = new PostRequest
                {
                    CustomerId = "Valid customer id"
                };

                var putLockStatusRequest = new PutLockStatusRequest
                {
                    CustomerId = postRequest.CustomerId,
                    LockStatus = false
                };

                var requestDt = new DateTime(2020, 12, 31, 23, 59, 45, 987);

                _dateTime.Now.Returns(requestDt);

                _mapper.Map<PutLockStatusRequest>(postRequest)
                    .Returns(putLockStatusRequest);

                _customerManager.PutLockStatus(putLockStatusRequest)
                    .Throws<DownstreamAuthenticationException>();

                var response = await _internalController.DeactivateAsync(postRequest);

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be(563);

                _mapper.Received(1).Map<PutLockStatusRequest>(postRequest);

                await _customerManager.Received(1).PutLockStatus(putLockStatusRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "563"
                    && x.ResponseStatusDescription == "Downstream Service Authentication Failed"
                    && x.RequestType == "DEACTIVATE_CREDITLOCK"
                    && x.RequestDt == requestDt
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.CustomerNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.Deactivate.DownstreamAuthenticationException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }
        }

        public class PostDeleteSubscription : InternalCreditLockControllerTests
        {
            public static IEnumerable<object[]> LogInformationMessages()
            {
                yield return new object[]
                {
                    LogEventNames.InternalCreditLockController.CustomerDelete.Invoked
                };

                yield return new object[]
                {
                    LogEventNames.InternalCreditLockController.CustomerDelete.Complete
                };
            }

            [Theory]
            [MemberData(nameof(LogInformationMessages))]
            public async Task HappyPathInformationLogged(string information)
            {
                await _internalController.DeleteAsync(new DeleteCustomerRequest());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(information)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task DeleteRequest_ModelStateInvalid_ReturnStatusBadRequest()
            {
                var request = new DeleteCustomerRequest
                {
                    CustomerId = "Not a Valid customer id"
                };

                _internalController.ModelState.AddModelError("Test", "TestError");

                var response = await _internalController.DeleteAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.BadRequest);

                _mapper.DidNotReceive().Map<Models.CreditLockService.Internal.Delete.Request.DeleteCustomerRequest>(request);

                await _customerManager.DidNotReceive().DeleteCustomer(Arg.Any<Models.CreditLockService.Internal.Delete.Request.DeleteCustomerRequest>());

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "400"
                    && x.ResponseStatusDescription == "Bad Request"
                    && x.RequestType == "DELETE_CUSTOMER"
                    && x.RequestDt == new DateTime(2000, 12, 31, 23, 59, 59, 123)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.CustomerNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task DeleteRequest_HappyPath_ReturnSuccessNoContent()
            {
                var request = new DeleteCustomerRequest
                {
                    CustomerId = "Valid customer id"
                };

                var internalDeleteRequest = new Models.CreditLockService.Internal.Delete.Request.DeleteCustomerRequest
                {
                    CustomerId = "customerId"
                };

                _mapper.Map<Models.CreditLockService.Internal.Delete.Request.DeleteCustomerRequest>(request)
                    .Returns(internalDeleteRequest);

                var response = await _internalController.DeleteAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.NoContent);

                _mapper.Received(1).Map<Models.CreditLockService.Internal.Delete.Request.DeleteCustomerRequest>(request);

                await _customerManager.Received(1).DeleteCustomer(internalDeleteRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "204"
                    && x.ResponseStatusDescription == "Success"
                    && x.RequestType == "DELETE_CUSTOMER"
                    && x.RequestDt == new DateTime(2000, 12, 31, 23, 59, 59, 123)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.CustomerNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task DeleteRequest_GeneralException_ReturnInternalServerError()
            {
                var request = new DeleteCustomerRequest
                {
                    CustomerId = "cb461ff2-ed68-4797-91bc-b438f21de5b0"
                };

                var internalRequest = new Models.CreditLockService.Internal.Delete.Request.DeleteCustomerRequest
                {
                    CustomerId = "cb461ff2-ed68-4797-91bc-b438f21de5b0"
                };

                _mapper.Map<Models.CreditLockService.Internal.Delete.Request.DeleteCustomerRequest>(request)
                    .Returns(internalRequest);

                _customerManager.DeleteCustomer(internalRequest)
                    .Throws<OutOfMemoryException>();

                var response = await _internalController.DeleteAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.InternalServerError);

                _mapper.Received(1).Map<Models.CreditLockService.Internal.Delete.Request.DeleteCustomerRequest>(request);

                await _customerManager.Received(1).DeleteCustomer(internalRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "500"
                    && x.ResponseStatusDescription == "Internal Server Error"
                    && x.RequestType == "DELETE_CUSTOMER"
                    && x.RequestDt == new DateTime(2000, 12, 31, 23, 59, 59, 123)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.CustomerNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task DeleteRequest_DownstreamMaintenanceException_Return561()
            {
                var request = new DeleteCustomerRequest
                {
                    CustomerId = "cb461ff2-ed68-4797-91bc-b438f21de5b0"
                };

                var internalRequest = new Models.CreditLockService.Internal.Delete.Request.DeleteCustomerRequest
                {
                    CustomerId = "cb461ff2-ed68-4797-91bc-b438f21de5b0"
                };

                _mapper.Map<Models.CreditLockService.Internal.Delete.Request.DeleteCustomerRequest>(request)
                    .Returns(internalRequest);

                _customerManager.DeleteCustomer(internalRequest)
                    .Throws<DownstreamMaintenanceException>();

                var response = await _internalController.DeleteAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be(561);

                _mapper.Received(1).Map<Models.CreditLockService.Internal.Delete.Request.DeleteCustomerRequest>(request);

                await _customerManager.Received(1).DeleteCustomer(internalRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "561"
                    && x.ResponseStatusDescription == "Downstream Service Unavailable - mainframe down for scheduled maintenance"
                    && x.RequestType == "DELETE_CUSTOMER"
                    && x.RequestDt == new DateTime(2000, 12, 31, 23, 59, 59, 123)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.CustomerNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task DeleteRequest_HttpServiceRequestException_ReturnInternalServerError()
            {
                var request = new DeleteCustomerRequest
                {
                    CustomerId = "cb461ff2-ed68-4797-91bc-b438f21de5b0"
                };

                var internalRequest = new Models.CreditLockService.Internal.Delete.Request.DeleteCustomerRequest
                {
                    CustomerId = "cb461ff2-ed68-4797-91bc-b438f21de5b0"
                };

                _mapper.Map<Models.CreditLockService.Internal.Delete.Request.DeleteCustomerRequest>(request)
                    .Returns(internalRequest);

                _customerManager.DeleteCustomer(internalRequest)
                    .Throws<HttpServiceRequestException>();

                var response = await _internalController.DeleteAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.InternalServerError);

                _mapper.Received(1).Map<Models.CreditLockService.Internal.Delete.Request.DeleteCustomerRequest>(request);

                await _customerManager.Received(1).DeleteCustomer(internalRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "500"
                    && x.ResponseStatusDescription == "Internal Server Error"
                    && x.RequestType == "DELETE_CUSTOMER"
                    && x.RequestDt == new DateTime(2000, 12, 31, 23, 59, 59, 123)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.CustomerNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                 Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.OktaTokenException)), null,
                 Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task DeleteRequest_ServiceTaskCanceledException_ReturnStatusCode564()
            {
                var request = new DeleteCustomerRequest
                {
                    CustomerId = "cb461ff2-ed68-4797-91bc-b438f21de5b0"
                };

                var internalRequest = new EXPN.Models.CreditLockService.Internal.Delete.Request.DeleteCustomerRequest
                {
                    CustomerId = "cb461ff2-ed68-4797-91bc-b438f21de5b0"
                };

                _mapper.Map<EXPN.Models.CreditLockService.Internal.Delete.Request.DeleteCustomerRequest>(request)
                    .Returns(internalRequest);

                _customerManager.DeleteCustomer(internalRequest)
                    .Throws<ServiceTaskCanceledException>();

                var response = await _internalController.DeleteAsync(request) as ObjectResult;

                _mapper.Received(1).Map<Models.CreditLockService.Internal.Delete.Request.DeleteCustomerRequest>(request);

                await _customerManager.Received(1).DeleteCustomer(internalRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "564"
                    && x.ResponseStatusDescription == MessageConstants.DownstreamTimeout
                    && x.RequestType == "DELETE_CUSTOMER"
                    && x.RequestDt == new DateTime(2000, 12, 31, 23, 59, 59, 123)
                    && x.SalesforceUserId == null));

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be(564);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.CustomerNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                 Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.OktaTokenException)), null,
                 Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task DeleteRequest_ServiceUnavailableException_ReturnInternalServerError()
            {
                var request = new DeleteCustomerRequest
                {
                    CustomerId = "cb461ff2-ed68-4797-91bc-b438f21de5b0"
                };

                var internalRequest = new EXPN.Models.CreditLockService.Internal.Delete.Request.DeleteCustomerRequest
                {
                    CustomerId = "cb461ff2-ed68-4797-91bc-b438f21de5b0"
                };

                _mapper.Map<Models.CreditLockService.Internal.Delete.Request.DeleteCustomerRequest>(request)
                    .Returns(internalRequest);

                _customerManager.DeleteCustomer(internalRequest)
                    .Throws<ServiceUnavailableException>();

                var response = await _internalController.DeleteAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.ServiceUnavailable);

                _mapper.Received(1).Map<Models.CreditLockService.Internal.Delete.Request.DeleteCustomerRequest>(request);

                await _customerManager.Received(1).DeleteCustomer(internalRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "503"
                    && x.ResponseStatusDescription == "Service Unavailable"
                    && x.RequestType == "DELETE_CUSTOMER"
                    && x.RequestDt == new DateTime(2000, 12, 31, 23, 59, 59, 123)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                 Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.OktaTokenException)), null,
                 Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task DeleteRequest_CustomerNotFoundException_ReturnInternalServerError()
            {
                var request = new DeleteCustomerRequest
                {
                    CustomerId = "cb461ff2-ed68-4797-91bc-b438f21de5b0"
                };

                var internalRequest = new EXPN.Models.CreditLockService.Internal.Delete.Request.DeleteCustomerRequest
                {
                    CustomerId = "cb461ff2-ed68-4797-91bc-b438f21de5b0"
                };

                _mapper.Map<Models.CreditLockService.Internal.Delete.Request.DeleteCustomerRequest>(request)
                    .Returns(internalRequest);

                _customerManager.DeleteCustomer(internalRequest)
                    .Throws<CustomerNotFoundException>();

                var response = await _internalController.DeleteAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.NotFound);

                _mapper.Received(1).Map<Models.CreditLockService.Internal.Delete.Request.DeleteCustomerRequest>(request);

                await _customerManager.Received(1).DeleteCustomer(internalRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "404"
                    && x.ResponseStatusDescription == "VIP Customer is Not Found"
                    && x.RequestType == "DELETE_CUSTOMER"
                    && x.RequestDt == new DateTime(2000, 12, 31, 23, 59, 59, 123)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.CustomerNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                 Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.OktaTokenException)), null,
                 Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task DeleteRequest_CustomerProfileNotFoundException_ReturnInternalServerError()
            {
                var request = new DeleteCustomerRequest
                {
                    CustomerId = "cb461ff2-ed68-4797-91bc-b438f21de5b0"
                };

                var internalRequest = new EXPN.Models.CreditLockService.Internal.Delete.Request.DeleteCustomerRequest
                {
                    CustomerId = "cb461ff2-ed68-4797-91bc-b438f21de5b0"
                };

                _mapper.Map<Models.CreditLockService.Internal.Delete.Request.DeleteCustomerRequest>(request)
                    .Returns(internalRequest);

                _customerManager.DeleteCustomer(internalRequest)
                    .Throws<CustomerProfileNotFoundException>();

                var response = await _internalController.DeleteAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.InternalServerError);

                _mapper.Received(1).Map<Models.CreditLockService.Internal.Delete.Request.DeleteCustomerRequest>(request);

                await _customerManager.Received(1).DeleteCustomer(internalRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "500"
                    && x.ResponseStatusDescription == "Internal Server Error"
                    && x.RequestType == "DELETE_CUSTOMER"
                    && x.RequestDt == new DateTime(2000, 12, 31, 23, 59, 59, 123)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                 Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.OktaTokenException)), null,
                 Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task DeleteRequest_OktaTokenNullException_ReturnBadGateway()
            {
                var request = new DeleteCustomerRequest
                {
                    CustomerId = "cb461ff2-ed68-4797-91bc-b438f21de5b0"
                };

                var internalRequest = new EXPN.Models.CreditLockService.Internal.Delete.Request.DeleteCustomerRequest
                {
                    CustomerId = "cb461ff2-ed68-4797-91bc-b438f21de5b0"
                };

                _mapper.Map<Models.CreditLockService.Internal.Delete.Request.DeleteCustomerRequest>(request)
                    .Returns(internalRequest);

                _customerManager.DeleteCustomer(internalRequest)
                    .Throws<OktaTokenNullException>();

                var response = await _internalController.DeleteAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.BadGateway);

                _mapper.Received(1).Map<Models.CreditLockService.Internal.Delete.Request.DeleteCustomerRequest>(request);

                await _customerManager.Received(1).DeleteCustomer(internalRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "502"
                    && x.ResponseStatusDescription == "Bad Gateway"
                    && x.RequestType == "DELETE_CUSTOMER"
                    && x.RequestDt == new DateTime(2000, 12, 31, 23, 59, 59, 123)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                 Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.OktaTokenException)), null,
                 Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task DeleteRequest_OktaException_ReturnBadGateway()
            {
                var request = new DeleteCustomerRequest
                {
                    CustomerId = "cb461ff2-ed68-4797-91bc-b438f21de5b0"
                };

                var internalRequest = new EXPN.Models.CreditLockService.Internal.Delete.Request.DeleteCustomerRequest
                {
                    CustomerId = "cb461ff2-ed68-4797-91bc-b438f21de5b0"
                };

                _mapper.Map<Models.CreditLockService.Internal.Delete.Request.DeleteCustomerRequest>(request)
                    .Returns(internalRequest);

                _customerManager.DeleteCustomer(internalRequest)
                    .Throws<OktaException>();

                var response = await _internalController.DeleteAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.BadGateway);

                _mapper.Received(1).Map<Models.CreditLockService.Internal.Delete.Request.DeleteCustomerRequest>(request);

                await _customerManager.Received(1).DeleteCustomer(internalRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "502"
                    && x.ResponseStatusDescription == "Bad Gateway"
                    && x.RequestType == "DELETE_CUSTOMER"
                    && x.RequestDt == new DateTime(2000, 12, 31, 23, 59, 59, 123)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task DeleteRequest_DownstreamAuthenticationException_ReturnStatusCode563()
            {
                var request = new DeleteCustomerRequest
                {
                    CustomerId = "cb461ff2-ed68-4797-91bc-b438f21de5b0"
                };

                var internalRequest = new EXPN.Models.CreditLockService.Internal.Delete.Request.DeleteCustomerRequest
                {
                    CustomerId = "cb461ff2-ed68-4797-91bc-b438f21de5b0"
                };

                _mapper.Map<Models.CreditLockService.Internal.Delete.Request.DeleteCustomerRequest>(request)
                    .Returns(internalRequest);

                _customerManager.DeleteCustomer(internalRequest)
                    .Throws<DownstreamAuthenticationException>();

                var response = await _internalController.DeleteAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be(563);

                _mapper.Received(1).Map<Models.CreditLockService.Internal.Delete.Request.DeleteCustomerRequest>(request);

                await _customerManager.Received(1).DeleteCustomer(internalRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "563"
                    && x.ResponseStatusDescription == "Downstream Service Authentication Failed"
                    && x.RequestType == "DELETE_CUSTOMER"
                    && x.RequestDt == new DateTime(2000, 12, 31, 23, 59, 59, 123)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.DownstreamAuthenticationException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                 Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.OktaTokenException)), null,
                 Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task DeleteRequest_Exception_ReturnStatusCode500()
            {
                var request = new DeleteCustomerRequest
                {
                    CustomerId = "cb461ff2-ed68-4797-91bc-b438f21de5b0"
                };

                var internalRequest = new EXPN.Models.CreditLockService.Internal.Delete.Request.DeleteCustomerRequest
                {
                    CustomerId = "cb461ff2-ed68-4797-91bc-b438f21de5b0"
                };

                _mapper.Map<Models.CreditLockService.Internal.Delete.Request.DeleteCustomerRequest>(request)
                    .Returns(internalRequest);

                _customerManager.DeleteCustomer(internalRequest)
                    .Throws<Exception>();

                var response = await _internalController.DeleteAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be(500);

                _mapper.Received(1).Map<Models.CreditLockService.Internal.Delete.Request.DeleteCustomerRequest>(request);

                await _customerManager.Received(1).DeleteCustomer(internalRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "500"
                    && x.ResponseStatusDescription == "Internal Server Error"
                    && x.RequestType == "DELETE_CUSTOMER"
                    && x.RequestDt == new DateTime(2000, 12, 31, 23, 59, 59, 123)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                   Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.OktaTokenException)), null,
                   Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task DeleteRequest_OktaException_ReturnstatusCodeBadGateway()
            {
                var request = new DeleteCustomerRequest
                {
                    CustomerId = "cb461ff2-ed68-4797-91bc-b438f21de5b0"
                };

                var internalRequest = new EXPN.Models.CreditLockService.Internal.Delete.Request.DeleteCustomerRequest
                {
                    CustomerId = "cb461ff2-ed68-4797-91bc-b438f21de5b0"
                };

                _mapper.Map<Models.CreditLockService.Internal.Delete.Request.DeleteCustomerRequest>(request)
                    .Returns(internalRequest);

                _customerManager.DeleteCustomer(internalRequest)
                    .Throws<OktaException>();

                var response = await _internalController.DeleteAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.BadGateway);

                _mapper.Received(1).Map<Models.CreditLockService.Internal.Delete.Request.DeleteCustomerRequest>(request);

                await _customerManager.Received(1).DeleteCustomer(internalRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "502"
                    && x.ResponseStatusDescription == "Bad Gateway"
                    && x.RequestType == "DELETE_CUSTOMER"
                    && x.RequestDt == new DateTime(2000, 12, 31, 23, 59, 59, 123)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerDelete.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }
        }

        public class PostUpdateCustomer : InternalCreditLockControllerTests
        {
            public static IEnumerable<object[]> LogInformationMessages()
            {
                yield return new object[]
                {
                    LogEventNames.InternalCreditLockController.CustomerUpdate.Invoked
                };

                yield return new object[]
                {
                    LogEventNames.InternalCreditLockController.CustomerUpdate.Complete
                };
            }

            [Theory]
            [MemberData(nameof(LogInformationMessages))]
            public async Task HappyPathInformationLogged(string information)
            {
                await _internalController.UpdateAsync(new PostRequest());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(information)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PostRequest_ModelStateInvalid_ReturnStatusBadRequest()
            {
                var request = new PostRequest { CustomerId = "Not a Valid customer id" };

                _internalController.ModelState.AddModelError("Test", "TestError");

                var requestDt = new DateTime(2020, 12, 31, 23, 59, 45, 987);

                _dateTime.Now.Returns(requestDt);

                var response = await _internalController.UpdateAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.BadRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "400"
                    && x.ResponseStatusDescription == "Bad Request"
                    && x.RequestType == "UPDATE_CUSTOMER"
                    && x.RequestDt == requestDt
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _mapper.DidNotReceive().Map<CustomerRequest>(Arg.Any<PostRequest>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.DownstreamBadResponse)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.SyncCustomerPinningException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PostRequest_HappyPath_ReturnSuccessNoContent()
            {
                var postRequest = new PostRequest
                {
                    CustomerId = "Valid customer id"
                };

                var requestDt = new DateTime(2020, 12, 31, 23, 59, 45, 987);

                _dateTime.Now.Returns(requestDt);

                var putCustomerRequest = new PutCustomerRequest
                {
                    CustomerId = postRequest.CustomerId
                };

                _mapper.Map<PutCustomerRequest>(postRequest)
                    .Returns(putCustomerRequest);

                var response = await _internalController.UpdateAsync(postRequest) as ObjectResult;

                response.Should().BeOfType<ApiResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.NoContent);

                _mapper.Received(1).Map<PutCustomerRequest>(postRequest);

                await _customerManager.Received(1).UpdateCustomer(putCustomerRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "204"
                    && x.ResponseStatusDescription == "Success"
                    && x.RequestType == "UPDATE_CUSTOMER"
                    && x.RequestDt == requestDt
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.DownstreamBadResponse)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.SyncCustomerPinningException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PostRequest_GeneralException_ReturnsInternalServerError()
            {
                var postRequest = new PostRequest
                {
                    CustomerId = "Valid customer id"
                };

                var internalRequest = new PutCustomerRequest
                {
                    CustomerId = "cb461ff2-ed68-4797-91bc-b438f21de5b0"
                };

                _mapper.Map<PutCustomerRequest>(postRequest)
                    .Returns(internalRequest);

                var requestDt = new DateTime(2020, 12, 31, 23, 59, 45, 987);

                _dateTime.Now.Returns(requestDt);

                _customerManager.UpdateCustomer(internalRequest)
                    .Throws<Exception>();

                var response = await _internalController.UpdateAsync(postRequest) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.InternalServerError);

                _mapper.Received(1).Map<PutCustomerRequest>(postRequest);

                await _customerManager.Received(1).UpdateCustomer(internalRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "500"
                    && x.ResponseStatusDescription == "Internal Server Error"
                    && x.RequestType == "UPDATE_CUSTOMER"
                    && x.RequestDt == requestDt
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.DownstreamBadResponse)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.SyncCustomerPinningException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PostRequest_OktaTokenNullException_ReturnBadGatewayError()
            {
                var postRequest = new PostRequest
                {
                    CustomerId = "Valid customer id"
                };

                var internalRequest = new PutCustomerRequest
                {
                    CustomerId = "cb461ff2-ed68-4797-91bc-b438f21de5b0"
                };

                var requestDt = new DateTime(2020, 12, 31, 23, 59, 45, 987);

                _dateTime.Now.Returns(requestDt);

                _mapper.Map<PutCustomerRequest>(postRequest)
                    .Returns(internalRequest);

                _customerManager.UpdateCustomer(internalRequest)
                    .Throws<OktaTokenNullException>();

                var response = await _internalController.UpdateAsync(postRequest) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.BadGateway);

                _mapper.Received(1).Map<PutCustomerRequest>(postRequest);

                await _customerManager.Received(1).UpdateCustomer(internalRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "502"
                    && x.ResponseStatusDescription == "Bad Gateway"
                    && x.RequestType == "UPDATE_CUSTOMER"
                    && x.RequestDt == requestDt
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.DownstreamBadResponse)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.SyncCustomerPinningException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PostRequest_OktaException_ReturnBadGatewayError()
            {
                var postRequest = new PostRequest
                {
                    CustomerId = "Valid customer id"
                };

                var internalRequest = new PutCustomerRequest
                {
                    CustomerId = "cb461ff2-ed68-4797-91bc-b438f21de5b0"
                };

                _mapper.Map<PutCustomerRequest>(postRequest)
                    .Returns(internalRequest);

                _customerManager.UpdateCustomer(internalRequest)
                    .Throws<OktaException>();

                var response = await _internalController.UpdateAsync(postRequest) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.BadGateway);

                _mapper.Received(1).Map<PutCustomerRequest>(postRequest);

                await _customerManager.Received(1).UpdateCustomer(internalRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "502"
                    && x.ResponseStatusDescription == "Bad Gateway"
                    && x.RequestType == "UPDATE_CUSTOMER"
                    && x.RequestDt == new DateTime(2000, 12, 31, 23, 59, 59, 123)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.DownstreamBadResponse)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.SyncCustomerPinningException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PostRequest_ServiceUnavailableException_ReturnsServiceUnavailableError()
            {
                var postRequest = new PostRequest
                {
                    CustomerId = "Valid customer id"
                };

                var internalRequest = new PutCustomerRequest
                {
                    CustomerId = "cb461ff2-ed68-4797-91bc-b438f21de5b0"
                };

                _mapper.Map<PutCustomerRequest>(postRequest)
                    .Returns(internalRequest);

                _customerManager.UpdateCustomer(internalRequest)
                    .Throws<ServiceUnavailableException>();

                var response = await _internalController.UpdateAsync(postRequest) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.ServiceUnavailable);

                _mapper.Received(1).Map<PutCustomerRequest>(postRequest);

                await _customerManager.Received(1).UpdateCustomer(internalRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "503"
                    && x.ResponseStatusDescription == "Service Unavailable"
                    && x.RequestType == "UPDATE_CUSTOMER"
                    && x.RequestDt == new DateTime(2000, 12, 31, 23, 59, 59, 123)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.DownstreamBadResponse)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.SyncCustomerPinningException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PostRequest_CustomerProfileNotFoundException_ReturnInternalServerError()
            {
                var postRequest = new PostRequest
                {
                    CustomerId = "Valid customer id"
                };

                var internalRequest = new PutCustomerRequest
                {
                    CustomerId = "cb461ff2-ed68-4797-91bc-b438f21de5b0"
                };

                _mapper.Map<PutCustomerRequest>(postRequest)
                    .Returns(internalRequest);

                _customerManager.UpdateCustomer(internalRequest)
                    .Throws<CustomerProfileNotFoundException>();

                var response = await _internalController.UpdateAsync(postRequest) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.InternalServerError);

                _mapper.Received(1).Map<PutCustomerRequest>(postRequest);

                await _customerManager.Received(1).UpdateCustomer(internalRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "500"
                    && x.ResponseStatusDescription == "Internal Server Error"
                    && x.RequestType == "UPDATE_CUSTOMER"
                    && x.RequestDt == new DateTime(2000, 12, 31, 23, 59, 59, 123)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.DownstreamBadResponse)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.SyncCustomerPinningException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PostRequest_DownstreamMaintenanceException_ReturnDownstreamMaintenanceStatusCodeError()
            {
                var postRequest = new PostRequest
                {
                    CustomerId = "Valid customer id"
                };

                var internalRequest = new PutCustomerRequest
                {
                    CustomerId = "cb461ff2-ed68-4797-91bc-b438f21de5b0"
                };

                _mapper.Map<PutCustomerRequest>(postRequest)
                    .Returns(internalRequest);

                _customerManager.UpdateCustomer(internalRequest)
                    .Throws<DownstreamMaintenanceException>();

                var response = await _internalController.UpdateAsync(postRequest) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be(DownstreamMaintenanceStatusCode);

                _mapper.Received(1).Map<PutCustomerRequest>(postRequest);

                await _customerManager.Received(1).UpdateCustomer(internalRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "561"
                    && x.ResponseStatusDescription == "Downstream Service Unavailable - mainframe down for scheduled maintenance"
                    && x.RequestType == "UPDATE_CUSTOMER"
                    && x.RequestDt == new DateTime(2000, 12, 31, 23, 59, 59, 123)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.DownstreamBadResponse)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.SyncCustomerPinningException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PostRequest_HttpServiceRequestException_ReturnInternalServerError()
            {
                var request = new PostRequest
                {
                    CustomerId = "Valid customer id"
                };

                var internalRequest = new PutCustomerRequest
                {
                    CustomerId = "cb461ff2-ed68-4797-91bc-b438f21de5b0"
                };

                _mapper.Map<PutCustomerRequest>(request)
                    .Returns(internalRequest);

                _customerManager.UpdateCustomer(internalRequest)
                    .Throws<HttpServiceRequestException>();

                var response = await _internalController.UpdateAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.InternalServerError);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.DownstreamBadResponse)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                     Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.OktaTokenNullException)), null,
                     Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.SyncCustomerPinningException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PostRequest_ServiceTaskCanceledException_ReturnStatuCode564()
            {
                var request = new PostRequest
                {
                    CustomerId = "Valid customer id"
                };

                var internalRequest = new PutCustomerRequest
                {
                    CustomerId = "cb461ff2-ed68-4797-91bc-b438f21de5b0"
                };

                _mapper.Map<PutCustomerRequest>(request)
                    .Returns(internalRequest);

                _customerManager.UpdateCustomer(internalRequest)
                    .Throws<ServiceTaskCanceledException>();

                var response = await _internalController.UpdateAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be(564);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.DownstreamBadResponse)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                     Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.OktaTokenNullException)), null,
                     Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.SyncCustomerPinningException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PostRequest_DownstreamBadResponseException_ReturnInternalServerError()
            {
                var request = new PostRequest
                {
                    CustomerId = "Valid customer id"
                };

                var internalRequest = new PutCustomerRequest
                {
                    CustomerId = "cb461ff2-ed68-4797-91bc-b438f21de5b0"
                };

                _mapper.Map<PutCustomerRequest>(request)
                    .Returns(internalRequest);

                _customerManager.UpdateCustomer(internalRequest)
                    .Throws<DownstreamBadResponseException>();

                var response = await _internalController.UpdateAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be(DownstreamBadResponseStatusCode);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.DownstreamBadResponse)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                     Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.OktaTokenNullException)), null,
                     Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.SyncCustomerPinningException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PostRequest_CustomerNotFoundException_ReturnNotFound()
            {
                var request = new PostRequest
                {
                    CustomerId = "Valid customer id"
                };

                var internalRequest = new PutCustomerRequest
                {
                    CustomerId = "cb461ff2-ed68-4797-91bc-b438f21de5b0"
                };

                _mapper.Map<PutCustomerRequest>(request)
                    .Returns(internalRequest);

                _customerManager.UpdateCustomer(internalRequest)
                    .Throws<CustomerNotFoundException>();

                var response = await _internalController.UpdateAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.NoContent);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.CustomerNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                     Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.OktaTokenNullException)), null,
                     Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.SyncCustomerPinningException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PostRequest_SyncCustomerPinningException_ReturnConflict()
            {
                var request = new PostRequest
                {
                    CustomerId = "Valid customer id"
                };

                var internalRequest = new PutCustomerRequest
                {
                    CustomerId = "cb461ff2-ed68-4797-91bc-b438f21de5b0"
                };

                _mapper.Map<PutCustomerRequest>(request)
                    .Returns(internalRequest);

                _customerManager.UpdateCustomer(internalRequest)
                    .Throws<SyncCustomerPinningException>();

                var response = await _internalController.UpdateAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.Conflict);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.CustomerNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                     Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.OktaTokenNullException)), null,
                     Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.SyncCustomerPinningException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PostRequest_DownstreamAuthenticationException_ReturnStatusCode563()
            {
                var request = new PostRequest
                {
                    CustomerId = "Valid customer id"
                };

                var internalRequest = new PutCustomerRequest
                {
                    CustomerId = "cb461ff2-ed68-4797-91bc-b438f21de5b0"
                };

                _mapper.Map<PutCustomerRequest>(request)
                    .Returns(internalRequest);

                _customerManager.UpdateCustomer(internalRequest)
                    .Throws<DownstreamAuthenticationException>();

                var response = await _internalController.UpdateAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be(563);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.DownstreamAuthenticationException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.CustomerProfileNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                     Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.OktaTokenNullException)), null,
                     Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.SyncCustomerPinningException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.InternalCreditLockController.CustomerUpdate.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }
        }
    }
}