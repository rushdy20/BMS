﻿namespace EXPN.Models.CreditLockService.Internal
{
    public class SecretsManagerData
    {
        public string KeyName { get; set; }
        public string ClientId { get; set; }
        public string SharedSecret { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string Endpoint { get; set; }
        public string GrantType { get; set; }
        public string Scope { get; set; }
        public string ServiceEndpoint { get; set; }
    }
}