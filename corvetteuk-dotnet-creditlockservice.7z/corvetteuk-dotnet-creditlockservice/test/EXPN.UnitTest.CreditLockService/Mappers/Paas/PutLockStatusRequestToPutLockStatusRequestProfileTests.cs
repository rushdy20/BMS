﻿using AutoMapper;
using EXPN.Mappers.CreditLockService.Paas;
using EXPN.Models.CreditLockService.Internal.Put.Request;
using FluentAssertions;
using System.Collections.Generic;
using Xunit;
using PaasModel = EXPN.Models.CreditLockService.Paas.PutLockStatus.Request;

namespace EXPN.UnitTest.CreditLockService.Mappers.Paas
{
    public class PutLockStatusRequestToPutLockStatusRequestProfileTests
    {
        private readonly MapperConfiguration _mapperConfiguration;

        public PutLockStatusRequestToPutLockStatusRequestProfileTests()
        {
            _mapperConfiguration = new MapperConfiguration(
                cfg => { cfg.AddProfile<PutLockStatusRequestToPutLockStatusRequestProfile>(); });
        }

        [Fact]
        public void ModelProfile_AssertConfiguration_IsValid()
        {
            _mapperConfiguration.AssertConfigurationIsValid();
        }

        public static IEnumerable<object[]> MappingData()
        {
            yield return new object[]
            {
                null,
                null
            };

            yield return new object[]
            {
                new PutLockStatusRequest(),
                new PaasModel.PutLockStatusRequest
                {
                    CustomerRef = string.Empty,
                    Status = "N"
                }
            };

            yield return new object[]
            {
                new PutLockStatusRequest
                {
                    CustomerId = string.Empty,
                    LockStatus = false
                },
                new PaasModel.PutLockStatusRequest
                {
                    CustomerRef = string.Empty,
                    CustomerId= string.Empty,
                    Status = "N"
                }
            };

            yield return new object[]
            {
                new PutLockStatusRequest
                {
                    CustomerId = "ABC",
                    LockStatus = false
                },
                new PaasModel.PutLockStatusRequest
                {
                    CustomerRef = string.Empty,
                    Status = "N",
                    CustomerId = "ABC"
                }
            };

            yield return new object[]
            {
                new PutLockStatusRequest
                {
                    CustomerId = "ABC1234",
                    LockStatus = false
                },
                new PaasModel.PutLockStatusRequest
                {
                    CustomerRef = string.Empty,
                    Status = "N",
                    CustomerId = "ABC1234"

                }
            };

            yield return new object[]
            {
                new PutLockStatusRequest
                {
                    LockStatus = true
                },
                new PaasModel.PutLockStatusRequest
                {
                    CustomerRef = string.Empty,
                    Status = "Y"
                }
            };

            yield return new object[]
            {
                new PutLockStatusRequest
                {
                    CustomerId = string.Empty,
                    LockStatus = true
                },
                new PaasModel.PutLockStatusRequest
                {
                    CustomerRef = string.Empty,
                    Status = "Y",
                    CustomerId = string.Empty
                }
            };

            yield return new object[]
            {
                new PutLockStatusRequest
                {
                    CustomerId = "ABC",
                    LockStatus = true
                },
                new PaasModel.PutLockStatusRequest
                {
                    CustomerRef = string.Empty,
                    Status = "Y",
                    CustomerId = "ABC"
                }
            };

            yield return new object[]
            {
                new PutLockStatusRequest
                {
                    CustomerId = "ABC1234",
                    LockStatus = true
                },
                new PaasModel.PutLockStatusRequest
                {
                    CustomerRef = string.Empty,
                    Status = "Y",
                    CustomerId ="ABC1234"
                }
            };
        }

        [Theory]
        [MemberData(nameof(MappingData))]
        public void InternalModelProfile_ExampleInput_MapsCorrectly(PutLockStatusRequest input, PaasModel.PutLockStatusRequest expected)
        {
            var mapper = _mapperConfiguration.CreateMapper();
            var result = mapper.Map<PaasModel.PutLockStatusRequest>(input);

            result.Should().BeEquivalentTo(expected);
        }
    }
}