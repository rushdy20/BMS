using System.Diagnostics.CodeAnalysis;

namespace EXPN.Models.CreditLockService.External.Put.Request
{
    [ExcludeFromCodeCoverage]
    public class PutStatusRequestBody
    {
        public string Status { get; set; }
    }
}