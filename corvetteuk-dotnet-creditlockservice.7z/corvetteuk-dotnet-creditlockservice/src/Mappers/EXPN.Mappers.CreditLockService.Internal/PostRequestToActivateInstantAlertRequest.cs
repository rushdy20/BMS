﻿using System.Diagnostics.CodeAnalysis;
using AutoMapper;
using EXPN.Models.CreditLockService.External.Post.Request;
using EXPN.Models.CreditLockService.Internal.Post.Request;

namespace EXPN.Mappers.CreditLockService.Internal
{
    [ExcludeFromCodeCoverage]
    public  class PostRequestToActivateInstantAlertRequest :Profile
    {
        public PostRequestToActivateInstantAlertRequest()
        {
            CreateMap<PostRequest, PostActivateInstantAlertRequest>(MemberList.None)
                .ForMember(d => d.CustomerId, m => m.MapFrom(s => s.CustomerId));
        }
    }
}