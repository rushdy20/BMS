﻿using System;
using System.Runtime.Serialization;

namespace EXPN.DataLayer.CreditLockService.Common.Exceptions
{
    [Serializable]
    public class BenefitsInvalidOperationException : Exception
    {
        protected BenefitsInvalidOperationException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }

        public BenefitsInvalidOperationException()
        {
        }

        public BenefitsInvalidOperationException(string message)
            : base(message)
        {
        }

        public BenefitsInvalidOperationException(string message, Exception innerException)
            : base(message, innerException)
        {
        }
    }
}