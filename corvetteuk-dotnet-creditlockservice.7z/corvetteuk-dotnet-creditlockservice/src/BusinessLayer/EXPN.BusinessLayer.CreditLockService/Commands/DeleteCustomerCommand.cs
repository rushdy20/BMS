﻿using AutoMapper;
using Experian.AWS.Logging.Extensions;
using EXPN.BusinessLayer.CreditLockService.Constants;
using EXPN.DataLayer.CreditLockService.Paas.HttpClient;
using EXPN.Models.CreditLockService.Internal.Delete.Request;
using EXPN.Models.CreditLockService.Internal.Delete.Response;
using EXPN.Models.CreditLockService.Internal.Get.Response;
using Microsoft.Extensions.Logging;
using System;
using PaaSRequest = EXPN.Models.CreditLockService.Paas.Delete.Request;

namespace EXPN.BusinessLayer.CreditLockService.Commands
{
    public class DeleteCustomerCommand<TRequest, TResponse> : ICommand<TRequest, TResponse>
        where TRequest : DeleteCustomerRequest
        where TResponse : DeleteCustomerResponse
    {
        private readonly ICreditLockPaasClient _creditLockPaasClient;
        private readonly ILogger<DeleteCustomerCommand<TRequest, TResponse>> _logger;
        private readonly IMapper _mapper;

        public DeleteCustomerCommand(ICreditLockPaasClient creditLockPaasClient,
            ILogger<DeleteCustomerCommand<TRequest, TResponse>> logger,
            IMapper mapper)
        {
            _creditLockPaasClient = creditLockPaasClient ?? throw new ArgumentNullException(nameof(creditLockPaasClient));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        }

        public string Id => "DELETE CUSTOMER";

        public TResponse Execute(TRequest request, GetResponseCustomerProfile customerProfile)
        {
            _logger.LogAsInformation(LogEventNames.DeleteCustomerCommand.Execute.Enter);

            if (request == null)
                throw new ArgumentNullException(nameof(request)); 

            if (string.IsNullOrWhiteSpace(request.CustomerId))
                throw new ArgumentException($"{nameof(request.CustomerId)} cannot be null or whitespace", nameof(request));

            var paasDeleteCustomerRequest = _mapper.Map<PaaSRequest.DeleteCustomerRequest>(request);

            _creditLockPaasClient.Delete(paasDeleteCustomerRequest).Wait();

            _logger.LogAsInformation(LogEventNames.DeleteCustomerCommand.Execute.Exit);

            return (TResponse)new DeleteCustomerResponse
            {
                CustomerId = request.CustomerId
            };
        }
    }
}