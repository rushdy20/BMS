﻿using System.Diagnostics.CodeAnalysis;

namespace EXPN.Models.CreditLockService.Internal.Post.Response
{
    [ExcludeFromCodeCoverage]
    public class PostActivateInstantAlertResponse
    {
        public string LockStatus { get; set; }
    }
}