using System;
using System.IO;

namespace EXPN.IntegrationTest.CreditLockService.Utility
{
    public static class SolutionFileSystem
    {
        public static string Root
        {
            get { return AppContext.BaseDirectory.GetAncestor(f => File.Exists(Path.Combine(f, "CreditLockService.sln"))); }
        }
    }
}
