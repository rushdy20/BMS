﻿using System;
using System.Collections.Generic;
using System.Linq;
using EXPN.Models.CreditLockService.External.Put.Request;
using FluentValidation;

namespace EXPN.Validators.CreditLockService.Put.Customer
{
    public class PutStatusRequestBodyValidator : AbstractValidator<PutStatusRequestBody>
    {
        private readonly List<string> _statusType = new List<string> { "ON", "OFF" };

        public PutStatusRequestBodyValidator()
        {
            RuleFor(x => x)
                .NotNull()
                .WithName(nameof(PutStatusRequestBody))
                .DependentRules(() =>
                {
                    RuleFor(x => x.Status)
                        .Cascade(CascadeMode.StopOnFirstFailure)
                        .NotEmpty()
                        .Must(x => _statusType.Contains(x, StringComparer.OrdinalIgnoreCase))
                        .WithMessage("'{PropertyValue}' is not a valid Status type.");
                });
        }

        protected override void EnsureInstanceNotNull(object instanceToValidate)
        {
            // v6.4  of FluentValidation causes Validators to reject null input, instead of allowing NotNull() to handle it. 
            // This implements the suggested workaround by the library author - https://github.com/JeremySkinner/FluentValidation/issues/486
        }
    }
}