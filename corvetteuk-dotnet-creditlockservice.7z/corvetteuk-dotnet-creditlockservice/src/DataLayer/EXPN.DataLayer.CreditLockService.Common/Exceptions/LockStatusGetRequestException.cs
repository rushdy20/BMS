﻿using System;
using System.Runtime.Serialization;

namespace EXPN.DataLayer.CreditLockService.Common.Exceptions
{
    [Serializable]
    public class LockStatusGetRequestException : Exception
    {
        protected LockStatusGetRequestException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }

        public LockStatusGetRequestException()
        {
        }

        public LockStatusGetRequestException(string message)
            : base(message)
        {
        }

        public LockStatusGetRequestException(string message, Exception innerException)
            : base(message, innerException)
        {
        }
    }
}