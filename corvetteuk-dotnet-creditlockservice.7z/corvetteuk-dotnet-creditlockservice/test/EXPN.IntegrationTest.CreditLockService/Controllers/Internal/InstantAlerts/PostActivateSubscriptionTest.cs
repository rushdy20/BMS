﻿using EXPN.DataLayer.CreditLockService.Paas.HttpClient;
using EXPN.IntegrationTest.CreditLockService.Utility;
using FluentAssertions;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using System.Net;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Xunit;

namespace EXPN.IntegrationTest.CreditLockService.Controllers.Internal.InstantAlerts
{
    public class PostActivateSubscriptionTest
    {
        private readonly IHostBuilder _hostBuilder;

        public PostActivateSubscriptionTest()
        {
            _hostBuilder = new HostBuilder()
                .UseIntegrationTestSettings()
                .ConfigureServices(s =>
                    s.AddHttpClient<ICreditLockPaasClient, CreditLockPaasClient>(c =>
                    {
                        c.DefaultRequestHeaders
                            .Accept
                            .Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    }).AddHttpMessageHandler<MockPaasHttpClientHandler>());
        }

        public static IEnumerable<object[]> GetReportData()
        {
            yield return new object[]
            {
                "4b1f51c5-e902-4efb-8366-816e29e788e7",
                (HttpStatusCode) 204,
                null
            };

            yield return new object[]
            {
                "not a valid id",
                (HttpStatusCode) 400,
                "{\"fieldErrors\": {\"CustomerId\": \"'CustomerId' is not in valid format\"},\"status\": 400,\"message\": null}"
            };

            yield return new object[]
            {
                "4a1f51c5-e902-4efb-8366-816e29e78561",
                (HttpStatusCode) 561,
                "{\"fieldErrors\":{},\"status\":561,\"message\":null}"
            };

            yield return new object[]
            {
                "4a1f51c5-e902-4efb-8366-816e29e78503",
                (HttpStatusCode) 503,
                "{\"fieldErrors\":{},\"status\":503,\"message\":null}"
            };

            yield return new object[]
            {
                "4a1f51c5-e902-4efb-8399-816e29e78555",
                (HttpStatusCode) 500,
                "{\"fieldErrors\": {},\"status\": 500,\"message\": null}"
            };

            yield return new object[]
            {
                "4a1f51c5-e902-4efb-8366-816e29e78404",
                (HttpStatusCode) 404,
                "{\"fieldErrors\":{},\"status\":404,\"message\":null}"
            };

            yield return new object[]
            {
                "4a1f51c5-e902-4efb-8400-816e29e78999",
                (HttpStatusCode) 563,
                "{\"fieldErrors\": {},\"status\": 563,\"message\": null}"
            };
        }

        [Theory]
        [MemberData(nameof(GetReportData))]
        public async Task PostActivateSubscription_ResponseExpectedStatusCode(string customerId, HttpStatusCode expectedStatusCode, string expectedServiceResponseJsonStr)
        {
            const string endPoint = "/internal/instantalerts/activate";

            var actualServiceResponse = await CommonIntegrationFunctions.PostRequest(endPoint, customerId, _hostBuilder);

            actualServiceResponse.StatusCode.Should().Be(expectedStatusCode);

            if (expectedServiceResponseJsonStr != null)
            {
                var actualServiceResponseJsonStr = await actualServiceResponse.Content.ReadAsStringAsync();

                JToken.DeepEquals(JObject.Parse(actualServiceResponseJsonStr),
                    JObject.Parse(expectedServiceResponseJsonStr)).Should().BeTrue();
            }
        }
    }
}