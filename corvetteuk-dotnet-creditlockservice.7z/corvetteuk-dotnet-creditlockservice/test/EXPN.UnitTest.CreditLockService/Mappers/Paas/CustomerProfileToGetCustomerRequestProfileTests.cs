﻿using AutoMapper;
using EXPN.Mappers.CreditLockService.Paas;
using EXPN.Models.CreditLockService.Internal.Get.Response;
using EXPN.Models.CreditLockService.Paas.Get.Request;
using FluentAssertions;
using System.Collections.Generic;
using Xunit;

namespace EXPN.UnitTest.CreditLockService.Mappers.Paas
{
    public class CustomerProfileToGetCustomerRequestProfileTests
    {
        private readonly MapperConfiguration _mapperConfiguration;

        public CustomerProfileToGetCustomerRequestProfileTests()
        {
            _mapperConfiguration = new MapperConfiguration(
                cfg => { cfg.AddProfile<CustomerProfileToGetCustomerRequestProfile>(); });
        }

        [Fact]
        public void ModelProfile_AssertConfiguration_IsValid()
        {
            _mapperConfiguration.AssertConfigurationIsValid();
        }

        public static IEnumerable<object[]> MappingData()
        {
            yield return new object[]
            {
                null,
                null
            };
            yield return new object[]
            {
                new GetResponseCustomerProfile(),
                new GetCustomerRequest()
            };

            yield return new object[]
            {
                new GetResponseCustomerProfile
                {
                    IconRef = string.Empty,
                    CustomerId = string.Empty,
                },
                new GetCustomerRequest
                {
                    CustomerId = string.Empty,
                }
            };

            yield return new object[]
            {
                new GetResponseCustomerProfile
                {
                    IconRef = string.Empty.PadLeft(1),
                    CustomerId = string.Empty.PadLeft(1)

                },
                new GetCustomerRequest
                {
                    CustomerId= string.Empty.PadLeft(1)
                }
            };

            yield return new object[]
            {
                new GetResponseCustomerProfile
                {
                    IconRef = "12345678A",
                    CustomerRef = "customerRef",
                    CustomerId = "customerId"
                },
                new GetCustomerRequest
                {
                    CustomerRef = "customerRef",
                    CustomerId = "customerId"
                }
            };
        }

        [Theory]
        [MemberData(nameof(MappingData))]
        public void ExternalModelProfile_ExampleInput_MapsCorrectly(GetResponseCustomerProfile input, GetCustomerRequest expected)
        {
            var mapper = _mapperConfiguration.CreateMapper();
            var result = mapper.Map<GetCustomerRequest>(input);

            result.Should().BeEquivalentTo(expected);
        }
    }
}