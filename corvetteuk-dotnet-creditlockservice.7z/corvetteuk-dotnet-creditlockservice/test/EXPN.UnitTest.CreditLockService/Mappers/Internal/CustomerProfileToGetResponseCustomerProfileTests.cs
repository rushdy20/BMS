﻿using AutoMapper;
using Experian.HttpClient.Services.Customers.Models.External;
using EXPN.Mappers.CreditLockService.Internal;
using EXPN.Models.CreditLockService.Internal.Get.Response;
using FluentAssertions;
using System;
using System.Collections.Generic;
using Xunit;
using GetResponseCustomerAddressModel = EXPN.Models.CreditLockService.Internal.Get.Response.GetResponseCustomerAddressModel;

namespace EXPN.UnitTest.CreditLockService.Mappers.Internal
{
    public class CustomerProfileToGetResponseCustomerProfileTests
    {
        private readonly MapperConfiguration _mapperConfiguration;

        public CustomerProfileToGetResponseCustomerProfileTests()
        {
            _mapperConfiguration = new MapperConfiguration(
                cfg =>
                {
                    cfg.AddProfile<CustomerProfileToGetResponseCustomerProfile>();
                    cfg.AddProfile<CustomerProfilerAddressToGetResponseCustomerAddressModelProfiler>();
                });
        }

        [Fact]
        public void ModelProfile_AssertConfiguration_IsValid()
        {
            _mapperConfiguration.AssertConfigurationIsValid();
        }

        public static IEnumerable<object[]> MappingData()
        {
            yield return new object[]
            {
                null,
                null
            };

            yield return new object[]
            {
                new CustomerProfile(),
                new GetResponseCustomerProfile
                    {
                        Address = new List<GetResponseCustomerAddressModel>()
                    }
            };

            yield return new object[]
            {
                new CustomerProfile
                {
                    Address = new List<AddressModel>
                    {
                        new()
                        {
                            Abroad = false,
                            AddressType = "c",
                            City = "city",
                            Country = "country",
                            County = "county",
                            District = "district",
                            Flat = "flat",
                            FromDt = new DateTime(2010,8,31),
                            HouseName = "houseName",
                            HouseNumber = "houseNumber",
                            IsVerified = false,
                            LastUpdatedDt = new DateTime(2019, 12, 31),
                            Manual = false,
                            PostCode = "postcode",
                            Street = "street",
                            ToDt = new DateTime()
                        }
                    },
                    AliasFirstName = new List<Alias>(),
                    AliasLastName = new List<Alias>(),
                    AliasMiddleName = new List<Alias>(),
                    CorrelationId = "correlationId",
                    CreateDt = new DateTime(2020,12,31),
                    CustomerId = "customerId",
                    CustomerNumber = "customerNumber",
                    CustomerStatus = "customerStatus",
                    DOB = "1970-12-31",
                    Email = "email",
                    ExperianRef = "experianRef",
                    FirstName = "firstName",
                    Gender = "gender",
                    IconRef = "iconRef",
                    IdpRefId = "ipdRefId",
                    IdpRefInfo = new ProviderAuthModel
                    {
                        AuthenticatedDt = new DateTime(2020, 6, 30),
                        AuthLevel = "authLevel",
                        ProviderName = "providerName"
                    },
                    IsCustomerDataVerified = new CustomerDataVerifiedModel
                    {
                        DOB = false,
                        Email = false,
                        FirstName = false,
                        LastName = false,
                        MiddleName = false,
                        PreviousLastName = false
                    },
                    LastName = "lastName",
                    MiddleName = "middleName",
                    MothersMaidenName = "motherMaidenName",
                    MotivationReason = "motivationReason",
                    Phone = new List<PhoneModel>
                    {
                        new()
                        {
                            IsVerified = false,
                            PhoneNumber = "0123456789",
                            PhoneType = "phoneType"
                        }
                    },
                    PhxCustomerNumber = "phxCustomerNumber",
                    PotentialMatches = new List<PotentialMatches>(),
                    PreviousLastName = "previousLastName",
                    ProspectId = "prospectId",
                    RegisteredName = new List<RegisteredName>(),
                    SessionId = "sessionId",
                    TenantId = "tenantId",
                    Title = "title",
                    UpdateDt = new DateTime(2021, 1, 1),
                    VerifiedName = new List<RegisteredName>
                    {
                        new()
                        {
                            FirstName = "registeredFirstName",
                            FromDt = new DateTime(1999, 12, 30),
                            IsFirstNameVerified = false,
                            IsLastNameVerified = false,
                            IsMiddleNameVerified = false,
                            LastName = "registeredLastName",
                            MiddleName = "registeredMiddleName",
                            Title = "registeredTitle",
                            ToDt = null
                        }
                    }
                },
                new GetResponseCustomerProfile
                {
                    CustomerId = "customerId",
                    CorrelationId = "correlationId",
                    Title = "title",
                    FirstName = "firstName",
                    MiddleName = "middleName",
                    LastName = "lastName",
                    DOB = "1970-12-31",
                    IconRef = "iconRef",
                    Address = new List<GetResponseCustomerAddressModel>
                    {
                        new()
                        {
                            AddressType = "c",
                            City = "city",
                            Country = "country",
                            County = "county",
                            District = "district",
                            Flat = "flat",
                            HouseNumber = "houseNumbe",
                            HouseName = "houseName",
                            IsVerified = false,
                            Manual = false,
                            Abroad = false,
                            PostCode = "postcode",
                            Street = "street",
                            LastUpdatedDt = new DateTime(2019,12 ,31 ),
                            FromDt = new DateTime(2010, 8,31),
                            ToDt = new DateTime(),
                            IsCurrent = true
                        }
                    },
                    CustomerRef = "customerNumber"

                }
            };

            yield return new object[]
            {
                new CustomerProfile
                {
                    Address = new List<AddressModel>
                    {
                        new()
                        {
                            Abroad = false,
                            AddressType = "addressType1",
                            City = "city1",
                            Country = "country1",
                            County = "county1",
                            District = "district1",
                            Flat = "flat1",
                            FromDt = new DateTime(2010,8,31),
                            HouseName = "houseName1",
                            HouseNumber = "houseNumber1",
                            IsVerified = false,
                            LastUpdatedDt = new DateTime(2019, 12, 31),
                            Manual = false,
                            PostCode = "postcode1",
                            Street = "street1",
                            ToDt = new DateTime(2012, 2, 29)
                        },
                        new()
                        {
                            Abroad = true,
                            AddressType = "addressType2",
                            City = "city2",
                            Country = "country2",
                            County = "county2",
                            District = "district2",
                            Flat = "flat2",
                            FromDt = new DateTime(2015,2,28),
                            HouseName = "houseName2",
                            HouseNumber = "houseNumber2",
                            IsVerified = true,
                            LastUpdatedDt = new DateTime(2020, 12, 31),
                            Manual = true,
                            PostCode = "postcode2",
                            Street = "street2",
                            ToDt = new DateTime(2017, 2, 28)
                        },
                        new()
                        {
                            Abroad = false,
                            AddressType = "addressType3",
                            City = "city3",
                            Country = "country3",
                            County = "county3",
                            District = "district3",
                            Flat = "flat3",
                            FromDt = new DateTime(2019,8,31),
                            HouseName = "houseName3",
                            HouseNumber = "houseNumber3",
                            IsVerified = false,
                            LastUpdatedDt = new DateTime(2021, 12, 31),
                            Manual = false,
                            PostCode = "postcode3",
                            Street = "street3",
                            ToDt = new DateTime(2021, 12, 31)
                        }
                    },
                    AliasFirstName = new List<Alias>(),
                    AliasLastName = new List<Alias>(),
                    AliasMiddleName = new List<Alias>(),
                    CorrelationId = "correlationId",
                    CreateDt = new DateTime(2020,12,31),
                    CustomerId = "customerId",
                    CustomerNumber = "customerNumber",
                    CustomerStatus = "customerStatus",
                    DOB = "1970-12-31",
                    Email = "email",
                    ExperianRef = "experianRef",
                    FirstName = "firstName",
                    Gender = "gender",
                    IconRef = "iconRef",
                    IdpRefId = "ipdRefId",
                    IdpRefInfo = new ProviderAuthModel
                    {
                        AuthenticatedDt = new DateTime(2020, 6, 30),
                        AuthLevel = "authLevel",
                        ProviderName = "providerName"
                    },
                    IsCustomerDataVerified = new CustomerDataVerifiedModel
                    {
                        DOB = false,
                        Email = false,
                        FirstName = false,
                        LastName = false,
                        MiddleName = false,
                        PreviousLastName = false
                    },
                    LastName = "lastName",
                    MiddleName = "middleName",
                    MothersMaidenName = "motherMaidenName",
                    MotivationReason = "motivationReason",
                    Phone = new List<PhoneModel>
                    {
                        new()
                        {
                            IsVerified = false,
                            PhoneNumber = "0123456789",
                            PhoneType = "phoneType"
                        }
                    },
                    PhxCustomerNumber = "phxCustomerNumber",
                    PotentialMatches = new List<PotentialMatches>(),
                    PreviousLastName = "previousLastName",
                    ProspectId = "prospectId",
                    RegisteredName = new List<RegisteredName>(),
                    SessionId = "sessionId",
                    TenantId = "tenantId",
                    Title = "title",
                    UpdateDt = new DateTime(2021, 1, 1),
                    VerifiedName = new List<RegisteredName>
                    {
                        new()
                        {
                            FirstName = "registeredFirstName",
                            FromDt = new DateTime(1999, 12, 30),
                            IsFirstNameVerified = false,
                            IsLastNameVerified = false,
                            IsMiddleNameVerified = false,
                            LastName = "registeredLastName",
                            MiddleName = "registeredMiddleName",
                            Title = "registeredTitle",
                            ToDt = null
                        }
                    }
                },
                new GetResponseCustomerProfile
                {
                    CustomerId = "customerId",
                    CorrelationId = "correlationId",
                    Title = "title",
                    FirstName = "firstName",
                    MiddleName = "middleName",
                    LastName = "lastName",
                    DOB = "1970-12-31",
                    IconRef = "iconRef",
                    Address = new List<GetResponseCustomerAddressModel>
                    {
                        new()
                        {
                            AddressType = "addressType1",
                            City = "city1",
                            Country = "country1",
                            County = "county1",
                            District = "district1",
                            Flat = "flat1",
                            HouseNumber = "houseNumbe",
                            HouseName = "houseName1",
                            IsVerified = false,
                            Manual = false,
                            Abroad = false,
                            PostCode = "postcode",
                            Street = "street1",
                            LastUpdatedDt = new DateTime(2019,12 ,31 ),
                            FromDt = new DateTime(2010, 8,31),
                            ToDt = new DateTime(2012,2,29)
                        },
                        new()
                        {
                            Abroad = false,
                            AddressType = "addressType3",
                            City = "city3",
                            Country = "country3",
                            County = "county3",
                            District = "district3",
                            Flat = "flat3",
                            FromDt = new DateTime(2019,8,31),
                            HouseName = "houseName3",
                            HouseNumber = "houseNumbe",
                            IsVerified = false,
                            LastUpdatedDt = new DateTime(2021, 12, 31),
                            Manual = false,
                            PostCode = "postcode",
                            Street = "street3",
                            ToDt = new DateTime(2021, 12, 31)
                        }

                    },
                    CustomerRef = "customerNumber"
                }
            };

            yield return new object[]
            {
                new CustomerProfile
                     {
                         Address = new List<AddressModel>
                         {
                             new()
                             {
                                 Abroad = false,
                                 AddressType = "c",
                                 City = "city1",
                                 Country = "country1",
                                 County = "county1",
                                 District = "district1",
                                 Flat = "flat1",
                                 FromDt = new DateTime(2011,1,31),
                                 HouseName = "houseName1",
                                 HouseNumber = "houseNumber1",
                                 IsVerified = false,
                                 LastUpdatedDt = new DateTime(2019, 12, 31),
                                 Manual = false,
                                 PostCode = "postcode1",
                                 Street = "street1",
                                 ToDt = new DateTime()
                             },
                             new()
                             {
                                 Abroad = true,
                                 AddressType = "addressType2",
                                 City = "city2",
                                 Country = "country2",
                                 County = "county2",
                                 District = "district2",
                                 Flat = "flat2",
                                 FromDt = new DateTime(2010,1,31),
                                 HouseName = "houseName2",
                                 HouseNumber = "houseNumber2",
                                 IsVerified = true,
                                 LastUpdatedDt = new DateTime(2020, 12, 31),
                                 Manual = true,
                                 PostCode = "postcode2",
                                 Street = "street2",
                                 ToDt = new DateTime(2021, 12, 31)
                             },
                             new()
                             {
                                 Abroad = false,
                                 AddressType = "addressType3",
                                 City = "city3",
                                 Country = "country3",
                                 County = "county3",
                                 District = "district3",
                                 Flat = "flat3",
                                 FromDt = new DateTime(2009,01,31),
                                 HouseName = "houseName3",
                                 HouseNumber = "houseNumber3",
                                 IsVerified = false,
                                 LastUpdatedDt = new DateTime(2021, 12, 31),
                                 Manual = false,
                                 PostCode = "postcode3",
                                 Street = "street3",
                                 ToDt = new DateTime(2021, 12, 31)
                             },
                             new()
                             {
                                 Abroad = false,
                                 AddressType = "addressType4",
                                 City = "city4",
                                 Country = "country4",
                                 County = "county4",
                                 District = "district4",
                                 Flat = "flat4",
                                 FromDt = new DateTime(2008,01,31),
                                 HouseName = "houseName3",
                                 HouseNumber = "houseNumber3",
                                 IsVerified = false,
                                 LastUpdatedDt = new DateTime(2021, 12, 31),
                                 Manual = false,
                                 PostCode = "postcode4",
                                 Street = "street4",
                                 ToDt = new DateTime(2021, 12, 31)
                             },
                             new()
                             {
                                 Abroad = false,
                                 AddressType = "addressType3",
                                 City = "city5",
                                 Country = "country5",
                                 County = "county5",
                                 District = "district5",
                                 Flat = "flat3",
                                 FromDt = new DateTime(2007,01,31),
                                 HouseName = "houseName5",
                                 HouseNumber = "houseNumber5",
                                 IsVerified = false,
                                 LastUpdatedDt = new DateTime(2021, 12, 31),
                                 Manual = false,
                                 PostCode = "postcode5",
                                 Street = "street5",
                                 ToDt = new DateTime(2021, 12, 31)
                             },
                             new()
                             {
                                 Abroad = false,
                                 AddressType = "addressType3",
                                 City = "city6",
                                 Country = "country6",
                                 County = "county6",
                                 District = "district6",
                                 Flat = "flat6",
                                 FromDt = new DateTime(2006,01,31),
                                 HouseName = "houseName6",
                                 HouseNumber = "houseNumber6",
                                 IsVerified = false,
                                 LastUpdatedDt = new DateTime(2021, 12, 31),
                                 Manual = false,
                                 PostCode = "postcode6",
                                 Street = "street6",
                                 ToDt = new DateTime(2021, 12, 31)
                             },
                             new()
                             {
                                 Abroad = false,
                                 AddressType = "addressType7",
                                 City = "city7",
                                 Country = "country7",
                                 County = "county7",
                                 District = "district7",
                                 Flat = "flat7",
                                 FromDt = new DateTime(2005,01,31),
                                 HouseName = "houseName7",
                                 HouseNumber = "houseNumber7",
                                 IsVerified = false,
                                 LastUpdatedDt = new DateTime(2021, 12, 31),
                                 Manual = false,
                                 PostCode = "postcode7",
                                 Street = "street7",
                                 ToDt = new DateTime(2021, 12, 31)
                             },
                             new()
                             {
                                 Abroad = false,
                                 AddressType = "addressType8",
                                 City = "city8",
                                 Country = "country8",
                                 County = "county8",
                                 District = "district8",
                                 Flat = "flat8",
                                 FromDt = new DateTime(2004,01,31),
                                 HouseName = "houseName8",
                                 HouseNumber = "houseNumber8",
                                 IsVerified = false,
                                 LastUpdatedDt = new DateTime(2021, 12, 31),
                                 Manual = false,
                                 PostCode = "postcode8",
                                 Street = "street8",
                                 ToDt = new DateTime(2021, 12, 31)
                             },
                             new()
                             {
                                 Abroad = true,
                                 AddressType = "addressType9",
                                 City = "city9",
                                 Country = "country9",
                                 County = "county9",
                                 District = "district9",
                                 Flat = "flat9",
                                 FromDt = new DateTime(2003,01,31),
                                 HouseName = "houseName9",
                                 HouseNumber = "houseNumber9",
                                 IsVerified = false,
                                 LastUpdatedDt = new DateTime(2021, 12, 31),
                                 Manual = false,
                                 PostCode = "postcode9",
                                 Street = "street9",
                                 ToDt = new DateTime(2021, 12, 31)
                             },
                             new()
                             {
                                 Abroad = false,
                                 AddressType = "addressType10",
                                 City = "city10",
                                 Country = "country10",
                                 County = "county10",
                                 District = "district10",
                                 Flat = "flat3",
                                 FromDt = new DateTime(2002,01,31),
                                 HouseName = "houseName10",
                                 HouseNumber = "houseNumber10",
                                 IsVerified = false,
                                 LastUpdatedDt = new DateTime(2021, 12, 31),
                                 Manual = false,
                                 PostCode = "postcode10",
                                 Street = "street10",
                                 ToDt = new DateTime(2021, 12, 31)
                             },
                             new()
                             {
                                 Abroad = false,
                                 AddressType = "addressType11",
                                 City = "city11",
                                 Country = "country11",
                                 County = "county11",
                                 District = "district11",
                                 Flat = "flat11",
                                 FromDt = new DateTime(2001,01,31),
                                 HouseName = "houseName11",
                                 HouseNumber = "houseNumber11",
                                 IsVerified = false,
                                 LastUpdatedDt = new DateTime(2021, 12, 31),
                                 Manual = false,
                                 PostCode = "postcode11",
                                 Street = "street11",
                                 ToDt = new DateTime(2021, 12, 31)
                             },
                             new()
                             {
                                 Abroad = false,
                                 AddressType = "addressType11",
                                 City = "city12",
                                 Country = "country12",
                                 County = "county12",
                                 District = "district12",
                                 Flat = "flat12",
                                 FromDt = new DateTime(2000,01,31),
                                 HouseName = "houseName12",
                                 HouseNumber = "houseNumber12",
                                 IsVerified = false,
                                 LastUpdatedDt = new DateTime(2021, 12, 31),
                                 Manual = false,
                                 PostCode = "postcode12",
                                 Street = "street12",
                                 ToDt = new DateTime(2021, 12, 31)
                             }
                         },
                         AliasFirstName = new List<Alias>(),
                         AliasLastName = new List<Alias>(),
                         AliasMiddleName = new List<Alias>(),
                         CorrelationId = "correlationId",
                         CreateDt = new DateTime(2020,12,31),
                         CustomerId = "customerId",
                         CustomerNumber = "customerNumber",
                         CustomerStatus = "customerStatus",
                         DOB = "1970-12-31",
                         Email = "email",
                         ExperianRef = "experianRef",
                         FirstName = "firstName",
                         Gender = "gender",
                         IconRef = "iconRef",
                         IdpRefId = "ipdRefId",
                         IdpRefInfo = new ProviderAuthModel
                         {
                             AuthenticatedDt = new DateTime(2020, 6, 30),
                             AuthLevel = "authLevel",
                             ProviderName = "providerName"
                         },
                         IsCustomerDataVerified = new CustomerDataVerifiedModel
                         {
                             DOB = false,
                             Email = false,
                             FirstName = false,
                             LastName = false,
                             MiddleName = false,
                             PreviousLastName = false
                         },
                         LastName = "lastName",
                         MiddleName = "middleName",
                         MothersMaidenName = "motherMaidenName",
                         MotivationReason = "motivationReason",
                         Phone = new List<PhoneModel>
                         {
                             new()
                             {
                                 IsVerified = false,
                                 PhoneNumber = "0123456789",
                                 PhoneType = "phoneType"
                             }
                         },
                         PhxCustomerNumber = "phxCustomerNumber",
                         PotentialMatches = new List<PotentialMatches>(),
                         PreviousLastName = "previousLastName",
                         ProspectId = "prospectId",
                         RegisteredName = new List<RegisteredName>(),
                         SessionId = "sessionId",
                         TenantId = "tenantId",
                         Title = "title",
                         UpdateDt = new DateTime(2021, 1, 1),
                         VerifiedName = new List<RegisteredName>
                         {
                             new()
                             {
                                 FirstName = "registeredFirstName",
                                 FromDt = new DateTime(1999, 12, 30),
                                 IsFirstNameVerified = false,
                                 IsLastNameVerified = false,
                                 IsMiddleNameVerified = false,
                                 LastName = "registeredLastName",
                                 MiddleName = "registeredMiddleName",
                                 Title = "registeredTitle",
                                 ToDt = null
                             }
                         }
                     },
                new GetResponseCustomerProfile
                     {
                         CustomerId = "customerId",
                         CorrelationId = "correlationId",
                         Title = "title",
                         FirstName = "firstName",
                         MiddleName = "middleName",
                         LastName = "lastName",
                         DOB = "1970-12-31",
                         IconRef = "iconRef",
                         Address = new List<GetResponseCustomerAddressModel>
                         {
                             new()
                             {
                                 Abroad = false,
                                 AddressType = "c",
                                 City = "city1",
                                 Country = "country1",
                                 County = "county1",
                                 District = "district1",
                                 Flat = "flat1",
                                 FromDt = new DateTime(2011,1,31),
                                 HouseName = "houseName1",
                                 HouseNumber = "houseNumbe",
                                 IsVerified = false,
                                 LastUpdatedDt = new DateTime(2019, 12, 31),
                                 Manual = false,
                                 PostCode = "postcode",
                                 Street = "street1",
                                 ToDt = new DateTime(),
                                 IsCurrent = true
                             },
                             new()
                             {
                                 Abroad = false,
                                 AddressType = "addressType3",
                                 City = "city3",
                                 Country = "country3",
                                 County = "county3",
                                 District = "district3",
                                 Flat = "flat3",
                                 FromDt = new DateTime(2009,01,31),
                                 HouseName = "houseName3",
                                 HouseNumber = "houseNumbe",
                                 IsVerified = false,
                                 LastUpdatedDt = new DateTime(2021, 12, 31),
                                 Manual = false,
                                 PostCode = "postcode",
                                 Street = "street3",
                                 ToDt = new DateTime(2021, 12, 31)
                             },
                             new()
                             {
                                 Abroad = false,
                                 AddressType = "addressType4",
                                 City = "city4",
                                 Country = "country4",
                                 County = "county4",
                                 District = "district4",
                                 Flat = "flat4",
                                 FromDt = new DateTime(2008,01,31),
                                 HouseName = "houseName3",
                                 HouseNumber = "houseNumbe",
                                 IsVerified = false,
                                 LastUpdatedDt = new DateTime(2021, 12, 31),
                                 Manual = false,
                                 PostCode = "postcode",
                                 Street = "street4",
                                 ToDt = new DateTime(2021, 12, 31)
                             },
                             new()
                             {
                                 Abroad = false,
                                 AddressType = "addressType3",
                                 City = "city5",
                                 Country = "country5",
                                 County = "county5",
                                 District = "district5",
                                 Flat = "flat3",
                                 FromDt = new DateTime(2007,01,31),
                                 HouseName = "houseName5",
                                 HouseNumber = "houseNumbe",
                                 IsVerified = false,
                                 LastUpdatedDt = new DateTime(2021, 12, 31),
                                 Manual = false,
                                 PostCode = "postcode",
                                 Street = "street5",
                                 ToDt = new DateTime(2021, 12, 31)
                             },
                             new()
                             {
                                 Abroad = false,
                                 AddressType = "addressType3",
                                 City = "city6",
                                 Country = "country6",
                                 County = "county6",
                                 District = "district6",
                                 Flat = "flat6",
                                 FromDt = new DateTime(2006,01,31),
                                 HouseName = "houseName6",
                                 HouseNumber = "houseNumbe",
                                 IsVerified = false,
                                 LastUpdatedDt = new DateTime(2021, 12, 31),
                                 Manual = false,
                                 PostCode = "postcode",
                                 Street = "street6",
                                 ToDt = new DateTime(2021, 12, 31)
                             },
                             new()
                             {
                                 Abroad = false,
                                 AddressType = "addressType7",
                                 City = "city7",
                                 Country = "country7",
                                 County = "county7",
                                 District = "district7",
                                 Flat = "flat7",
                                 FromDt = new DateTime(2005,01,31),
                                 HouseName = "houseName7",
                                 HouseNumber = "houseNumbe",
                                 IsVerified = false,
                                 LastUpdatedDt = new DateTime(2021, 12, 31),
                                 Manual = false,
                                 PostCode = "postcode",
                                 Street = "street7",
                                 ToDt = new DateTime(2021, 12, 31)
                             },
                             new()
                             {
                                 Abroad = false,
                                 AddressType = "addressType8",
                                 City = "city8",
                                 Country = "country8",
                                 County = "county8",
                                 District = "district8",
                                 Flat = "flat8",
                                 FromDt = new DateTime(2004,01,31),
                                 HouseName = "houseName8",
                                 HouseNumber = "houseNumbe",
                                 IsVerified = false,
                                 LastUpdatedDt = new DateTime(2021, 12, 31),
                                 Manual = false,
                                 PostCode = "postcode",
                                 Street = "street8",
                                 ToDt = new DateTime(2021, 12, 31)
                             },
                             new()
                             {
                                 Abroad = false,
                                 AddressType = "addressType10",
                                 City = "city10",
                                 Country = "country10",
                                 County = "county10",
                                 District = "district10",
                                 Flat = "flat3",
                                 FromDt = new DateTime(2002,01,31),
                                 HouseName = "houseName10",
                                 HouseNumber = "houseNumbe",
                                 IsVerified = false,
                                 LastUpdatedDt = new DateTime(2021, 12, 31),
                                 Manual = false,
                                 PostCode = "postcode",
                                 Street = "street10",
                                 ToDt = new DateTime(2021, 12, 31)
                             },
                             new()
                             {
                                 Abroad = false,
                                 AddressType = "addressType11",
                                 City = "city11",
                                 Country = "country11",
                                 County = "county11",
                                 District = "district11",
                                 Flat = "flat11",
                                 FromDt = new DateTime(2001,01,31),
                                 HouseName = "houseName11",
                                 HouseNumber = "houseNumbe",
                                 IsVerified = false,
                                 LastUpdatedDt = new DateTime(2021, 12, 31),
                                 Manual = false,
                                 PostCode = "postcode",
                                 Street = "street11",
                                 ToDt = new DateTime(2021, 12, 31)
                             }
                         },
                         CustomerRef = "customerNumber"
                     }
            };

            yield return new object[]
            {
                new CustomerProfile
                    {
                        Address = new List<AddressModel>
                        {
                            new()
                            {
                                AddressType = "c",
                                City = "city large city then 20 charactor ",
                                Country = "country",
                                County = "county Large  County lenthy then 20 charactor",
                                District = "district large district more then 30 charactor",
                                Flat = "flat large more than 16 charactor",
                                HouseNumber = "houseNumber than 10 charactor",
                                HouseName = "houseName than 26 charactor",
                                IsVerified = false,
                                Manual = false,
                                Abroad = false,
                                PostCode = "postcode more than 8",
                                Street = "street long longer than than 40 charactor ",
                                LastUpdatedDt = new DateTime(2019,12 ,31 ),
                                FromDt = new DateTime(2010, 8,31),
                                ToDt = new DateTime()
                            },
                            new()
                             {
                                 Abroad = false,
                                 AddressType = "address type",
                                 City = "city1",
                                 Country = "country1",
                                 County = "county1",
                                 District = "district1",
                                 Flat = "flat1",
                                 FromDt = new DateTime(2011,1,31),
                                 HouseName = "houseName1",
                                 HouseNumber = "houseNumbe",
                                 IsVerified = false,
                                 LastUpdatedDt = new DateTime(2019, 12, 31),
                                 Manual = false,
                                 PostCode = "postcode",
                                 Street = "street1",
                                 ToDt = new DateTime(2019, 12, 31),
                             },
                            new()
                             {
                                 Abroad = false,
                                 AddressType = "address type",
                                 City = "city1",
                                 Country = "country1",
                                 County = "county1",
                                 District = "district1",
                                 Flat = "flat1",
                                 FromDt = new DateTime(),
                                 HouseName = "houseName1",
                                 HouseNumber = "houseNumbe",
                                 IsVerified = false,
                                 LastUpdatedDt = new DateTime(2019, 12, 31),
                                 Manual = false,
                                 PostCode = "postcode",
                                 Street = "street1",
                                 ToDt = new DateTime(2019, 12, 31)
                             },
                        },
                        AliasFirstName = new List<Alias>(),
                        AliasLastName = new List<Alias>(),
                        AliasMiddleName = new List<Alias>(),
                        CorrelationId = "correlationId",
                        CreateDt = new DateTime(2020,12,31),
                        CustomerId = "customerId",
                        CustomerNumber = "customerNumber",
                        CustomerStatus = "customerStatus",
                        DOB = "1970-12-31",
                        Email = "email",
                        ExperianRef = "experianRef",
                        FirstName = "firstName",
                        Gender = "gender",
                        IconRef = "iconRef",
                        IdpRefId = "ipdRefId",
                        IdpRefInfo = new ProviderAuthModel
                        {
                            AuthenticatedDt = new DateTime(2020, 6, 30),
                            AuthLevel = "authLevel",
                            ProviderName = "providerName"
                        },
                        IsCustomerDataVerified = new CustomerDataVerifiedModel
                        {
                            DOB = false,
                            Email = false,
                            FirstName = false,
                            LastName = false,
                            MiddleName = false,
                            PreviousLastName = false
                        },
                        LastName = "lastName",
                        MiddleName = "middleName",
                        MothersMaidenName = "motherMaidenName",
                        MotivationReason = "motivationReason",
                        Phone = new List<PhoneModel>
                        {
                            new()
                            {
                                IsVerified = false,
                                PhoneNumber = "0123456789",
                                PhoneType = "phoneType"
                            }
                        },
                        PhxCustomerNumber = "phxCustomerNumber",
                        PotentialMatches = new List<PotentialMatches>(),
                        PreviousLastName = "previousLastName",
                        ProspectId = "prospectId",
                        RegisteredName = new List<RegisteredName>(),
                        SessionId = "sessionId",
                        TenantId = "tenantId",
                        Title = "title",
                        UpdateDt = new DateTime(2021, 1, 1),
                        VerifiedName = new List<RegisteredName>
                        {
                            new()
                            {
                                FirstName = "registeredFirstName",
                                FromDt = new DateTime(1999, 12, 30),
                                IsFirstNameVerified = false,
                                IsLastNameVerified = false,
                                IsMiddleNameVerified = false,
                                LastName = "registeredLastName",
                                MiddleName = "registeredMiddleName",
                                Title = "registeredTitle",
                                ToDt = null
                            }
                        }
                    },
                new GetResponseCustomerProfile
                    {
                        CustomerId = "customerId",
                        CorrelationId = "correlationId",
                        Title = "title",
                        FirstName = "firstName",
                        MiddleName = "middleName",
                        LastName = "lastName",
                        DOB = "1970-12-31",
                        IconRef = "iconRef",
                        Address = new List<GetResponseCustomerAddressModel>
                        {
                            new()
                            {
                                AddressType = "c",
                                City = "city large city then",
                                Country = "country",
                                County = "county Large  County",
                                District = "district large district more t",
                                Flat = "flat large more ",
                                HouseNumber = "houseNumbe",
                                HouseName = "houseName than 26 characto",
                                IsVerified = false,
                                Manual = false,
                                Abroad = false,
                                PostCode = "postcode",
                                Street = "street long longer than than 40 characto",
                                LastUpdatedDt = new DateTime(2019,12 ,31 ),
                                FromDt = new DateTime(2010, 8,31),
                                ToDt = new DateTime(),
                                IsCurrent = true
                            },
                            new()
                            {
                                 Abroad = false,
                                 AddressType = "address type",
                                 City = "city1",
                                 Country = "country1",
                                 County = "county1",
                                 District = "district1",
                                 Flat = "flat1",
                                 FromDt = new DateTime(2011,1,31),
                                 HouseName = "houseName1",
                                 HouseNumber = "houseNumbe",
                                 IsVerified = false,
                                 LastUpdatedDt = new DateTime(2019, 12, 31),
                                 Manual = false,
                                 PostCode = "postcode",
                                 Street = "street1",
                                 ToDt = new DateTime(2019, 12, 31),
                                 IsCurrent = false
                            },
                            new()
                            {
                                 Abroad = false,
                                 AddressType = "address type",
                                 City = "city1",
                                 Country = "country1",
                                 County = "county1",
                                 District = "district1",
                                 Flat = "flat1",
                                 FromDt = new DateTime(),
                                 HouseName = "houseName1",
                                 HouseNumber = "houseNumbe",
                                 IsVerified = false,
                                 LastUpdatedDt = new DateTime(2019, 12, 31),
                                 Manual = false,
                                 PostCode = "postcode",
                                 Street = "street1",
                                 ToDt = new DateTime(2019, 12, 31),
                                 IsCurrent = false
                            },
                        },
                        CustomerRef = "customerNumber"
                    }
            };

            yield return new object[]
            {
                new CustomerProfile
                    {
                        Address = new List<AddressModel>
                        {
                            new()
                            {
                                AddressType = "c",
                                City = "city large city then 20 charactor ",
                                Country = "country",
                                County = "county Large  County lenthy then 20 charactor",
                                District = "district large district more then 30 charactor",
                                Flat = "flat large more than 16 charactor",
                                HouseNumber = "houseNumber than 10 charactor",
                                HouseName = "houseName than 26 charactor",
                                IsVerified = false,
                                Manual = false,
                                Abroad = false,
                                PostCode = "postcode more than 8",
                                Street = "street long longer than than 40 charactor ",
                                LastUpdatedDt = new DateTime(2019,12 ,31 ),
                                FromDt = new DateTime(2010, 8,31),
                                ToDt = new DateTime()
                            },
                            new()
                             {
                                 Abroad = false,
                                 AddressType = "address type",
                                 City = "city1",
                                 Country = "country1",
                                 County = "county1",
                                 District = "district1",
                                 Flat = "flat1",
                                 FromDt = new DateTime(2011,1,31),
                                 HouseName = "houseName1",
                                 HouseNumber = "houseNumbe",
                                 IsVerified = false,
                                 LastUpdatedDt = new DateTime(2019, 12, 31),
                                 Manual = false,
                                 PostCode = "postcode",
                                 Street = "street1",
                                 ToDt = new DateTime(2019, 12, 31),
                             },
                            new()
                             {
                                 Abroad = false,
                                 AddressType = "address type",
                                 City = "city1",
                                 Country = "country1",
                                 County = "county1",
                                 District = "district1",
                                 Flat = "flat1",
                                 FromDt = new DateTime(),
                                 HouseName = "houseName1",
                                 HouseNumber = "houseNumbe",
                                 IsVerified = false,
                                 LastUpdatedDt = new DateTime(2019, 12, 31),
                                 Manual = false,
                                 PostCode = "postcode",
                                 Street = "street1",
                                 ToDt = new DateTime(2019, 12, 31)
                             },
                            new()
                            {
                                 Abroad = false,
                                 AddressType = "address type",
                                 City = "city1",
                                 Country = "country1",
                                 County = "county1",
                                 District = "district1",
                                 Flat = "flat1",
                                 FromDt = new DateTime(),
                                 HouseName = "houseName1",
                                 HouseNumber = "houseNumbe",
                                 IsVerified = false,
                                 LastUpdatedDt = new DateTime(2019, 12, 31),
                                 Manual = false,
                                 PostCode = string.Empty,
                                 Street = "street1",
                                 ToDt = new DateTime(2019, 12, 31)
                             },
                            new()
                            {
                                 Abroad = false,
                                 AddressType = "address type",
                                 City = "city1",
                                 Country = "country1",
                                 County = "county1",
                                 District = "district1",
                                 Flat = "flat1",
                                 FromDt = new DateTime(),
                                 HouseName = "houseName1",
                                 HouseNumber = "houseNumbe",
                                 IsVerified = false,
                                 LastUpdatedDt = new DateTime(2019, 12, 31),
                                 Manual = false,
                                 PostCode = string.Empty.PadLeft(2),
                                 Street = "street1",
                                 ToDt = new DateTime(2019, 12, 31)
                             },
                            new()
                            {
                                 Abroad = false,
                                 AddressType = "address type",
                                 City = "city1",
                                 Country = "country1",
                                 County = "county1",
                                 District = "district1",
                                 Flat = "flat1",
                                 FromDt = new DateTime(),
                                 HouseName = "houseName1",
                                 HouseNumber = "houseNumbe",
                                 IsVerified = false,
                                 LastUpdatedDt = new DateTime(2019, 12, 31),
                                 Manual = false,
                                 PostCode = null,
                                 Street = "street1",
                                 ToDt = new DateTime(2019, 12, 31)
                             },
                        },
                        AliasFirstName = new List<Alias>(),
                        AliasLastName = new List<Alias>(),
                        AliasMiddleName = new List<Alias>(),
                        CorrelationId = "correlationId",
                        CreateDt = new DateTime(2020,12,31),
                        CustomerId = "customerId",
                        CustomerNumber = "customerNumber",
                        CustomerStatus = "customerStatus",
                        DOB = "1970-12-31",
                        Email = "email",
                        ExperianRef = "experianRef",
                        FirstName = "firstName",
                        Gender = "gender",
                        IconRef = "iconRef",
                        IdpRefId = "ipdRefId",
                        IdpRefInfo = new ProviderAuthModel
                        {
                            AuthenticatedDt = new DateTime(2020, 6, 30),
                            AuthLevel = "authLevel",
                            ProviderName = "providerName"
                        },
                        IsCustomerDataVerified = new CustomerDataVerifiedModel
                        {
                            DOB = false,
                            Email = false,
                            FirstName = false,
                            LastName = false,
                            MiddleName = false,
                            PreviousLastName = false
                        },
                        LastName = "lastName",
                        MiddleName = "middleName",
                        MothersMaidenName = "motherMaidenName",
                        MotivationReason = "motivationReason",
                        Phone = new List<PhoneModel>
                        {
                            new()
                            {
                                IsVerified = false,
                                PhoneNumber = "0123456789",
                                PhoneType = "phoneType"
                            }
                        },
                        PhxCustomerNumber = "phxCustomerNumber",
                        PotentialMatches = new List<PotentialMatches>(),
                        PreviousLastName = "previousLastName",
                        ProspectId = "prospectId",
                        RegisteredName = new List<RegisteredName>(),
                        SessionId = "sessionId",
                        TenantId = "tenantId",
                        Title = "title",
                        UpdateDt = new DateTime(2021, 1, 1),
                        VerifiedName = new List<RegisteredName>
                        {
                            new()
                            {
                                FirstName = "registeredFirstName",
                                FromDt = new DateTime(1999, 12, 30),
                                IsFirstNameVerified = false,
                                IsLastNameVerified = false,
                                IsMiddleNameVerified = false,
                                LastName = "registeredLastName",
                                MiddleName = "registeredMiddleName",
                                Title = "registeredTitle",
                                ToDt = null
                            }
                        }
                    },
                new GetResponseCustomerProfile
                    {
                        CustomerId = "customerId",
                        CorrelationId = "correlationId",
                        Title = "title",
                        FirstName = "firstName",
                        MiddleName = "middleName",
                        LastName = "lastName",
                        DOB = "1970-12-31",
                        IconRef = "iconRef",
                        Address = new List<GetResponseCustomerAddressModel>
                        {
                            new()
                            {
                                AddressType = "c",
                                City = "city large city then",
                                Country = "country",
                                County = "county Large  County",
                                District = "district large district more t",
                                Flat = "flat large more ",
                                HouseNumber = "houseNumbe",
                                HouseName = "houseName than 26 characto",
                                IsVerified = false,
                                Manual = false,
                                Abroad = false,
                                PostCode = "postcode",
                                Street = "street long longer than than 40 characto",
                                LastUpdatedDt = new DateTime(2019,12 ,31 ),
                                FromDt = new DateTime(2010, 8,31),
                                ToDt = new DateTime(),
                                IsCurrent = true
                            },
                            new()
                            {
                                 Abroad = false,
                                 AddressType = "address type",
                                 City = "city1",
                                 Country = "country1",
                                 County = "county1",
                                 District = "district1",
                                 Flat = "flat1",
                                 FromDt = new DateTime(2011,1,31),
                                 HouseName = "houseName1",
                                 HouseNumber = "houseNumbe",
                                 IsVerified = false,
                                 LastUpdatedDt = new DateTime(2019, 12, 31),
                                 Manual = false,
                                 PostCode = "postcode",
                                 Street = "street1",
                                 ToDt = new DateTime(2019, 12, 31),
                                 IsCurrent = false
                            },
                            new()
                            {
                                 Abroad = false,
                                 AddressType = "address type",
                                 City = "city1",
                                 Country = "country1",
                                 County = "county1",
                                 District = "district1",
                                 Flat = "flat1",
                                 FromDt = new DateTime(),
                                 HouseName = "houseName1",
                                 HouseNumber = "houseNumbe",
                                 IsVerified = false,
                                 LastUpdatedDt = new DateTime(2019, 12, 31),
                                 Manual = false,
                                 PostCode = "postcode",
                                 Street = "street1",
                                 ToDt = new DateTime(2019, 12, 31),
                                 IsCurrent = false
                            },
                        },
                        CustomerRef = "customerNumber"
                    }
            };
        }

        [Theory]
        [MemberData(nameof(MappingData))]
        public void ExternalModelProfile_ExampleInput_MapsCorrectly(CustomerProfile input, GetResponseCustomerProfile expected)
        {
            var mapper = _mapperConfiguration.CreateMapper();
            var result = mapper.Map<GetResponseCustomerProfile>(input);

            result.Should().BeEquivalentTo(expected);
        }
    }
}