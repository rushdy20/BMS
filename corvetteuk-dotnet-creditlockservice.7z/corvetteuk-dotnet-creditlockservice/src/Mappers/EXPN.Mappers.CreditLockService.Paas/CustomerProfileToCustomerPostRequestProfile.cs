﻿using AutoMapper;
using EXPN.Models.CreditLockService.Internal.Get.Response;
using EXPN.Models.CreditLockService.Paas.Post.Request;

namespace EXPN.Mappers.CreditLockService.Paas
{
    public class CustomerProfileToCustomerPostRequestProfile : Profile
    {
        private const string ClientId = "ECS";
        public CustomerProfileToCustomerPostRequestProfile()
        {
            CreateMap<GetResponseCustomerProfile, PostCustomerRequest>(MemberList.None)
                .ForMember(d => d.ClientId, m => m.MapFrom(s => ClientId))
                .ForMember(d => d.CustomerId, m => m.MapFrom(s => s.CustomerId))
                .ForMember(d => d.Name, m => m.MapFrom(s => s))
                .ForMember(d => d.Addresses, m => m.MapFrom(s => s.Address));
        }
    }
}