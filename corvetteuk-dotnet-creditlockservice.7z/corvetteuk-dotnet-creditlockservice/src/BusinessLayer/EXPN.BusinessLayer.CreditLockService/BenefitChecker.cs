﻿using Experian.AWS.Logging.Extensions;
using EXPN.BusinessLayer.CreditLockService.Constants;
using EXPN.BusinessLayer.CreditLockService.Exceptions;
using EXPN.DataLayer.CreditLockService.Subscriptions;
using Microsoft.Extensions.Logging;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace EXPN.BusinessLayer.CreditLockService;

public class BenefitChecker : IBenefitChecker
{
    private const string CreditLockBenefit = "B028";
    private const string NoBenefitMessage = "Benefit could not be fulfilled";

    private readonly ILogger<BenefitChecker> _logger;
    private readonly ISubscriptionsClientProxy _subscriptionsClientProxy;

    public BenefitChecker(ILogger<BenefitChecker> logger,
        ISubscriptionsClientProxy subscriptionsClientProxy)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _subscriptionsClientProxy = subscriptionsClientProxy ?? throw new ArgumentNullException(nameof(subscriptionsClientProxy));
    }

    public async Task EnsureValidBenefitAsync()
    {
        _logger.LogAsInformation(LogEventNames.BenefitChecker.EnsureValidBenefitAsync.Start);

        var subscriptions = await _subscriptionsClientProxy.GetSubscriptionsAsync();

        if (subscriptions?.Benefits == null || !subscriptions.Benefits.Any(benefit =>
                string.Equals(benefit.Id, CreditLockBenefit, StringComparison.OrdinalIgnoreCase)))
        {
            throw new NoBenefitException(NoBenefitMessage, CreditLockBenefit);
        }
    }
}