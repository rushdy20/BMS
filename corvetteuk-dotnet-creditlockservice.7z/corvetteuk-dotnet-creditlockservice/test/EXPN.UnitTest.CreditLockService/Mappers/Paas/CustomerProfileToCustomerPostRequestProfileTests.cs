﻿using AutoMapper;
using EXPN.Mappers.CreditLockService.Paas;
using EXPN.Models.CreditLockService.Internal.Get.Response;
using EXPN.Models.CreditLockService.Paas;
using EXPN.Models.CreditLockService.Paas.Post.Request;
using FluentAssertions;
using System;
using System.Collections.Generic;
using Xunit;

namespace EXPN.UnitTest.CreditLockService.Mappers.Paas
{
    public class CustomerProfileToCustomerPostRequestProfileTests
    {
        private readonly MapperConfiguration _mapperConfiguration;

        public CustomerProfileToCustomerPostRequestProfileTests()
        {
            _mapperConfiguration = new MapperConfiguration(
                cfg =>
                {
                    cfg.AddProfile<AddressModelToAddressProfile>();
                    cfg.AddProfile<CustomerProfileToCustomerNameProfile>();
                    cfg.AddProfile<CustomerProfileToCustomerPostRequestProfile>();
                });
        }

        [Fact]
        public void ModelProfile_AssertConfiguration_IsValid()
        {
            _mapperConfiguration.AssertConfigurationIsValid();
        }

        public static IEnumerable<object[]> MappingData()
        {
            yield return new object[]
            {
                null,
                null
            };

            yield return new object[]
            {
                new GetResponseCustomerProfile(),
                new PostCustomerRequest
                {
                    ClientId = "ECS",
                    Addresses = new Address[]{},
                    Name = new CustomerName()
                }
            };

            yield return new object[]
            {
                new GetResponseCustomerProfile
                {
                    CustomerId = "customerid",
                    CorrelationId = "correlationid",
                    DOB = "2000-12-31",
                    FirstName = "firstname",
                    MiddleName = "middlename",
                    Title = "title",
                    LastName = "lastname",
                    Address = new List<GetResponseCustomerAddressModel>
                    {
                        new GetResponseCustomerAddressModel
                        {
                            Abroad = false,
                            AddressType = "AT",
                            City = "city",
                            Country = "country",
                            County = "county",
                            District = "district",
                            Flat = "flat",
                            FromDt = new DateTime(2010, 12, 31),
                            HouseName = "housename",
                            HouseNumber = "housenumber",
                            IsVerified = false,
                            LastUpdatedDt = new DateTime(2020, 9,30),
                            Manual = false,
                            PostCode = "postcode",
                            Street = "street",
                            ToDt = null
                        }
                    }
                },
                new PostCustomerRequest
                {
                    CustomerId = "customerid",
                    ClientId = "ECS",
                    Dob = new DateTime(2000,12,31),
                    Name = new CustomerName
                    {
                        FirstName = "firstname",
                        LastName = "lastname",
                        OtherName = "middlename",
                        Title = "title"
                    },
                    Addresses = new[]
                    {
                        new Address
                        {
                            County = "county",
                            Street = "street",
                            Flat = "flat",
                            HouseName = "housename",
                            HouseNumber = "housenumber",
                            Postcode = "postcode",
                            Town = "city",
                            IsCurrent = false,
                            District = "district"
                        }
                    }
                }
            };

            yield return new object[]
{
                new GetResponseCustomerProfile
                {
                    CustomerId = "customerid",
                    CorrelationId = "correlationid",
                    DOB = "2000-12-31",
                    FirstName = "firstname",
                    MiddleName = "middlename",
                    Title = "title",
                    LastName = "lastname",
                    Address = new List<GetResponseCustomerAddressModel>
                    {
                        new GetResponseCustomerAddressModel
                        {
                            Abroad = false,
                            AddressType = "c",
                            City = "city1",
                            Country = "country1",
                            County = "county1",
                            District = "district1",
                            Flat = "flat1",
                            FromDt = new DateTime(2010, 12, 31),
                            HouseName = "housename1",
                            HouseNumber = "housenumber1",
                            IsVerified = false,
                            LastUpdatedDt = new DateTime(2020, 9,30),
                            Manual = false,
                            PostCode = "postcode1",
                            Street = "street1",
                            ToDt = new DateTime(2015, 12, 31)
                        },
                        new GetResponseCustomerAddressModel
                        {
                            Abroad = true,
                            AddressType = "C",
                            City = "city2",
                            Country = "country2",
                            County = "county2",
                            District = "district2",
                            Flat = "flat2",
                            FromDt = new DateTime(2010, 12, 31),
                            HouseName = "housename2",
                            HouseNumber = "housenumber2",
                            IsVerified = true,
                            LastUpdatedDt = new DateTime(2020, 9,30),
                            Manual = true,
                            PostCode = "postcode2",
                            Street = "street2",
                            ToDt = null
                        },
                        new GetResponseCustomerAddressModel
                        {
                            Abroad = true,
                            AddressType = "C1",
                            City = "city2",
                            Country = "country2",
                            County = "county2",
                            District = "district2",
                            Flat = "flat2",
                            FromDt = new DateTime(2010, 12, 31),
                            HouseName = "housename2",
                            HouseNumber = "housenumber2",
                            IsVerified = true,
                            LastUpdatedDt = new DateTime(2020, 9,30),
                            Manual = true,
                            PostCode = "postcode2",
                            Street = "street2",
                            ToDt = null
                        }
                    }
                },
                new PostCustomerRequest
                {
                    CustomerId = "customerid",
                    ClientId = "ECS",
                    Dob = new DateTime(2000,12,31),
                    Name = new CustomerName
                    {
                        FirstName = "firstname",
                        LastName = "lastname",
                        OtherName = "middlename",
                        Title = "title"
                    },
                    Addresses = new[]
                    {
                        new Address
                        {
                            County = "county1",
                            Street = "street1",
                            Flat = "flat1",
                            HouseName = "housename1",
                            HouseNumber = "housenumber1",
                            Postcode = "postcode1",
                            Town = "city1",
                            IsCurrent = true,
                            District = "district1"
                        },
                        new Address
                        {
                            County = "county2",
                            Street = "street2",
                            Flat = "flat2",
                            HouseName = "housename2",
                            HouseNumber = "housenumber2",
                            Postcode = "postcode2",
                            Town = "city2",
                            IsCurrent = true,
                            District = "district2"
                        },
                        new Address
                        {
                            County = "county2",
                            Street = "street2",
                            Flat = "flat2",
                            HouseName = "housename2",
                            HouseNumber = "housenumber2",
                            Postcode = "postcode2",
                            Town = "city2",
                            IsCurrent = false,
                            District = "district2"
                        }
                    }
                }
            };
        }

        [Theory]
        [MemberData(nameof(MappingData))]
        public void ExternalModelProfile_ExampleInput_MapsCorrectly(GetResponseCustomerProfile input, PostCustomerRequest expected)
        {
            var mapper = _mapperConfiguration.CreateMapper();
            var result = mapper.Map<PostCustomerRequest>(input);

            result.Should().BeEquivalentTo(expected);
        }
    }
}