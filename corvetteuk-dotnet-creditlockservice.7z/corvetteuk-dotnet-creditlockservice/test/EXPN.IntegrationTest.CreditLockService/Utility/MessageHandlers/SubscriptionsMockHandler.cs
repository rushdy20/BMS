﻿using Experian.HttpClient.Services.Subscriptions.Models.Internal;
using Experian.ResponseModels;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Mime;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace EXPN.IntegrationTest.CreditLockService.Utility.MessageHandlers;

public class SubscriptionsMockHandler : DelegatingHandler
{
    protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
    {
        const string validBenefitId = "B028";
        const string invalidBenefitId = "X999";

        var benefitId = validBenefitId;

        var headerValues = request.Headers.GetValues("x-customerId");
        var customerId = headerValues.FirstOrDefault();

        if (!string.IsNullOrEmpty(customerId))
        {
            switch (customerId)
            {
                case "9009758b-62f8-42d4-8f93-1dec01772a6f":
                    benefitId = invalidBenefitId;
                    break;

                case "9009758b-62f8-42d4-8f93-1dec01772ccf":
                    benefitId = null;
                    break;

                default:
                    benefitId = validBenefitId;
                    break;
            }
        }

        if (benefitId != null)
        {
            return Task.FromResult(new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.OK,
                Content = new StringContent(JsonConvert.SerializeObject(new Result<Subscription>
                  (new[]
                  {
                    new Subscription
                    {
                        Benefits = new List<Benefit>
                        {
                            new()
                            {
                                Id = benefitId
                            }
                        }
                    }
                  })),
                  Encoding.UTF8, MediaTypeNames.Application.Json)
            });
        }

        return Task.FromResult(new HttpResponseMessage
        {
            StatusCode = HttpStatusCode.OK,
            Content = new StringContent(JsonConvert.SerializeObject(new Result<Subscription>()), Encoding.UTF8, MediaTypeNames.Application.Json)
        });
    }
}