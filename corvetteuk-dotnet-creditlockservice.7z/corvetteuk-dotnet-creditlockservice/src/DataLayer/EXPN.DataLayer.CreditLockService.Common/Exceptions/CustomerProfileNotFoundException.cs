﻿using System;
using System.Runtime.Serialization;

namespace EXPN.DataLayer.CreditLockService.Common.Exceptions
{
    [Serializable]
    public class CustomerProfileNotFoundException : Exception
    {
        protected CustomerProfileNotFoundException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }

        public CustomerProfileNotFoundException()
        {
        }

        public CustomerProfileNotFoundException(string message)
            : base(message)
        {
        }

        public CustomerProfileNotFoundException(string message, Exception innerException)
            : base(message, innerException)
        {
        }
    }
}