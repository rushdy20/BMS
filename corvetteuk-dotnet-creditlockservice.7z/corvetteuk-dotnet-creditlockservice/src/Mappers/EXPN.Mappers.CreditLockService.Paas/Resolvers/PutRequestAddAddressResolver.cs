﻿using AutoMapper;
using EXPN.Mappers.CreditLockService.Paas.Extensions;
using EXPN.Models.CreditLockService.Internal.Get.Response;
using EXPN.Models.CreditLockService.Paas.Put.Request;
using System;
using System.Collections.Generic;
using System.Linq;

namespace EXPN.Mappers.CreditLockService.Paas.Resolvers
{
    public class PutRequestAddAddressResolver : IMemberValueResolver<object, object, IEnumerable<GetResponsePaasAddressResponse>, IEnumerable<PutCustomerAddressRequest>>
    {
        private readonly IEnumerable<string> _exclusionList = new List<string> { "District", "IsCurrent" };

        public IEnumerable<PutCustomerAddressRequest> Resolve(
            object source,
            object destination,
            IEnumerable<GetResponsePaasAddressResponse> sourceMember,
            IEnumerable<PutCustomerAddressRequest> destMember,
            ResolutionContext context)
        {
            if (sourceMember == null)
                return Enumerable.Empty<PutCustomerAddressRequest>();

            if (destMember == null)
                return Enumerable.Empty<PutCustomerAddressRequest>();

            var sourceAddressList = sourceMember.Select(x => { x.Postcode = x.Postcode?.Replace(" ", string.Empty).ToUpper(); return x; }).ToList();

            var destAddressList = destMember.Select(x => { x.Postcode = x.Postcode?.Replace(" ", string.Empty).ToUpper(); return x; }).ToList();

            foreach (var address in sourceAddressList)
            {
                var existingAddresses = destAddressList.Where(o => string.Equals(o.Postcode, address.Postcode, StringComparison.CurrentCultureIgnoreCase));

                var putCustomerAddressRequests = existingAddresses as PutCustomerAddressRequest[] ?? existingAddresses.ToArray();
                if (!putCustomerAddressRequests.Any())
                    continue;

                foreach (var existingAddress in from existingAddress in putCustomerAddressRequests
                                                where ExtensionMethods.AreMatchingStringPropertiesSame(address, existingAddress, _exclusionList)
                                                select existingAddress)
                {
                    destAddressList.Remove(existingAddress);
                }
            }

            return destAddressList;
        }
    }
}