﻿using System;
using System.Diagnostics.CodeAnalysis;
using AutoMapper;
using EXPN.Models.CreditLockService.External.Put.Request;
using EXPN.Models.CreditLockService.Internal.Put.Request;

namespace EXPN.Mappers.CreditLockService.Internal
{
    [ExcludeFromCodeCoverage]
    public class PutStatusUpdateBodyToPutLockStatusRequestProfile : Profile
    {
        public PutStatusUpdateBodyToPutLockStatusRequestProfile()
        {
            CreateMap<PutStatusRequestBody, PutLockStatusRequest>()
                .ForMember(d => d.LockStatus, m => m.MapFrom(s => s.Status.Equals("ON", StringComparison.OrdinalIgnoreCase)));
        }
    }
}