﻿using Newtonsoft.Json;

namespace EXPN.Models.CreditLockService.Paas.Get.Request
{
    public class GetCustomerRequest
    {
        public string CustomerRef { get; set; }

        [JsonIgnore]
        public string CustomerId { get; set; }
    }
}