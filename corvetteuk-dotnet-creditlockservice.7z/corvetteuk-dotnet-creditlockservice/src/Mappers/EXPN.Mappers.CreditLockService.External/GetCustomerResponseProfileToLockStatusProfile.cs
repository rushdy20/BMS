﻿using AutoMapper;
using EXPN.Mappers.CreditLockService.External.Resolver;
using System.Diagnostics.CodeAnalysis;
using ExternalModel = EXPN.Models.CreditLockService.External.Get.Customer.Response;
using InternalModel = EXPN.Models.CreditLockService.Internal.Get.Response;

namespace EXPN.Mappers.CreditLockService.External
{
    [ExcludeFromCodeCoverage]
    public class GetCustomerResponseProfileToLockStatusProfile : Profile
    {
        public GetCustomerResponseProfileToLockStatusProfile()
        {
            CreateMap<InternalModel.GetCustomerResponse, ExternalModel.GetLockStatusResponse>()
                .ForMember(d => d.LockStatus, m => m.MapFrom<LockStatusResolver>());
        }
    }
}