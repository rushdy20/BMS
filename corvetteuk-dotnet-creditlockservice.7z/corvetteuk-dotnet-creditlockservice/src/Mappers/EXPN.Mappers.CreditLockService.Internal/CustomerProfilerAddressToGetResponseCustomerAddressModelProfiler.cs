﻿using AutoMapper;
using Experian.HttpClient.Services.Customers.Models.External;
using EXPN.Mappers.CreditLockService.Internal.Extensions;
using EXPN.Models.CreditLockService.Internal.Get.Response;
using System;

namespace EXPN.Mappers.CreditLockService.Internal
{
    public class CustomerProfilerAddressToGetResponseCustomerAddressModelProfiler : Profile
    {
        private const string CurrentAddressIndicator = "C";
        public CustomerProfilerAddressToGetResponseCustomerAddressModelProfiler()
        {
            CreateMap<AddressModel, GetResponseCustomerAddressModel>()
                 .ForMember(d => d.HouseName, m => m.MapFrom(s => s.HouseName.TrimToSize(26)))
                 .ForMember(d => d.HouseNumber, m => m.MapFrom(s => s.HouseNumber.TrimToSize(10)))
                 .ForMember(d => d.Flat, m => m.MapFrom(s => s.Flat.TrimToSize(16)))
                 .ForMember(d => d.Street, m => m.MapFrom(s => s.Street.TrimToSize(40)))
                 .ForMember(d => d.District, m => m.MapFrom(s => s.District.TrimToSize(30)))
                 .ForMember(d => d.City, m => m.MapFrom(s => s.City.TrimToSize(20)))
                 .ForMember(d => d.County, m => m.MapFrom(s => s.County.TrimToSize(20)))
                 .ForMember(d => d.PostCode, m => m.MapFrom(s => s.PostCode.TrimToSize(8)))
                 .ForMember(d => d.IsCurrent, m => m.MapFrom(s => s.AddressType.Equals(CurrentAddressIndicator, StringComparison.OrdinalIgnoreCase)));
        }
    }
}