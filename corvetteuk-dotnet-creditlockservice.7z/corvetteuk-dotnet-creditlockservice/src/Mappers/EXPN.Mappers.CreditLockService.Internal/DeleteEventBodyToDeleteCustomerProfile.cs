﻿using AutoMapper;
using ExternalModel = EXPN.Models.CreditLockService.External.Delete.Request;
using InternalModel = EXPN.Models.CreditLockService.Internal.Delete.Request;

namespace EXPN.Mappers.CreditLockService.Internal
{
    public class DeleteEventBodyToDeleteCustomerProfile : Profile
    {
        public DeleteEventBodyToDeleteCustomerProfile()
        {
            CreateMap<ExternalModel.DeleteEventBody, InternalModel.DeleteCustomerRequest>()
                   .ForMember(d => d.CustomerNumber, m => m.MapFrom(s => s.CustomerNumber))
                   .ForMember(d => d.IdpRefId, m => m.MapFrom(s => s.IdpRefId))
                   .ForMember(d => d.TenantId, m => m.MapFrom(s => s.TenantId))
                   .ForMember(d => d.CustomerId, m => m.MapFrom(s => s.CustomerId));
        }
    }
}