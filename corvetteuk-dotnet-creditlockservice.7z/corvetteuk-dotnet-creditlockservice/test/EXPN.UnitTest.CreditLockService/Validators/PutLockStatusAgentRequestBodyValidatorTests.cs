﻿using System.Collections.Generic;
using System.Linq;
using EXPN.Models.CreditLockService.External.Put.Request;
using EXPN.Validators.CreditLockService.Put;
using FluentAssertions;
using Xunit;

namespace EXPN.UnitTest.CreditLockService.Validators
{
    public class PutLockStatusAgentRequestBodyValidatorTests
    {
        public static IEnumerable<object[]> PostStatusRequestBodyData()
        {
            yield return new object[]
            {
                new PutStatusAgentRequestBody
                {
                    SalesforceUserId = "abcd"
                },
                false,
                "'Status' must not be empty."
            };

            yield return new object[]
            {
                new PutStatusAgentRequestBody
                {
                    Status = string.Empty,
                    SalesforceUserId = "abc"
                },
                false,
                "'Status' must not be empty."
            };

            yield return new object[]
            {
                new PutStatusAgentRequestBody
                {
                    Status = "NOT valid",
                    SalesforceUserId = "Abcde"
                },
                false,
                "'NOT valid' is not a valid Status type."
            };

            yield return new object[]
            {
                new PutStatusAgentRequestBody
                {
                    Status = "ON",
                    SalesforceUserId = string.Empty
                },
                false,
                "'Salesforce User Id' should not be null"
            };

            yield return new object[]
            {
                new PutStatusAgentRequestBody
                {
                    Status = "on",
                    SalesforceUserId = "abcdef"
                },
                true,
                null
            };

            yield return new object[]
            {
                new PutStatusAgentRequestBody
                {
                    Status = "ON",
                    SalesforceUserId = "abcde"
                },
                true,
                null
            };

            yield return new object[]
            {
                new PutStatusAgentRequestBody
                {
                    Status = "off",
                    SalesforceUserId = "abdcd"
                },
                true,
                null
            };

            yield return new object[]
            {
                new PutStatusAgentRequestBody
                {
                    Status = "OFF",
                    SalesforceUserId = "abdc"
                },
                true,
                null
            };
        }

        [Theory]
        [MemberData(nameof(PostStatusRequestBodyData))]
        public void PutLockStatusAgentRequestBodyValidator_ValidRequest_ShouldBeSameAsExpected(PutStatusAgentRequestBody putStatusAgentRequest, bool expected, string errorMessage)
        {
            var result = new PutLockStatusAgentRequestBodyValidator()
                .Validate(putStatusAgentRequest);

            if (expected)
            {
                result.IsValid.Should().BeTrue();
                result.Errors.Should().HaveCount(0);
            }
            else
            {
                result.IsValid.Should().BeFalse();
                result.Errors.Should().HaveCount(1);
                result.Errors.Select(x => x.ErrorMessage).FirstOrDefault().Should().BeEquivalentTo(errorMessage);
            }
        }
    }
}