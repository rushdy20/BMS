﻿using EXPN.Models.CreditLockService.External.Get.Customer.Request;
using EXPN.Models.CreditLockService.External.Post.Request;
using EXPN.Models.CreditLockService.External.Put.Request;
using EXPN.Validators.CreditLockService;
using EXPN.Validators.CreditLockService.Get;
using EXPN.Validators.CreditLockService.Post;
using EXPN.Validators.CreditLockService.Put.Customer;
using FluentAssertions;
using FluentValidation;
using Microsoft.Extensions.DependencyInjection;
using Xunit;

namespace EXPN.UnitTest.CreditLockService.Validators
{
    public class ValidatorsModuleTests
    {
        [Fact]
        public void ModuleDependencyRegistrations_CanBeResolved()
        {
            var services = new ServiceCollection();

            services.RegisterValidatorsModule();
            var serviceProvider = services.BuildServiceProvider();

            serviceProvider.GetService(typeof(IValidator<GetStatusRequest>)).Should().BeOfType(typeof(GetStatusRequestModelValidator));
            serviceProvider.GetService(typeof(IValidator<PutStatusRequest>)).Should().BeOfType(typeof(PutStatusRequestValidator));
            serviceProvider.GetService(typeof(IValidator<PutStatusRequestBody>)).Should().BeOfType(typeof(PutStatusRequestBodyValidator));
            serviceProvider.GetService(typeof(IValidator<PostRequest>)).Should().BeOfType(typeof(PostSubscriptionRequestValidator));
        }
    }
}