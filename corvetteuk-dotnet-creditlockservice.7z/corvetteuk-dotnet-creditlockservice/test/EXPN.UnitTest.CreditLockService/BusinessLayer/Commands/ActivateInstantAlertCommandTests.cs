﻿using System;
using System.Collections.Generic;
using System.Text;
using AutoMapper;
using EXPN.BusinessLayer.CreditLockService.Commands;
using EXPN.BusinessLayer.CreditLockService.Constants;
using EXPN.DataLayer.CreditLockService.Paas.HttpClient;
using EXPN.Models.CreditLockService.Internal.Get.Response;
using EXPN.Models.CreditLockService.Internal.Post.Request;
using EXPN.Models.CreditLockService.Internal.Post.Response;
using EXPN.Models.CreditLockService.Paas.PutAlertStatus.Request;
using FluentAssertions;
using Microsoft.Extensions.Logging;
using NSubstitute;
using NSubstitute.ExceptionExtensions;
using Xunit;

namespace EXPN.UnitTest.CreditLockService.BusinessLayer.Commands
{
 public  class ActivateInstantAlertCommandTests
    {
        private readonly ICreditLockPaasClient _creditLockPaaSClient;
        private readonly ILogger<ActivateInstantAlertCommand<PostActivateInstantAlertRequest, PostActivateInstantAlertResponse>> _logger;
        private readonly IMapper _mapper;
        private readonly ICommand<PostActivateInstantAlertRequest, PostActivateInstantAlertResponse> _activateInstantAlertCommand;

        public ActivateInstantAlertCommandTests()
        {
            _creditLockPaaSClient = Substitute.For<ICreditLockPaasClient>();
            _logger = Substitute.For<ILogger<ActivateInstantAlertCommand<PostActivateInstantAlertRequest, PostActivateInstantAlertResponse>>>();
            _mapper = Substitute.For<IMapper>();

            _activateInstantAlertCommand = new ActivateInstantAlertCommand<PostActivateInstantAlertRequest, PostActivateInstantAlertResponse>(_creditLockPaaSClient, _logger, _mapper);
        }

        public class Constructor
        {
            public static IEnumerable<object[]> NullParameters()
            {
                yield return new object[]
                {
                    null,
                    Substitute.For<ILogger<ActivateInstantAlertCommand<PostActivateInstantAlertRequest, PostActivateInstantAlertResponse>>>(),
                    Substitute.For<IMapper>(),
                    "creditLockPaasClient"
                };

                yield return new object[]
                {
                    Substitute.For<ICreditLockPaasClient>(),
                    null,
                    Substitute.For<IMapper>(),
                    "logger"
                };

                yield return new object[]
                {
                    Substitute.For<ICreditLockPaasClient>(),
                    Substitute.For<ILogger<ActivateInstantAlertCommand<PostActivateInstantAlertRequest, PostActivateInstantAlertResponse>>>(),
                    null,
                    "mapper"
                };
            }

            [Theory]
            [MemberData(nameof(NullParameters))]
            public void NullRequiredConstructorParameter_ThrowsArgumentNullException(
                ICreditLockPaasClient paasHttpClient,
                ILogger<ActivateInstantAlertCommand<PostActivateInstantAlertRequest, PostActivateInstantAlertResponse>> logger,
                IMapper mapper,
                string expectedErrorParameter)
            {
                Action action = () => {
                    new ActivateInstantAlertCommand<PostActivateInstantAlertRequest, PostActivateInstantAlertResponse>(paasHttpClient, logger, mapper);
                };

                action.Should().Throw<ArgumentNullException>()
                    .Where(x => x.ParamName == expectedErrorParameter);
            }

            [Fact]
            public void Id_IsCorrect()
            {
                new ActivateInstantAlertCommand<PostActivateInstantAlertRequest, PostActivateInstantAlertResponse>(
                    Substitute.For<ICreditLockPaasClient>(),
                    Substitute.For<ILogger<ActivateInstantAlertCommand<PostActivateInstantAlertRequest, PostActivateInstantAlertResponse>>>(),
                    Substitute.For<IMapper>()).Id.Should().Be("ACTIVATE-INSTANT-ALERT");
            }
        }

        public class Execute : ActivateInstantAlertCommandTests
        {
            public static IEnumerable<object[]> LogInformationMessages()
            {
                yield return new object[]
                {
                    LogEventNames.ActivateInstantAlertCommand.Execute.Enter
                };

                yield return new object[]
                {
                    LogEventNames.ActivateInstantAlertCommand.Execute.Exit
                };
            }

            [Theory]
            [MemberData(nameof(LogInformationMessages))]
            public void HappyPathInformationLogged(string loggerMessage)
            {
                const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

                var getResponseCustomerProfile = new GetResponseCustomerProfile
                {
                    CustomerId = customerId,
                    CustomerRef = "ABC"
                };

                var postActivateInstantAlertRequest = new PostActivateInstantAlertRequest
                {
                    CustomerId = customerId,
                    CustomerRef = "ABC"
                };

                var putAlertStatusRequest = new PutAlertStatusRequest
                {
                    CustomerRef = "ABC",
                    Status = "Y"
                };

                _mapper.Map<PostActivateInstantAlertRequest>(getResponseCustomerProfile)
                    .Returns(postActivateInstantAlertRequest);

                _mapper.Map<PutAlertStatusRequest>(postActivateInstantAlertRequest)
                    .Returns(putAlertStatusRequest);

                _activateInstantAlertCommand.Execute(postActivateInstantAlertRequest, getResponseCustomerProfile);

                _mapper.Received().Map<PutAlertStatusRequest>(postActivateInstantAlertRequest);

                _mapper.Received().Map<PostActivateInstantAlertRequest>(getResponseCustomerProfile);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(loggerMessage)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public void ExecutePutLockStatusRequestNull_ThrowsArgumentNullException()
            {
                Action action = () => { _activateInstantAlertCommand.Execute(null, null); };

                action.Should().Throw<ArgumentNullException>()
                    .Where(x => x.ParamName == "request");
            }

            [Fact]
            public void ExecutePutLockStatusCustomerProfileNull_ThrowsArgumentNullException()
            {
                Action action = () => { _activateInstantAlertCommand.Execute(new PostActivateInstantAlertRequest(), null); };

                action.Should().Throw<ArgumentNullException>()
                    .Where(x => x.ParamName == "customerProfile");
            }

            [Theory]
            [InlineData(null)]
            [InlineData("")]
            [InlineData("     ")]
            public void ExecutePostActivateInstantAlertRequestInvalidCustomerId_ThrowsArgumentException(string customerId)
            {
                var postActivateInstantAlertRequest = new PostActivateInstantAlertRequest
                {
                    CustomerId = customerId
                };

                var getResponseCustomerProfile = new GetResponseCustomerProfile
                {
                    CustomerId = customerId,
                    CustomerRef = "ABC"
                };

                Action action = () =>
                {
                    _activateInstantAlertCommand.Execute(postActivateInstantAlertRequest, getResponseCustomerProfile);
                };

                action.Should().Throw<ArgumentException>()
                    .Where(x => x.Message == "CustomerId cannot be null or whitespace (Parameter 'request')");
            }

            [Fact]
            public void ValidRequest_Execute_HappyPath_Success()
            {
                const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

                var getResponseCustomerProfile = new GetResponseCustomerProfile
                {
                    CustomerId = customerId,
                    IconRef = "ABC",
                };
               
                var postActivateInstantAlertRequest = new PostActivateInstantAlertRequest
                {
                    CustomerId = customerId,
                    CustomerRef = "ABC"
                };

                var putAlertStatusRequest = new PutAlertStatusRequest
                {
                    CustomerRef = "ABC",
                    Status = "Y"
                };

                _mapper.Map<PostActivateInstantAlertRequest>(getResponseCustomerProfile)
                    .Returns(postActivateInstantAlertRequest);

                _mapper.Map<PutAlertStatusRequest>(postActivateInstantAlertRequest)
                    .Returns(putAlertStatusRequest);

                var response = _activateInstantAlertCommand.Execute(postActivateInstantAlertRequest, getResponseCustomerProfile);

                _mapper.Received(1).Map<PostActivateInstantAlertRequest>(getResponseCustomerProfile);

                _mapper.Received(1).Map<PutAlertStatusRequest>(postActivateInstantAlertRequest);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ActivateInstantAlertCommand.Execute.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ActivateInstantAlertCommand.Execute.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public void ValidRequest_Execute_ClientThrowsOutofMemoryException_Fails()
            {
                const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

                var expectedEx = new OutOfMemoryException("Test Exception Message");

                var getResponseCustomerProfile = new GetResponseCustomerProfile
                {
                    CustomerId = customerId,
                    IconRef = "ABC"
                };

                var putAlertStatus = new PutAlertStatusRequest
                {
                    CustomerRef = "ABC",
                    Status = "N"
                };

                var postActivateInstantAlertRequest = new PostActivateInstantAlertRequest
                {
                    CustomerId = customerId,
                    CustomerRef = "ABC"
                };

                _mapper.Map<PostActivateInstantAlertRequest>(getResponseCustomerProfile)
                    .Returns(postActivateInstantAlertRequest);

                _mapper.Map<PutAlertStatusRequest>(postActivateInstantAlertRequest)
                    .Returns(putAlertStatus);

                _creditLockPaaSClient.PutAlertStatus(putAlertStatus)
                    .Throws(expectedEx);

                Action action = () =>
                {
                    _activateInstantAlertCommand.Execute(postActivateInstantAlertRequest, getResponseCustomerProfile);
                };

                action.Should().Throw<OutOfMemoryException>()
                    .Where(x => x.Message == expectedEx.Message);

                _mapper.Received(1).Map<PutAlertStatusRequest>(postActivateInstantAlertRequest);

                _mapper.Received(1).Map<PostActivateInstantAlertRequest>(getResponseCustomerProfile);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ActivateInstantAlertCommand.Execute.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ActivateInstantAlertCommand.Execute.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }
        }
    }
}