﻿using AutoMapper;
using EXPN.BusinessLayer.CreditLockService.Extension;
using EXPN.Mappers.CreditLockService.Paas;
using EXPN.Models.CreditLockService.Internal.Get.Response;
using EXPN.Models.CreditLockService.Paas;
using EXPN.Models.CreditLockService.Paas.Put.Request;
using FluentAssertions;
using System;
using System.Collections.Generic;
using Xunit;

namespace EXPN.UnitTest.CreditLockService.Mappers.Paas
{
    public class PutCustomerRequestTests
    {
        private readonly MapperConfiguration _mapperConfiguration;

        public PutCustomerRequestTests()
        {
            _mapperConfiguration = new MapperConfiguration(
                cfg =>
                {
                    cfg.AddProfile<GetResponseCustomerAddressModelToPutCustomerAddressRequestProfile>();
                    cfg.AddProfile<GetResponseCustomerProfileToPutCustomerRequestProfile>();
                    cfg.AddProfile<GetResponsePaasCustomerToPutCustomerRequestProfile>();
                });
        }

        [Fact]
        public void ModelProfile_AssertConfiguration_IsValid()
        {
            _mapperConfiguration.AssertConfigurationIsValid();
        }

        public static IEnumerable<object[]> MappingData()
        {
            yield return new object[]
            {
                null,
                null,
                null
            };

            yield return new object[]
            {
                new GetResponseCustomerProfile(),
                new GetCustomerResponse(),
                new PutCustomerRequest()
            };

            yield return new object[]
            {
                new GetResponseCustomerProfile
                {
                    CustomerId = "customerId"
                },
                new GetCustomerResponse
                {
                    CustomerId = "customerId"
                },
                new PutCustomerRequest()
            };

            yield return new object[]
            {
                new GetResponseCustomerProfile
                {
                    CustomerId = "customerId",
                    DOB = "1990-12-31"
                },
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    Dob = new DateTime(1990, 12, 31)
                },
                new PutCustomerRequest()
            };

            yield return new object[]
            {
                new GetResponseCustomerProfile
                {
                    CustomerId = "customerId",
                    DOB = "1991-12-31"
                },
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    Dob = new DateTime(1990, 12, 31)
                },
                new PutCustomerRequest
                {
                    CustomerId = "customerId",
                    Dob = new DateTime(1991, 12, 31),
                    ClientId = "ECS",
                    AddressesToAdd = new List<PutCustomerAddressRequest>()
                }
            };

            yield return new object[]
            {
                new GetResponseCustomerProfile
                {
                    CustomerId = "customerId",
                    Title = "Mr"
                },
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    CustomerName = new GetResponsePaasCustomerName
                    {
                        Title = "Mr"
                    }
                },
                new PutCustomerRequest()
            };

            yield return new object[]
            {
                new GetResponseCustomerProfile
                {
                    CustomerId = "customerId",
                    Title = "Sir"
                },
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    CustomerName = new GetResponsePaasCustomerName
                    {
                        Title = "Mr"
                    }
                },
                new PutCustomerRequest()
            };

            yield return new object[]
            {
                new GetResponseCustomerProfile
                {
                    CustomerId = "customerId",
                    FirstName = "Barry"
                },
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    CustomerName = new GetResponsePaasCustomerName
                    {
                        FirstName = "Barry"
                    }
                },
                new PutCustomerRequest()
            };

            yield return new object[]
            {
                new GetResponseCustomerProfile
                {
                    CustomerId = "customerId",
                    FirstName = "John"
                },
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    CustomerName = new GetResponsePaasCustomerName
                    {
                        FirstName = "Barry"
                    }
                },
                new PutCustomerRequest
                {
                    ClientId = "ECS",
                    CustomerId = "customerId",
                    Name = new CustomerName
                    {
                        FirstName = "John"
                    },
                    AddressesToAdd = new List<PutCustomerAddressRequest>()
                }
            };

            yield return new object[]
            {
                new GetResponseCustomerProfile
                {
                    CustomerId = "customerId",
                    FirstName = string.Empty
                },
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    CustomerName = new GetResponsePaasCustomerName
                    {
                        FirstName = "Barry"
                    }
                },
                new PutCustomerRequest
                {
                    ClientId = "ECS",
                    CustomerId = "customerId",
                    Name = new CustomerName
                    {
                        FirstName = string.Empty
                    },
                    AddressesToAdd = new List<PutCustomerAddressRequest>()
                }
            };

            yield return new object[]
            {
                new GetResponseCustomerProfile
                {
                    CustomerId = "customerId",
                    LastName = "Smith"
                },
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    CustomerName = new GetResponsePaasCustomerName
                    {
                        LastName = "Smith"
                    }
                },
                new PutCustomerRequest()
            };

            yield return new object[]
            {
                new GetResponseCustomerProfile
                {
                    CustomerId = "customerId",
                    LastName = "Smith"
                },
                new GetCustomerResponse
                {
                    ClientId = "ECS",
                    CustomerId = "customerId",
                    CustomerName = new GetResponsePaasCustomerName
                    {
                        LastName = "Smithe"
                    }
                },
                new PutCustomerRequest
                {
                    CustomerId = "customerId",
                    Name = new CustomerName
                    {
                        LastName = "Smith"
                    },
                    ClientId = "ECS",
                    AddressesToAdd = new List<PutCustomerAddressRequest>()
                }
            };

            yield return new object[]
            {
                new GetResponseCustomerProfile
                {
                    CustomerId = "customerId",
                    MiddleName = "Thomas"
                },
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    CustomerName = new GetResponsePaasCustomerName
                    {
                        OtherName = "Thomas"
                    }
                },
                new PutCustomerRequest()
            };

            yield return new object[]
            {
                new GetResponseCustomerProfile
                {
                    CustomerId = "customerId",
                    MiddleName = "Thomas"
                },
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    CustomerName = new GetResponsePaasCustomerName
                    {
                        OtherName = "Tom"
                    }
                },
                new PutCustomerRequest
                {
                    CustomerId = "customerId",
                    Name = new CustomerName
                    {
                        OtherName = "Thomas"
                    },
                    ClientId = "ECS",
                    AddressesToAdd = new List<PutCustomerAddressRequest>()
                }
            };

            yield return new object[]
            {
                new GetResponseCustomerProfile
                {
                    CustomerId = "customerId"
                },
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    CustomerName = new GetResponsePaasCustomerName
                    {
                        Suffix = "Jnr"
                    }
                },
                new PutCustomerRequest()
            };

            yield return new object[]
            {
                new GetResponseCustomerProfile
                {
                    CustomerId = "customerId",
                    DOB = "1990-12-31",
                    Title = "Mr",
                    FirstName = "Dave",
                    MiddleName = "Thomas",
                    LastName = "Smith"
                },
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    Dob = new DateTime(1990, 12, 31),
                    CustomerName = new GetResponsePaasCustomerName
                    {
                        Title = "Mr",
                        FirstName = "Dave",
                        OtherName = "Thomas",
                        LastName = "Smith",
                        Suffix = "Jnr"
                    }
                },
                new PutCustomerRequest
                {
                    ClientId = "ECS",
                    CustomerId = "customerId",
                    Name = new CustomerName
                    {
                        Title = "Mr",
                        FirstName = "Dave",
                        OtherName = "Thomas",
                        LastName = "Smith"
                    },
                    AddressesToAdd = new List<PutCustomerAddressRequest>()
                }
            };

            yield return new object[]
            {
                new GetResponseCustomerProfile
                {
                    CustomerId = "customerId",
                    DOB = "1990-12-31",
                    Title = "Mr",
                    FirstName = "Dave",
                    MiddleName = "Thomas",
                    LastName = "Smith"
                },
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    Dob = new DateTime(1990, 12, 31),
                    CustomerName = new GetResponsePaasCustomerName
                    {
                        Title = "Mr",
                        FirstName = "David",
                        OtherName = "Thomas",
                        LastName = "Smith"
                    }
                },
                new PutCustomerRequest
                {
                    ClientId = "ECS",
                    CustomerId = "customerId",
                    Name = new CustomerName
                    {
                        FirstName = "Dave",
                        LastName = "Smith",
                        OtherName = "Thomas",
                        Title = "Mr"
                    },
                    AddressesToAdd = new List<PutCustomerAddressRequest>()
                }
            };

            yield return new object[]
            {
                new GetResponseCustomerProfile
                {
                    CustomerId = "customerId",
                    DOB = "1990-12-31",
                    Title = "Mr",
                    FirstName = "Dave",
                    MiddleName = "Tomas",
                    LastName = "Smith"
                },
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    Dob = new DateTime(1990, 12, 31),
                    CustomerName = new GetResponsePaasCustomerName
                    {
                        Title = "Mr",
                        FirstName = "Dave",
                        OtherName = "Thomas",
                        LastName = "Smith"
                    }
                },
                new PutCustomerRequest
                {
                    ClientId = "ECS",
                    CustomerId = "customerId",
                    Name = new CustomerName
                    {
                        FirstName = "Dave",
                        LastName = "Smith",
                        OtherName = "Tomas",
                        Title = "Mr"
                    },
                    AddressesToAdd = new List<PutCustomerAddressRequest>()
                }
            };

            yield return new object[]
            {
                new GetResponseCustomerProfile
                {
                    CustomerId = "customerId",
                    DOB = "1990-12-31",
                    Title = "Dr",
                    FirstName = "Dave",
                    MiddleName = "Thomas",
                    LastName = "Smith"
                },
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    Dob = new DateTime(1990, 12, 31),
                    CustomerName = new GetResponsePaasCustomerName
                    {
                        Title = "mr",
                        FirstName = "DAVE",
                        OtherName = "THOMAS",
                        LastName = "SMITH"
                    }
                },
                new PutCustomerRequest()
            };

            yield return new object[]
            {
                new GetResponseCustomerProfile
                {
                    CustomerId = "customerId",
                    DOB = "1990-12-31",
                    Title = "Mr",
                    FirstName = "Dave",
                    MiddleName = "Thomas",
                    LastName = "Smithe"
                },
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    Dob = new DateTime(1990, 12, 31),
                    CustomerName = new GetResponsePaasCustomerName
                    {
                        Title = "Mr",
                        FirstName = "Dave",
                        OtherName = "Thomas",
                        LastName = "Smith"
                    }
                },
                new PutCustomerRequest
                {
                    ClientId = "ECS",
                    CustomerId = "customerId",
                    Name = new CustomerName
                    {
                        FirstName = "Dave",
                        LastName = "Smithe",
                        OtherName = "Thomas",
                        Title = "Mr"
                    },
                    AddressesToAdd = new List<PutCustomerAddressRequest>()
                }
            };

            yield return new object[]
            {
                new GetResponseCustomerProfile
                {
                    CustomerId = "customerId",
                    DOB = "1991-12-31",
                    Title = "Sir",
                    FirstName = "Dave",
                    MiddleName = "Harold",
                    LastName = "Smithe"
                },
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    Dob = new DateTime(1990, 12, 31),
                    CustomerName = new GetResponsePaasCustomerName
                    {
                        Title = "Mr",
                        FirstName = "David",
                        OtherName = "Thomas",
                        LastName = "Smith",
                        Suffix = "Jnr"
                    }
                },
                new PutCustomerRequest()
                {
                    ClientId = "ECS",
                    CustomerId = "customerId",
                    Dob = new DateTime(1991, 12, 31),
                    Name = new CustomerName
                    {
                        Title = "Sir",
                        FirstName = "Dave",
                        OtherName = "Harold",
                        LastName = "Smithe"
                    },
                    AddressesToAdd = new List<PutCustomerAddressRequest>()
                }
            };

            yield return new object[]
            {
                new GetResponseCustomerProfile
                {
                    CustomerId = "customerId",
                    DOB = "1990-12-31",
                    Address = new List<GetResponseCustomerAddressModel>
                    {
                        new GetResponseCustomerAddressModel
                        {
                            Flat = "flat",
                            HouseName = "houseName",
                            HouseNumber = "1",
                            Street = "street",
                            City = "city",
                            District = "district",
                            County = "county",
                            Country = "country",
                            PostCode = "postcode",
                            FromDt = new DateTime(2000, 12, 31)
                        }
                    }
                },
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    Dob = new DateTime(1990, 12, 31),
                    Addresses = new[]
                    {
                        new GetResponsePaasAddressResponse
                        {
                            Flat = "flat",
                            HouseName = "houseName",
                            HouseNumber = "1",
                            Street = "street",
                            Town = "city",
                            County = "county",
                            Postcode = "postcode"
                        }
                    }
                },
                new PutCustomerRequest
                {
                    AddressFromCorvetteProfiler = new List<PutCustomerAddressRequest>
                    {
                        new PutCustomerAddressRequest
                        {
                            County = "county",
                            District = "district",
                            Flat = "flat",
                            HouseName = "houseName",
                            HouseNumber = "1",
                            IsCurrent = false,
                            Postcode = "POSTCODE",
                            Street = "street",
                            Town = "city"
                        }
                    }
                }
            };

            yield return new object[]
            {
                new GetResponseCustomerProfile
                {
                    CustomerId = "customerId",
                    DOB = "1990-12-31",
                    Address = new List<GetResponseCustomerAddressModel>
                    {
                        new GetResponseCustomerAddressModel
                        {
                            AddressType = "C",
                            HouseNumber = "1",
                            City = "city",
                            County = "county",
                            PostCode = "postcode",
                            FromDt = new DateTime(2000, 12, 31),
                            ToDt = new DateTime(2021, 4, 30)
                        },
                        new GetResponseCustomerAddressModel
                        {
                            HouseNumber = "123",
                            City = "new city",
                            County = "new county",
                            PostCode = "new postcode",
                            FromDt = new DateTime(2021, 4, 30)
                        }
                    }
                },
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    Dob = new DateTime(1990, 12, 31),
                    Addresses = new[]
                    {
                        new GetResponsePaasAddressResponse
                        {
                            County = "county",
                            HouseNumber = "1",
                            Town = "city",
                            Postcode = "postcode"
                        }
                    }
                },
                new PutCustomerRequest
                {
                    ClientId = "ECS",
                    CustomerId = "customerId",
                    AddressesToAdd = new List<PutCustomerAddressRequest>
                    {
                        new PutCustomerAddressRequest
                        {
                            IsCurrent = false,
                            HouseNumber = "123",
                            Town = "new city",
                            County = "new county",
                            Postcode = "NEWPOSTCODE"
                        }
                    },
                    AddressesToDelete = new List<string>(),
                    AddressFromCorvetteProfiler = new List<PutCustomerAddressRequest>
                    {
                        new PutCustomerAddressRequest
                        {
                            County = "county",
                            HouseNumber = "1",
                            IsCurrent = true,
                            Postcode = "POSTCODE",
                            Town = "city"
                        },
                        new PutCustomerAddressRequest
                        {
                            County = "new county",
                            HouseNumber = "123",
                            IsCurrent = false,
                            Postcode = "NEWPOSTCODE",
                            Town = "new city"
                        }
                    }
                }
            };

            yield return new object[]
            {
                new GetResponseCustomerProfile
                {
                    CustomerId = "customerId",
                    DOB = "1990-12-31",
                    Address = new List<GetResponseCustomerAddressModel>
                    {
                        new GetResponseCustomerAddressModel
                        {
                            HouseNumber = "1",
                            City = "city",
                            County = "county",
                            PostCode = "postcode",
                            FromDt = new DateTime(2000, 12, 31),
                            ToDt = new DateTime(2021, 4, 30)
                        },
                        new GetResponseCustomerAddressModel
                        {
                            AddressType = "C",
                            Flat = "flat",
                            City = "city",
                            County = "county",
                            PostCode = "postcode",
                            FromDt = new DateTime(2021, 4, 30)
                        }
                    }
                },
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    Dob = new DateTime(1990, 12, 31),
                    Addresses = new[]
                    {
                        new GetResponsePaasAddressResponse
                        {
                            County = "county",
                            HouseNumber = "1",
                            Town = "city",
                            Postcode = "postcode"
                        }
                    }
                },
                new PutCustomerRequest
                {
                    CustomerId = "customerId",
                    AddressesToAdd = new List<PutCustomerAddressRequest>
                    {
                        new PutCustomerAddressRequest
                        {
                            IsCurrent = true,
                            Flat = "flat",
                            Town = "city",
                            County = "county",
                            Postcode = "POSTCODE"
                        }
                    },
                    AddressesToDelete = new List<string>(),
                    ClientId = "ECS",
                    AddressFromCorvetteProfiler = new List<PutCustomerAddressRequest>
                    {
                        new PutCustomerAddressRequest
                        {
                            County = "county",
                            HouseNumber = "1",
                            IsCurrent = false,
                            Postcode = "POSTCODE",
                            Town = "city"
                        },
                        new PutCustomerAddressRequest
                        {
                            County = "county",
                            Flat = "flat",
                            IsCurrent = true,
                            Postcode = "POSTCODE",
                            Town = "city"
                        }
                    }
                }
            };

            yield return new object[]
            {
                new GetResponseCustomerProfile
                {
                    CustomerId = "customerId",
                    DOB = "1990-12-31",
                    Address = new List<GetResponseCustomerAddressModel>
                    {
                        new GetResponseCustomerAddressModel
                        {
                            HouseNumber = "1",
                            City = "city",
                            County = "county",
                            PostCode = "postcode",
                            FromDt = new DateTime(2000, 12, 31),
                            ToDt = new DateTime(2021, 4, 30)
                        },
                        new GetResponseCustomerAddressModel
                        {
                            AddressType = "C",
                            Flat = "flat",
                            City = "city",
                            County = "county",
                            PostCode = "postcode",
                            FromDt = new DateTime(2021, 4, 30)
                        }
                    }
                },
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    Dob = new DateTime(1990, 12, 31),
                    Addresses = new[]
                    {
                        new GetResponsePaasAddressResponse
                        {
                            Din = "12345678",
                            County = "county",
                            HouseNumber = "12",
                            Town = "city",
                            Postcode = "postcode"
                        }
                    }
                },
                new PutCustomerRequest
                {
                    CustomerId = "customerId",
                    AddressesToAdd = new List<PutCustomerAddressRequest>
                    {
                        new PutCustomerAddressRequest
                        {
                            IsCurrent = false,
                            HouseNumber = "1",
                            Town = "city",
                            County = "county",
                            Postcode = "POSTCODE"
                        },
                        new PutCustomerAddressRequest
                        {
                            IsCurrent = true,
                            Flat = "flat",
                            Town = "city",
                            County = "county",
                            Postcode = "POSTCODE"
                        }
                    },
                    AddressesToDelete = new List<string> {"12345678"},
                    ClientId = "ECS",
                    AddressFromCorvetteProfiler = new List<PutCustomerAddressRequest>
                    {
                        new PutCustomerAddressRequest
                        {
                            County = "county",
                            HouseNumber = "1",
                            IsCurrent = false,
                            Postcode = "POSTCODE",
                            Town = "city"
                        },
                        new PutCustomerAddressRequest
                        {
                            County = "county",
                            Flat = "flat",
                            IsCurrent = true,
                            Postcode = "POSTCODE",
                            Town = "city"
                        }
                    }
                }
            };

            yield return new object[]
            {
                new GetResponseCustomerProfile
                {
                    CustomerId = "customerId",
                    DOB = "1990-12-31",
                    Address = new List<GetResponseCustomerAddressModel>
                    {
                        new GetResponseCustomerAddressModel
                        {
                            HouseNumber = "1",
                            City = "city",
                            County = "county",
                            PostCode = "postcode",
                            FromDt = new DateTime(2000, 12, 31),
                            ToDt = new DateTime(2021, 4, 30)
                        },
                        new GetResponseCustomerAddressModel
                        {
                            AddressType = "C",
                            HouseName = "houseName",
                            City = "city",
                            County = "county",
                            PostCode = "postcode",
                            FromDt = new DateTime(2021, 4, 30)
                        }
                    }
                },
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    Dob = new DateTime(1990, 12, 31),
                    Addresses = new[]
                    {
                        new GetResponsePaasAddressResponse
                        {
                            County = "county",
                            HouseNumber = "1",
                            Town = "city",
                            Postcode = "postcode"
                        }
                    }
                },
                new PutCustomerRequest
                {
                    CustomerId = "customerId",
                    AddressesToAdd = new List<PutCustomerAddressRequest>
                    {
                        new PutCustomerAddressRequest
                        {
                            IsCurrent = true,
                            HouseName = "houseName",
                            Town = "city",
                            County = "county",
                            Postcode = "POSTCODE"
                        }
                    },
                    AddressesToDelete = new List<string>(),
                    ClientId = "ECS",
                    AddressFromCorvetteProfiler = new List<PutCustomerAddressRequest>
                    {
                        new PutCustomerAddressRequest
                        {
                            County = "county",
                            HouseNumber = "1",
                            IsCurrent = false,
                            Postcode = "POSTCODE",
                            Town = "city"
                        },
                        new PutCustomerAddressRequest
                        {
                            County = "county",
                            HouseName = "houseName",
                            IsCurrent = true,
                            Postcode = "POSTCODE",
                            Town = "city"
                        }
                    }
                }
            };

            yield return new object[]
            {
                new GetResponseCustomerProfile
                {
                    CustomerId = "customerId",
                    DOB = "1990-12-31",
                    Address = new List<GetResponseCustomerAddressModel>
                    {
                        new GetResponseCustomerAddressModel
                        {
                            HouseNumber = "1",
                            City = "city",
                            County = "county",
                            PostCode = "postcode",
                            FromDt = new DateTime(2000, 12, 31),
                            ToDt = new DateTime(2021, 4, 30)
                        },
                        new GetResponseCustomerAddressModel
                        {
                            HouseName = "houseName",
                            City = "city",
                            County = "county",
                            PostCode = "postcode",
                            FromDt = new DateTime(2021, 4, 30)
                        }
                    }
                },
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    Dob = new DateTime(1990, 12, 31),
                    Addresses = new[]
                    {
                        new GetResponsePaasAddressResponse
                        {
                            County = "county",
                            HouseNumber = "1",
                            Town = "city",
                            Postcode = "postcode"
                        },
                        new GetResponsePaasAddressResponse
                        {
                            County = "county",
                            HouseName = "houseName",
                            Town = "city",
                            Postcode = "postcode"
                        }
                    }
                },
                new PutCustomerRequest
                {
                    AddressFromCorvetteProfiler = new List<PutCustomerAddressRequest>
                    {
                        new PutCustomerAddressRequest
                        {
                            HouseNumber = "1",
                            Town = "city",
                            County = "county",
                            Postcode = "POSTCODE",
                            IsCurrent = false
                        },
                        new PutCustomerAddressRequest
                        {
                            HouseName = "houseName",
                            Town = "city",
                            County = "county",
                            Postcode = "POSTCODE",
                            IsCurrent = false
                        }
                    }
                }
            };

            yield return new object[]
            {
                new GetResponseCustomerProfile
                {
                    CustomerId = "customerId",
                    DOB = "1990-12-31",
                    Address = new List<GetResponseCustomerAddressModel>
                    {
                        new GetResponseCustomerAddressModel
                        {
                            Flat = "flat",
                            HouseName = "houseName",
                            HouseNumber = "1",
                            Street = "street",
                            City = "city",
                            District = "district",
                            County = "county",
                            Country = "country",
                            PostCode = "postcode",
                            FromDt = new DateTime(2000, 12, 31)
                        }
                    }
                },
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    Dob = new DateTime(1990, 12, 31),
                    Addresses = new[]
                    {
                        new GetResponsePaasAddressResponse
                        {
                            Flat = "flat",
                            HouseName = "houseName",
                            HouseNumber = "1",
                            Street = "street",
                            Town = "city",
                            County = "county",
                            Postcode = "postcode"
                        }
                    }
                },
                new PutCustomerRequest
                {
                    AddressFromCorvetteProfiler = new List<PutCustomerAddressRequest>
                    {
                        new PutCustomerAddressRequest
                        {
                            Flat = "flat",
                            HouseName = "houseName",
                            HouseNumber = "1",
                            Street = "street",
                            Town = "city",
                            District = "district",
                            County = "county",
                            Postcode = "POSTCODE",
                            IsCurrent = false
                        }
                    }
                }
            };

            yield return new object[]
            {
                new GetResponseCustomerProfile
                {
                    CustomerId = "customerId",
                    DOB = "1990-12-31",
                    Address = new List<GetResponseCustomerAddressModel>
                    {
                        new GetResponseCustomerAddressModel
                        {
                            HouseNumber = "1",
                            City = "city",
                            County = "county",
                            PostCode = "postcode",
                            FromDt = new DateTime(2000, 12, 31),
                            ToDt = new DateTime(2021, 4, 30)
                        },
                        new GetResponseCustomerAddressModel
                        {
                            AddressType = "C",
                            HouseNumber = "123",
                            City = "new city",
                            County = "county",
                            PostCode = "postcode",
                            FromDt = new DateTime(2021, 4, 30)
                        }
                    }
                },
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    Dob = new DateTime(1990, 12, 31),
                    Addresses = new[]
                    {
                        new GetResponsePaasAddressResponse
                        {
                            County = "county",
                            HouseNumber = "1",
                            Town = "city",
                            Postcode = "postcode"
                        }
                    }
                },
                new PutCustomerRequest
                {
                    ClientId = "ECS",
                    CustomerId = "customerId",
                    AddressesToAdd = new List<PutCustomerAddressRequest>
                    {
                        new PutCustomerAddressRequest
                        {
                            IsCurrent = true,
                            HouseNumber = "123",
                            Town = "new city",
                            County = "county",
                            Postcode = "POSTCODE"
                        }
                    },
                    AddressesToDelete = new List<string>(),
                    AddressFromCorvetteProfiler = new List<PutCustomerAddressRequest>
                    {
                        new PutCustomerAddressRequest
                        {
                            HouseNumber = "1",
                            Town = "city",
                            County = "county",
                            Postcode = "POSTCODE",
                            IsCurrent = false
                        },
                        new PutCustomerAddressRequest
                        {
                            IsCurrent = true,
                            HouseNumber = "123",
                            Town = "new city",
                            County = "county",
                            Postcode = "POSTCODE"
                        }
                    }
                }
            };

            yield return new object[]
            {
                new GetResponseCustomerProfile
                {
                    CustomerId = "customerId",
                    DOB = "1990-12-31",
                    Address = new List<GetResponseCustomerAddressModel>
                    {
                        new GetResponseCustomerAddressModel
                        {
                            HouseNumber = "1",
                            City = "city",
                            County = "county",
                            PostCode = "postcode",
                            FromDt = new DateTime(2000, 12, 31),
                            ToDt = new DateTime(2021, 4, 30)
                        },
                        new GetResponseCustomerAddressModel
                        {
                            HouseName = "houseName",
                            City = "city",
                            County = "county",
                            PostCode = "postcode",
                            FromDt = new DateTime(2021, 4, 30),
                            ToDt = new DateTime(2021, 5, 31)
                        },
                        new GetResponseCustomerAddressModel
                        {
                            Flat = "flat",
                            City = "city",
                            County = "county",
                            PostCode = "postcode2",
                            FromDt = new DateTime(2021, 6, 1),
                            ToDt = new DateTime(2021, 7, 31)
                        },
                        new GetResponseCustomerAddressModel
                        {
                            AddressType = "C",
                            HouseNumber = "1",
                            Street = "street",
                            City = "city",
                            County = "county",
                            PostCode = "postcode",
                            FromDt = new DateTime(2021, 8, 1)
                        }
                    }
                },
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    Dob = new DateTime(1990, 12, 31),
                    Addresses = new[]
                    {
                        new GetResponsePaasAddressResponse
                        {
                            HouseNumber = "1",
                            Town = "city",
                            County = "county",
                            Postcode = "postcode"
                        }
                    }
                },
                new PutCustomerRequest
                {
                    CustomerId = "customerId",
                    AddressesToAdd = new List<PutCustomerAddressRequest>
                    {
                        new PutCustomerAddressRequest
                        {
                            IsCurrent = false,
                            HouseName = "houseName",
                            Town = "city",
                            County = "county",
                            Postcode = "POSTCODE"
                        },
                        new PutCustomerAddressRequest
                        {
                            IsCurrent = false,
                            Flat = "flat",
                            Town = "city",
                            County = "county",
                            Postcode = "POSTCODE2"
                        },
                        new PutCustomerAddressRequest
                        {
                            IsCurrent = true,
                            HouseNumber = "1",
                            Street = "street",
                            Town = "city",
                            County = "county",
                            Postcode = "POSTCODE"
                        }
                    },
                    AddressesToDelete = new List<string>(),
                    ClientId = "ECS",
                    AddressFromCorvetteProfiler = new List<PutCustomerAddressRequest>
                    {
                        new PutCustomerAddressRequest
                        {
                            HouseNumber = "1",
                            Town = "city",
                            County = "county",
                            Postcode = "POSTCODE",
                            IsCurrent = false
                        },
                        new PutCustomerAddressRequest
                        {
                            HouseName = "houseName",
                            Town = "city",
                            County = "county",
                            Postcode = "POSTCODE",
                            IsCurrent = false
                        },
                        new PutCustomerAddressRequest
                        {
                            Flat = "flat",
                            Town = "city",
                            County = "county",
                            Postcode = "POSTCODE2",
                            IsCurrent = false
                        },
                        new PutCustomerAddressRequest
                        {
                            IsCurrent = true,
                            HouseNumber = "1",
                            Street = "street",
                            Town = "city",
                            County = "county",
                            Postcode = "POSTCODE"
                        }
                    }
                }
            };

            yield return new object[]
            {
                new GetResponseCustomerProfile
                {
                    CustomerId = "customerId",
                    DOB = "1990-12-31",
                    Address = new List<GetResponseCustomerAddressModel>
                    {
                        new GetResponseCustomerAddressModel
                        {
                            HouseNumber = "1",
                            City = "city",
                            County = "county",
                            PostCode = "postcode",
                            FromDt = new DateTime(2000, 12, 31),
                            ToDt = new DateTime(2021, 4, 30)
                        },
                        new GetResponseCustomerAddressModel
                        {
                            Flat = "flat",
                            City = "city",
                            County = "county",
                            PostCode = "postcode",
                            FromDt = new DateTime(2021, 5, 1),
                            ToDt = new DateTime(2021, 12, 31)
                        },
                        new GetResponseCustomerAddressModel
                        {
                            HouseName = "houseName",
                            City = "city",
                            County = "county",
                            PostCode = "postcode",
                            FromDt = new DateTime(2022, 1, 1)
                        }
                    }
                },
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    Dob = new DateTime(1990, 12, 31),
                    Addresses = new[]
                    {
                        new GetResponsePaasAddressResponse
                        {
                            County = "county",
                            HouseNumber = "1",
                            Town = "city",
                            Postcode = "postcode"
                        },
                        new GetResponsePaasAddressResponse
                        {
                            County = "county",
                            HouseName = "houseName",
                            Town = "city",
                            Postcode = "postcode"
                        }
                    }
                },
                new PutCustomerRequest
                {
                    ClientId = "ECS",
                    CustomerId = "customerId",
                    AddressesToAdd = new List<PutCustomerAddressRequest>
                    {
                        new PutCustomerAddressRequest
                        {
                            Flat = "flat",
                            Town = "city",
                            County = "county",
                            Postcode = "POSTCODE"
                        }
                    },
                    AddressesToDelete = new List<string>(),
                    AddressFromCorvetteProfiler = new List<PutCustomerAddressRequest>
                    {
                        new PutCustomerAddressRequest
                        {
                            HouseNumber = "1",
                            Town = "city",
                            County = "county",
                            Postcode = "POSTCODE"
                        },
                        new PutCustomerAddressRequest
                        {
                            Flat = "flat",
                            Town = "city",
                            County = "county",
                            Postcode = "POSTCODE",
                            IsCurrent = false
                        },
                        new PutCustomerAddressRequest
                        {
                            HouseName = "houseName",
                            Town = "city",
                            County = "county",
                            Postcode = "POSTCODE",
                            IsCurrent = false
                        }
                    }
                }
            };

            yield return new object[]
            {
                new GetResponseCustomerProfile
                {
                    CustomerId = "customerId",
                    DOB = "1990-12-31",
                    Address = new List<GetResponseCustomerAddressModel>
                    {
                        new GetResponseCustomerAddressModel
                        {
                            Flat = string.Empty,
                            HouseName = string.Empty,
                            HouseNumber = "1",
                            City = "city",
                            County = "county",
                            PostCode = "postcode",
                            FromDt = new DateTime(2000, 12, 31),
                            ToDt = new DateTime(2021, 4, 30)
                        }
                    }
                },
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    Dob = new DateTime(1990, 12, 31),
                    Addresses = new[]
                    {
                        new GetResponsePaasAddressResponse
                        {
                            County = "county",
                            HouseNumber = "1",
                            Town = "city",
                            Postcode = "postcode"
                        }
                    }
                },
                new PutCustomerRequest
                {
                    AddressFromCorvetteProfiler = new List<PutCustomerAddressRequest>
                    {
                        new PutCustomerAddressRequest
                        {
                            Flat = string.Empty,
                            HouseName = string.Empty,
                            HouseNumber = "1",
                            Town = "city",
                            County = "county",
                            Postcode = "POSTCODE"
                        }
                    }
                }
            };

            yield return new object[]
            {
                new GetResponseCustomerProfile
                {
                    CustomerId = "customerId",
                    DOB = "1990-12-31",
                    Address = new List<GetResponseCustomerAddressModel>
                    {
                        new GetResponseCustomerAddressModel
                        {
                            HouseNumber = "1",
                            City = "city",
                            County = "county",
                            PostCode = "postcode",
                            FromDt = new DateTime(2000, 12, 31)
                        }
                    }
                },
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    Dob = new DateTime(1990, 12, 31),
                    Addresses = new[]
                    {
                        new GetResponsePaasAddressResponse
                        {
                            Din = "87654321",
                            County = "county",
                            HouseNumber = "1",
                            Town = "city",
                            Postcode = "postcode"
                        },
                        new GetResponsePaasAddressResponse
                        {
                            Din = "12345678",
                            County = "ex-county",
                            HouseNumber = "999",
                            Town = "ex-city",
                            Postcode = "old postcode"
                        }
                    }
                },
                new PutCustomerRequest
                {
                    CustomerId = "customerId",
                    AddressesToAdd = new List<PutCustomerAddressRequest>(),
                    AddressesToDelete = new List<string> {"12345678"},
                    ClientId = "ECS",
                    AddressFromCorvetteProfiler = new List<PutCustomerAddressRequest>
                    {
                        new PutCustomerAddressRequest
                        {
                            County = "county",
                            HouseNumber = "1",
                            IsCurrent = false,
                            Postcode = "POSTCODE",
                            Town = "city"
                        }
                    }
                }
            };

            yield return new object[]
            {
                new GetResponseCustomerProfile
                {
                    CustomerId = "customerId",
                    DOB = "1990-12-31",
                    Address = new List<GetResponseCustomerAddressModel>
                    {
                        new GetResponseCustomerAddressModel
                        {
                            HouseNumber = "1",
                            City = "city",
                            County = "county",
                            PostCode = "postcode",
                            FromDt = new DateTime(2000, 12, 31)
                        }
                    }
                },
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    Dob = new DateTime(1990, 12, 31),
                    Addresses = new[]
                    {
                        new GetResponsePaasAddressResponse
                        {
                            Din = "87654321",
                            County = "county",
                            HouseNumber = "1",
                            Town = "city",
                            Postcode = "postcode"
                        },
                        new GetResponsePaasAddressResponse
                        {
                            Din = "12345678",
                            County = "ex-county",
                            HouseNumber = "999",
                            Town = "ex-city",
                            Postcode = "old postcode"
                        },
                        new GetResponsePaasAddressResponse
                        {
                            Din = "1122334455",
                            County = "ex-county 2",
                            HouseNumber = "222",
                            Town = "ex-city 2",
                            Postcode = "old postcode 2"
                        }
                    }
                },
                new PutCustomerRequest
                {
                    CustomerId = "customerId",
                    AddressesToAdd = new List<PutCustomerAddressRequest>(),
                    AddressesToDelete = new List<string> {"12345678", "1122334455"},
                    ClientId = "ECS",
                    AddressFromCorvetteProfiler = new List<PutCustomerAddressRequest>
                    {
                        new PutCustomerAddressRequest
                        {
                            County = "county",
                            HouseNumber = "1",
                            IsCurrent = false,
                            Postcode = "POSTCODE",
                            Town = "city"
                        }
                    }
                }
            };

            yield return new object[]
            {
                new GetResponseCustomerProfile
                {
                    CustomerId = "customerId",
                    DOB = "1990-12-31",
                    Address = new List<GetResponseCustomerAddressModel>
                    {
                        new GetResponseCustomerAddressModel
                        {
                            HouseNumber = "1",
                            City = "city",
                            County = "county",
                            PostCode = "postcode",
                            FromDt = new DateTime(2000, 12, 31),
                            ToDt = new DateTime(2020, 12, 31)
                        },
                        new GetResponseCustomerAddressModel
                        {
                            AddressType = "C",
                            HouseNumber = "30",
                            City = "another city",
                            County = "another county",
                            PostCode = "new postcode",
                            FromDt = new DateTime(2021, 1, 1)
                        }
                    }
                },
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    Dob = new DateTime(1990, 12, 31),
                    Addresses = new[]
                    {
                        new GetResponsePaasAddressResponse
                        {
                            Din = "87654321",
                            County = "county",
                            HouseNumber = "1",
                            Town = "city",
                            Postcode = "postcode"
                        },
                        new GetResponsePaasAddressResponse
                        {
                            Din = "12345678",
                            County = "ex-county",
                            HouseNumber = "999",
                            Town = "ex-city",
                            Postcode = "old postcode"
                        },
                        new GetResponsePaasAddressResponse
                        {
                            Din = "1122334455",
                            County = "ex-county 2",
                            HouseNumber = "222",
                            Town = "ex-city 2",
                            Postcode = "old postcode 2"
                        }
                    }
                },
                new PutCustomerRequest
                {
                    ClientId = "ECS",
                    CustomerId = "customerId",
                    AddressesToAdd = new List<PutCustomerAddressRequest>
                    {
                        new PutCustomerAddressRequest
                        {
                            IsCurrent = true,
                            HouseNumber = "30",
                            Town = "another city",
                            County = "another county",
                            Postcode = "NEWPOSTCODE"
                        }
                    },
                    AddressesToDelete = new List<string> {"12345678", "1122334455"},
                    AddressFromCorvetteProfiler = new List<PutCustomerAddressRequest>
                    {
                        new PutCustomerAddressRequest
                        {
                            HouseNumber = "1",
                            Town = "city",
                            County = "county",
                            Postcode = "POSTCODE",
                            IsCurrent = false
                        },
                        new PutCustomerAddressRequest
                        {
                            IsCurrent = true,
                            HouseNumber = "30",
                            Town = "another city",
                            County = "another county",
                            Postcode = "NEWPOSTCODE"
                        }
                    }
                }
            };

            yield return new object[]
            {
                new GetResponseCustomerProfile
                {
                    CustomerId = "customerId",
                    DOB = "1990-12-31",
                    Address = new List<GetResponseCustomerAddressModel>
                    {
                        new GetResponseCustomerAddressModel
                        {
                            HouseNumber = "1",
                            City = "city",
                            County = "county",
                            PostCode = "B20 3UE",
                            FromDt = new DateTime(2000, 12, 31),
                            ToDt = new DateTime(2020, 12, 31)
                        },
                        new GetResponseCustomerAddressModel
                        {
                            AddressType = "C",
                            HouseNumber = "30",
                            City = "another city",
                            County = "another county",
                            PostCode = "B20 3UE",
                            FromDt = new DateTime(2021, 1, 1)
                        }
                    }
                },
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    Dob = new DateTime(1990, 12, 31),
                    Addresses = new[]
                    {
                        new GetResponsePaasAddressResponse
                        {
                            Din = "87654321",
                            County = "county",
                            HouseNumber = "1",
                            Town = "city",
                            Postcode = "B20 3UE"
                        },
                        new GetResponsePaasAddressResponse
                        {
                            Din = "12345678",
                            County = "ex-county",
                            HouseNumber = "25",
                            Town = "ex-city",
                            Postcode = "HA3 4AR"
                        },
                        new GetResponsePaasAddressResponse
                        {
                            Din = "1122334455",
                            County = "ex-county 2",
                            HouseNumber = "225",
                            Town = "ex-city 2",
                            Postcode = "B28 7GH"
                        },
                        new GetResponsePaasAddressResponse
                        {
                        Din = "1122334600",
                        County = "ex-county 2",
                        HouseNumber = "275",
                        Town = "ex-city 2",
                        Postcode = "B28 7GH"
                        }
                    }
                },
                new PutCustomerRequest
                {
                    ClientId = "ECS",
                    CustomerId = "customerId",
                    AddressesToAdd = new List<PutCustomerAddressRequest>
                    {
                        new PutCustomerAddressRequest
                        {
                            IsCurrent = true,
                            HouseNumber = "30",
                            Town = "another city",
                            County = "another county",
                            Postcode = "B203UE"
                        }
                    },
                    AddressesToDelete = new List<string> {"12345678", "1122334455","1122334600"},
                    AddressFromCorvetteProfiler = new List<PutCustomerAddressRequest>
                    {
                        new PutCustomerAddressRequest
                        {
                            HouseNumber = "1",
                            Town = "city",
                            County = "county",
                            Postcode = "B203UE",
                            IsCurrent = false
                        },
                        new PutCustomerAddressRequest
                        {
                            IsCurrent = true,
                            HouseNumber = "30",
                            Town = "another city",
                            County = "another county",
                            Postcode = "B203UE"
                        }
                    }
                }
            };

            yield return new object[]
            {
                new GetResponseCustomerProfile
                {
                    CustomerId = "customerId",
                    DOB = "1990-12-31",
                    Address = new List<GetResponseCustomerAddressModel>
                    {
                        new GetResponseCustomerAddressModel
                        {
                            AddressType = "P",
                            HouseNumber = "34",
                            City = "city1",
                            County = "county1",
                            PostCode = "A129RE",
                            FromDt = new DateTime(1996, 12, 31),
                            ToDt = new DateTime(2020, 12, 31)
                        },
                        new GetResponseCustomerAddressModel
                        {
                            AddressType = "P",
                            HouseNumber = "1",
                            City = "city",
                            County = "county",
                            PostCode = "D991XX",
                            FromDt = new DateTime(2000, 12, 31),
                            ToDt = new DateTime(2020, 12, 31)
                        },
                        new GetResponseCustomerAddressModel
                        {
                            AddressType = "C",
                            HouseNumber = "30",
                            City = "another city",
                            County = "another county",
                            PostCode = "B203UE",
                            FromDt = new DateTime(2021, 1, 1),
                            IsCurrent = true
                        }
                    }
                },
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    Dob = new DateTime(1990, 12, 31),
                    Addresses = new[]
                    {
                        new GetResponsePaasAddressResponse
                        {
                            Din = "87654321",
                            County = "another county",
                            HouseNumber = "30",
                            Town = "another city",
                            Postcode = "B20 3UE"
                        },
                        new GetResponsePaasAddressResponse
                        {
                            Din = "12345678",
                            County = "county",
                            HouseNumber = "1",
                            Town = "city",
                            Postcode = "D99 1XX"
                        }
                    }
                },
                new PutCustomerRequest
                {
                    ClientId = "ECS",
                    CustomerId = "customerId",
                    AddressesToAdd = new List<PutCustomerAddressRequest>
                    {
                        new PutCustomerAddressRequest
                        {
                            HouseNumber = "34",
                            Town = "city1",
                            County = "county1",
                            Postcode = "A129RE",
                            IsCurrent = false
                        }
                    },
                    AddressesToDelete = new List<string>(),
                    AddressFromCorvetteProfiler = new List<PutCustomerAddressRequest>
                    {
                        new PutCustomerAddressRequest
                        {
                            HouseNumber = "34",
                            Town = "city1",
                            County = "county1",
                            Postcode = "A129RE",
                            IsCurrent = false
                        },
                        new PutCustomerAddressRequest
                        {
                            HouseNumber = "1",
                            Town = "city",
                            County = "county",
                            Postcode = "D991XX",
                            IsCurrent = false
                        },
                        new PutCustomerAddressRequest
                        {
                            HouseNumber = "30",
                            Town = "another city",
                            County = "another county",
                            Postcode = "B203UE",
                            IsCurrent = true
                        }
                    }
                }
            };

            yield return new object[]
            {
                new GetResponseCustomerProfile
                {
                    CustomerId = "customerId",
                    DOB = "1990-12-31",
                    Address = new List<GetResponseCustomerAddressModel>
                    {
                        new GetResponseCustomerAddressModel
                        {
                            AddressType = "P",
                            HouseNumber = "34",
                            City = "city1",
                            County = "county1",
                            PostCode = "A12 9RE",
                            FromDt = new DateTime(1996, 12, 31),
                            ToDt = new DateTime(2020, 12, 31)
                        },
                        new GetResponseCustomerAddressModel
                        {
                            AddressType = "P",
                            HouseNumber = "1",
                            City = "city",
                            County = "county",
                            PostCode = "D99 1XX",
                            FromDt = new DateTime(2000, 12, 31),
                            ToDt = new DateTime(2020, 12, 31)
                        },
                        new GetResponseCustomerAddressModel
                        {
                            AddressType = "C",
                            HouseNumber = "30",
                            City = "another city",
                            County = "another county",
                            PostCode = "B20 3UE",
                            FromDt = new DateTime(2021, 1, 1),
                            IsCurrent = true
                        }
                    }
                },
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    Dob = new DateTime(1990, 12, 31),
                    Addresses = new[]
                    {
                        new GetResponsePaasAddressResponse
                        {
                            Din = "87654321",
                            County = "another county",
                            HouseNumber = "30",
                            Town = "another city",
                            Postcode = "B203UE"
                        },
                        new GetResponsePaasAddressResponse
                        {
                            Din = "12345678",
                            County = "county",
                            HouseNumber = "1",
                            Town = "city",
                            Postcode = "D991XX"
                        }
                    }
                },
                new PutCustomerRequest
                {
                    ClientId = "ECS",
                    CustomerId = "customerId",
                    AddressesToAdd = new List<PutCustomerAddressRequest>
                    {
                        new PutCustomerAddressRequest
                        {
                            HouseNumber = "34",
                            Town = "city1",
                            County = "county1",
                            Postcode = "A129RE",
                            IsCurrent = false
                        }
                    },
                    AddressesToDelete = new List<string>(),
                    AddressFromCorvetteProfiler = new List<PutCustomerAddressRequest>
                    {
                        new PutCustomerAddressRequest
                        {
                            HouseNumber = "34",
                            Town = "city1",
                            County = "county1",
                            Postcode = "A129RE",
                            IsCurrent = false
                        },
                        new PutCustomerAddressRequest
                        {
                            HouseNumber = "1",
                            Town = "city",
                            County = "county",
                            Postcode = "D991XX",
                            IsCurrent = false
                        },
                        new PutCustomerAddressRequest
                        {
                            HouseNumber = "30",
                            Town = "another city",
                            County = "another county",
                            Postcode = "B203UE",
                            IsCurrent = true
                        }
                    }
                }
            };

            yield return new object[]
            {
                new GetResponseCustomerProfile
                {
                    CustomerId = "customerId",
                    DOB = "1990-12-31",
                    Address = new List<GetResponseCustomerAddressModel>
                    {
                        new GetResponseCustomerAddressModel
                        {
                            AddressType = "P",
                            HouseNumber = "34",
                            City = "city1",
                            County = "county1",
                            PostCode = "a12 9rE",
                            FromDt = new DateTime(1996, 12, 31),
                            ToDt = new DateTime(2020, 12, 31)
                        },
                        new GetResponseCustomerAddressModel
                        {
                            AddressType = "P",
                            HouseNumber = "1",
                            City = "city",
                            County = "county",
                            PostCode = "d99 1xx",
                            FromDt = new DateTime(2000, 12, 31),
                            ToDt = new DateTime(2020, 12, 31)
                        },
                        new GetResponseCustomerAddressModel
                        {
                            AddressType = "C",
                            HouseNumber = "30",
                            City = "another city",
                            County = "another county",
                            PostCode = "b20 3ue",
                            FromDt = new DateTime(2021, 1, 1),
                            IsCurrent = true
                        }
                    }
                },
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    Dob = new DateTime(1990, 12, 31),
                    Addresses = new[]
                    {
                        new GetResponsePaasAddressResponse
                        {
                            Din = "87654321",
                            County = "another county",
                            HouseNumber = "30",
                            Town = "another city",
                            Postcode = "B203UE"
                        },
                        new GetResponsePaasAddressResponse
                        {
                            Din = "12345678",
                            County = "county",
                            HouseNumber = "1",
                            Town = "city",
                            Postcode = "D991XX"
                        }
                    }
                },
                new PutCustomerRequest
                {
                    ClientId = "ECS",
                    CustomerId = "customerId",
                    AddressesToAdd = new List<PutCustomerAddressRequest>
                    {
                        new PutCustomerAddressRequest
                        {
                            HouseNumber = "34",
                            Town = "city1",
                            County = "county1",
                            Postcode = "A129RE",
                            IsCurrent = false
                        }
                    },
                    AddressesToDelete = new List<string>(),
                    AddressFromCorvetteProfiler = new List<PutCustomerAddressRequest>
                    {
                        new PutCustomerAddressRequest
                        {
                            HouseNumber = "34",
                            Town = "city1",
                            County = "county1",
                            Postcode = "A129RE",
                            IsCurrent = false
                        },
                        new PutCustomerAddressRequest
                        {
                            HouseNumber = "1",
                            Town = "city",
                            County = "county",
                            Postcode = "D991XX",
                            IsCurrent = false
                        },
                        new PutCustomerAddressRequest
                        {
                            HouseNumber = "30",
                            Town = "another city",
                            County = "another county",
                            Postcode = "B203UE",
                            IsCurrent = true
                        }
                    }
                }
            };

            yield return new object[]
            {
                new GetResponseCustomerProfile
                {
                    CustomerId = "customerId",
                    DOB = "1990-12-31",
                    Address = new List<GetResponseCustomerAddressModel>
                    {
                        new GetResponseCustomerAddressModel
                        {
                            Flat = "FLAT",
                            HouseName = "HOUSENAME",
                            HouseNumber = "1",
                            Street = "STREET",
                            City = "CITY",
                            District = "DISTRICT",
                            County = "COUNTY",
                            Country = "COUNTRY",
                            PostCode = "POSTCODE",
                            FromDt = new DateTime(2000, 12, 31)
                        }
                    }
                },
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    Dob = new DateTime(1990, 12, 31),
                    Addresses = new[]
                    {
                        new GetResponsePaasAddressResponse
                        {
                            Flat = "flat",
                            HouseName = "houseName",
                            HouseNumber = "1",
                            Street = "street",
                            Town = "city",
                            County = "county",
                            Postcode = "postcode"
                        }
                    }
                },
                new PutCustomerRequest
                {
                    AddressFromCorvetteProfiler = new List<PutCustomerAddressRequest>
                    {
                        new PutCustomerAddressRequest
                        {
                            County = "COUNTY",
                            District = "DISTRICT",
                            Flat = "FLAT",
                            HouseName = "HOUSENAME",
                            HouseNumber = "1",
                            IsCurrent = false,
                            Postcode = "POSTCODE",
                            Street = "STREET",
                            Town = "CITY"
                        }
                    }
                }
            };

            yield return new object[]
            {
                new GetResponseCustomerProfile
                {
                    CustomerId = "customerId",
                    DOB = "1990-12-31",
                    Title = "Sir",
                    FirstName = "Dave",
                    MiddleName = "Thomas",
                    LastName = "Smithe"
                },
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    Dob = new DateTime(1990, 12, 31),
                    CustomerName = new GetResponsePaasCustomerName
                    {
                        Title = "Mr",
                        FirstName = "Dave",
                        OtherName = "Thomas",
                        LastName = "Smithe"
                    }
                },
                new PutCustomerRequest()
            };

            // Test: CVT Profile is current address "C" (true), PaaS Profile address is Profile is false - excluded from search so no change
            yield return new object[]
            {
                new GetResponseCustomerProfile
                {
                    CustomerId = "customerId",
                    DOB = "1990-12-31",
                    Title = "Sir",
                    FirstName = "Dave",
                    MiddleName = "Thomas",
                    LastName = "Smithe",
                    Address = new GetResponseCustomerAddressModel[]
                    {
                        new()
                        {
                            AddressType = "C",
                            Flat = "FLAT",
                            HouseName = "HOUSENAME",
                            HouseNumber = "1",
                            Street = "STREET",
                            City = "CITY",
                            District = "DISTRICT",
                            County = "COUNTY",
                            Country = "COUNTRY",
                            PostCode = "POSTCODE",
                            FromDt = new DateTime(2000, 12, 31)
                        }
                    }
                },
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    Dob = new DateTime(1990, 12, 31),
                    CustomerName = new GetResponsePaasCustomerName
                    {
                        Title = "Mr",
                        FirstName = "Dave",
                        OtherName = "Thomas",
                        LastName = "Smithe"
                    },
                    Addresses = new GetResponsePaasAddressResponse[]
                    {
                        new()
                        {
                            Flat = "FLAT",
                            HouseName = "HOUSENAME",
                            HouseNumber = "1",
                            Street = "STREET",
                            District = "DISTRICT",
                            County = "COUNTY",
                            Town = "CITY",
                            Postcode = "POSTCODE",
                            IsCurrent = false
                        }
                    }
                },
                new PutCustomerRequest
                {
                    AddressFromCorvetteProfiler = new List<PutCustomerAddressRequest>
                    {
                        new()
                        {
                            Flat = "FLAT",
                            HouseName = "HOUSENAME",
                            HouseNumber = "1",
                            Street = "STREET",
                            District = "DISTRICT",
                            County = "COUNTY",
                            Town = "CITY",
                            Postcode = "POSTCODE",
                            IsCurrent = true
                        }
                    }
                }
            };

            // Test: CVT Profile is current address empty (false), PaaS Profile address is Profile is true - excluded from search so no change
            yield return new object[]
            {
                new GetResponseCustomerProfile
                {
                    CustomerId = "customerId",
                    DOB = "1990-12-31",
                    Title = "Sir",
                    FirstName = "Dave",
                    MiddleName = "Thomas",
                    LastName = "Smithe",
                    Address = new GetResponseCustomerAddressModel[]
                    {
                        new()
                        {
                            AddressType = string.Empty,
                            Flat = "FLAT",
                            HouseName = "HOUSENAME",
                            HouseNumber = "1",
                            Street = "STREET",
                            City = "CITY",
                            District = "DISTRICT",
                            County = "COUNTY",
                            Country = "COUNTRY",
                            PostCode = "POSTCODE",
                            FromDt = new DateTime(2000, 12, 31)
                        }
                    }
                },
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    Dob = new DateTime(1990, 12, 31),
                    CustomerName = new GetResponsePaasCustomerName
                    {
                        Title = "Mr",
                        FirstName = "Dave",
                        OtherName = "Thomas",
                        LastName = "Smithe"
                    },
                    Addresses = new GetResponsePaasAddressResponse[]
                    {
                        new()
                        {
                            Flat = "FLAT",
                            HouseName = "HOUSENAME",
                            HouseNumber = "1",
                            Street = "STREET",
                            District = "DISTRICT",
                            County = "COUNTY",
                            Town = "CITY",
                            Postcode = "POSTCODE",
                            IsCurrent = true
                        }
                    }
                },
                new PutCustomerRequest
                {
                    AddressFromCorvetteProfiler = new List<PutCustomerAddressRequest>
                    {
                        new()
                        {
                            Flat = "FLAT",
                            HouseName = "HOUSENAME",
                            HouseNumber = "1",
                            Street = "STREET",
                            District = "DISTRICT",
                            County = "COUNTY",
                            Town = "CITY",
                            Postcode = "POSTCODE",
                            IsCurrent = false
                        }
                    }
                }
            };

            // Test: CVT Profile is current no district, PaaS Profile address has district - excluded from search so no change
            yield return new object[]
            {
                new GetResponseCustomerProfile
                {
                    CustomerId = "customerId",
                    DOB = "1990-12-31",
                    Title = "Sir",
                    FirstName = "Dave",
                    MiddleName = "Thomas",
                    LastName = "Smithe",
                    Address = new GetResponseCustomerAddressModel[]
                    {
                        new()
                        {
                            AddressType = "C",
                            Flat = "FLAT",
                            HouseName = "HOUSENAME",
                            HouseNumber = "1",
                            Street = "STREET",
                            City = "CITY",
                            District = null,
                            County = "COUNTY",
                            Country = "COUNTRY",
                            PostCode = "POSTCODE",
                            FromDt = new DateTime(2000, 12, 31)
                        }
                    }
                },
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    Dob = new DateTime(1990, 12, 31),
                    CustomerName = new GetResponsePaasCustomerName
                    {
                        Title = "Mr",
                        FirstName = "Dave",
                        OtherName = "Thomas",
                        LastName = "Smithe"
                    },
                    Addresses = new GetResponsePaasAddressResponse[]
                    {
                        new()
                        {
                            Flat = "FLAT",
                            HouseName = "HOUSENAME",
                            HouseNumber = "1",
                            Street = "STREET",
                            District = "DISTRICT",
                            County = "COUNTY",
                            Town = "CITY",
                            Postcode = "POSTCODE",
                            IsCurrent = true
                        }
                    }
                },
                new PutCustomerRequest
                {
                    AddressFromCorvetteProfiler = new List<PutCustomerAddressRequest>
                    {
                        new()
                        {
                            Flat = "FLAT",
                            HouseName = "HOUSENAME",
                            HouseNumber = "1",
                            Street = "STREET",
                            District = null,
                            County = "COUNTY",
                            Town = "CITY",
                            Postcode = "POSTCODE",
                            IsCurrent = true
                        }
                    }
                }
            };

            // Test: CVT Profile is current has district, PaaS Profile address district is empty - excluded from search so no change
            yield return new object[]
            {
                new GetResponseCustomerProfile
                {
                    CustomerId = "customerId",
                    DOB = "1990-12-31",
                    Title = "Sir",
                    FirstName = "Dave",
                    MiddleName = "Thomas",
                    LastName = "Smithe",
                    Address = new GetResponseCustomerAddressModel[]
                    {
                        new()
                        {
                            AddressType = "C",
                            Flat = "FLAT",
                            HouseName = "HOUSENAME",
                            HouseNumber = "1",
                            Street = "STREET",
                            City = "CITY",
                            District = "DISTRICT",
                            County = "COUNTY",
                            Country = "COUNTRY",
                            PostCode = "POSTCODE",
                            FromDt = new DateTime(2000, 12, 31)
                        }
                    }
                },
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    Dob = new DateTime(1990, 12, 31),
                    CustomerName = new GetResponsePaasCustomerName
                    {
                        Title = "Mr",
                        FirstName = "Dave",
                        OtherName = "Thomas",
                        LastName = "Smithe"
                    },
                    Addresses = new GetResponsePaasAddressResponse[]
                    {
                        new()
                        {
                            Flat = "FLAT",
                            HouseName = "HOUSENAME",
                            HouseNumber = "1",
                            Street = "STREET",
                            District = null,
                            County = "COUNTY",
                            Town = "CITY",
                            Postcode = "POSTCODE",
                            IsCurrent = true
                        }
                    }
                },
                new PutCustomerRequest
                {
                    AddressFromCorvetteProfiler = new List<PutCustomerAddressRequest>
                    {
                        new()
                        {
                            Flat = "FLAT",
                            HouseName = "HOUSENAME",
                            HouseNumber = "1",
                            Street = "STREET",
                            District = "DISTRICT",
                            County = "COUNTY",
                            Town = "CITY",
                            Postcode = "POSTCODE",
                            IsCurrent = true
                        }
                    }
                }
            };
        }

        [Theory]
        [MemberData(nameof(MappingData))]
        public void InternalModelProfile_ExampleInput_MapsCorrectly(GetResponseCustomerProfile input, GetCustomerResponse start, PutCustomerRequest expected)
        {
            var mapper = _mapperConfiguration.CreateMapper();
            var result = mapper.Map<GetResponseCustomerProfile, GetCustomerResponse, PutCustomerRequest>(input, start);

            result.Should().BeEquivalentTo(expected);
        }
    }
}