﻿using AutoMapper;
using EXPN.Models.CreditLockService.Internal;
using EXPN.Models.CreditLockService.Internal.Put.Request;
using System.Diagnostics.CodeAnalysis;

namespace EXPN.Mappers.CreditLockService.Internal
{
    [ExcludeFromCodeCoverage]
    public class CustomerRequestToPutCustomerRequestProfile : Profile
    {
        public CustomerRequestToPutCustomerRequestProfile()
        {
            CreateMap<CustomerRequest, PutCustomerRequest>();
        }
    }
}