﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;
using AutoMapper;
using EXPN.Models.CreditLockService.External.Post.Request;
using EXPN.Models.CreditLockService.Internal.Post.Request;

namespace EXPN.Mappers.CreditLockService.Internal
{
    [ExcludeFromCodeCoverage]
    public  class PostRequestToDeactivateInstantAlertRequestProfile :  Profile
    {
        public PostRequestToDeactivateInstantAlertRequestProfile()
        {
            CreateMap<PostRequest, PostDeactivateInstantAlertRequest>();
        }
    }
}
