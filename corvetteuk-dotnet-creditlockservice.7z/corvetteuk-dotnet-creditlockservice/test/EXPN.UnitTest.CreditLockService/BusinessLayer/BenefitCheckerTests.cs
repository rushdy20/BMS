﻿using Experian.HttpClient.Services.Subscriptions.Models.Internal;
using EXPN.BusinessLayer.CreditLockService;
using EXPN.BusinessLayer.CreditLockService.Constants;
using EXPN.BusinessLayer.CreditLockService.Exceptions;
using EXPN.DataLayer.CreditLockService.Subscriptions;
using FluentAssertions;
using Microsoft.Extensions.Logging;
using NSubstitute;
using NSubstitute.ExceptionExtensions;
using NSubstitute.ReturnsExtensions;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;

namespace EXPN.UnitTest.CreditLockService.BusinessLayer
{
    public class BenefitCheckerTests
    {
        private readonly IBenefitChecker _benefitChecker;
        private readonly ISubscriptionsClientProxy _subscriptionsClientProxy;
        private readonly ILogger<BenefitChecker> _logger;

        private const string BenefitCode = "B028";

        public BenefitCheckerTests()
        {
            _logger = Substitute.For<ILogger<BenefitChecker>>();
            _subscriptionsClientProxy = Substitute.For<ISubscriptionsClientProxy>();
            _subscriptionsClientProxy.GetSubscriptionsAsync().Returns(new Subscription
            {
                Benefits = new List<Benefit>
                {
                    new()
                    {
                        Id = BenefitCode
                    }
                }
            });
            _benefitChecker = new BenefitChecker(_logger, _subscriptionsClientProxy);
        }

        public class Constructor
        {
            public static IEnumerable<object[]> NullParameters()
            {
                yield return new object[]
                {
                    null,
                    Substitute.For<ISubscriptionsClientProxy>(),
                    "logger"
                };
                yield return new object[]
                {
                    Substitute.For<ILogger<BenefitChecker>>(),
                    null,
                    "subscriptionsClientProxy"
                };
            }

            [Theory]
            [MemberData(nameof(NullParameters))]
            public void WithNullArgs_ThrowsException(ILogger<BenefitChecker> logger,
                ISubscriptionsClientProxy subscriptionBenefitProxy, string expectedValue)
            {
                var task = () =>
                {
                    var unused = new BenefitChecker(logger, subscriptionBenefitProxy);
                };

                task.Should().Throw<ArgumentNullException>()
                    .Where(x => x.ParamName == expectedValue);
            }
        }

        public class CheckBenefitAsync : BenefitCheckerTests
        {
            [Fact]
            public async Task EnsureValidBenefit_LogsEntry()
            {
                await _benefitChecker.EnsureValidBenefitAsync();

                await _subscriptionsClientProxy.Received(1).GetSubscriptionsAsync();

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.BenefitChecker.EnsureValidBenefitAsync.Start)),
                    null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public void EnsureValidBenefit_BenefitNotFound_ThrowsNoBenefitException()
            {
                var subscriptionProxy = Substitute.For<ISubscriptionsClientProxy>();
                subscriptionProxy.GetSubscriptionsAsync().Returns(new Subscription
                {
                    Benefits = new List<Benefit>
                    {
                        new()
                        {
                            Id = "B011"
                        }
                    }
                });

                var benefitChecker = new BenefitChecker(_logger, subscriptionProxy);

                var task = async () => await benefitChecker.EnsureValidBenefitAsync();

                task.Should().Throw<NoBenefitException>()
                    .And.BenefitsRequested.Should().Be(BenefitCode);

                subscriptionProxy.Received(1).GetSubscriptionsAsync().Wait();
            }

            [Fact]
            public void EnsureValidBenefit_ReturnsNull_ThrowsNullReferenceException()
            {
                var subscriptionProxy = Substitute.For<ISubscriptionsClientProxy>();
                subscriptionProxy.GetSubscriptionsAsync().ReturnsNull();

                var benefitChecker = new BenefitChecker(_logger, subscriptionProxy);

                var task = async () => await benefitChecker.EnsureValidBenefitAsync();

                task.Should().Throw<NoBenefitException>();

                subscriptionProxy.Received(1).GetSubscriptionsAsync().Wait();
            }

            [Fact]
            public void EnsureValidBenefit_ReturnsBenefitNull_ThrowsNullReferenceException()
            {
                var subscriptionProxy = Substitute.For<ISubscriptionsClientProxy>();
                subscriptionProxy.GetSubscriptionsAsync().Returns(new Subscription
                {
                    Benefits = null
                });

                var benefitChecker = new BenefitChecker(_logger, subscriptionProxy);

                var task = async () => await benefitChecker.EnsureValidBenefitAsync();

                task.Should().Throw<NoBenefitException>();

                subscriptionProxy.Received(1).GetSubscriptionsAsync().Wait();
            }

            [Fact]
            public void EnsureValidBenefit_Exception_Fails()
            {
                var subscriptionProxy = Substitute.For<ISubscriptionsClientProxy>();
                subscriptionProxy.GetSubscriptionsAsync()
                    .Throws(new AggregateException(new Exception()));

                var benefitChecker = new BenefitChecker(_logger, subscriptionProxy);

                var task = async () => await benefitChecker.EnsureValidBenefitAsync();

                task.Should().Throw<AggregateException>();

                subscriptionProxy.Received(1).GetSubscriptionsAsync().Wait();
            }
        }
    }
}