﻿using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Mime;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.TestHost;
using Microsoft.Extensions.Hosting;

namespace EXPN.IntegrationTest.CreditLockService.Utility
{
    public static class CommonIntegrationFunctions
    {
        public static async Task<HttpResponseMessage> GetExternalController(string customerId, IHostBuilder hostBuilder)
        {
            using var host = await hostBuilder.StartAsync();
            var webClient = host.GetTestClient();
            webClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(MediaTypeNames.Application.Json));
            webClient.DefaultRequestHeaders.Add("x-customerId", customerId);

            return await webClient.GetAsync($"/api/creditlock");
        }
        
        public static async Task<HttpResponseMessage> PutExternalController(string header,string status, IHostBuilder hostBuilder)
        {
            using var host = await hostBuilder.StartAsync();
            var webClient = host.GetTestClient();
            webClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(MediaTypeNames.Application.Json));
            webClient.DefaultRequestHeaders.Add("x-customerId", header);
            var httpContent = new StringContent(status, Encoding.UTF8, MediaTypeNames.Application.Json);
            return await webClient.PutAsync($"/api/creditlock", httpContent);
		}

        public static async Task<HttpResponseMessage> PutAgentExternalController(string header, string status, IHostBuilder hostBuilder)
        {
            using var host = await hostBuilder.StartAsync();
            var webClient = host.GetTestClient();
            webClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(MediaTypeNames.Application.Json));
            webClient.DefaultRequestHeaders.Add("x-customerId", header);
            var httpContent = new StringContent(status, Encoding.UTF8, MediaTypeNames.Application.Json);
            return await webClient.PutAsync($"/api/creditlock/cs", httpContent);
        }

        public static async Task<HttpResponseMessage> PostRequest(string endPoint, string header, IHostBuilder hostBuilder)
        {
            using var host = await hostBuilder.StartAsync();
            var webClient = host.GetTestClient();
            webClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(MediaTypeNames.Application.Json));
            webClient.DefaultRequestHeaders.Add("x-customerid", header);
            var httpContent = new StringContent(string.Empty, Encoding.UTF8, MediaTypeNames.Application.Json);
            return await webClient.PostAsync(endPoint, httpContent);
        }

        public static async Task<HttpResponseMessage> DeleteRequest(string endPoint,string body, string header, IHostBuilder hostBuilder)
        {
            using var host = await hostBuilder.StartAsync();
            var webClient = host.GetTestClient();
            webClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(MediaTypeNames.Application.Json));
            webClient.DefaultRequestHeaders.Add("x-customerid", header);
            var httpContent = new StringContent(body, Encoding.UTF8, MediaTypeNames.Application.Json);
            return await webClient.PostAsync(endPoint, httpContent);
        }
    }
}