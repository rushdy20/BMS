﻿using AutoMapper;
using EXPN.Models.CreditLockService.Internal.Get.Response;
using EXPN.Models.CreditLockService.Paas;
using EXPN.Models.CreditLockService.Paas.Get.Response;

namespace EXPN.Mappers.CreditLockService.Paas
{
    public class CustomerProfileToCustomerNameProfile : Profile
    {
        public CustomerProfileToCustomerNameProfile()
        {
            CreateMap<GetResponseCustomerProfile, CustomerName>(MemberList.None)
                .ForMember(d => d.FirstName, m => m.MapFrom(s => s.FirstName))
                .ForMember(d => d.OtherName, m => m.MapFrom(s => s.MiddleName))
                .ForMember(d => d.LastName, m => m.MapFrom(s => s.LastName))
                .ForMember(d => d.Title, m => m.MapFrom(s => s.Title))
                .ForMember(d => d.Suffix, m => m.Ignore());
        }
    }
}