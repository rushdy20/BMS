﻿using System;
using System.Runtime.Serialization;

namespace EXPN.BusinessLayer.CreditLockService.Exceptions
{
    [Serializable]
    public class SyncCustomerPinningException : Exception
    {
        protected SyncCustomerPinningException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }

        public SyncCustomerPinningException()
        {
        }

        public SyncCustomerPinningException(string message)
            : base(message)
        {
        }

        public SyncCustomerPinningException(string message, Exception innerException)
            : base(message, innerException)
        {
        }
    }
}