﻿using System.Diagnostics.CodeAnalysis;
using Experian.HttpClient.Services.Customers.Internal.GET;
using Microsoft.Extensions.DependencyInjection;

namespace EXPN.DataLayer.CreditLockService.Customers
{
    [ExcludeFromCodeCoverage]
    public static class CustomersDataLayerModule
    {
        public static IServiceCollection AddCustomersDataLayerModule(this IServiceCollection services)
        {
            services.AddTransient<IGetCustomerProfile, GetCustomerProfile>();
            services.AddSingleton<ICustomersClientProxy, CustomersClientProxy>();

            return services;
        }
    }
}