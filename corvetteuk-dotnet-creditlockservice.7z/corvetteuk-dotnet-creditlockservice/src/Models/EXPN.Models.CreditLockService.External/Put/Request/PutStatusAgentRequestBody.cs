using System.Diagnostics.CodeAnalysis;

namespace EXPN.Models.CreditLockService.External.Put.Request
{
    [ExcludeFromCodeCoverage]
    public class PutStatusAgentRequestBody
    {
        public string Status { get; set; }
        public string SalesforceUserId { get; set; }
    }
}