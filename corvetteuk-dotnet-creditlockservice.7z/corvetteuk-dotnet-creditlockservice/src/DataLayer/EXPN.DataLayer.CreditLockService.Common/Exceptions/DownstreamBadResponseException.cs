﻿using System;
using System.Runtime.Serialization;

namespace EXPN.DataLayer.CreditLockService.Common.Exceptions
{
    [Serializable]
    public class DownstreamBadResponseException : Exception
  {
      protected DownstreamBadResponseException(SerializationInfo info, StreamingContext context)
          : base(info, context)
      {
      }

      public DownstreamBadResponseException()
      {
      }

      public DownstreamBadResponseException(string message)
          : base(message)
      {
      }

      public DownstreamBadResponseException(string message, Exception innerException)
          : base(message, innerException)
      {
      }
  }
}