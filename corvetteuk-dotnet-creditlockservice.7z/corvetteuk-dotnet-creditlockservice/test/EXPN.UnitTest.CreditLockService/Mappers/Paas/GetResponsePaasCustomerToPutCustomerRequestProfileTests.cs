﻿using AutoMapper;
using EXPN.Mappers.CreditLockService.Paas;
using EXPN.Models.CreditLockService.Internal.Get.Response;
using EXPN.Models.CreditLockService.Paas;
using EXPN.Models.CreditLockService.Paas.Put.Request;
using FluentAssertions;
using System;
using System.Collections.Generic;
using Xunit;

namespace EXPN.UnitTest.CreditLockService.Mappers.Paas
{
    public class GetResponsePaasCustomerToPutCustomerRequestProfileTests
    {
        private readonly MapperConfiguration _mapperConfiguration;

        public GetResponsePaasCustomerToPutCustomerRequestProfileTests()
        {
            _mapperConfiguration = new MapperConfiguration(
                cfg => { cfg.AddProfile<GetResponsePaasCustomerToPutCustomerRequestProfile>(); });
        }

        [Fact]
        public void ModelProfile_AssertConfiguration_IsValid()
        {
            _mapperConfiguration.AssertConfigurationIsValid();
        }

        public static IEnumerable<object[]> MappingData()
        {
            yield return new object[]
            {
                null,
                null,
                null
            };

            yield return new object[]
            {
                new GetCustomerResponse(),
                new PutCustomerRequest(),
                new PutCustomerRequest()
            };

            yield return new object[]
            {
                new GetCustomerResponse
                {
                    CustomerId = "customerId"
                },
                new PutCustomerRequest
                {
                    CustomerId = "customerId"
                },
                new PutCustomerRequest()
            };

            yield return new object[]
            {
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    Dob = new DateTime(1990, 12, 31)
                },
                new PutCustomerRequest
                {
                    CustomerId = "customerId",
                    Dob = new DateTime(1990, 12, 31)
                },
                new PutCustomerRequest()
            };

            yield return new object[]
            {
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    Dob = new DateTime(1990, 12, 31)
                },
                new PutCustomerRequest
                {
                    CustomerId = "customerId",
                    Dob = null
                },
                new PutCustomerRequest()
            };

            yield return new object[]
            {
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    Dob = new DateTime(1990, 12, 31)
                },
                new PutCustomerRequest
                {
                    CustomerId = "customerId",
                    Dob = new DateTime(1992, 12, 31)
                },
                new PutCustomerRequest
                {
                    CustomerId = "customerId",
                    Dob = new DateTime(1992, 12, 31),
                    AddressesToAdd = new List<PutCustomerAddressRequest>()
                }
            };

            yield return new object[]
            {
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    CustomerName = new GetResponsePaasCustomerName()
                },
                new PutCustomerRequest
                {
                    CustomerId = "customerId",
                    Name = new CustomerName()
                },
                new PutCustomerRequest()
            };

            yield return new object[]
            {
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    CustomerName = new GetResponsePaasCustomerName
                    {
                        FirstName = "Dave"
                    }
                },
                new PutCustomerRequest
                {
                    CustomerId = "customerId",
                    Name = new CustomerName
                    {
                        FirstName = "Dave"
                    }
                },
                new PutCustomerRequest()
            };

            yield return new object[]
            {
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    CustomerName = new GetResponsePaasCustomerName
                    {
                        FirstName = "Harry"
                    }
                },
                new PutCustomerRequest
                {
                    CustomerId = "customerId",
                    Name = new CustomerName
                    {
                        FirstName = "Dave"
                    }
                },
                new PutCustomerRequest
                {
                    CustomerId = "customerId",
                    Name = new CustomerName
                    {
                        FirstName = "Dave"
                    },
                    AddressesToAdd = new List<PutCustomerAddressRequest>()
                }
            };

            yield return new object[]
            {
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    CustomerName = new GetResponsePaasCustomerName
                    {
                        FirstName = "Dave",
                        LastName = "Smith"
                    }
                },
                new PutCustomerRequest
                {
                    CustomerId = "customerId",
                    Name = new CustomerName
                    {
                        FirstName = "Dave",
                        LastName = "Smith"
                    },
                    AddressesToAdd = new List<PutCustomerAddressRequest>()
                },
                new PutCustomerRequest()
            };

            yield return new object[]
            {
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    CustomerName = new GetResponsePaasCustomerName
                    {
                        FirstName = "DAVE",
                        LastName = "smith"
                    }
                },
                new PutCustomerRequest
                {
                    CustomerId = "customerId",
                    Name = new CustomerName
                    {
                        FirstName = "Dave",
                        LastName = "SMITH"
                    }
                },
                new PutCustomerRequest()
            };

            yield return new object[]
            {
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    CustomerName = new GetResponsePaasCustomerName
                    {
                        FirstName = "Dave",
                        LastName = "King"
                    }
                },
                new PutCustomerRequest
                {
                    CustomerId = "customerId",
                    Name = new CustomerName
                    {
                        FirstName = "Dave",
                        LastName = "Smith"
                    }
                },
                new PutCustomerRequest
                {
                    CustomerId = "customerId",
                    Name = new CustomerName
                    {
                        FirstName = "Dave",
                        LastName = "Smith"
                    },
                    AddressesToAdd = new List<PutCustomerAddressRequest>()
                }
            };

            yield return new object[]
            {
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    CustomerName = new GetResponsePaasCustomerName
                    {
                        FirstName = "Dave",
                        LastName = "Smith",
                        OtherName = "John"
                    }
                },
                new PutCustomerRequest
                {
                    CustomerId = "customerId",
                    Name = new CustomerName
                    {
                        FirstName = "Dave",
                        LastName = "Smith",
                        OtherName = "John"
                    }
                },
                new PutCustomerRequest()
            };

            yield return new object[]
            {
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    CustomerName = new GetResponsePaasCustomerName
                    {
                        FirstName = "Dave",
                        LastName = "Smith",
                        OtherName = "John"
                    }
                },
                new PutCustomerRequest
                {
                    CustomerId = "customerId",
                    Name = new CustomerName
                    {
                        FirstName = "Dave",
                        LastName = "Smith",
                        OtherName = "JOHN"
                    }
                },
                new PutCustomerRequest()
            };

            yield return new object[]
            {
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    CustomerName = new GetResponsePaasCustomerName
                    {
                        FirstName = "Dave",
                        LastName = "Smith",
                        OtherName = "Simon"
                    }
                },
                new PutCustomerRequest
                {
                    CustomerId = "customerId",
                    Name = new CustomerName
                    {
                        FirstName = "Dave",
                        LastName = "Smith",
                        OtherName = "John"
                    }
                },
                new PutCustomerRequest
                {
                    CustomerId = "customerId",
                    Name = new CustomerName
                    {
                        FirstName = "Dave",
                        LastName = "Smith",
                        OtherName = "John"
                    },
                    AddressesToAdd = new List<PutCustomerAddressRequest>()
                }
            };

            yield return new object[]
            {
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    CustomerName = new GetResponsePaasCustomerName
                    {
                        FirstName = "Dave",
                        LastName = "Smith",
                        OtherName = "John"
                    }
                },
                new PutCustomerRequest
                {
                    CustomerId = "customerId",
                    Name = new CustomerName
                    {
                        FirstName = "Dave",
                        LastName = "Smith",
                        OtherName = string.Empty
                    }
                },
                new PutCustomerRequest
                {
                    CustomerId = "customerId",
                    Name = new CustomerName
                    {
                        FirstName = "Dave",
                        LastName = "Smith",
                        OtherName = string.Empty
                    },
                    AddressesToAdd = new List<PutCustomerAddressRequest>()
                }
            };

            yield return new object[]
            {
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    CustomerName = new GetResponsePaasCustomerName
                    {
                        FirstName = "Dave",
                        LastName = "Smith",
                        OtherName = "John",
                        Suffix = "Jnr"
                    }
                },
                new PutCustomerRequest
                {
                    CustomerId = "customerId",
                    Name = new CustomerName
                    {
                        FirstName = "Dave",
                        LastName = "Smith",
                        OtherName = "John",
                        Suffix = "Jnr"
                    }
                },
                new PutCustomerRequest()
            };

            yield return new object[]
            {
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    CustomerName = new GetResponsePaasCustomerName
                    {
                        FirstName = "Dave",
                        LastName = "Smith",
                        OtherName = "John",
                        Suffix = "jnr"
                    }
                },
                new PutCustomerRequest
                {
                    CustomerId = "customerId",
                    Name = new CustomerName
                    {
                        FirstName = "Dave",
                        LastName = "Smith",
                        OtherName = "John",
                        Suffix = "Jnr"
                    }
                },
                new PutCustomerRequest()
            };

            yield return new object[]
            {
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    CustomerName = new GetResponsePaasCustomerName
                    {
                        FirstName = "Dave",
                        LastName = "Smith",
                        OtherName = "John",
                        Suffix = "Snr"
                    }
                },
                new PutCustomerRequest
                {
                    CustomerId = "customerId",
                    Name = new CustomerName
                    {
                        FirstName = "Dave",
                        LastName = "Smith",
                        OtherName = "John",
                        Suffix = "Jnr"
                    }
                },
                new PutCustomerRequest
                {
                    CustomerId = "customerId",
                    Name = new CustomerName
                    {
                        FirstName = "Dave",
                        LastName = "Smith",
                        OtherName = "John",
                        Suffix = "Jnr"
                    },
                    AddressesToAdd = new List<PutCustomerAddressRequest>()
                }
            };

            yield return new object[]
            {
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    CustomerName = new GetResponsePaasCustomerName
                    {
                        FirstName = "Dave",
                        LastName = "Smith",
                        OtherName = "John",
                        Suffix = "Jnr",
                        Title = "Mr"
                    }
                },
                new PutCustomerRequest
                {
                    CustomerId = "customerId",
                    Name = new CustomerName
                    {
                        FirstName = "Dave",
                        LastName = "Smith",
                        OtherName = "John",
                        Suffix = "Jnr",
                        Title = "Mr"
                    }
                },
                new PutCustomerRequest()
            };

            yield return new object[]
            {
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    CustomerName = new GetResponsePaasCustomerName
                    {
                        FirstName = "Dave",
                        LastName = "Smith",
                        OtherName = "John",
                        Suffix = "jnr",
                        Title = "MR"
                    }
                },
                new PutCustomerRequest
                {
                    CustomerId = "customerId",
                    Name = new CustomerName
                    {
                        FirstName = "Dave",
                        LastName = "Smith",
                        OtherName = "John",
                        Suffix = "Jnr",
                        Title = "Mr"
                    }
                },
                new PutCustomerRequest()
            };

            yield return new object[]
            {
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    CustomerName = new GetResponsePaasCustomerName
                    {
                        FirstName = "Dave",
                        LastName = "Smith",
                        OtherName = "John",
                        Suffix = "Jnr",
                        Title = "Mr"
                    }
                },
                new PutCustomerRequest
                {
                    CustomerId = "customerId",
                    Name = new CustomerName
                    {
                        FirstName = "Dave",
                        LastName = "Smith",
                        OtherName = "John",
                        Suffix = "Jnr",
                        Title = "Sir"
                    }
                },
                new PutCustomerRequest()
            };

            yield return new object[]
            {
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    CustomerName = new GetResponsePaasCustomerName
                    {
                        FirstName = "Dave",
                        LastName = "Smith",
                        OtherName = "John",
                        Suffix = "Jnr",
                        Title = "Mr"
                    },
                    Addresses = new[]
                    {
                        new GetResponsePaasAddressResponse
                        {
                            County = "county",
                            Postcode = "postcode"
                        }
                    }
                },
                new PutCustomerRequest
                {
                    CustomerId = "customerId",
                    Name = new CustomerName
                    {
                        FirstName = "Dave",
                        LastName = "Smith",
                        OtherName = "John",
                        Suffix = "Jnr",
                        Title = "Mr"
                    },
                    AddressesToAdd = new List<PutCustomerAddressRequest>
                    {
                        new PutCustomerAddressRequest
                        {
                            County = "county",
                            Postcode = "postcode"
                        }
                    }
                },
                new PutCustomerRequest()
            };

            yield return new object[]
            {
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    CustomerName = new GetResponsePaasCustomerName
                    {
                        FirstName = "Dave",
                        LastName = "Smith",
                        OtherName = "John",
                        Suffix = "Jnr",
                        Title = "Mr"
                    },
                    Addresses = Array.Empty<GetResponsePaasAddressResponse>()
                },
                new PutCustomerRequest
                {
                    CustomerId = "customerId",
                    Name = new CustomerName
                    {
                        FirstName = "Dave",
                        LastName = "Smith",
                        OtherName = "John",
                        Suffix = "Jnr",
                        Title = "Mr"
                    }
                },
                new PutCustomerRequest()
            };

            yield return new object[]
            {
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    CustomerName = new GetResponsePaasCustomerName
                    {
                        FirstName = "Dave",
                        LastName = "Smith",
                        OtherName = "John",
                        Suffix = "Jnr",
                        Title = "Mr"
                    },
                    Addresses = new[]
                    {
                        new GetResponsePaasAddressResponse
                        {
                            County = "county",
                            Postcode = "postcode"
                        }
                    }
                },
                new PutCustomerRequest
                {
                    CustomerId = "customerId",
                    Name = new CustomerName
                    {
                        FirstName = "Dave",
                        LastName = "Smith",
                        OtherName = "John",
                        Suffix = "Jnr",
                        Title = "Mr"
                    },
                    AddressesToAdd = new List<PutCustomerAddressRequest>
                    {
                        new PutCustomerAddressRequest
                        {
                            County = "county",
                            Postcode = "postcode"
                        },
                        new PutCustomerAddressRequest
                        {
                            County = "county",
                            Postcode = "postcode_new"
                        }
                    }
                },
                new PutCustomerRequest
                {
                    CustomerId = "customerId",
                    AddressesToAdd = new List<PutCustomerAddressRequest>
                    {
                        new PutCustomerAddressRequest
                        {
                            County = "county",
                            Postcode = "POSTCODE_NEW"
                        }
                    }
                }
            };

            yield return new object[]
            {
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    CustomerName = new GetResponsePaasCustomerName
                    {
                        FirstName = "Dave",
                        LastName = "Smith",
                        OtherName = "John",
                        Suffix = "Jnr",
                        Title = "Mr"
                    },
                    Addresses = new[]
                    {
                        new GetResponsePaasAddressResponse
                        {
                            County = "county",
                            Postcode = "postcode"
                        }
                    }
                },
                new PutCustomerRequest
                {
                    CustomerId = "customerId",
                    Name = new CustomerName
                    {
                        FirstName = "Dave",
                        LastName = "Smith",
                        OtherName = "John",
                        Suffix = "Jnr",
                        Title = "Mr"
                    },
                    AddressesToAdd = new List<PutCustomerAddressRequest>
                    {
                        new PutCustomerAddressRequest
                        {
                            County = "county",
                            Postcode = "postcode"
                        },
                        new PutCustomerAddressRequest
                        {
                            County = "county",
                            Postcode = "postcode_new"
                        },
                        new PutCustomerAddressRequest
                        {
                            County = "county",
                            Postcode = "postcode_another_new"
                        }
                    },
                    AddressFromCorvetteProfiler = new List<PutCustomerAddressRequest>
                    {
                        new PutCustomerAddressRequest
                        {
                            County = "county",
                            Postcode = "postcode"
                        },
                        new PutCustomerAddressRequest
                        {
                            County = "county",
                            Postcode = "postcode_new"
                        },
                        new PutCustomerAddressRequest
                        {
                            County = "county",
                            Postcode = "postcode_another_new"
                        }
                    }
                },
                new PutCustomerRequest
                {
                    CustomerId = "customerId",
                    AddressesToAdd = new List<PutCustomerAddressRequest>
                    {
                        new PutCustomerAddressRequest
                        {
                            County = "county",
                            Postcode = "POSTCODE_NEW"
                        },
                        new PutCustomerAddressRequest
                        {
                            County = "county",
                            Postcode = "POSTCODE_ANOTHER_NEW"
                        }
                    },
                    AddressFromCorvetteProfiler = new List<PutCustomerAddressRequest>
                    {
                        new PutCustomerAddressRequest
                        {
                            County = "county",
                            Postcode = "postcode"
                        },
                        new PutCustomerAddressRequest
                        {
                            County = "county",
                            Postcode = "postcode_new"
                        },
                        new PutCustomerAddressRequest
                        {
                            County = "county",
                            Postcode = "postcode_another_new"
                        }
                    }
                }
            };

            yield return new object[]
            {
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    CustomerName = new GetResponsePaasCustomerName
                    {
                        FirstName = "Dave",
                        LastName = "Smith",
                        OtherName = "John",
                        Suffix = "Jnr",
                        Title = "Mr"
                    },
                    Addresses = new[]
                    {
                        new GetResponsePaasAddressResponse
                        {
                            County = "county",
                            Postcode = "postcode"
                        },
                        new GetResponsePaasAddressResponse
                        {
                            Din = "din to delete",
                            County = "county",
                            Postcode = "postcode_old"
                        }
                    }
                },
                new PutCustomerRequest
                {
                    CustomerId = "customerId",
                    Name = new CustomerName
                    {
                        FirstName = "Dave",
                        LastName = "Smith",
                        OtherName = "John",
                        Suffix = "Jnr",
                        Title = "Mr"
                    },
                    AddressesToAdd = new List<PutCustomerAddressRequest>
                    {
                        new PutCustomerAddressRequest
                        {
                            County = "county",
                            Postcode = "postcode"
                        },
                        new PutCustomerAddressRequest
                        {
                            County = "county",
                            Postcode = "postcode_new"
                        },
                        new PutCustomerAddressRequest
                        {
                            County = "county",
                            Postcode = "postcode_another_new"
                        }
                    },
                    AddressesToDelete = new List<string> { "postcode", "postcode_new", "postcode_another_new" },
                    AddressFromCorvetteProfiler = new List<PutCustomerAddressRequest>
                    {
                        new PutCustomerAddressRequest
                        {
                            County = "county",
                            Postcode = "postcode"
                        },
                        new PutCustomerAddressRequest
                        {
                            County = "county",
                            Postcode = "postcode_new"
                        },
                        new PutCustomerAddressRequest
                        {
                            County = "county",
                            Postcode = "postcode_another_new"
                        }
                    }
                },
                new PutCustomerRequest
                {
                    CustomerId = "customerId",
                    AddressesToAdd = new List<PutCustomerAddressRequest>
                    {
                        new PutCustomerAddressRequest
                        {
                            County = "county",
                            Postcode = "POSTCODE_NEW"
                        },
                        new PutCustomerAddressRequest
                        {
                            County = "county",
                            Postcode = "POSTCODE_ANOTHER_NEW"
                        }
                    },
                    AddressesToDelete = new List<string>{ "din to delete" },
                    AddressFromCorvetteProfiler = new List<PutCustomerAddressRequest>
                    {
                        new PutCustomerAddressRequest
                        {
                            County = "county",
                            Postcode = "POSTCODE"
                        },
                        new PutCustomerAddressRequest
                        {
                            County = "county",
                            Postcode = "POSTCODE_NEW"
                        },
                        new PutCustomerAddressRequest
                        {
                            County = "county",
                            Postcode = "POSTCODE_ANOTHER_NEW"
                        }
                    }
                }
            };

            yield return new object[]
            {
                new GetCustomerResponse
                {
                    CustomerId = "customerId",
                    CustomerName = new GetResponsePaasCustomerName
                    {
                        FirstName = "Dave",
                        LastName = "Smith",
                        OtherName = "John",
                        Suffix = "Jnr",
                        Title = "Mr"
                    },
                    Addresses = new[]
                    {
                        new GetResponsePaasAddressResponse
                        {
                            County = "county",
                            Postcode = "postcode"
                        }
                    }
                },
                new PutCustomerRequest
                {
                    CustomerId = "customerId",
                    Name = new CustomerName
                    {
                        FirstName = "Dave",
                        LastName = "Smith",
                        OtherName = "John",
                        Suffix = "Jnr",
                        Title = "Mr"
                    },
                    AddressesToAdd = new List<PutCustomerAddressRequest>
                    {
                        new PutCustomerAddressRequest
                        {
                            County = "COUNTY",
                            Postcode = "POSTCODE"
                        }
                    }
                },
                new PutCustomerRequest()
            };

        }

        [Theory]
        [MemberData(nameof(MappingData))]
        public void InternalModelProfile_ExampleInput_MapsCorrectly(GetCustomerResponse input, PutCustomerRequest start, PutCustomerRequest expected)
        {
            var mapper = _mapperConfiguration.CreateMapper();
            var result = mapper.Map(input, start);

            result.Should().BeEquivalentTo(expected);
        }
    }
}