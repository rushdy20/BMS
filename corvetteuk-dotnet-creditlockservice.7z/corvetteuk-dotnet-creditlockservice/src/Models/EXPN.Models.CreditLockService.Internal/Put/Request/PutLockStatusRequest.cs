﻿using System.Diagnostics.CodeAnalysis;

namespace EXPN.Models.CreditLockService.Internal.Put.Request
{
    [ExcludeFromCodeCoverage]
    public class PutLockStatusRequest
    {
        public string CustomerId { get; set; }
        public bool LockStatus { get; set; }
        public string SalesForceUserId { get; set; }
    }
}