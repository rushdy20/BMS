﻿using Experian.AWS.Config;
using FluentAssertions;
using Newtonsoft.Json;
using System;
using EXPN.Controllers.CreditLockService.Messaging;
using Xunit;

namespace EXPN.UnitTest.CreditLockService.BusinessLayer.Messaging
{
    public class TopicRetrieverTests
    {
        private readonly TopicRetriever _topicRetriever;

        public TopicRetrieverTests()
        {
            var topicConfig = JsonConvert.DeserializeObject<ConsolidatedConfig>("{\"sns_topics_published\": [{\"physicalid\": \"TestTopic\",\"logicalid\": \"test\"}]}");
            _topicRetriever = new TopicRetriever(topicConfig);
        }

        [Fact]
        public void NullConstructorParam_Throws()
        {
            Action action = () =>
            {
                new TopicRetriever(null);
            };

            action.Should().Throw<ArgumentNullException>()
                .Where(x => x.ParamName == "topicConfig");
        }

        [Fact]
        public void NoTopics_ReturnsNull()
        {
            var result = _topicRetriever.GetTopicPhysicalId("testTopic");

            result.Should().BeNullOrEmpty();
        }

        [Fact]
        public void Topic_ReturnsString()
        {
            var result = _topicRetriever.GetTopicPhysicalId("test");

            result.Should().Be("TestTopic");
        }
    }
}