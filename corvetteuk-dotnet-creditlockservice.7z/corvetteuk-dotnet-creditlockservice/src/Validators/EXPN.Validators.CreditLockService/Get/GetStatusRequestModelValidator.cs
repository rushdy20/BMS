﻿using System;
using EXPN.Models.CreditLockService.External;
using EXPN.Models.CreditLockService.External.Get.Customer.Request;
using FluentValidation;

namespace EXPN.Validators.CreditLockService.Get
{
    public class GetStatusRequestModelValidator : AbstractValidator<GetStatusRequest>
    {
        public GetStatusRequestModelValidator()
        {
            RuleFor(x => x)
                .NotNull()
                .DependentRules(() =>
                    RuleFor(instance => instance.CustomerId)
                        .Cascade(CascadeMode.StopOnFirstFailure)
                        .NotEmpty()
                        .Must(x => Guid.TryParse(x, out _))
                        .WithMessage("'CustomerId' is not in valid format"));
        }
    }
}