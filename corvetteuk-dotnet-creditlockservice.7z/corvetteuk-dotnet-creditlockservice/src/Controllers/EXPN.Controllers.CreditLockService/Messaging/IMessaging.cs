﻿using System.Threading.Tasks;

namespace EXPN.Controllers.CreditLockService.Messaging
{
    public interface IMessaging
    {
        Task PublishEventAsync(string eventName, CreditLockEventContent creditLockEventContent);
    }
}
