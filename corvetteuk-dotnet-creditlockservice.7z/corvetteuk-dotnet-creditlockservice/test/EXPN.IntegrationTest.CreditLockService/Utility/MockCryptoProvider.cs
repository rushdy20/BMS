﻿using Experian.AWS.Cryptography;
using System;
using System.Threading.Tasks;

namespace EXPN.IntegrationTest.CreditLockService.Utility
{
    public class MockCryptoProvider : ICryptographyProvider
    {
        public Task<bool> CompareHash(string hash, string text, Guid tenantId, string dataClass = "default")
        {
            return Task.FromResult(true);
        }
        public Task<bool> CompareHashSharedKey(string hash, string text, Guid tenantId, string dataClass = "default")
        {
            return Task.FromResult(true);
        }
        public Task<string> Decrypt(string encryptedData)
        {
            return Task.FromResult(encryptedData);
        }
        public Task<byte[]> Decrypt(byte[] encryptedData)
        {
            return Task.FromResult(encryptedData);
        }
        public Task<string> Encrypt(string text, Guid tenantId, string dataClass = "default")
        {
            return Task.FromResult(text);
        }
        public Task<byte[]> Encrypt(byte[] text, Guid tenantId, string dataClass = "default")
        {
            return Task.FromResult(text);
        }
        public Task<string> EncryptSharedKey(string text, Guid tenantId, string dataClass = "default")
        {
            return Task.FromResult(text);
        }
        public Task<byte[]> EncryptSharedKey(byte[] text, Guid tenantId, string dataClass = "default")
        {
            return Task.FromResult(text);
        }
        public Task<string> Hash(string text, Guid tenantId, string dataClass = "default")
        {
            return Task.FromResult(text);
        }
        public Task<string> HashSharedKey(string text, Guid tenantId, string dataClass = "default")
        {
            return Task.FromResult(text);
        }
    }
}
