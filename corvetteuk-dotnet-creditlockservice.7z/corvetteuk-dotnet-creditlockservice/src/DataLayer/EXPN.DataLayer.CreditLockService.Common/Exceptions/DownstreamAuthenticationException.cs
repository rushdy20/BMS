﻿using System;
using System.Runtime.Serialization;

namespace EXPN.DataLayer.CreditLockService.Common.Exceptions
{
    [Serializable]
    public class DownstreamAuthenticationException : Exception
    {
        protected DownstreamAuthenticationException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }
        public DownstreamAuthenticationException()
        {
        }

        public DownstreamAuthenticationException(string message)
            : base(message)
        {
        }

        public DownstreamAuthenticationException(string message, Exception innerException)
            : base(message, innerException)
        {
        }
    }
}