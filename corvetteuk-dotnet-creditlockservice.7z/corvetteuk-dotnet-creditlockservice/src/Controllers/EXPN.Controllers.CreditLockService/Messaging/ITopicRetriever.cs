﻿namespace EXPN.Controllers.CreditLockService.Messaging
{
    public interface ITopicRetriever
    {
        string GetTopicPhysicalId(string logicalId);
    }
}
