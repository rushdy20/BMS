﻿using Experian.HttpClient.Services.Subscriptions.Models.Internal;

namespace EXPN.DataLayer.CreditLockService.Subscriptions;

public interface ISubscriptionsClientProxy
{
    Task<Subscription> GetSubscriptionsAsync();
}