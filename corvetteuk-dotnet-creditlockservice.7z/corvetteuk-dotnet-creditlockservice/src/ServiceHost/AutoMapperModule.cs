using AutoMapper;
using EXPN.Mappers.CreditLockService.Internal;
using EXPN.Mappers.CreditLockService.Paas;
using Microsoft.Extensions.DependencyInjection;
using System.Diagnostics.CodeAnalysis;

namespace EXPN.ServiceHost.CreditLockService
{
    [ExcludeFromCodeCoverage]
    public static class AutoMapperModule
    {
        public static IServiceCollection AddAutoMapper(this IServiceCollection services)
        {
            var mappingConfig = new MapperConfiguration(cfg =>
            {
                // External
                cfg.AddProfile<Mappers.CreditLockService.External.GetCustomerResponseProfileToLockStatusProfile>();

                // Internal
                cfg.AddProfile<CustomerProfileToGetResponseCustomerProfile>();
                cfg.AddProfile<CustomerRequestToPutCustomerRequestProfile>();
                cfg.AddProfile<GetCustomerResponseToGetResponsePaasCustomerProfile>();
                cfg.AddProfile<PostRequestToCustomerRequestProfile>();
                cfg.AddProfile<GetStatusRequestToGetLockStatusRequestProfile>();
                cfg.AddProfile<PutStatusRequestToPutLockStatusRequestProfile>();
                cfg.AddProfile<PutStatusUpdateBodyToPutLockStatusRequestProfile>();
                cfg.AddProfile<PostRequestToPutCustomerRequestProfile>();
                cfg.AddProfile<PostRequestToPutLockStatusRequestProfile>();
                cfg.AddProfile<DeleteCustomerToDeleteCustomerProfile>();
                cfg.AddProfile<PostRequestToDeactivateInstantAlertRequestProfile>();
                cfg.AddProfile<PutAgentLockStatusRequestToPutLockStatusRequestProfile>();
                cfg.AddProfile<PutAgentLockStatusBodyToPutLockStatusRequestProfile>();
                cfg.AddProfile<PutLockStatusRequestToPutCustomerRequest>();
                cfg.AddProfile<PostRequestToActivateInstantAlertRequest>();
                cfg.AddProfile<GetCustomerProfileToPostActivateInstantAlertRequestProfiler>();
                cfg.AddProfile<DeleteEventBodyToDeleteCustomerProfile>();
                cfg.AddProfile<CustomerProfilerAddressToGetResponseCustomerAddressModelProfiler>();

                // PaaS
                cfg.AddProfile<AddressModelToAddressProfile>();
                cfg.AddProfile<CustomerProfileToCustomerNameProfile>();
                cfg.AddProfile<CustomerProfileToCustomerPostRequestProfile>();
                cfg.AddProfile<GetResponseCustomerAddressModelToPutCustomerAddressRequestProfile>();
                cfg.AddProfile<GetResponseCustomerProfileToPutCustomerRequestProfile>();
                cfg.AddProfile<GetResponsePaasCustomerToPutCustomerRequestProfile>();
                cfg.AddProfile<SecretsManagerDataToOktaAuthCredentialProfile>();
                cfg.AddProfile<PutLockStatusRequestToPutLockStatusRequestProfile>();
                cfg.AddProfile<CustomerProfileToGetCustomerRequestProfile>();
                cfg.AddProfile<CustomerProfileToDeleteCustomerRequestProfile>();
                cfg.AddProfile<CustomerProfileToPutLockStatusRequestProfile>();
                cfg.AddProfile<CustomerProfileToPutAlertStatusRequestProfile>();
                cfg.AddProfile<PostActivateInstantAlertRequestToPutAlertStatusRequestProfiler>();
            });

            services.AddSingleton(mappingConfig);
            services.AddSingleton(mappingConfig.CreateMapper());

            return services;
        }
    }
}