﻿using System;
using EXPN.Models.CreditLockService.External.Delete.Request;
using EXPN.Models.CreditLockService.External.Put.Request;
using FluentValidation;

namespace EXPN.Validators.CreditLockService.Delete
{
    public class DeleteCustomerRequestValidator : AbstractValidator<DeleteCustomerRequest>
    {
        public DeleteCustomerRequestValidator(IValidator<DeleteEventBody> requestBodyValidator)
        {
            if (requestBodyValidator == null)
                throw new ArgumentNullException(nameof(requestBodyValidator));

            RuleFor(x => x)
                .NotNull()
                .WithName(nameof(DeleteCustomerRequest))
                .DependentRules(() =>
                {
                    RuleFor(instance => instance.CustomerId)
                        .Cascade(CascadeMode.StopOnFirstFailure)
                        .NotEmpty()
                        .Must(x => Guid.TryParse(x, out _))
                        .WithMessage("'CustomerId' is not in valid format");

                    RuleFor(instance => instance.Body)
                        .Cascade(CascadeMode.StopOnFirstFailure)
                        .SetValidator(requestBodyValidator);
                });
        }
    }
}