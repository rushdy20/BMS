﻿using EXPN.DataLayer.CreditLockService.Common.Exceptions;
using EXPN.DataLayer.CreditLockService.Paas.Constants;
using EXPN.DataLayer.CreditLockService.Paas.HttpClient;
using EXPN.Models.CreditLockService.External.OktaService;
using EXPN.Models.CreditLockService.Paas;
using FluentAssertions;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using NSubstitute;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Net.Mime;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace EXPN.UnitTest.CreditLockService.DataLayer.Paas.HttpClients
{
    public class OktaClientTests
    {
        private readonly HttpClient _httpClient;
        private readonly ILogger<OktaClient> _logger;
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly IMemoryCache _memoryCache;
        private readonly IOptions<OktaAuthCredentials> _oktaAuthCredentials;

        public OktaClientTests()
        {
            _httpClient = Substitute.For<HttpClient>();
            _logger = Substitute.For<ILogger<OktaClient>>();
            _memoryCache = Substitute.For<IMemoryCache>();
            _oktaAuthCredentials = Substitute.For<IOptions<OktaAuthCredentials>>();
            
            _oktaAuthCredentials.Value
                .Returns(new OktaAuthCredentials
                {
                    KeyName = "transactions",
                    ServiceEndpoint = "https://example.com/endpoint",
                    ClientId = "",
                    Endpoint = "https://example.com/endpoint",
                    GrantType = "",
                    Password = "",
                    Scope = "",
                    SharedSecret = "",
                    Username = ""
                });

            _httpClientFactory = Substitute.For<IHttpClientFactory>();
        }

        public class Constructor : OktaClientTests
        {
            public static IEnumerable<object[]> NullParameters()
            {
                yield return new object[]
                {
                    null,
                    Substitute.For<ILogger<OktaClient>>(),
                    Substitute.For<IOptions<OktaAuthCredentials>>(),
                    Substitute.For<IMemoryCache>(),
                    "httpClient"
                };

                yield return new object[]
                {
                    Substitute.For<HttpClient>(),
                    null,
                    Substitute.For<IOptions<OktaAuthCredentials>>(),
                    Substitute.For<IMemoryCache>(),
                    "logger"
                };

                yield return new object[]
                {
                    Substitute.For<HttpClient>(),
                    Substitute.For<ILogger<OktaClient>>(),
                    null,
                    Substitute.For<IMemoryCache>(),
                    "oktaAuthCredentials"
                };

                yield return new object[]
                {
                    Substitute.For<HttpClient>(),
                    Substitute.For<ILogger<OktaClient>>(),
                    Substitute.For<IOptions<OktaAuthCredentials>>(),
                    null,
                    "memoryCache"
                };
            }

            [Theory]
            [MemberData(nameof(NullParameters))]
            public void NullRequiredConstructorParameter_ThrowsArgumentNullException(HttpClient httpClient,
                ILogger<OktaClient> logger,
                IOptions<OktaAuthCredentials> oktaAuthCredentials,
                IMemoryCache memoryCache,
                string expectedErrorParameter
            )
            {
                oktaAuthCredentials?.Value
                    .Returns(new OktaAuthCredentials());

                Action action = () =>
                {
                    var unused = new OktaClient(httpClient, logger, oktaAuthCredentials, memoryCache);
                };

                action.Should().Throw<ArgumentNullException>()
                    .Where(x => x.ParamName == expectedErrorParameter);
            }

            [Fact]
            public void NullRequiredOktaAuthCredentialsValueInConstructor_ThrowsArgumentException()
            {
                _oktaAuthCredentials.Value
                    .Returns(x => null);

                Action action = () =>
                {
                    var unused = new OktaClient(_httpClient, _logger, _oktaAuthCredentials, _memoryCache);
                };

                action.Should()
                    .Throw<ArgumentException>()
                    .WithMessage("Value cannot be null (Parameter 'oktaAuthCredentials')");
            }
        }

        public class GetAuthTokenAsync : OktaClientTests
        {
            [Fact]
            public async Task GetAuthTokenAsync_ReadyFrom_Memory()
            {
                var oktaClient = new OktaClient(_httpClient, _logger, _oktaAuthCredentials, _memoryCache);

                _memoryCache.TryGetValue(Arg.Any<string>(), out _)
                    .Returns(info =>
                    {
                        info[1] = "tokenAuth";
                        return true;
                    });

                var token = await oktaClient.GetAuthTokenAsync();

                token.Should().BeEquivalentTo("tokenAuth");

                _memoryCache.DidNotReceive().Remove(Arg.Any<string>());
                _memoryCache.Received(1).TryGetValue("PaasOktaToken", out _);
                _memoryCache.DidNotReceive().Set(Arg.Any<object>(), Arg.Any<string>(), Arg.Any<DateTimeOffset>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.OktaClient.GetAuthTokenAsync.RemoveOktaTokenFromMemoryCache)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.OktaClient.GetAuthTokenAsync.AuthRequestSuccess)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.OktaClient.GetAuthTokenAsync.AddOktaTokenToMemoryCache)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.OktaClient.GetAuthTokenAsync.RetrievedOktaTokenFromMemoryCache)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.OktaClient.GetAuthTokenAsync.AuthRequestFail)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.OktaClient.GetAuthTokenAsync.FailedToStoreOktaTokenInMemoryCache)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task GetAuthTokenAsync_ResponseSuccess_ImmediateExpire()
            {
                var oktaAuthTokenResponse = new OktaAuthTokenResponse
                {
                    AccessToken = "Token",
                    ExpiresIn = 0
                };

                var httpResponseMessage = new HttpResponseMessage
                {
                    StatusCode = HttpStatusCode.OK,
                    Content = new StringContent(JsonConvert.SerializeObject(oktaAuthTokenResponse), Encoding.UTF8, MediaTypeNames.Application.Json)
                };

                var fakeHttpMessageHandler = new FakeHttpMessageHandler(httpResponseMessage);
                var fakeHttpClient = new HttpClient(fakeHttpMessageHandler);

                _httpClientFactory.CreateClient()
                    .Returns(fakeHttpClient);

                var oktaClient = new OktaClient(_httpClientFactory.CreateClient(), _logger, _oktaAuthCredentials, _memoryCache);

                var token = await oktaClient.GetAuthTokenAsync();

                token.Should().BeEquivalentTo("Token");

                _memoryCache.DidNotReceive().Remove(Arg.Any<string>());
                _memoryCache.Received(1).TryGetValue("PaasOktaToken", out _);
                _memoryCache.DidNotReceive().Set(Arg.Any<object>(), Arg.Any<string>(), Arg.Any<DateTimeOffset>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.OktaClient.GetAuthTokenAsync.AuthRequestSuccess)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.OktaClient.GetAuthTokenAsync.RemoveOktaTokenFromMemoryCache)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.OktaClient.GetAuthTokenAsync.AddOktaTokenToMemoryCache)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.OktaClient.GetAuthTokenAsync.RetrievedOktaTokenFromMemoryCache)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.OktaClient.GetAuthTokenAsync.AuthRequestFail)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.OktaClient.GetAuthTokenAsync.FailedToStoreOktaTokenInMemoryCache)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task GetAuthTokenAsync_ResponseSuccess_SetTokenInMemory()
            {
                var oktaAuthTokenResponse = new OktaAuthTokenResponse
                {
                    AccessToken = "Token",
                    ExpiresIn = 1
                };

                var httpResponseMessage = new HttpResponseMessage
                {
                    StatusCode = HttpStatusCode.OK,
                    Content = new StringContent(JsonConvert.SerializeObject(oktaAuthTokenResponse), Encoding.UTF8, MediaTypeNames.Application.Json)
                };

                var fakeHttpMessageHandler = new FakeHttpMessageHandler(httpResponseMessage);
                var fakeHttpClient = new HttpClient(fakeHttpMessageHandler);

                _httpClientFactory.CreateClient()
                    .Returns(fakeHttpClient);

                var oktaClient = new OktaClient(_httpClientFactory.CreateClient(), _logger, _oktaAuthCredentials, _memoryCache);

                var token = await oktaClient.GetAuthTokenAsync();

                token.Should().BeEquivalentTo("Token");

                _memoryCache.DidNotReceive().Remove(Arg.Any<string>());
                _memoryCache.Received(1).TryGetValue("PaasOktaToken", out _);
                _memoryCache.Received(1).Set("PaasOktaToken", "Token", DateTimeOffset.UtcNow.AddSeconds(0.9));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.OktaClient.GetAuthTokenAsync.AuthRequestSuccess)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.OktaClient.GetAuthTokenAsync.AddOktaTokenToMemoryCache)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.OktaClient.GetAuthTokenAsync.RemoveOktaTokenFromMemoryCache)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.OktaClient.GetAuthTokenAsync.RetrievedOktaTokenFromMemoryCache)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.OktaClient.GetAuthTokenAsync.AuthRequestFail)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.OktaClient.GetAuthTokenAsync.FailedToStoreOktaTokenInMemoryCache)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task GetAuthTokenAsync_ResponseSuccess_RefreshToken()
            {
                var oktaAuthTokenResponse = new OktaAuthTokenResponse
                {
                    AccessToken = "Token",
                    ExpiresIn = 1
                };

                var httpResponseMessage = new HttpResponseMessage
                {
                    StatusCode = HttpStatusCode.OK,
                    Content = new StringContent(JsonConvert.SerializeObject(oktaAuthTokenResponse), Encoding.UTF8, MediaTypeNames.Application.Json)
                };

                var fakeHttpMessageHandler = new FakeHttpMessageHandler(httpResponseMessage);
                var fakeHttpClient = new HttpClient(fakeHttpMessageHandler);

                _httpClientFactory.CreateClient()
                    .Returns(fakeHttpClient);

                var oktaClient = new OktaClient(_httpClientFactory.CreateClient(), _logger, _oktaAuthCredentials, _memoryCache);

                var token = await oktaClient.GetAuthTokenAsync(true);

                token.Should().BeEquivalentTo("Token");

                _memoryCache.Received(1).Remove("PaasOktaToken");
                _memoryCache.Received(1).TryGetValue("PaasOktaToken", out _);
                _memoryCache.Received(1).Set("PaasOktaToken", "Token", DateTimeOffset.UtcNow.AddSeconds(0.9));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.OktaClient.GetAuthTokenAsync.AuthRequestSuccess)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.OktaClient.GetAuthTokenAsync.AddOktaTokenToMemoryCache)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.OktaClient.GetAuthTokenAsync.RemoveOktaTokenFromMemoryCache)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.OktaClient.GetAuthTokenAsync.RetrievedOktaTokenFromMemoryCache)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.OktaClient.GetAuthTokenAsync.AuthRequestFail)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.OktaClient.GetAuthTokenAsync.FailedToStoreOktaTokenInMemoryCache)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public void GetAuthTokenAsync_OktaEndPointNull_ThrowsException()
            {
                _oktaAuthCredentials.Value.Returns(new OktaAuthCredentials
                {
                    KeyName = "transactions",
                    ServiceEndpoint = "https://example.com/endpoint",
                    ClientId = "",
                    Endpoint = "",
                    GrantType = "",
                    Password = "",
                    Scope = "",
                    SharedSecret = "",
                    Username = ""
                });

                var oktaAuthTokenResponse = new OktaAuthTokenResponse
                {
                    AccessToken = "Token",
                    ExpiresIn = 1
                };

                var httpResponseMessage = new HttpResponseMessage
                {
                    StatusCode = HttpStatusCode.OK,
                    Content = new StringContent(JsonConvert.SerializeObject(oktaAuthTokenResponse), Encoding.UTF8,
                        MediaTypeNames.Application.Json)
                };

                var fakeHttpMessageHandler = new FakeHttpMessageHandler(httpResponseMessage);
                var fakeHttpClient = new HttpClient(fakeHttpMessageHandler);

                _httpClientFactory.CreateClient()
                    .Returns(fakeHttpClient);

                var oktaClient = new OktaClient(_httpClientFactory.CreateClient(), _logger, _oktaAuthCredentials, _memoryCache);

                Func<Task> action = async () => await oktaClient.GetAuthTokenAsync();

                action.Should().Throw<OktaCredentialsEndpointNullException>();

                _memoryCache.DidNotReceive().Remove("PaasOktaToken");
                _memoryCache.Received(1).TryGetValue("PaasOktaToken", out _);
                _memoryCache.DidNotReceive().Set("PaasOktaToken", Arg.Any<string>(), Arg.Any<DateTimeOffset>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.OktaClient.GetAuthTokenAsync.RemoveOktaTokenFromMemoryCache)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.OktaClient.GetAuthTokenAsync.AuthRequestSuccess)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.OktaClient.GetAuthTokenAsync.AddOktaTokenToMemoryCache)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.OktaClient.GetAuthTokenAsync.RetrievedOktaTokenFromMemoryCache)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.OktaClient.GetAuthTokenAsync.AuthRequestFail)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.OktaClient.GetAuthTokenAsync.FailedToStoreOktaTokenInMemoryCache)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public void GetAuthTokenAsync_ServiceEndPointNull_ThrowsException()
            {
                _oktaAuthCredentials.Value.Returns(new OktaAuthCredentials
                {
                    KeyName = "transactions",
                    ServiceEndpoint = "",
                    ClientId = "",
                    Endpoint = "",
                    GrantType = "",
                    Password = "",
                    Scope = "",
                    SharedSecret = "",
                    Username = ""
                });

                var oktaAuthTokenResponse = new OktaAuthTokenResponse
                {
                    AccessToken = "Token",
                    ExpiresIn = 1
                };

                var httpResponseMessage = new HttpResponseMessage
                {
                    StatusCode = HttpStatusCode.OK,
                    Content = new StringContent(JsonConvert.SerializeObject(oktaAuthTokenResponse), Encoding.UTF8, MediaTypeNames.Application.Json)
                };

                var fakeHttpMessageHandler = new FakeHttpMessageHandler(httpResponseMessage);
                var fakeHttpClient = new HttpClient(fakeHttpMessageHandler);

                _httpClientFactory.CreateClient()
                    .Returns(fakeHttpClient);

                var oktaClient = new OktaClient(_httpClientFactory.CreateClient(), _logger, _oktaAuthCredentials, _memoryCache);

                Func<Task> action = async () => await oktaClient.GetAuthTokenAsync();

                action.Should()
                    .Throw<OktaCredentialsEndpointNullException>();

                _memoryCache.DidNotReceive().Remove("PaasOktaToken");
                _memoryCache.Received(1).TryGetValue("PaasOktaToken", out _);
                _memoryCache.DidNotReceive().Set("PaasOktaToken", Arg.Any<string>(), Arg.Any<DateTimeOffset>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.OktaClient.GetAuthTokenAsync.RemoveOktaTokenFromMemoryCache)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.OktaClient.GetAuthTokenAsync.AuthRequestSuccess)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.OktaClient.GetAuthTokenAsync.AddOktaTokenToMemoryCache)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.OktaClient.GetAuthTokenAsync.RetrievedOktaTokenFromMemoryCache)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.OktaClient.GetAuthTokenAsync.AuthRequestFail)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.OktaClient.GetAuthTokenAsync.FailedToStoreOktaTokenInMemoryCache)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public void GetAuthTokenAsync_OktaResponseNotOK_ThrowsException()
            {
                _oktaAuthCredentials.Value.Returns(new OktaAuthCredentials
                {
                    KeyName = "transactions",
                    ServiceEndpoint = "https://example.com/endpoint",
                    ClientId = "",
                    Endpoint = "https://example.com/endpoint",
                    GrantType = "",
                    Password = "",
                    Scope = "",
                    SharedSecret = "",
                    Username = ""
                });

                var oktaErrorResponse = new OktaErrorResponse
                {
                    Error = "Error",
                    ErrorDescription = "error description "
                };

                var httpResponseMessage = new HttpResponseMessage
                {
                    StatusCode = HttpStatusCode.BadRequest,
                    Content = new StringContent(JsonConvert.SerializeObject(oktaErrorResponse), Encoding.UTF8, MediaTypeNames.Application.Json)
                };

                var fakeHttpMessageHandler = new FakeHttpMessageHandler(httpResponseMessage);
                var fakeHttpClient = new HttpClient(fakeHttpMessageHandler);

                _httpClientFactory.CreateClient()
                    .Returns(fakeHttpClient);

                var oktaClient = new OktaClient(_httpClientFactory.CreateClient(), _logger, _oktaAuthCredentials, _memoryCache);

                Func<Task> action = async () => await oktaClient.GetAuthTokenAsync();

                action.Should()
                    .Throw<OktaException>()
                    .WithMessage("Response does not indicate success - Status Code: 400");

                _memoryCache.DidNotReceive().Remove("PaasOktaToken");
                _memoryCache.Received(1).TryGetValue("PaasOktaToken", out _);
                _memoryCache.DidNotReceive().Set("PaasOktaToken", Arg.Any<string>(), Arg.Any<DateTimeOffset>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.OktaClient.GetAuthTokenAsync.RemoveOktaTokenFromMemoryCache)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.OktaClient.GetAuthTokenAsync.AuthRequestSuccess)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.OktaClient.GetAuthTokenAsync.AddOktaTokenToMemoryCache)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.OktaClient.GetAuthTokenAsync.RetrievedOktaTokenFromMemoryCache)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.OktaClient.GetAuthTokenAsync.AuthRequestFail)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.OktaClient.GetAuthTokenAsync.FailedToStoreOktaTokenInMemoryCache)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task GetAuthTokenAsync_ResponseSuccess_RefreshTokenFailsToSet()
            {
                var oktaAuthTokenResponse = new OktaAuthTokenResponse
                {
                    AccessToken = "Token",
                    ExpiresIn = 1
                };

                var httpResponseMessage = new HttpResponseMessage
                {
                    StatusCode = HttpStatusCode.OK,
                    Content = new StringContent(JsonConvert.SerializeObject(oktaAuthTokenResponse), Encoding.UTF8, MediaTypeNames.Application.Json)
                };

                var fakeHttpMessageHandler = new FakeHttpMessageHandler(httpResponseMessage);
                var fakeHttpClient = new HttpClient(fakeHttpMessageHandler);

                _httpClientFactory.CreateClient()
                    .Returns(fakeHttpClient);

                _memoryCache
                    .When(x => x.CreateEntry("PaasOktaToken"))
                    .Do(x => throw new InvalidOperationException());

                var oktaClient = new OktaClient(_httpClientFactory.CreateClient(), _logger, _oktaAuthCredentials, _memoryCache);

                var token = await oktaClient.GetAuthTokenAsync(true);

                token.Should().BeEquivalentTo("Token");

                _memoryCache.Received(1).Remove("PaasOktaToken");
                _memoryCache.Received(1).TryGetValue("PaasOktaToken", out _);
                _memoryCache.Received(1).Set("PaasOktaToken", "Token", DateTimeOffset.UtcNow.AddSeconds(0.9));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.OktaClient.GetAuthTokenAsync.RemoveOktaTokenFromMemoryCache)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.OktaClient.GetAuthTokenAsync.AuthRequestSuccess)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.OktaClient.GetAuthTokenAsync.AddOktaTokenToMemoryCache)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.OktaClient.GetAuthTokenAsync.RetrievedOktaTokenFromMemoryCache)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.OktaClient.GetAuthTokenAsync.AuthRequestFail)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.OktaClient.GetAuthTokenAsync.FailedToStoreOktaTokenInMemoryCache)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }
        }
    }
}