﻿using EXPN.Models.CreditLockService.Paas;
using Microsoft.Extensions.Options;

namespace EXPN.IntegrationTest.CreditLockService.Utility
{
    public class TestOktaAuthCredential : IOptions<OktaAuthCredentials>
    {
        public OktaAuthCredentials Value =>
            new OktaAuthCredentials
            {
                ClientId = "testclientid",
                Endpoint = "http://testendpoint.com",
                SharedSecret = "Secret",
                ServiceEndpoint = "http://testendpoint.com"
            };
    }
}