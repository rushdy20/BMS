﻿using System.Threading.Tasks;
using EXPN.Models.CreditLockService.Paas.Get.Request;
using EXPN.Models.CreditLockService.Paas.Get.Response;
using EXPN.Models.CreditLockService.Paas.Post.Request;
using EXPN.Models.CreditLockService.Paas.Put.Request;
using EXPN.Models.CreditLockService.Paas.PutLockStatus.Request;
using EXPN.Models.CreditLockService.Paas.Delete.Request;
using EXPN.Models.CreditLockService.Paas.PutAlertStatus.Request;

namespace EXPN.DataLayer.CreditLockService.Paas.HttpClient
{
    public interface ICreditLockPaasClient
    {
        Task<GetCustomerResponse> GetPaasCustomerAsync(GetCustomerRequest getCustomerRequest);
        Task Post(PostCustomerRequest postCustomerRequest);
        Task Put(PutCustomerRequest putCustomerRequest);
        Task Delete(DeleteCustomerRequest deleteCustomerRequest);
        Task PutLockStatus(PutLockStatusRequest putLockStatusRequest);
        Task PutAlertStatus(PutAlertStatusRequest putAlertStatusRequest);
    }
}