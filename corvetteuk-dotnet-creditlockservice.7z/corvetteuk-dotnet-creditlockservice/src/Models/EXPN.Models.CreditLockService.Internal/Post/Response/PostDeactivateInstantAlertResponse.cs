﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EXPN.Models.CreditLockService.Internal.Post.Response
{
 public   class PostDeactivateInstantAlertResponse
    {
        public string LockStatus { get; set; }
    }
}
