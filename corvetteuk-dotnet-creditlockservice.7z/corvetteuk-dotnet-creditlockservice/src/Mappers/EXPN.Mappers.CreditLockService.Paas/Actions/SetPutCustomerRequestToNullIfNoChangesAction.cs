﻿using AutoMapper;
using EXPN.Models.CreditLockService.Internal.Get.Response;
using EXPN.Models.CreditLockService.Paas.Put.Request;
using System.Linq;

namespace EXPN.Mappers.CreditLockService.Paas.Actions
{
    public class SetPutCustomerRequestToNullIfNoChangesAction : IMappingAction<GetCustomerResponse, PutCustomerRequest>
    {
        public void Process(GetCustomerResponse source, PutCustomerRequest destination)
        {
            var isNameNotNull = !(destination.Name is null) && destination.Name.GetType().GetProperties().Any(p => p.GetValue(destination.Name) != null);

            if (!(destination.AddressesToAdd is null) && destination.AddressesToAdd.Any() ||
                !(destination.AddressesToDelete is null) && destination.AddressesToDelete.Any() ||
                isNameNotNull || !(destination.Dob is null))
                return;

            destination.ClientId = null;
            destination.CustomerId = null;
            destination.AddressesToAdd = null;
            destination.AddressesToDelete = null;
            destination.Dob = null;
            destination.Name = null;
        }
    }
}