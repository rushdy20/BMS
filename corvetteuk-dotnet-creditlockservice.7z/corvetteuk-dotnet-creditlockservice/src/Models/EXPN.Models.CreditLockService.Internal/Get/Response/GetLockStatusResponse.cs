﻿namespace EXPN.Models.CreditLockService.Internal.Get.Response
{
    public class GetLockStatusResponse
    {
        public string LockStatus {  get; set; }
    }
}