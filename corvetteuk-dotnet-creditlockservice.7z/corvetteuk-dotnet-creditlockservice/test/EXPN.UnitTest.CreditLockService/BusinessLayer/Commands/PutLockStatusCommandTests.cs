﻿using AutoMapper;
using EXPN.BusinessLayer.CreditLockService.Commands;
using EXPN.BusinessLayer.CreditLockService.Constants;
using EXPN.DataLayer.CreditLockService.Paas.HttpClient;
using EXPN.Models.CreditLockService.Internal.Get.Response;
using EXPN.Models.CreditLockService.Internal.Put.Request;
using EXPN.Models.CreditLockService.Internal.Put.Response;
using FluentAssertions;
using Microsoft.Extensions.Logging;
using NSubstitute;
using NSubstitute.ExceptionExtensions;
using System;
using System.Collections.Generic;
using Xunit;
using PaaSRequest = EXPN.Models.CreditLockService.Paas.PutLockStatus.Request;

namespace EXPN.UnitTest.CreditLockService.BusinessLayer.Commands
{
    public class PutLockStatusCommandTests
    {
        private readonly ICreditLockPaasClient _creditLockPaaSClient;
        private readonly ILogger<PutLockStatusCommand<PutLockStatusRequest, PutLockStatusResponse>> _logger;
        private readonly IMapper _mapper;

        private readonly ICommand<PutLockStatusRequest, PutLockStatusResponse> _putLockStatusCommand;

        public PutLockStatusCommandTests()
        {
            _creditLockPaaSClient = Substitute.For<ICreditLockPaasClient>();
            _logger = Substitute.For<ILogger<PutLockStatusCommand<PutLockStatusRequest, PutLockStatusResponse>>>();
            _mapper = Substitute.For<IMapper>();

            _putLockStatusCommand = new PutLockStatusCommand<PutLockStatusRequest, PutLockStatusResponse>(_creditLockPaaSClient, _logger, _mapper);
        }

        public class Constructor
        {
            public static IEnumerable<object[]> NullParameters()
            {
                yield return new object[]
                {
                    null,
                    Substitute.For<ILogger<PutLockStatusCommand<PutLockStatusRequest, PutLockStatusResponse>>>(),
                    Substitute.For<IMapper>(),
                    "creditLockPaasClient"
                };

                yield return new object[]
                {
                    Substitute.For<ICreditLockPaasClient>(),
                    null,
                    Substitute.For<IMapper>(),
                    "logger"
                };

                yield return new object[]
                {
                    Substitute.For<ICreditLockPaasClient>(),
                    Substitute.For<ILogger<PutLockStatusCommand<PutLockStatusRequest, PutLockStatusResponse>>>(),
                    null,
                    "mapper"
                };
            }

            [Theory]
            [MemberData(nameof(NullParameters))]
            public void NullRequiredConstructorParameter_ThrowsArgumentNullException(
                ICreditLockPaasClient paasHttpClient,
                ILogger<PutLockStatusCommand<PutLockStatusRequest, PutLockStatusResponse>> logger,
                IMapper mapper,
                string expectedErrorParameter)
            {
                Action action = () => 
                {
                    new PutLockStatusCommand<PutLockStatusRequest, PutLockStatusResponse>(paasHttpClient, logger, mapper);
                };

                action.Should().Throw<ArgumentNullException>()
                    .Where(x => x.ParamName == expectedErrorParameter);
            }

            [Fact]
            public void Id_IsCorrect()
            {
                new PutLockStatusCommand<PutLockStatusRequest, PutLockStatusResponse>(
                    Substitute.For<ICreditLockPaasClient>(),
                    Substitute.For<ILogger<PutLockStatusCommand<PutLockStatusRequest, PutLockStatusResponse>>>(),
                    Substitute.For<IMapper>()).Id.Should().Be("LOCK-PUT");
            }
        }

        public class Execute : PutLockStatusCommandTests
        {
            public static IEnumerable<object[]> LogInformationMessages()
            {
                yield return new object[]
                {
                    LogEventNames.PutLockStatusCommand.Execute.Enter
                };

                yield return new object[]
                {
                    LogEventNames.PutLockStatusCommand.Execute.Exit
                };
            }

            [Theory]
            [MemberData(nameof(LogInformationMessages))]
            public void HappyPathInformationLogged(string loggerMessage)
            {
                const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

                var getResponseCustomerProfile = new GetResponseCustomerProfile
                {
                    CustomerId = customerId
                };

                var paasPutLockStatusRequest = new PaaSRequest.PutLockStatusRequest
                {
                    CustomerRef = "ABC",
                    Status = "Y"
                };

                var putLockStatusRequest = new PutLockStatusRequest
                {
                    CustomerId = customerId,
                    LockStatus = true
                };
                
                _mapper.Map<PaaSRequest.PutLockStatusRequest>(putLockStatusRequest)
                    .Returns(paasPutLockStatusRequest);

                _putLockStatusCommand.Execute(putLockStatusRequest, getResponseCustomerProfile);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(loggerMessage)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public void ExecutePutLockStatusRequestNull_ThrowsArgumentNullException()
            {
                Action action = () =>
                {
                    _putLockStatusCommand.Execute(null, null);
                };

                action.Should().Throw<ArgumentNullException>()
                    .Where(x => x.ParamName == "request");
            }

            [Fact]
            public void ExecutePutLockStatusCustomerProfileNull_ThrowsArgumentNullException()
            {
                Action action = () =>
                {
                    _putLockStatusCommand.Execute(new PutLockStatusRequest(), null);
                };

                action.Should().Throw<ArgumentNullException>()
                    .Where(x => x.ParamName == "customerProfile");
            }

            [Theory]
            [InlineData(null)]
            [InlineData("")]
            [InlineData("     ")]
            public void ExecutePutLockRequestInvalidCustomerId_ThrowsArgumentException(string customerId)
            {
                var putLockStatusRequest = new PutLockStatusRequest
                {
                    CustomerId = customerId
                };

                Action action = () =>
                {
                    _putLockStatusCommand.Execute(putLockStatusRequest, new GetResponseCustomerProfile());
                };

                action.Should().Throw<ArgumentException>()
                    .Where(x => x.Message == "CustomerId cannot be null or whitespace (Parameter 'request')");
            }

            [Fact]
            public void ValidRequest_Execute_HappyPath_Success()
            {
                const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

                var getResponseCustomerProfile = new GetResponseCustomerProfile
                {
                    CustomerId = customerId
                };

                var paasPutLockStatusRequest = new PaaSRequest.PutLockStatusRequest
                {
                    CustomerRef = "ABC",
                    Status = "Y"
                };

                var putLockStatusRequest = new PutLockStatusRequest
                {
                    CustomerId = customerId,
                    LockStatus = true
                };

                _mapper.Map<PaaSRequest.PutLockStatusRequest>(putLockStatusRequest)
                    .Returns(paasPutLockStatusRequest);

                var response = _putLockStatusCommand.Execute(putLockStatusRequest, getResponseCustomerProfile);

                response.LockStatus.Should().Be(paasPutLockStatusRequest.Status);

                _mapper.Received(1).Map<PaaSRequest.PutLockStatusRequest>(putLockStatusRequest);
                
                _creditLockPaaSClient.Received(1).PutLockStatus(paasPutLockStatusRequest);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.PutLockStatusCommand.Execute.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.PutLockStatusCommand.Execute.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public void ValidRequest_Execute_ClientThrowsOutofMemoryException_Fails()
            {
                const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

                var expectedEx = new OutOfMemoryException("Test Exception Message");

                var getResponseCustomerProfile = new GetResponseCustomerProfile
                {
                    CustomerId = customerId
                };

                var paaSPutLockStatusRequest = new PaaSRequest.PutLockStatusRequest
                {
                    CustomerRef = "ABC",
                    Status = "Y"
                };

                var putLockStatusRequest = new PutLockStatusRequest
                {
                    CustomerId = customerId,
                    LockStatus = true
                };

                _mapper.Map<PaaSRequest.PutLockStatusRequest>(putLockStatusRequest)
                    .Returns(paaSPutLockStatusRequest);

                _creditLockPaaSClient.PutLockStatus(paaSPutLockStatusRequest)
                    .Throws(expectedEx);

                Action action = () =>
                {
                    _putLockStatusCommand.Execute(putLockStatusRequest, getResponseCustomerProfile);
                };

                action.Should().Throw<OutOfMemoryException>()
                    .Where(x => x.Message == expectedEx.Message);

                _mapper.Received(1).Map<PaaSRequest.PutLockStatusRequest>(putLockStatusRequest);

                _creditLockPaaSClient.Received(1).PutLockStatus(paaSPutLockStatusRequest);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.PutLockStatusCommand.Execute.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.PutLockStatusCommand.Execute.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }
        }
    }
}