﻿using System.Diagnostics.CodeAnalysis;
using Microsoft.AspNetCore.Mvc;

namespace EXPN.Models.CreditLockService.External.Delete.Request
{
    [ExcludeFromCodeCoverage]
    public  class DeleteCustomerRequest
    {
        [FromHeader(Name = "x-customerId")]
        public string CustomerId { get; set; }

        [FromBody]
        public DeleteEventBody Body  { get;set;  }
    }
}
