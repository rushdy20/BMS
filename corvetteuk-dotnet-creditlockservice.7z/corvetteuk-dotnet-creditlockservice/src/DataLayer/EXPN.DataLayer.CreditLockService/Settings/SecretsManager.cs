﻿using Amazon.SecretsManager;
using Amazon.SecretsManager.Model;
using Experian.AWS.Config;
using Experian.AWS.HostInformation;
using Newtonsoft.Json;
using System;
using System.Threading.Tasks;

namespace EXPN.DataLayer.CreditLockService.Paas.Settings
{
    public class SecretsManager : ISecretsManager
    {
        private readonly IAmazonSecretsManager _secretsManager;
        private readonly IHostInformation _hostInformation;
        private readonly IServiceConfig _serviceConfig;

        private const string Environment = "Environment";

        public SecretsManager(IAmazonSecretsManager secretsManager,
            IHostInformation hostInformation, IServiceConfig serviceConfig)
        {
            _secretsManager = secretsManager ?? throw new ArgumentNullException(nameof(secretsManager));
            _hostInformation = hostInformation ?? throw new ArgumentNullException(nameof(hostInformation));
            _serviceConfig = serviceConfig ?? throw new ArgumentNullException(nameof(serviceConfig));
        }

        public async Task<T> GetSecretAsync<T>(string key)
        {
            return JsonConvert.DeserializeObject<T>(await GetSecretAsync(key));
        }

        public async Task<string> GetSecretAsync(string key)
        {
            var getSecretValueRequest = new GetSecretValueRequest
            {
                SecretId = $"{_hostInformation.GetHostTags()[Environment]}/{_serviceConfig.ServiceName}/{key}"
            };

            var response = await _secretsManager.GetSecretValueAsync(getSecretValueRequest);

            if (string.IsNullOrWhiteSpace(response?.SecretString))
            {
                throw new InvalidOperationException($"Unable to retrieve key: {key}");
            }

            return response.SecretString;
        }
    }
}