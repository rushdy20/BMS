using Amazon.SecretsManager;
using Amazon.SimpleNotificationService;
using Experian.AWS.Config;
using Experian.AWS.Config.NetworkConfig;
using Experian.AWS.Cryptography;
using Experian.AWS.Cryptography.KeyBroker;
using Experian.AWS.HostInformation;
using Experian.AWS.HostInformation.EnvVar;
using Experian.AWS.HostInformation.Fargate;
using Experian.Events.MessageBuilder.Helios;
using Experian.Http.Middleware.RequestHeaders;
using Experian.HttpClient.Services.Customers;
using EXPN.Controllers.CreditLockService;
using EXPN.DataLayer.CreditLockService.Paas;
using FluentValidation.AspNetCore;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.OpenApi.Models;
using System;
using System.Diagnostics.CodeAnalysis;

namespace EXPN.ServiceHost.CreditLockService
{
    [ExcludeFromCodeCoverage]
    public class Startup
    {
        protected readonly IConfigurationRoot Configuration;

        public Startup(IWebHostEnvironment env)
        {
            Configuration = new ConfigurationBuilder()
                .SetBasePath(env.ContentRootPath)
                .AddJsonFile("appsettings.json", false, reloadOnChange: true)
                .AddJsonFile($"appsettings.{env.EnvironmentName}.json", true)
                .AddEnvironmentVariables()
                .Build();
        }

        // This method gets called by a runtime.
        // Use this method to add services to the container
        public void ConfigureServices(IServiceCollection services)
        {
            var configResult = Configuration.GetValue("Environment", string.Empty).Equals("local", StringComparison.OrdinalIgnoreCase) ?
                GetNetworkConfigProvider<EnvVarHostInformation>(services).GetConfig() :
                GetNetworkConfigProvider<FargateHostInformation>(services).GetConfig();

            services.AddSingleton<ILoggingConfig>(configResult);
            services.AddSingleton<IServiceConfig>(configResult);
            services.AddSingleton<ITopicConfig>(configResult);
            services.AddSingleton<IConfiguration>(Configuration);
            services.AddSingleton<ICryptographyConfig>(configResult);
            services.AddSingleton(configResult);
            services.AddSingleton(GetAmazonSecretsManagerSettings);
            services.AddSingleton(GetAmazonSnsSettings);

            services.AddSingleton<ICryptographyProvider, KeyBrokerCryptographyProvider>();
            services.AddSingleton(HeliosMessageBuilder.FactoryMethod);
            services.ConfigureOptions<CredentialsConfiguration>();

            services.AddControllers()
                .AddApplicationPart(typeof(InternalCreditLockController).Assembly)
                .AddNewtonsoftJson()
                .AddFluentValidation();

            services.Configure<ApiBehaviorOptions>(options =>
            {
                options.SuppressConsumesConstraintForFormFileParameters = true;
                options.SuppressInferBindingSourcesForParameters = true;
                options.SuppressModelStateInvalidFilter = true;
            });

            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v3.0.0", new OpenApiInfo { Title = "CreditLock Service", Description = "A RESTful API.", Version = "3.0.0" });
            });
            services.AddSwaggerGenNewtonsoftSupport();

            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();

            services.AddHealthChecks();

            services.AddLoggingModule(Configuration);
            services.AddServiceHostModule();
            services.AddAutoMapper();
            services.AddCustomersClient();
            services.AddMemoryCache();
        }

        // Configure is called after ConfigureServices is called.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            app.UseRouting();
            app.UseCommonRequestHeaderSubstitution();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
                endpoints.MapHealthChecks("/internal/admin/ping");
            });
            app.UseSwagger();
            app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v3.0.0/swagger.json", "CreditLock Service - v3.0.0"));
        }

        private NetworkConfigProvider GetNetworkConfigProvider<T>(IServiceCollection services) where T : IHostInformation, new()
        {
            var host = new T();
            services.AddSingleton<IHostInformation>(host);
            return new NetworkConfigProvider(host);
        }

        private static IAmazonSecretsManager GetAmazonSecretsManagerSettings(IServiceProvider sp)
        {
            var serviceConfig = sp.GetRequiredService<IHostInformation>();

            var config = new AmazonSecretsManagerConfig
            {
                RegionEndpoint = serviceConfig.Region
            };

            return new AmazonSecretsManagerClient(config);
        }

        private static IAmazonSimpleNotificationService GetAmazonSnsSettings(IServiceProvider sp)
        {
            var serviceConfig = sp.GetRequiredService<IHostInformation>();

            var config = new AmazonSimpleNotificationServiceConfig
            {
                RegionEndpoint = serviceConfig.Region
            };

            return new AmazonSimpleNotificationServiceClient(config);
        }
    }
}