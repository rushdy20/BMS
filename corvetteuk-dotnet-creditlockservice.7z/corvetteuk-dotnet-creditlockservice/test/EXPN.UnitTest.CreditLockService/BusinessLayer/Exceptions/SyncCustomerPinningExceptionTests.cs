﻿using EXPN.BusinessLayer.CreditLockService.Binders;
using EXPN.BusinessLayer.CreditLockService.Exceptions;
using FluentAssertions;
using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using Xunit;

namespace EXPN.UnitTest.CreditLockService.BusinessLayer.Exceptions
{
    public class SyncCustomerPinningExceptionTests
    {
        [Fact]
        public void DefaultConstructor_CreatesException()
        {
            var exception = new SyncCustomerPinningException();

            exception.Message.Should().Be("Exception of type 'EXPN.BusinessLayer.CreditLockService.Exceptions.SyncCustomerPinningException' was thrown.");
        }

        public static IEnumerable<object[]> SingleParams()
        {
            yield return new object[]
            {
                string.Empty
            };

            yield return new object[]
            {
                "test message"
            };
        }

        [Theory]
        [MemberData(nameof(SingleParams))]
        public void SingleParamConstructor_CreatesException(string message)
        {
            var exception = new SyncCustomerPinningException(message);

            exception.Message.Should().Be(message);
        }

        public static IEnumerable<object[]> DoubleParams()
        {
            yield return new object[]
            {
                null,
                null,
                "Exception of type 'EXPN.BusinessLayer.CreditLockService.Exceptions.SyncCustomerPinningException' was thrown."
            };

            yield return new object[]
            {
                string.Empty,
                null,
                string.Empty
            };

            yield return new object[]
            {
                "test message",
                null,
                "test message"
            };

            yield return new object[]
            {
                "test message",
                new SyncCustomerPinningException("bad op"),
                "test message"
            };
        }

        [Theory]
        [MemberData(nameof(DoubleParams))]
        public void DoubleParamConstructor_CreatesException(string message, Exception innerException, string expectedMessage)
        {
            var exception = new SyncCustomerPinningException(message, innerException);

            exception.Message.Should().Be(expectedMessage);
            exception.InnerException.Should().BeEquivalentTo(innerException);
        }

        [Fact]
        public void Serialization_CreatesException()
        {
            const string expectedMsg = "Test";
            var ex = new SyncCustomerPinningException(expectedMsg);

            var formatter = new BinaryFormatter
            {
                Binder = new CreditLockBusinessExceptionBinder()
            };

            using (var s = new MemoryStream())
            {
                formatter.Serialize(s, ex);
                s.Position = 0;
                ex = formatter.Deserialize(s) as SyncCustomerPinningException;
            }

            ex?.Message.Should().Be(expectedMsg);
        }
    }

}