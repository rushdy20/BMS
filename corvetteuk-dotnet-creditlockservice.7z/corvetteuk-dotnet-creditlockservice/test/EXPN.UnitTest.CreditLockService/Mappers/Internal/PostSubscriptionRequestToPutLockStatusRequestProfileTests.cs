﻿using AutoMapper;
using EXPN.Mappers.CreditLockService.Internal;
using EXPN.Models.CreditLockService.Internal.Put.Request;
using FluentAssertions;
using System.Collections.Generic;
using EXPN.Models.CreditLockService.External.Post.Request;
using Xunit;

namespace EXPN.UnitTest.CreditLockService.Mappers.Internal
{
    public class PostSubscriptionRequestToPutLockStatusRequestProfileTests
    {
        private readonly MapperConfiguration _mapperConfiguration;

        public PostSubscriptionRequestToPutLockStatusRequestProfileTests()
        {
            _mapperConfiguration = new MapperConfiguration(
                cfg => { cfg.AddProfile<PostRequestToPutLockStatusRequestProfile>(); });
        }

        [Fact]
        public void ModelProfile_AssertConfiguration_IsValid()
        {
            _mapperConfiguration.AssertConfigurationIsValid();
        }

        public static IEnumerable<object[]> MappingData()
        {
            yield return new object[]
            {
                null,
                null
            };

            yield return new object[]
            {
                new PostRequest(),
                new PutLockStatusRequest()
            };

            yield return new object[]
            {
                new PostRequest
                {
                    CustomerId = "customerId"
                },
                new PutLockStatusRequest
                {
                    CustomerId = "customerId",
                    LockStatus = false
                }
            };
        }

        [Theory]
        [MemberData(nameof(MappingData))]
        public void ExternalModelProfile_ExampleInput_MapsCorrectly(PostRequest input, PutLockStatusRequest expected)
        {
            var mapper = _mapperConfiguration.CreateMapper();
            var result = mapper.Map<PutLockStatusRequest>(input);

            result.Should().BeEquivalentTo(expected);
        }
    }
}