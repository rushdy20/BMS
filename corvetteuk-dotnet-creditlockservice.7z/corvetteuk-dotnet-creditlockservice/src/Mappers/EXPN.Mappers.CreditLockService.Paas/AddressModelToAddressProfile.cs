﻿using AutoMapper;
using EXPN.Models.CreditLockService.Internal.Get.Response;
using EXPN.Models.CreditLockService.Paas;
using System;

namespace EXPN.Mappers.CreditLockService.Paas
{
    public class AddressModelToAddressProfile : Profile
    {
        private const string CurrentAddressIndicator = "C";
        public AddressModelToAddressProfile()
        {
            CreateMap<GetResponseCustomerAddressModel, Address>(MemberList.None)
                .ForMember(d => d.HouseName, m => m.MapFrom(s => s.HouseName))
                .ForMember(d => d.County, m => m.MapFrom(s => s.County))
                .ForMember(d => d.HouseNumber, m => m.MapFrom(s => s.HouseNumber))
                .ForMember(d => d.Street, m => m.MapFrom(s => s.Street))
                .ForMember(d => d.Town, m => m.MapFrom(s => s.City))
                .ForMember(d => d.Flat, m => m.MapFrom(s => s.Flat))
                .ForMember(d => d.Postcode, m => m.MapFrom(s => s.PostCode))
                .ForMember(d => d.District, m => m.MapFrom(s => s.District))
                .ForMember(d => d.IsCurrent, m => m.MapFrom(s => s.AddressType.Equals(CurrentAddressIndicator, StringComparison.OrdinalIgnoreCase)));
        }
    }
}