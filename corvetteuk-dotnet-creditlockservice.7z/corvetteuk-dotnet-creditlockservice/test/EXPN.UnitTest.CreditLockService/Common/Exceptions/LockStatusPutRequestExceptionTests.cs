﻿using EXPN.DataLayer.CreditLockService.Common.Exceptions;
using EXPN.UnitTest.CreditLockService.Common.Extension;
using FluentAssertions;
using System;
using System.Collections.Generic;
using Xunit;

namespace EXPN.UnitTest.CreditLockService.Common.Exceptions
{
    public class LockStatusPutRequestExceptionTests
    {
        [Fact]
        public void DefaultConstructor_CreatesException()
        {
            var exception = new LockStatusPutRequestException();

            exception.Message.Should().Be("Exception of type 'EXPN.DataLayer.CreditLockService.Common.Exceptions.LockStatusPutRequestException' was thrown.");
        }

        public static IEnumerable<object[]> SingleParams()
        {
            yield return new object[]
            {
                string.Empty
            };

            yield return new object[]
            {
                "test message"
            };
        }

        [Theory]
        [MemberData(nameof(SingleParams))]
        public void SingleParamConstructor_CreatesException(string message)
        {
            var exception = new LockStatusPutRequestException(message);

            exception.Message.Should().Be(message);
        }

        public static IEnumerable<object[]> DoubleParams()
        {
            yield return new object[]
            {
                null,
                null,
                "Exception of type 'EXPN.DataLayer.CreditLockService.Common.Exceptions.LockStatusPutRequestException' was thrown."
            };

            yield return new object[]
            {
                string.Empty,
                null,
                string.Empty
            };

            yield return new object[]
            {
                "test message",
                null,
                "test message"
            };

            yield return new object[]
            {
                "test message",
                new LockStatusPutRequestException("bad op"),
                "test message"
            };
        }

        [Theory]
        [MemberData(nameof(DoubleParams))]
        public void DoubleParamConstructor_CreatesException(string message, Exception innerException, string expectedMessage)
        {
            var exception = new LockStatusPutRequestException(message, innerException);

            exception.Message.Should().Be(expectedMessage);
            exception.InnerException.Should().BeEquivalentTo(innerException);
        }

        [Fact]
        public void Serialization_CreatesException()
        {
            const string expectedMsg = "Test";
            var ex = new LockStatusPutRequestException(expectedMsg);

            var actual = ex.SerializeAndDeserialize();

            actual.Should().BeEquivalentTo(ex);
        }
    }
}
