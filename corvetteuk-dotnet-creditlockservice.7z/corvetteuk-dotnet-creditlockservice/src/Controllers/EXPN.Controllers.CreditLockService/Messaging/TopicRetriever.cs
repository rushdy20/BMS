﻿using System;
using System.Linq;
using Experian.AWS.Config;

namespace EXPN.Controllers.CreditLockService.Messaging
{
    public class TopicRetriever : ITopicRetriever
    {
        private readonly ITopicConfig _topicConfig;

        public TopicRetriever(ITopicConfig topicConfig)
        {
            _topicConfig = topicConfig ?? throw new ArgumentNullException(nameof(topicConfig));
        }

        public string GetTopicPhysicalId(string logicalId)
        {
            return _topicConfig?.PublishedTopics?.FirstOrDefault(x => x.LogicalId == logicalId)?.PhysicalId;
        }
    }
}