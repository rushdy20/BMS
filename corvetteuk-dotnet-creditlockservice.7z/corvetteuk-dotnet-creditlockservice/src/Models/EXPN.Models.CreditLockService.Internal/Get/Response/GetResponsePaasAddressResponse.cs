﻿namespace EXPN.Models.CreditLockService.Internal.Get.Response
{
    public class GetResponsePaasAddressResponse
    {
        public string Flat { get; set; }
        public string HouseName { get; set; }
        public string HouseNumber { get; set; }
        public string Street { get; set; }
        public string Town { get; set; }
        public string County { get; set; }
        public string Postcode { get; set; }
        public string Din { get; set; }
        public string PinStatus { get; set; }
        public string PinErrorCode { get; set; }
        public string District { get; set; }  
        public bool IsCurrent { get; set; }
    }
}