﻿using AutoMapper;
using EXPN.Mappers.CreditLockService.Paas;
using FluentAssertions;
using System.Collections.Generic;
using Xunit;
using InternalModel = EXPN.Models.CreditLockService.Internal.Delete.Request;
using PaaSRequest = EXPN.Models.CreditLockService.Paas.Delete.Request;

namespace EXPN.UnitTest.CreditLockService.Mappers.Paas
{
    public class CustomerProfileToDeleteCustomerRequestProfileTests
    {
        private readonly MapperConfiguration _mapperConfiguration;

        public CustomerProfileToDeleteCustomerRequestProfileTests()
        {
            _mapperConfiguration = new MapperConfiguration(
                cfg => { cfg.AddProfile<CustomerProfileToDeleteCustomerRequestProfile>(); });
        }

        [Fact]
        public void ModelProfile_AssertConfiguration_IsValid()
        {
            _mapperConfiguration.AssertConfigurationIsValid();
        }

        public static IEnumerable<object[]> MappingData()
        {
            yield return new object[]
            {
                null,
                null
            };
            yield return new object[]
            {
                new InternalModel.DeleteCustomerRequest(),
                new PaaSRequest.DeleteCustomerRequest()
            };

            yield return new object[]
            {
                new InternalModel.DeleteCustomerRequest
                {
                    CustomerId = string.Empty
                },
                new PaaSRequest.DeleteCustomerRequest
                {
                    CustomerId = string.Empty,
                }
            };

            yield return new object[]
            {
                new InternalModel.DeleteCustomerRequest
                {
                    CustomerId = string.Empty.PadLeft(2)
                },
                new PaaSRequest.DeleteCustomerRequest
                {
                    CustomerId = string.Empty.PadLeft(2)
                }
            };

            yield return new object[]
            {
                new InternalModel.DeleteCustomerRequest
                {
                    CustomerId = "CustomerId"
                },
                new PaaSRequest.DeleteCustomerRequest
                {
                    CustomerId = "CustomerId",
                }
            };
        }

        [Theory]
        [MemberData(nameof(MappingData))]
        public void CustomerProfileToDeleteCustomerRequestProfile_ExampleInput_MapsCorrectly(InternalModel.DeleteCustomerRequest input, PaaSRequest.DeleteCustomerRequest expected)
        {
            var mapper = _mapperConfiguration.CreateMapper();
            var result = mapper.Map<PaaSRequest.DeleteCustomerRequest>(input);

            result.Should().BeEquivalentTo(expected);
        }
    }
}