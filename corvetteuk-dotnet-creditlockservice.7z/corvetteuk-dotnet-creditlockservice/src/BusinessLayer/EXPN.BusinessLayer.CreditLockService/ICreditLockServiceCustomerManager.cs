using EXPN.Models.CreditLockService.Internal;
using EXPN.Models.CreditLockService.Internal.Put.Request;
using System.Threading.Tasks;
using EXPN.BusinessLayer.CreditLockService.Constants;
using EXPN.Models.CreditLockService.Internal.Delete.Request;
using EXPN.Models.CreditLockService.Internal.Post.Request;
using InternalModel = EXPN.Models.CreditLockService.Internal;

namespace EXPN.BusinessLayer.CreditLockService
{
    public interface ICreditLockServiceCustomerManager
    {
        Task ActivateAsync(CustomerRequest customerRequest);
        Task<InternalModel.Get.Response.GetCustomerResponse> GetCustomerAsync(InternalModel.Get.Request.GetCustomerRequest getCustomerRequest);
        Task PutLockStatus(PutLockStatusRequest putLockStatusRequest);
        Task DeleteCustomer(DeleteCustomerRequest deleteCustomerRequest);
        Task DeactivateInstantAlert(PostDeactivateInstantAlertRequest postDeactivateInstantAlertRequest);
        Task UpdateCustomer(PutCustomerRequest putCustomerRequest);
        Task ActivateInstantAlert(PostActivateInstantAlertRequest postActivateInstantAlertRequest);
    }
}