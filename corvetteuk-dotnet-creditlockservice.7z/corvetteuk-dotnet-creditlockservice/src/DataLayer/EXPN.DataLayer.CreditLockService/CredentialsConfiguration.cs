﻿using System;
using AutoMapper;
using EXPN.Models.CreditLockService.Internal;
using EXPN.Models.CreditLockService.Paas;
using Microsoft.Extensions.Options;

namespace EXPN.DataLayer.CreditLockService.Paas
{
    public class CredentialsConfiguration : IConfigureOptions<OktaAuthCredentials>
    {
        private readonly ISecretsManager _secretsManager;
        private readonly IMapper _mapper;

        private const string Okta = "okta";

        public CredentialsConfiguration(ISecretsManager secretsManager, IMapper mapper)
        {
            _secretsManager = secretsManager ?? throw new ArgumentNullException(nameof(secretsManager));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        }

        public void Configure(OktaAuthCredentials options)
        {
            var response = _secretsManager.GetSecretAsync<SecretsManagerData>(Okta).Result;

            _mapper.Map(response, options);
        }
    }
}