using AutoMapper;
using Experian.ResponseModels;
using EXPN.BusinessLayer.CreditLockService;
using EXPN.BusinessLayer.CreditLockService.Exceptions;
using EXPN.Controllers.CreditLockService;
using EXPN.Controllers.CreditLockService.Constants;
using EXPN.Controllers.CreditLockService.DateTime;
using EXPN.Controllers.CreditLockService.Messaging;
using EXPN.DataLayer.CreditLockService.Common.Exceptions;
using EXPN.Models.CreditLockService.External.Get.Customer.Request;
using EXPN.Models.CreditLockService.External.Put.Request;
using EXPN.Models.CreditLockService.Internal.Get.Request;
using EXPN.Models.CreditLockService.Internal.Put.Request;
using FluentAssertions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using NSubstitute;
using NSubstitute.ExceptionExtensions;
using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using Xunit;
using ApiErrorResult = Experian.ResponseModels.ApiErrorResult;
using ExternalModel = EXPN.Models.CreditLockService.External.Get.Customer.Response;
using InternalResponseModel = EXPN.Models.CreditLockService.Internal.Get.Response;

namespace EXPN.UnitTest.CreditLockService.Controllers
{
    public class ExternalControllerTests
    {
        private readonly ILogger<ExternalController> _logger;
        private readonly IMapper _mapper;
        private readonly ICreditLockServiceCustomerManager _creditLockServiceCustomerManager;
        private readonly IMessaging _messaging;
        private readonly ExternalController _externalController;
        private readonly IBenefitChecker _benefitChecker;

        private const int DownstreamMaintenanceStatusCode = 561;

        private const string EventName = "auditCreditLockRequest";

        public ExternalControllerTests()
        {
            _logger = Substitute.For<ILogger<ExternalController>>();
            _mapper = Substitute.For<IMapper>();
            _creditLockServiceCustomerManager = Substitute.For<ICreditLockServiceCustomerManager>();
            _messaging = Substitute.For<IMessaging>();
            _benefitChecker = Substitute.For<IBenefitChecker>();

            var dateTime = Substitute.For<IDateTime>();

            dateTime.Now.Returns(new DateTime(2000, 12, 31, 23, 59, 59, 123));

            _externalController = new ExternalController(_logger, _mapper, _creditLockServiceCustomerManager, _messaging, dateTime, _benefitChecker);
        }

        public static IEnumerable<object[]> NullParameters()
        {
            yield return new object[]
            {
                null,
                Substitute.For<IMapper>(),
                Substitute.For<ICreditLockServiceCustomerManager>(),
                Substitute.For<IMessaging>(),
                Substitute.For<IDateTime>(),
                Substitute.For<IBenefitChecker>(),
                "logger"
            };

            yield return new object[]
            {
                Substitute.For<ILogger<ExternalController>>(),
                null,
                Substitute.For<ICreditLockServiceCustomerManager>(),
                Substitute.For<IMessaging>(),
                Substitute.For<IDateTime>(),
                Substitute.For<IBenefitChecker>(),
                "mapper"
            };

            yield return new object[]
            {
                Substitute.For<ILogger<ExternalController>>(),
                Substitute.For<IMapper>(),
                null,
                Substitute.For<IMessaging>(),
                Substitute.For<IDateTime>(),
                Substitute.For<IBenefitChecker>(),
                "creditLockServiceCustomerManager"
            };

            yield return new object[]
            {
                Substitute.For<ILogger<ExternalController>>(),
                Substitute.For<IMapper>(),
                Substitute.For<ICreditLockServiceCustomerManager>(),
                null,
                Substitute.For<IDateTime>(),
                Substitute.For<IBenefitChecker>(),
                "messaging"
            };

            yield return new object[]
            {
                Substitute.For<ILogger<ExternalController>>(),
                Substitute.For<IMapper>(),
                Substitute.For<ICreditLockServiceCustomerManager>(),
                Substitute.For<IMessaging>(),
                null,
                Substitute.For<IBenefitChecker>(),
                "dateTime"
            };

            yield return new object[]
            {
                Substitute.For<ILogger<ExternalController>>(),
                Substitute.For<IMapper>(),
                Substitute.For<ICreditLockServiceCustomerManager>(),
                Substitute.For<IMessaging>(),
                Substitute.For<IDateTime>(),
                null,
                "benefitChecker"
            };
        }

        [Theory]
        [MemberData(nameof(NullParameters))]
        public void Constructor_RequiredParameterNull_ThrowsArgumentNullException(
            ILogger<ExternalController> logger,
            IMapper mapper,
            ICreditLockServiceCustomerManager creditLockServiceCustomerManager,
            IMessaging messaging,
            IDateTime dateTime,
            IBenefitChecker benefitChecker,
        string expectedErrorParameter)
        {
            var action = () =>
            {
                new ExternalController(logger, mapper, creditLockServiceCustomerManager, messaging, dateTime, benefitChecker);
            };

            action.Should().Throw<ArgumentNullException>()
                .Where(x => x.ParamName == expectedErrorParameter);
        }

        public class PutAsyncTests : ExternalControllerTests
        {
            public static IEnumerable<object[]> LogInformationMessages()
            {
                yield return new object[]
                {
                    LogEventNames.ExternalController.Put.Invoked
                };

                yield return new object[]
                {
                    LogEventNames.ExternalController.Put.Complete
                };
            }

            [Theory]
            [MemberData(nameof(LogInformationMessages))]
            public async Task HappyPathInformationLogged(string information)
            {
                var request = new PutStatusRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4",
                    Body = new PutStatusRequestBody
                    {
                        Status = "ON"
                    }
                };

                var internalRequest = new PutLockStatusRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4",
                    LockStatus = true
                };

                _mapper.Map<PutLockStatusRequest>(request)
                    .Returns(internalRequest);

                var response = await _externalController.PutAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.NoContent);

                _mapper.Received(1).Map<PutLockStatusRequest>(request);
                _mapper.Received(1).Map(request.Body, internalRequest);

                _benefitChecker.Received(1).EnsureValidBenefitAsync().Wait();

                await _creditLockServiceCustomerManager.Received(1).PutLockStatus(internalRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "204"
                    && x.ResponseStatusDescription == "Success"
                    && x.RequestType == "SET_LOCK_ON"
                    && x.RequestDt == new DateTime(2000, 12, 31, 23, 59, 59, 123)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(information)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.RequestBodyNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.CustomerNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.SyncCustomerPinningException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                   Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.BenefitsInvalidOperationException)), null,
                   Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                   Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.BenefitCheckFail)), null,
                   Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PutRequest_ModelStateInvalid_ReturnStatusBadRequest()
            {
                var request = new PutStatusRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4",
                    Body = new PutStatusRequestBody
                    {
                        Status = "ON"
                    }
                };

                _externalController.ModelState.AddModelError("Test", "TestError");

                var response = await _externalController.PutAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.BadRequest);

                _mapper.DidNotReceive().Map<PutLockStatusRequest>(Arg.Any<PutStatusRequest>());
                _mapper.DidNotReceive().Map(Arg.Any<PutStatusRequestBody>(), Arg.Any<PutLockStatusRequest>());

                _benefitChecker.DidNotReceive().EnsureValidBenefitAsync().Wait();

                await _creditLockServiceCustomerManager.DidNotReceive().PutLockStatus(Arg.Any<PutLockStatusRequest>());

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "400"
                    && x.ResponseStatusDescription == "Bad Request"
                    && x.RequestType == "SET_LOCK"
                    && x.RequestDt == new DateTime(2000, 12, 31, 23, 59, 59, 123)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.RequestBodyNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.CustomerNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.SyncCustomerPinningException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                   Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.BenefitsInvalidOperationException)), null,
                   Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                   Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.BenefitCheckFail)), null,
                   Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Theory]
            [InlineData("ON")]
            [InlineData("OFF")]
            public async Task PutRequest_Valid_ReturnsStatusNoContent(string lockStatus)
            {
                var request = new PutStatusRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4",
                    Body = new PutStatusRequestBody
                    {
                        Status = lockStatus
                    }
                };

                var internalRequest = new PutLockStatusRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4",
                    LockStatus = true
                };

                _mapper.Map<PutLockStatusRequest>(request)
                    .Returns(internalRequest);

                var response = await _externalController.PutAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.NoContent);

                _mapper.Received(1).Map<PutLockStatusRequest>(request);
                _mapper.Received(1).Map(request.Body, internalRequest);

                _benefitChecker.Received(1).EnsureValidBenefitAsync().Wait();

                await _creditLockServiceCustomerManager.Received(1).PutLockStatus(internalRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "204"
                    && x.ResponseStatusDescription == "Success"
                    && x.RequestType == $"SET_LOCK_{lockStatus}"
                    && x.RequestDt == new DateTime(2000, 12, 31, 23, 59, 59, 123)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.RequestBodyNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.CustomerNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                   Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.BenefitsInvalidOperationException)), null,
                   Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                   Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.BenefitCheckFail)), null,
                   Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Theory]
            [InlineData("ON")]
            [InlineData("OFF")]
            public async Task PutRequest_ThrowsException_ReturnsStatusInternalServerError(string lockStatus)
            {
                var request = new PutStatusRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4",
                    Body = new PutStatusRequestBody
                    {
                        Status = lockStatus
                    }
                };

                var internalRequest = new PutLockStatusRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4",
                    LockStatus = true
                };

                _mapper.Map<PutLockStatusRequest>(request)
                    .Returns(internalRequest);

                _creditLockServiceCustomerManager.PutLockStatus(internalRequest)
                    .Throws(new InvalidOperationException("Test Message"));

                var response = await _externalController.PutAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.InternalServerError);

                _mapper.Received(1).Map<PutLockStatusRequest>(request);
                _mapper.Received(1).Map(request.Body, internalRequest);

                _benefitChecker.Received(1).EnsureValidBenefitAsync().Wait();

                await _creditLockServiceCustomerManager.Received(1).PutLockStatus(internalRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "500"
                    && x.ResponseStatusDescription == "Internal Server Error"
                    && x.RequestType == $"SET_LOCK_{lockStatus}"
                    && x.RequestDt == new DateTime(2000, 12, 31, 23, 59, 59, 123)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.RequestBodyNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.CustomerNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.SyncCustomerPinningException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                   Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.BenefitsInvalidOperationException)), null,
                   Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                   Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.BenefitCheckFail)), null,
                   Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Theory]
            [InlineData("ON")]
            [InlineData("OFF")]
            public async Task PutRequest_DownstreamMaintenanceException_ReturnsStatus561(string lockStatus)
            {
                var request = new PutStatusRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4",
                    Body = new PutStatusRequestBody
                    {
                        Status = lockStatus
                    }
                };

                var internalRequest = new PutLockStatusRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4",
                    LockStatus = true
                };

                _mapper.Map<PutLockStatusRequest>(request)
                    .Returns(internalRequest);

                _creditLockServiceCustomerManager.PutLockStatus(internalRequest)
                    .Throws(new DownstreamMaintenanceException("Test Exception"));

                var response = await _externalController.PutAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be(DownstreamMaintenanceStatusCode);

                _mapper.Received(1).Map<PutLockStatusRequest>(request);
                _mapper.Received(1).Map(request.Body, internalRequest);

                _benefitChecker.Received(1).EnsureValidBenefitAsync().Wait();

                await _creditLockServiceCustomerManager.Received(1).PutLockStatus(internalRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "561"
                    && x.ResponseStatusDescription == "Downstream Service Unavailable - mainframe down for scheduled maintenance"
                    && x.RequestType == $"SET_LOCK_{lockStatus}"
                    && x.RequestDt == new DateTime(2000, 12, 31, 23, 59, 59, 123)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.Invoked)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.Complete)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.CustomerNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.SyncCustomerPinningException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                   Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.BenefitsInvalidOperationException)), null,
                   Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                   Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.BenefitCheckFail)), null,
                   Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Theory]
            [InlineData("ON")]
            [InlineData("OFF")]
            public async Task PutRequest_OktaTokenNullException_ReturnsStatusBadGateway(string lockStatus)
            {
                var request = new PutStatusRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4",
                    Body = new PutStatusRequestBody
                    {
                        Status = lockStatus
                    }
                };

                var internalRequest = new PutLockStatusRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4",
                    LockStatus = true
                };

                _mapper.Map<PutLockStatusRequest>(request)
                    .Returns(internalRequest);

                _creditLockServiceCustomerManager.PutLockStatus(internalRequest)
                    .Throws(new OktaTokenNullException("Test Exception"));

                var response = await _externalController.PutAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be(502);

                _mapper.Received(1).Map<PutLockStatusRequest>(request);
                _mapper.Received(1).Map(request.Body, internalRequest);

                _benefitChecker.Received(1).EnsureValidBenefitAsync().Wait();

                await _creditLockServiceCustomerManager.Received(1).PutLockStatus(internalRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "502"
                    && x.ResponseStatusDescription == "Bad Gateway"
                    && x.RequestType == $"SET_LOCK_{lockStatus}"
                    && x.RequestDt == new DateTime(2000, 12, 31, 23, 59, 59, 123)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.Invoked)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.Complete)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.CustomerNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.SyncCustomerPinningException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                   Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.BenefitsInvalidOperationException)), null,
                   Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                   Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.BenefitCheckFail)), null,
                   Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Theory]
            [InlineData("ON")]
            [InlineData("OFF")]
            public async Task PutRequest_OktaException_ReturnsStatusBadGateway(string lockStatus)
            {
                var request = new PutStatusRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4",
                    Body = new PutStatusRequestBody
                    {
                        Status = lockStatus
                    }
                };

                var internalRequest = new PutLockStatusRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4",
                    LockStatus = true
                };

                _mapper.Map<PutLockStatusRequest>(request)
                    .Returns(internalRequest);

                _creditLockServiceCustomerManager.PutLockStatus(internalRequest)
                    .Throws(new OktaException("Test Exception"));

                var response = await _externalController.PutAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be(502);

                _mapper.Received(1).Map<PutLockStatusRequest>(request);
                _mapper.Received(1).Map(request.Body, internalRequest);

                _benefitChecker.Received(1).EnsureValidBenefitAsync().Wait();

                await _creditLockServiceCustomerManager.Received(1).PutLockStatus(internalRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "502"
                    && x.ResponseStatusDescription == "Bad Gateway"
                    && x.RequestType == $"SET_LOCK_{lockStatus}"
                    && x.RequestDt == new DateTime(2000, 12, 31, 23, 59, 59, 123)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.Invoked)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.Complete)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.SyncCustomerPinningException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                   Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.BenefitsInvalidOperationException)), null,
                   Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                   Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.BenefitCheckFail)), null,
                   Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Theory]
            [InlineData("ON")]
            [InlineData("OFF")]
            public async Task PutRequest_HttpServiceRequestException_ReturnsStatusInternalServerError(string lockStatus)
            {
                var request = new PutStatusRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4",
                    Body = new PutStatusRequestBody
                    {
                        Status = lockStatus
                    }
                };

                var internalRequest = new PutLockStatusRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4",
                    LockStatus = true
                };

                _mapper.Map<PutLockStatusRequest>(request)
                    .Returns(internalRequest);

                _creditLockServiceCustomerManager.PutLockStatus(internalRequest)
                    .Throws(new HttpServiceRequestException("Test Exception"));

                var response = await _externalController.PutAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be(500);

                _mapper.Received(1).Map<PutLockStatusRequest>(request);
                _mapper.Received(1).Map(request.Body, internalRequest);

                _benefitChecker.Received(1).EnsureValidBenefitAsync().Wait();

                await _creditLockServiceCustomerManager.Received(1).PutLockStatus(internalRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "500"
                    && x.ResponseStatusDescription == "Internal Server Error"
                    && x.RequestType == $"SET_LOCK_{lockStatus}"
                    && x.RequestDt == new DateTime(2000, 12, 31, 23, 59, 59, 123)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.Invoked)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.Complete)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.SyncCustomerPinningException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                   Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.BenefitsInvalidOperationException)), null,
                   Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                   Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.BenefitCheckFail)), null,
                   Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Theory]
            [InlineData("ON")]
            [InlineData("OFF")]
            public async Task PutRequest_ServiceTaskCanceledException_ReturnsStatusCode564(string lockStatus)
            {
                var request = new PutStatusRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4",
                    Body = new PutStatusRequestBody
                    {
                        Status = lockStatus
                    }
                };

                var internalRequest = new PutLockStatusRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4",
                    LockStatus = true
                };

                _mapper.Map<PutLockStatusRequest>(request)
                    .Returns(internalRequest);

                _creditLockServiceCustomerManager.PutLockStatus(internalRequest)
                    .Throws(new ServiceTaskCanceledException("Test Exception"));

                var response = await _externalController.PutAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be(MessageConstants.DownstreamTimeoutStatusCode);

                _mapper.Received(1).Map<PutLockStatusRequest>(request);
                _mapper.Received(1).Map(request.Body, internalRequest);

                await _creditLockServiceCustomerManager.Received(1).PutLockStatus(internalRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "564"
                    && x.ResponseStatusDescription == MessageConstants.DownstreamTimeout
                    && x.RequestType == $"SET_LOCK_{lockStatus}"
                    && x.RequestDt == new DateTime(2000, 12, 31, 23, 59, 59, 123)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.Invoked)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.Complete)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.SyncCustomerPinningException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                   Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.BenefitsInvalidOperationException)), null,
                   Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                   Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.BenefitCheckFail)), null,
                   Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Theory]
            [InlineData("ON")]
            [InlineData("OFF")]
            public async Task PutRequest_ServiceUnavailableException_ReturnsStatusServiceUnavailable(string lockStatus)
            {
                var request = new PutStatusRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4",
                    Body = new PutStatusRequestBody
                    {
                        Status = lockStatus
                    }
                };

                var internalRequest = new PutLockStatusRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4",
                    LockStatus = true
                };

                _mapper.Map<PutLockStatusRequest>(request)
                    .Returns(internalRequest);

                _creditLockServiceCustomerManager.PutLockStatus(internalRequest)
                    .Throws(new ServiceUnavailableException("Test Exception"));

                var response = await _externalController.PutAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be(503);

                _mapper.Received(1).Map<PutLockStatusRequest>(request);
                _mapper.Received(1).Map(request.Body, internalRequest);

                await _creditLockServiceCustomerManager.Received(1).PutLockStatus(internalRequest);

                _benefitChecker.Received(1).EnsureValidBenefitAsync().Wait();

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "503"
                    && x.ResponseStatusDescription == "Service Unavailable"
                    && x.RequestType == $"SET_LOCK_{lockStatus}"
                    && x.RequestDt == new DateTime(2000, 12, 31, 23, 59, 59, 123)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.Invoked)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.Complete)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.CustomerNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.SyncCustomerPinningException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                   Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.BenefitsInvalidOperationException)), null,
                   Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                   Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.BenefitCheckFail)), null,
                   Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Theory]
            [InlineData("ON")]
            [InlineData("OFF")]
            public async Task PutRequest_CustomerNotFoundException_ReturnsStatusNotFound(string lockStatus)
            {
                var request = new PutStatusRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4",
                    Body = new PutStatusRequestBody
                    {
                        Status = lockStatus
                    }
                };

                var internalRequest = new PutLockStatusRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4",
                    LockStatus = true
                };

                _mapper.Map<PutLockStatusRequest>(request)
                    .Returns(internalRequest);

                _creditLockServiceCustomerManager.PutLockStatus(internalRequest)
                    .Throws(new CustomerNotFoundException("Test Exception"));

                var response = await _externalController.PutAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be(404);

                _mapper.Received(1).Map<PutLockStatusRequest>(request);
                _mapper.Received(1).Map(request.Body, internalRequest);

                await _creditLockServiceCustomerManager.Received(1).PutLockStatus(internalRequest);

                _benefitChecker.Received(1).EnsureValidBenefitAsync().Wait();

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "404"
                    && x.ResponseStatusDescription == "VIP Customer is Not Found"
                    && x.RequestType == $"SET_LOCK_{lockStatus}"
                    && x.RequestDt == new DateTime(2000, 12, 31, 23, 59, 59, 123)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.Invoked)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.CustomerNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.Complete)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.SyncCustomerPinningException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                   Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.BenefitsInvalidOperationException)), null,
                   Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                   Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.BenefitCheckFail)), null,
                   Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Theory]
            [InlineData("ON")]
            [InlineData("OFF")]
            public async Task PutRequest_SyncCustomerPinningException_ReturnsStatus409(string lockStatus)
            {
                var request = new PutStatusRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4",
                    Body = new PutStatusRequestBody
                    {
                        Status = lockStatus
                    }
                };

                var internalRequest = new PutLockStatusRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4",
                    LockStatus = true
                };

                _mapper.Map<PutLockStatusRequest>(request)
                    .Returns(internalRequest);

                _creditLockServiceCustomerManager.PutLockStatus(internalRequest)
                    .Throws(new SyncCustomerPinningException("Test Exception"));

                var response = await _externalController.PutAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be(409);

                _mapper.Received(1).Map<PutLockStatusRequest>(request);
                _mapper.Received(1).Map(request.Body, internalRequest);

                _benefitChecker.Received(1).EnsureValidBenefitAsync().Wait();

                await _creditLockServiceCustomerManager.Received(1).PutLockStatus(internalRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "409"
                    && x.ResponseStatusDescription == "Conflict - customer waiting to be pinned or pinning in process"
                    && x.RequestType == $"SET_LOCK_{lockStatus}"
                    && x.RequestDt == new DateTime(2000, 12, 31, 23, 59, 59, 123)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.Invoked)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.SyncCustomerPinningException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.Complete)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                   Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.BenefitsInvalidOperationException)), null,
                   Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                   Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.BenefitCheckFail)), null,
                   Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Theory]
            [InlineData("ON")]
            [InlineData("OFF")]
            public async Task PutRequest_DownstreamAuthenticationException_ReturnsStatus563(string lockStatus)
            {
                var request = new PutStatusRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4",
                    Body = new PutStatusRequestBody
                    {
                        Status = lockStatus
                    }
                };

                var internalRequest = new PutLockStatusRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4",
                    LockStatus = true
                };

                _mapper.Map<PutLockStatusRequest>(request)
                    .Returns(internalRequest);

                _creditLockServiceCustomerManager.PutLockStatus(internalRequest)
                    .Throws(new DownstreamAuthenticationException("Test Exception"));

                var response = await _externalController.PutAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be(563);

                _mapper.Received(1).Map<PutLockStatusRequest>(request);
                _mapper.Received(1).Map(request.Body, internalRequest);

                _benefitChecker.Received(1).EnsureValidBenefitAsync().Wait();

                await _creditLockServiceCustomerManager.Received(1).PutLockStatus(internalRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "563"
                    && x.ResponseStatusDescription == "Downstream Service Authentication Failed"
                    && x.RequestType == $"SET_LOCK_{lockStatus}"
                    && x.RequestDt == new DateTime(2000, 12, 31, 23, 59, 59, 123)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.Invoked)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.DownstreamAuthenticationException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.Complete)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                   Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.BenefitsInvalidOperationException)), null,
                   Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                   Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.BenefitCheckFail)), null,
                   Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Theory]
            [InlineData("ON")]
            [InlineData("OFF")]
            public async Task PutRequest_NoBenefitException_ReturnsStatusForbidden(string lockStatus)
            {
                var request = new PutStatusRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4",
                    Body = new PutStatusRequestBody
                    {
                        Status = lockStatus
                    }
                };

                var internalRequest = new PutLockStatusRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4",
                    LockStatus = true
                };

                _mapper.Map<PutLockStatusRequest>(request)
                    .Returns(internalRequest);

                _creditLockServiceCustomerManager.PutLockStatus(internalRequest)
                    .Throws(new NoBenefitException("Benefit could not be fulfilled", "B999"));

                var response = await _externalController.PutAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be(403);

                _mapper.Received(1).Map<PutLockStatusRequest>(request);
                _mapper.Received(1).Map(request.Body, internalRequest);

                _benefitChecker.Received(1).EnsureValidBenefitAsync().Wait();

                await _creditLockServiceCustomerManager.Received(1).PutLockStatus(internalRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "403"
                    && x.ResponseStatusDescription == "Benefit could not be fulfilled"
                    && x.RequestType == $"SET_LOCK_{lockStatus}"
                    && x.RequestDt == new DateTime(2000, 12, 31, 23, 59, 59, 123)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.Invoked)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.BenefitCheckFail)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.Complete)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                   Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.BenefitsInvalidOperationException)), null,
                   Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Theory]
            [InlineData("ON")]
            [InlineData("OFF")]
            public async Task PutRequest_BenefitsInvalidOperationException_ReturnsStatusInternalServerError(string lockStatus)
            {
                var request = new PutStatusRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4",
                    Body = new PutStatusRequestBody
                    {
                        Status = lockStatus
                    }
                };

                var internalRequest = new PutLockStatusRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4",
                    LockStatus = true
                };

                _mapper.Map<PutLockStatusRequest>(request)
                    .Returns(internalRequest);

                _creditLockServiceCustomerManager.PutLockStatus(internalRequest)
                    .Throws(new BenefitsInvalidOperationException("Upstream service subscriptions returned no data."));

                var response = await _externalController.PutAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be(500);

                _mapper.Received(1).Map<PutLockStatusRequest>(request);
                _mapper.Received(1).Map(request.Body, internalRequest);

                _benefitChecker.Received(1).EnsureValidBenefitAsync().Wait();

                await _creditLockServiceCustomerManager.Received(1).PutLockStatus(internalRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "500"
                    && x.ResponseStatusDescription == "Upstream service subscriptions returned no data."
                    && x.RequestType == $"SET_LOCK_{lockStatus}"
                    && x.RequestDt == new DateTime(2000, 12, 31, 23, 59, 59, 123)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.Invoked)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.BenefitsInvalidOperationException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.Complete)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Put.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }
        }

        public class PutAgentAsyncTests : ExternalControllerTests
        {
            public static IEnumerable<object[]> LogInformationMessages()
            {
                yield return new object[]
                {
                    LogEventNames.ExternalController.PutAgent.Invoked
                };

                yield return new object[]
                {
                    LogEventNames.ExternalController.PutAgent.Complete
                };
            }

            [Theory]
            [MemberData(nameof(LogInformationMessages))]
            public async Task HappyPathInformationLogged(string information)
            {
                var request = new PutStatusAgentRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4",
                    Body = new PutStatusAgentRequestBody
                    {
                        SalesforceUserId = "SalesforceUserId",
                        Status = "ON"
                    }
                };

                var internalRequest = new PutLockStatusRequest
                {
                    CustomerId = "customerId",
                    LockStatus = true,
                    SalesForceUserId = "salesforceUserId"
                };

                _mapper.Map<PutLockStatusRequest>(request)
                    .Returns(internalRequest);

                var response = await _externalController.PutAgentAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.NoContent);

                _mapper.Received(1).Map<PutLockStatusRequest>(request);
                _mapper.Received(1).Map(request.Body, internalRequest);

                await _creditLockServiceCustomerManager.Received(1).PutLockStatus(internalRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "204"
                    && x.ResponseStatusDescription == "Success"
                    && x.RequestType == "AGENT_SET_LOCK_ON"
                    && x.RequestDt == new DateTime(2000, 12, 31, 23, 59, 59, 123)
                    && x.SalesforceUserId == "SalesforceUserId"));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(information)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o =>
                        o.ContainsValue(LogEventNames.ExternalController.PutAgent.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o =>
                        o.ContainsValue(LogEventNames.ExternalController.PutAgent.RequestBodyNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.SyncCustomerPinningException)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PutAgentRequest_ModelStateInvalid_WithSalesforceId_ReturnStatusBadRequest()
            {
                var request = new PutStatusAgentRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4",
                    Body = new PutStatusAgentRequestBody
                    {
                        SalesforceUserId = "SalesforceUserId",
                        Status = "ON"
                    }
                };

                _externalController.ModelState.AddModelError("Test", "TestError");

                var response = await _externalController.PutAgentAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.BadRequest);

                _mapper.DidNotReceive().Map<PutLockStatusRequest>(request);
                _mapper.DidNotReceive().Map(request.Body, Arg.Any<PutLockStatusRequest>());

                _benefitChecker.DidNotReceive().EnsureValidBenefitAsync().Wait();

                await _creditLockServiceCustomerManager.DidNotReceive().PutLockStatus(Arg.Any<PutLockStatusRequest>());

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "400"
                    && x.ResponseStatusDescription == "Bad Request"
                    && x.RequestType == "AGENT_SET_LOCK"
                    && x.RequestDt == new DateTime(2000, 12, 31, 23, 59, 59, 123)
                    && x.SalesforceUserId == "SalesforceUserId"));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.RequestBodyNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.SyncCustomerPinningException)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                 Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.BenefitCheckFail)), null,
                 Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                 Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.BenefitsInvalidOperationException)), null,
                 Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Theory]
            [InlineData(null)]
            [InlineData("")]
            [InlineData("        ")]
            public async Task PutAgentRequest_ModelStateInvalid_WithoutSalesforceId_ReturnStatusBadRequest(string salesforceId)
            {
                var request = new PutStatusAgentRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4",
                    Body = new PutStatusAgentRequestBody
                    {
                        SalesforceUserId = salesforceId,
                        Status = "ON"
                    }
                };

                _externalController.ModelState.AddModelError("Test", "TestError");

                var response = await _externalController.PutAgentAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.BadRequest);

                _mapper.DidNotReceive().Map<PutLockStatusRequest>(request);
                _mapper.DidNotReceive().Map(request.Body, Arg.Any<PutLockStatusRequest>());

                _benefitChecker.DidNotReceive().EnsureValidBenefitAsync().Wait();

                await _creditLockServiceCustomerManager.DidNotReceive().PutLockStatus(Arg.Any<PutLockStatusRequest>());

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "400"
                    && x.ResponseStatusDescription == "Bad Request"
                    && x.RequestType == "AGENT_SET_LOCK"
                    && x.RequestDt == new DateTime(2000, 12, 31, 23, 59, 59, 123)
                    && x.SalesforceUserId == null));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.RequestBodyNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.SyncCustomerPinningException)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                 Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.BenefitCheckFail)), null,
                 Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                 Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.BenefitsInvalidOperationException)), null,
                 Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Theory]
            [InlineData("ON")]
            [InlineData("OFF")]
            public async Task PutAgentRequest_Valid_ReturnsStatusNoContent(string lockStatus)
            {
                var request = new PutStatusAgentRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4",
                    Body = new PutStatusAgentRequestBody()
                    {
                        Status = lockStatus,
                        SalesforceUserId = "A123456798"
                    }
                };

                var internalRequest = new PutLockStatusRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4",
                    LockStatus = true,
                    SalesForceUserId = "A123456798"
                };

                _mapper.Map<PutLockStatusRequest>(request)
                    .Returns(internalRequest);

                _mapper.Map(request.Body, internalRequest)
                    .Returns(internalRequest);

                var response = await _externalController.PutAgentAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.NoContent);

                _mapper.Received(1).Map<PutLockStatusRequest>(request);
                _mapper.Received(1).Map(request.Body, internalRequest);

                _benefitChecker.Received(1).EnsureValidBenefitAsync().Wait();

                await _creditLockServiceCustomerManager.Received(1).PutLockStatus(internalRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "204"
                    && x.ResponseStatusDescription == "Success"
                    && x.RequestType == $"AGENT_SET_LOCK_{lockStatus}"
                    && x.RequestDt == new DateTime(2000, 12, 31, 23, 59, 59, 123)
                    && x.SalesforceUserId == "A123456798"));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.SyncCustomerPinningException)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                 Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.BenefitCheckFail)), null,
                 Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                 Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.BenefitsInvalidOperationException)), null,
                 Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Theory]
            [InlineData("ON")]
            [InlineData("OFF")]
            public async Task PutAgentRequest_ThrowsException_ReturnsStatusInternalServerError(string lockStatus)
            {
                var request = new PutStatusAgentRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4",
                    Body = new PutStatusAgentRequestBody()
                    {
                        Status = lockStatus,
                        SalesforceUserId = "A123456798"
                    }
                };

                var internalRequest = new PutLockStatusRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4",
                    LockStatus = true,
                    SalesForceUserId = "A123456798"
                };

                _mapper.Map<PutLockStatusRequest>(request)
                    .Returns(internalRequest);

                _mapper.Map(request.Body, internalRequest)
                    .Returns(internalRequest);

                _creditLockServiceCustomerManager.PutLockStatus(internalRequest)
                    .Throws(new InvalidOperationException("Test Message"));

                var response = await _externalController.PutAgentAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.InternalServerError);

                _mapper.Received(1).Map<PutLockStatusRequest>(request);
                _mapper.Received(1).Map(request.Body, internalRequest);

                _benefitChecker.Received(1).EnsureValidBenefitAsync().Wait();

                await _creditLockServiceCustomerManager.Received(1).PutLockStatus(internalRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "500"
                    && x.ResponseStatusDescription == "Internal Server Error"
                    && x.RequestType == $"AGENT_SET_LOCK_{lockStatus}"
                    && x.RequestDt == new DateTime(2000, 12, 31, 23, 59, 59, 123)
                    && x.SalesforceUserId == "A123456798"));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.Complete)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.RequestBodyNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.CustomerNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.SyncCustomerPinningException)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                 Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.BenefitCheckFail)), null,
                 Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                 Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.BenefitsInvalidOperationException)), null,
                 Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Theory]
            [InlineData("ON")]
            [InlineData("OFF")]
            public async Task PutAgentRequest_DownstreamMaintenanceException_ReturnsStatus561(string lockStatus)
            {
                var request = new PutStatusAgentRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4",
                    Body = new PutStatusAgentRequestBody()
                    {
                        Status = lockStatus,
                        SalesforceUserId = "A123456798"
                    }
                };

                var internalRequest = new PutLockStatusRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4",
                    LockStatus = true,
                    SalesForceUserId = "A123456798"
                };

                _mapper.Map<PutLockStatusRequest>(request)
                    .Returns(internalRequest);

                _mapper.Map(request.Body, internalRequest)
                    .Returns(internalRequest);

                _creditLockServiceCustomerManager.PutLockStatus(internalRequest)
                    .Throws(new DownstreamMaintenanceException("Test Exception"));

                var response = await _externalController.PutAgentAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be(DownstreamMaintenanceStatusCode);

                _mapper.Received(1).Map<PutLockStatusRequest>(request);
                _mapper.Received(1).Map(request.Body, internalRequest);

                _benefitChecker.Received(1).EnsureValidBenefitAsync().Wait();

                await _creditLockServiceCustomerManager.Received(1).PutLockStatus(internalRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "561"
                    && x.ResponseStatusDescription == "Downstream Service Unavailable - mainframe down for scheduled maintenance"
                    && x.RequestType == $"AGENT_SET_LOCK_{lockStatus}"
                    && x.RequestDt == new DateTime(2000, 12, 31, 23, 59, 59, 123)
                    && x.SalesforceUserId == "A123456798"));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.Invoked)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.Complete)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.CustomerNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.SyncCustomerPinningException)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                 Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.BenefitCheckFail)), null,
                 Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                 Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.BenefitsInvalidOperationException)), null,
                 Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Theory]
            [InlineData("ON")]
            [InlineData("OFF")]
            public async Task PutAgentRequest_OktaTokenNullException_ReturnsStatusBadGateway(string lockStatus)
            {
                var request = new PutStatusAgentRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4",
                    Body = new PutStatusAgentRequestBody()
                    {
                        Status = lockStatus,
                        SalesforceUserId = "A123456798"
                    }
                };

                var internalRequest = new PutLockStatusRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4",
                    LockStatus = true,
                    SalesForceUserId = "A123456798"
                };

                _mapper.Map<PutLockStatusRequest>(request)
                    .Returns(internalRequest);

                _mapper.Map(request.Body, internalRequest)
                    .Returns(internalRequest);

                _creditLockServiceCustomerManager.PutLockStatus(internalRequest)
                    .Throws(new OktaTokenNullException("Test Exception"));

                var response = await _externalController.PutAgentAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be(502);

                _mapper.Received(1).Map<PutLockStatusRequest>(request);
                _mapper.Received(1).Map(request.Body, internalRequest);

                _benefitChecker.Received(1).EnsureValidBenefitAsync().Wait();

                await _creditLockServiceCustomerManager.Received(1).PutLockStatus(internalRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "502"
                    && x.ResponseStatusDescription == "Bad Gateway"
                    && x.RequestType == $"AGENT_SET_LOCK_{lockStatus}"
                    && x.RequestDt == new DateTime(2000, 12, 31, 23, 59, 59, 123)
                    && x.SalesforceUserId == "A123456798"));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.Invoked)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.OktaTokenNullException)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.Complete)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.CustomerNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.SyncCustomerPinningException)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                 Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.BenefitCheckFail)), null,
                 Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                 Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.BenefitsInvalidOperationException)), null,
                 Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Theory]
            [InlineData("ON")]
            [InlineData("OFF")]
            public async Task PutAgentRequest_OktaException_ReturnsStatusBadGateway(string lockStatus)
            {
                var request = new PutStatusAgentRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4",
                    Body = new PutStatusAgentRequestBody
                    {
                        Status = lockStatus,
                        SalesforceUserId = "A123456798"
                    }
                };

                var internalRequest = new PutLockStatusRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4",
                    LockStatus = true,
                    SalesForceUserId = "A123456798"
                };

                _mapper.Map<PutLockStatusRequest>(request)
                    .Returns(internalRequest);

                _mapper.Map(request.Body, internalRequest)
                    .Returns(internalRequest);

                _creditLockServiceCustomerManager.PutLockStatus(internalRequest)
                    .Throws(new OktaException("Test Exception"));

                var response = await _externalController.PutAgentAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be(502);

                _mapper.Received(1).Map<PutLockStatusRequest>(request);
                _mapper.Received(1).Map(request.Body, internalRequest);

                _benefitChecker.Received(1).EnsureValidBenefitAsync().Wait();

                await _creditLockServiceCustomerManager.Received(1).PutLockStatus(internalRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "502"
                    && x.ResponseStatusDescription == "Bad Gateway"
                    && x.RequestType == $"AGENT_SET_LOCK_{lockStatus}"
                    && x.RequestDt == new DateTime(2000, 12, 31, 23, 59, 59, 123)
                    && x.SalesforceUserId == "A123456798"));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.Invoked)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.OktaTokenException)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.Complete)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.SyncCustomerPinningException)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                 Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.BenefitCheckFail)), null,
                 Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                 Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.BenefitsInvalidOperationException)), null,
                 Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Theory]
            [InlineData("ON")]
            [InlineData("OFF")]
            public async Task PutAgentRequest_HttpServiceRequestException_ReturnsStatusInternalServerError(string lockStatus)
            {
                var request = new PutStatusAgentRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4",
                    Body = new PutStatusAgentRequestBody()
                    {
                        Status = lockStatus,
                        SalesforceUserId = "A123456798"
                    }
                };

                var internalRequest = new PutLockStatusRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4",
                    LockStatus = true,
                    SalesForceUserId = "A123456798"
                };

                _mapper.Map<PutLockStatusRequest>(request)
                    .Returns(internalRequest);

                _mapper.Map(request.Body, internalRequest)
                    .Returns(internalRequest);

                _creditLockServiceCustomerManager.PutLockStatus(internalRequest)
                    .Throws(new HttpServiceRequestException("Test Exception"));

                var response = await _externalController.PutAgentAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be(500);

                _mapper.Received(1).Map<PutLockStatusRequest>(request);
                _mapper.Received(1).Map(request.Body, internalRequest);

                _benefitChecker.Received(1).EnsureValidBenefitAsync().Wait();

                await _creditLockServiceCustomerManager.Received(1).PutLockStatus(internalRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "500"
                    && x.ResponseStatusDescription == "Internal Server Error"
                    && x.RequestType == $"AGENT_SET_LOCK_{lockStatus}"
                    && x.RequestDt == new DateTime(2000, 12, 31, 23, 59, 59, 123)
                    && x.SalesforceUserId == "A123456798"));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.Invoked)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.HttpServiceRequestException)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.Complete)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.SyncCustomerPinningException)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                 Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.BenefitCheckFail)), null,
                 Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                 Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.BenefitsInvalidOperationException)), null,
                 Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Theory]
            [InlineData("ON")]
            [InlineData("OFF")]
            public async Task PutAgentRequest_ServiceTaskCanceledException_ReturnsStatusCode564(string lockStatus)
            {
                var request = new PutStatusAgentRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4",
                    Body = new PutStatusAgentRequestBody()
                    {
                        Status = lockStatus,
                        SalesforceUserId = "A123456798"
                    }
                };

                var internalRequest = new PutLockStatusRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4",
                    LockStatus = true,
                    SalesForceUserId = "A123456798"
                };

                _mapper.Map<PutLockStatusRequest>(request)
                    .Returns(internalRequest);

                _mapper.Map(request.Body, internalRequest)
                    .Returns(internalRequest);

                _creditLockServiceCustomerManager.PutLockStatus(internalRequest)
                    .Throws(new ServiceTaskCanceledException("Test Exception"));

                var response = await _externalController.PutAgentAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be(564);

                _mapper.Received(1).Map<PutLockStatusRequest>(request);
                _mapper.Received(1).Map(request.Body, internalRequest);

                _benefitChecker.Received(1).EnsureValidBenefitAsync().Wait();

                await _creditLockServiceCustomerManager.Received(1).PutLockStatus(internalRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "564"
                    && x.ResponseStatusDescription == MessageConstants.DownstreamTimeout
                    && x.RequestType == $"AGENT_SET_LOCK_{lockStatus}"
                    && x.RequestDt == new DateTime(2000, 12, 31, 23, 59, 59, 123)
                    && x.SalesforceUserId == "A123456798"));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.Invoked)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.ServiceTaskCanceledException)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.Complete)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.SyncCustomerPinningException)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                 Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.BenefitCheckFail)), null,
                 Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                 Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.BenefitsInvalidOperationException)), null,
                 Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Theory]
            [InlineData("ON")]
            [InlineData("OFF")]
            public async Task PutAgentRequest_ServiceUnavailableException_ReturnsStatusServiceUnavailable(string lockStatus)
            {
                var request = new PutStatusAgentRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4",
                    Body = new PutStatusAgentRequestBody()
                    {
                        Status = lockStatus,
                        SalesforceUserId = "A123456798"
                    }
                };

                var internalRequest = new PutLockStatusRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4",
                    LockStatus = true,
                    SalesForceUserId = "A123456798"
                };

                _mapper.Map<PutLockStatusRequest>(request)
                    .Returns(internalRequest);

                _mapper.Map(request.Body, internalRequest)
                    .Returns(internalRequest);

                _creditLockServiceCustomerManager.PutLockStatus(internalRequest)
                    .Throws(new ServiceUnavailableException("Test Exception"));

                var response = await _externalController.PutAgentAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.ServiceUnavailable);

                _mapper.Received(1).Map<PutLockStatusRequest>(request);
                _mapper.Received(1).Map(request.Body, internalRequest);

                _benefitChecker.Received(1).EnsureValidBenefitAsync().Wait();

                await _creditLockServiceCustomerManager.Received(1).PutLockStatus(internalRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "503"
                    && x.ResponseStatusDescription == "Service Unavailable"
                    && x.RequestType == $"AGENT_SET_LOCK_{lockStatus}"
                    && x.RequestDt == new DateTime(2000, 12, 31, 23, 59, 59, 123)
                    && x.SalesforceUserId == "A123456798"));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.Invoked)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.ServiceUnavailableException)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.Complete)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.CustomerNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.SyncCustomerPinningException)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                 Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.BenefitCheckFail)), null,
                 Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                 Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.BenefitsInvalidOperationException)), null,
                 Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Theory]
            [InlineData("ON")]
            [InlineData("OFF")]
            public async Task PutAgentRequest_CustomerNotFoundException_ReturnsStatusNotFound(string lockStatus)
            {
                var request = new PutStatusAgentRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4",
                    Body = new PutStatusAgentRequestBody()
                    {
                        Status = lockStatus,
                        SalesforceUserId = "A123456798"
                    }
                };

                var internalRequest = new PutLockStatusRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4",
                    LockStatus = true,
                    SalesForceUserId = "A123456798"
                };

                _mapper.Map<PutLockStatusRequest>(request)
                    .Returns(internalRequest);

                _mapper.Map(request.Body, internalRequest)
                    .Returns(internalRequest);

                _creditLockServiceCustomerManager.PutLockStatus(internalRequest)
                    .Throws(new CustomerNotFoundException("Test Exception"));

                var response = await _externalController.PutAgentAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be(404);

                _mapper.Received(1).Map<PutLockStatusRequest>(request);
                _mapper.Received(1).Map(request.Body, internalRequest);

                _benefitChecker.Received(1).EnsureValidBenefitAsync().Wait();

                await _creditLockServiceCustomerManager.Received(1).PutLockStatus(internalRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "404"
                    && x.ResponseStatusDescription == "VIP Customer is Not Found"
                    && x.RequestType == $"AGENT_SET_LOCK_{lockStatus}"
                    && x.RequestDt == new DateTime(2000, 12, 31, 23, 59, 59, 123)
                    && x.SalesforceUserId == "A123456798"));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.Invoked)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.CustomerNotFoundException)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.Complete)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.SyncCustomerPinningException)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                 Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.BenefitCheckFail)), null,
                 Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                 Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.BenefitsInvalidOperationException)), null,
                 Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Theory]
            [InlineData("ON")]
            [InlineData("OFF")]
            public async Task PutAgentRequest_SyncCustomerPinningException_ReturnsStatusNotFound(string lockStatus)
            {
                var request = new PutStatusAgentRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4",
                    Body = new PutStatusAgentRequestBody()
                    {
                        Status = lockStatus,
                        SalesforceUserId = "A123456798"
                    }
                };

                var internalRequest = new PutLockStatusRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4",
                    LockStatus = true,
                    SalesForceUserId = "A123456798"
                };

                _mapper.Map<PutLockStatusRequest>(request)
                    .Returns(internalRequest);

                _mapper.Map(request.Body, internalRequest)
                    .Returns(internalRequest);

                _creditLockServiceCustomerManager.PutLockStatus(internalRequest)
                    .Throws(new SyncCustomerPinningException("Test Exception"));

                var response = await _externalController.PutAgentAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be(409);

                _mapper.Received(1).Map<PutLockStatusRequest>(request);
                _mapper.Received(1).Map(request.Body, internalRequest);

                _benefitChecker.Received(1).EnsureValidBenefitAsync().Wait();

                await _creditLockServiceCustomerManager.Received(1).PutLockStatus(internalRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "409"
                    && x.ResponseStatusDescription == "Conflict - customer waiting to be pinned or pinning in process"
                    && x.RequestType == $"AGENT_SET_LOCK_{lockStatus}"
                    && x.RequestDt == new DateTime(2000, 12, 31, 23, 59, 59, 123)
                    && x.SalesforceUserId == "A123456798"));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.Invoked)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.SyncCustomerPinningException)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.Complete)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                 Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.BenefitCheckFail)), null,
                 Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                 Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.BenefitsInvalidOperationException)), null,
                 Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Theory]
            [InlineData("ON")]
            [InlineData("OFF")]
            public async Task PutAgentRequest_DownstreamAuthenticationException_ReturnsStat563(string lockStatus)
            {
                var request = new PutStatusAgentRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4",
                    Body = new PutStatusAgentRequestBody()
                    {
                        Status = lockStatus,
                        SalesforceUserId = "A123456798"
                    }
                };

                var internalRequest = new PutLockStatusRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4",
                    LockStatus = true,
                    SalesForceUserId = "A123456798"
                };

                _mapper.Map<PutLockStatusRequest>(request)
                    .Returns(internalRequest);

                _mapper.Map(request.Body, internalRequest)
                    .Returns(internalRequest);

                _creditLockServiceCustomerManager.PutLockStatus(internalRequest)
                    .Throws(new DownstreamAuthenticationException("Test Exception"));

                var response = await _externalController.PutAgentAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be(563);

                _mapper.Received(1).Map<PutLockStatusRequest>(request);
                _mapper.Received(1).Map(request.Body, internalRequest);

                _benefitChecker.Received(1).EnsureValidBenefitAsync().Wait();

                await _creditLockServiceCustomerManager.Received(1).PutLockStatus(internalRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "563"
                    && x.ResponseStatusDescription == "Downstream Service Authentication Failed"
                    && x.RequestType == $"AGENT_SET_LOCK_{lockStatus}"
                    && x.RequestDt == new DateTime(2000, 12, 31, 23, 59, 59, 123)
                    && x.SalesforceUserId == "A123456798"));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.Invoked)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.DownstreamAuthenticationException)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.Complete)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                 Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.BenefitCheckFail)), null,
                 Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                 Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.BenefitsInvalidOperationException)), null,
                 Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Theory]
            [InlineData("ON")]
            [InlineData("OFF")]
            public async Task PutAgentRequest_NoBenefitException_ReturnsForbidden(string lockStatus)
            {
                var request = new PutStatusAgentRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4",
                    Body = new PutStatusAgentRequestBody()
                    {
                        Status = lockStatus,
                        SalesforceUserId = "A123456798"
                    }
                };

                var internalRequest = new PutLockStatusRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4",
                    LockStatus = true,
                    SalesForceUserId = "A123456798"
                };

                _mapper.Map<PutLockStatusRequest>(request)
                    .Returns(internalRequest);

                _mapper.Map(request.Body, internalRequest)
                    .Returns(internalRequest);

                _benefitChecker
               .When(x => x.EnsureValidBenefitAsync())
               .Do(_ => throw new NoBenefitException("Test Exception", "X999"));

                var response = await _externalController.PutAgentAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.Forbidden);

                _mapper.DidNotReceive().Map<PutLockStatusRequest>(request);
                _mapper.DidNotReceive().Map(request.Body, internalRequest);

                _benefitChecker.Received(1).EnsureValidBenefitAsync().Wait();

                await _creditLockServiceCustomerManager.DidNotReceive().PutLockStatus(internalRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                    x.ResponseStatusCode == "403"
                    && x.ResponseStatusDescription == "Benefit could not be fulfilled"
                    && x.RequestType == $"AGENT_SET_LOCK_{lockStatus}"
                    && x.RequestDt == new DateTime(2000, 12, 31, 23, 59, 59, 123)
                    && x.SalesforceUserId == "A123456798"));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.Invoked)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.BenefitCheckFail)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.Complete)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                   Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.BenefitsInvalidOperationException)), null,
                   Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Theory]
            [InlineData("ON")]
            [InlineData("OFF")]
            public async Task PutAgentRequest_BenefitsInvalidOperationException_ReturnsInternalServerError(string lockStatus)
            {
                var request = new PutStatusAgentRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4",
                    Body = new PutStatusAgentRequestBody()
                    {
                        Status = lockStatus,
                        SalesforceUserId = "A123456798"
                    }
                };

                var internalRequest = new PutLockStatusRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4",
                    LockStatus = true,
                    SalesForceUserId = "A123456798"
                };

                _mapper.Map<PutLockStatusRequest>(request)
                    .Returns(internalRequest);

                _mapper.Map(request.Body, internalRequest)
                    .Returns(internalRequest);

                _benefitChecker
              .When(x => x.EnsureValidBenefitAsync())
              .Do(_ => throw new BenefitsInvalidOperationException("Upstream service subscriptions returned no data."));

                var response = await _externalController.PutAgentAsync(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.InternalServerError);

                _mapper.DidNotReceive().Map<PutLockStatusRequest>(request);
                _mapper.DidNotReceive().Map(request.Body, internalRequest);

                _benefitChecker.Received(1).EnsureValidBenefitAsync().Wait();

                await _creditLockServiceCustomerManager.DidNotReceive().PutLockStatus(internalRequest);

                await _messaging.Received(1).PublishEventAsync(EventName, Arg.Is<CreditLockEventContent>(x =>
                   x.ResponseStatusCode == "500"
                   && x.ResponseStatusDescription == "Upstream service subscriptions returned no data."
                   && x.RequestType == $"AGENT_SET_LOCK_{lockStatus}"
                   && x.RequestDt == new DateTime(2000, 12, 31, 23, 59, 59, 123)
                   && x.SalesforceUserId == "A123456798"));

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.Invoked)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.BenefitsInvalidOperationException)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.Complete)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.UnhandledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                   Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.PutAgent.BenefitCheckFail)), null,
                   Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

        }

        public class GetExternalController : ExternalControllerTests
        {
            public static IEnumerable<object[]> LogInformationMessages()
            {
                yield return new object[]
                {
                    LogEventNames.ExternalController.Get.Invoked
                };

                yield return new object[]
                {
                    LogEventNames.ExternalController.Get.Complete
                };
            }

            [Theory]
            [MemberData(nameof(LogInformationMessages))]
            public async Task HappyPathInformationLogged(string information)
            {
                var request = new GetStatusRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4"
                };

                var responseInternal = new InternalResponseModel.GetCustomerResponse
                {
                    LockStatus = "ON"
                };

                var expectedResponse = new ExternalModel.GetLockStatusResponse
                {
                    LockStatus = "ON"
                };

                var getLockStatusRequest = new GetCustomerRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4"
                };

                _mapper.Map<GetCustomerRequest>(request)
                    .Returns(getLockStatusRequest);

                _mapper.Map<ExternalModel.GetLockStatusResponse>(responseInternal)
                    .Returns(expectedResponse);

                _creditLockServiceCustomerManager.GetCustomerAsync(getLockStatusRequest)
                    .Returns(responseInternal);

                var response = await _externalController.Get(request) as ObjectResult;

                response.Should().BeOfType<ApiResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.OK);

                response?.Value.Should().BeEquivalentTo(expectedResponse);

                _mapper.Received(1).Map<GetCustomerRequest>(request);
                _mapper.Received(1).Map<ExternalModel.GetLockStatusResponse>(responseInternal);

                _benefitChecker.Received(1).EnsureValidBenefitAsync().Wait();

                await _creditLockServiceCustomerManager.Received(1).GetCustomerAsync(getLockStatusRequest);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(information)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.CustomerNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.AutoMapperMappingException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.BenefitCheckFail)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.BenefitsInvalidOperationException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task GetRequest_ModelStateInvalid_ReturnStatusBadRequest()
            {
                var request = new GetStatusRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4"
                };

                _externalController.ModelState.AddModelError("Test", "TestError");

                var response = await _externalController.Get(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.BadRequest);

                _mapper.DidNotReceive().Map<GetCustomerRequest>(Arg.Any<GetStatusRequest>());
                _mapper.DidNotReceive().Map<ExternalModel.GetLockStatusResponse>(Arg.Any<InternalResponseModel.GetCustomerResponse>());
                _benefitChecker.DidNotReceive().EnsureValidBenefitAsync().Wait();

                await _creditLockServiceCustomerManager.DidNotReceive().GetCustomerAsync(Arg.Any<GetCustomerRequest>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.Invoked)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.Complete)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.CustomerNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.AutoMapperMappingException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.BenefitCheckFail)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.BenefitsInvalidOperationException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task GetRequest_Valid_ReturnsStatusOk()
            {
                var request = new GetStatusRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4"
                };

                var responseInternal = new InternalResponseModel.GetCustomerResponse
                {
                    LockStatus = "Y"
                };

                var expectedResponse = new ExternalModel.GetLockStatusResponse
                {
                    LockStatus = "ON"
                };

                var getLockStatusRequest = new GetCustomerRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4"
                };

                _mapper.Map<GetCustomerRequest>(request)
                    .Returns(getLockStatusRequest);

                _mapper.Map<ExternalModel.GetLockStatusResponse>(responseInternal)
                    .Returns(expectedResponse);

                _creditLockServiceCustomerManager.GetCustomerAsync(getLockStatusRequest)
                    .Returns(responseInternal);

                var response = await _externalController.Get(request) as ObjectResult;

                response.Should().BeOfType<ApiResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.OK);

                response?.Value.Should().BeEquivalentTo(expectedResponse);

                _mapper.Received(1).Map<GetCustomerRequest>(request);
                _mapper.Received(1).Map<ExternalModel.GetLockStatusResponse>(responseInternal);

                _benefitChecker.Received(1).EnsureValidBenefitAsync().Wait();

                await _creditLockServiceCustomerManager.Received(1).GetCustomerAsync(getLockStatusRequest);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.Invoked)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.Complete)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.CustomerNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.AutoMapperMappingException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.BenefitCheckFail)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.BenefitsInvalidOperationException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task GetRequest_ThrowsException_ReturnsInternalServerError()
            {
                var request = new GetStatusRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4"
                };

                var responseInternal = new InternalResponseModel.GetLockStatusResponse
                {
                    LockStatus = "ON"
                };

                var expectedResponse = new ExternalModel.GetLockStatusResponse
                {
                    LockStatus = "ON"
                };

                var getLockStatusRequest = new GetCustomerRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4"
                };

                _mapper.Map<GetCustomerRequest>(request)
                    .Returns(getLockStatusRequest);

                _mapper.Map<ExternalModel.GetLockStatusResponse>(responseInternal)
                    .Returns(expectedResponse);

                _creditLockServiceCustomerManager.GetCustomerAsync(getLockStatusRequest)
                    .Throws(new InvalidOperationException("Test Exception"));

                var response = await _externalController.Get(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.InternalServerError);

                _mapper.Received(1).Map<GetCustomerRequest>(request);
                _mapper.DidNotReceive().Map<ExternalModel.GetLockStatusResponse>(Arg.Any<InternalResponseModel.GetLockStatusResponse>());

                _benefitChecker.Received(1).EnsureValidBenefitAsync().Wait();

                await _creditLockServiceCustomerManager.Received(1).GetCustomerAsync(getLockStatusRequest);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.Invoked)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.UnhandledException)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.Complete)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.ModelStateFailed)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.CustomerNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.AutoMapperMappingException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.BenefitCheckFail)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.BenefitsInvalidOperationException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task GetRequest_DownstreamMaintenanceException_ReturnsStatus561()
            {
                var request = new GetStatusRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4"
                };

                var responseInternal = new InternalResponseModel.GetLockStatusResponse
                {
                    LockStatus = "ON"
                };

                var expectedResponse = new ExternalModel.GetLockStatusResponse
                {
                    LockStatus = "ON"
                };

                var getLockStatusRequest = new GetCustomerRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4"
                };

                _mapper.Map<GetCustomerRequest>(request)
                    .Returns(getLockStatusRequest);

                _mapper.Map<ExternalModel.GetLockStatusResponse>(responseInternal)
                    .Returns(expectedResponse);

                _creditLockServiceCustomerManager.GetCustomerAsync(getLockStatusRequest)
                    .Throws(new DownstreamMaintenanceException("Test Exception"));

                var response = await _externalController.Get(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be(DownstreamMaintenanceStatusCode);

                response?.StatusCode.Should().Be(DownstreamMaintenanceStatusCode);

                _mapper.Received(1).Map<GetCustomerRequest>(request);
                _mapper.DidNotReceive().Map<ExternalModel.GetLockStatusResponse>(Arg.Any<InternalResponseModel.GetLockStatusResponse>());

                _benefitChecker.Received(1).EnsureValidBenefitAsync().Wait();

                await _creditLockServiceCustomerManager.Received(1).GetCustomerAsync(getLockStatusRequest);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.Invoked)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.Complete)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.CustomerNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.OktaTokenNullException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.OktaTokenException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.AutoMapperMappingException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.BenefitCheckFail)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.BenefitsInvalidOperationException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task GetRequest_CustomerNotFoundException_ReturnsStatusNotFound()
            {

                var request = new GetStatusRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4"
                };

                var responseInternal = new InternalResponseModel.GetLockStatusResponse
                {
                    LockStatus = "ON"
                };

                var expectedResponse = new ExternalModel.GetLockStatusResponse
                {
                    LockStatus = "ON"
                };

                var getLockStatusRequest = new GetCustomerRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4"
                };

                _mapper.Map<GetCustomerRequest>(request)
                    .Returns(getLockStatusRequest);

                _mapper.Map<ExternalModel.GetLockStatusResponse>(responseInternal)
                    .Returns(expectedResponse);

                _creditLockServiceCustomerManager.GetCustomerAsync(getLockStatusRequest)
                    .Throws(new CustomerNotFoundException("Test Exception"));

                var response = await _externalController.Get(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.NotFound);

                _mapper.Received(1).Map<GetCustomerRequest>(request);
                _mapper.DidNotReceive().Map<ExternalModel.GetLockStatusResponse>(Arg.Any<InternalResponseModel.GetLockStatusResponse>());

                _benefitChecker.Received(1).EnsureValidBenefitAsync().Wait();

                await _creditLockServiceCustomerManager.Received(1).GetCustomerAsync(getLockStatusRequest);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.Invoked)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.Complete)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.CustomerNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.AutoMapperMappingException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.BenefitCheckFail)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.BenefitsInvalidOperationException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task GetRequest_OktaTokenNullException_ReturnsBadGateway()
            {
                var request = new GetStatusRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4"
                };

                var responseInternal = new InternalResponseModel.GetLockStatusResponse
                {
                    LockStatus = "ON"
                };

                var expectedResponse = new ExternalModel.GetLockStatusResponse
                {
                    LockStatus = "ON"
                };

                var getLockStatusRequest = new GetCustomerRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4"
                };

                _mapper.Map<GetCustomerRequest>(request)
                    .Returns(getLockStatusRequest);

                _mapper.Map<ExternalModel.GetLockStatusResponse>(responseInternal)
                    .Returns(expectedResponse);

                _creditLockServiceCustomerManager.GetCustomerAsync(getLockStatusRequest)
                    .Throws(new OktaTokenNullException("Test Exception"));

                var response = await _externalController.Get(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.BadGateway);

                _mapper.Received(1).Map<GetCustomerRequest>(request);
                _mapper.DidNotReceive().Map<ExternalModel.GetLockStatusResponse>(Arg.Any<InternalResponseModel.GetLockStatusResponse>());

                _benefitChecker.Received(1).EnsureValidBenefitAsync().Wait();

                await _creditLockServiceCustomerManager.Received(1).GetCustomerAsync(getLockStatusRequest);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.Invoked)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.OktaTokenNullException)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.Complete)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.CustomerNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.AutoMapperMappingException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.BenefitCheckFail)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.BenefitsInvalidOperationException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task GetRequest_OktaException_ReturnsBadGateway()
            {
                var request = new GetStatusRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4"
                };

                var responseInternal = new InternalResponseModel.GetLockStatusResponse
                {
                    LockStatus = "ON"
                };

                var expectedResponse = new ExternalModel.GetLockStatusResponse
                {
                    LockStatus = "ON"
                };

                var getLockStatusRequest = new GetCustomerRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4"
                };

                _mapper.Map<GetCustomerRequest>(request)
                    .Returns(getLockStatusRequest);

                _mapper.Map<ExternalModel.GetLockStatusResponse>(responseInternal)
                    .Returns(expectedResponse);

                _creditLockServiceCustomerManager.GetCustomerAsync(getLockStatusRequest)
                    .Throws(new OktaException("Test Exception"));

                var response = await _externalController.Get(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.BadGateway);

                _mapper.Received(1).Map<GetCustomerRequest>(request);
                _mapper.DidNotReceive().Map<ExternalModel.GetLockStatusResponse>(Arg.Any<InternalResponseModel.GetLockStatusResponse>());

                _benefitChecker.Received(1).EnsureValidBenefitAsync().Wait();

                await _creditLockServiceCustomerManager.Received(1).GetCustomerAsync(getLockStatusRequest);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.Invoked)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.OktaTokenException)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.Complete)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.CustomerNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.ServiceUnavailableException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.AutoMapperMappingException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.BenefitCheckFail)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.BenefitsInvalidOperationException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task GetRequest_ServiceUnavailableException_ReturnsServiceUnavailable()
            {
                var request = new GetStatusRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4"
                };

                var responseInternal = new InternalResponseModel.GetLockStatusResponse
                {
                    LockStatus = "ON"
                };

                var expectedResponse = new ExternalModel.GetLockStatusResponse
                {
                    LockStatus = "ON"
                };

                var getLockStatusRequest = new GetCustomerRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4"
                };

                _mapper.Map<GetCustomerRequest>(request)
                    .Returns(getLockStatusRequest);

                _mapper.Map<ExternalModel.GetLockStatusResponse>(responseInternal)
                    .Returns(expectedResponse);

                _creditLockServiceCustomerManager.GetCustomerAsync(getLockStatusRequest)
                    .Throws(new ServiceUnavailableException("Test Exception"));

                var response = await _externalController.Get(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.ServiceUnavailable);

                _mapper.Received(1).Map<GetCustomerRequest>(request);
                _mapper.DidNotReceive().Map<ExternalModel.GetLockStatusResponse>(Arg.Any<InternalResponseModel.GetLockStatusResponse>());

                _benefitChecker.Received(1).EnsureValidBenefitAsync().Wait();

                await _creditLockServiceCustomerManager.Received(1).GetCustomerAsync(getLockStatusRequest);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.Invoked)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.ServiceUnavailableException)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.Complete)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.CustomerNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.AutoMapperMappingException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.BenefitCheckFail)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.BenefitsInvalidOperationException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task GetRequest_HttpServiceRequestException_ReturnsInternalServerError()
            {
                var request = new GetStatusRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4"
                };

                var responseInternal = new InternalResponseModel.GetLockStatusResponse
                {
                    LockStatus = "ON"
                };

                var expectedResponse = new ExternalModel.GetLockStatusResponse
                {
                    LockStatus = "ON"
                };

                var getLockStatusRequest = new GetCustomerRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4"
                };

                _mapper.Map<GetCustomerRequest>(request)
                    .Returns(getLockStatusRequest);

                _mapper.Map<ExternalModel.GetLockStatusResponse>(responseInternal)
                    .Returns(expectedResponse);

                _creditLockServiceCustomerManager.GetCustomerAsync(getLockStatusRequest)
                    .Throws(new HttpServiceRequestException("Test Exception"));

                var response = await _externalController.Get(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.InternalServerError);

                _mapper.Received(1).Map<GetCustomerRequest>(request);
                _mapper.DidNotReceive().Map<ExternalModel.GetLockStatusResponse>(Arg.Any<InternalResponseModel.GetLockStatusResponse>());

                _benefitChecker.Received(1).EnsureValidBenefitAsync().Wait();

                await _creditLockServiceCustomerManager.Received(1).GetCustomerAsync(getLockStatusRequest);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.Invoked)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.HttpServiceRequestException)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.Complete)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.CustomerNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.AutoMapperMappingException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.BenefitCheckFail)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.BenefitsInvalidOperationException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task GetRequest_ServiceTaskCanceledException_ReturnsStatusCode564()
            {
                var request = new GetStatusRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4"
                };

                var responseInternal = new InternalResponseModel.GetLockStatusResponse
                {
                    LockStatus = "ON"
                };

                var expectedResponse = new ExternalModel.GetLockStatusResponse
                {
                    LockStatus = "ON"
                };

                var getLockStatusRequest = new GetCustomerRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4"
                };

                _mapper.Map<GetCustomerRequest>(request)
                    .Returns(getLockStatusRequest);

                _mapper.Map<ExternalModel.GetLockStatusResponse>(responseInternal)
                    .Returns(expectedResponse);

                _creditLockServiceCustomerManager.GetCustomerAsync(getLockStatusRequest)
                    .Throws(new ServiceTaskCanceledException("Test Exception"));

                var response = await _externalController.Get(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be(564);

                _mapper.Received(1).Map<GetCustomerRequest>(request);
                _mapper.DidNotReceive().Map<ExternalModel.GetLockStatusResponse>(Arg.Any<InternalResponseModel.GetLockStatusResponse>());

                _benefitChecker.Received(1).EnsureValidBenefitAsync().Wait();

                await _creditLockServiceCustomerManager.Received(1).GetCustomerAsync(getLockStatusRequest);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.Invoked)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.ServiceTaskCanceledException)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.Complete)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.CustomerNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.AutoMapperMappingException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.BenefitCheckFail)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.BenefitsInvalidOperationException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task GetRequest_AutoMapperMappingException_ReturnsInternalServerError()
            {
                var request = new GetStatusRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4"
                };

                var responseInternal = new InternalResponseModel.GetCustomerResponse
                {
                    LockStatus = "Y"
                };

                var getLockStatusRequest = new GetCustomerRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4"
                };

                _mapper.Map<GetCustomerRequest>(request)
                    .Returns(getLockStatusRequest);

                var expectedInnerEx = new InvalidOperationException("Test Message");
                var expectedEx = new AutoMapperMappingException("Test Outer Message", expectedInnerEx);

                _mapper.Map<ExternalModel.GetLockStatusResponse>(responseInternal)
                    .Throws(expectedEx);

                _creditLockServiceCustomerManager.GetCustomerAsync(getLockStatusRequest)
                    .Returns(responseInternal);

                var response = await _externalController.Get(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be((int)HttpStatusCode.InternalServerError);

                await _creditLockServiceCustomerManager.Received(1).GetCustomerAsync(getLockStatusRequest);

                _mapper.Received(1).Map<GetCustomerRequest>(request);
                _mapper.Received(1).Map<ExternalModel.GetLockStatusResponse>(responseInternal);

                _benefitChecker.Received(1).EnsureValidBenefitAsync().Wait();

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.Invoked)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.ServiceUnavailableException)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.Complete)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.CustomerNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.ServiceTaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.HttpServiceRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.AutoMapperMappingException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.BenefitCheckFail)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.BenefitsInvalidOperationException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task GetRequest_DownstreamAuthenticationException_ReturnStatusCode563()
            {
                var request = new GetStatusRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4"
                };

                var responseInternal = new InternalResponseModel.GetLockStatusResponse
                {
                    LockStatus = "ON"
                };

                var expectedResponse = new ExternalModel.GetLockStatusResponse
                {
                    LockStatus = "ON"
                };

                var getLockStatusRequest = new GetCustomerRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4"
                };

                _mapper.Map<GetCustomerRequest>(request)
                    .Returns(getLockStatusRequest);

                _mapper.Map<ExternalModel.GetLockStatusResponse>(responseInternal)
                    .Returns(expectedResponse);

                _creditLockServiceCustomerManager.GetCustomerAsync(getLockStatusRequest)
                    .Throws(new DownstreamAuthenticationException("Test Exception"));

                var response = await _externalController.Get(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be(563);

                _mapper.Received(1).Map<GetCustomerRequest>(request);
                _mapper.DidNotReceive().Map<ExternalModel.GetLockStatusResponse>(Arg.Any<InternalResponseModel.GetLockStatusResponse>());

                _benefitChecker.Received(1).EnsureValidBenefitAsync().Wait();

                await _creditLockServiceCustomerManager.Received(1).GetCustomerAsync(getLockStatusRequest);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.Invoked)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.DownstreamAuthenticationException)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.Complete)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.CustomerNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.AutoMapperMappingException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.BenefitCheckFail)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.BenefitsInvalidOperationException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task GetRequest_NoBenefitException_ReturnStatusCode403()
            {
                var request = new GetStatusRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4"
                };

                var responseInternal = new InternalResponseModel.GetLockStatusResponse
                {
                    LockStatus = "ON"
                };

                var expectedResponse = new ExternalModel.GetLockStatusResponse
                {
                    LockStatus = "ON"
                };

                var getLockStatusRequest = new GetCustomerRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4"
                };

                _mapper.Map<GetCustomerRequest>(request)
                    .Returns(getLockStatusRequest);

                _mapper.Map<ExternalModel.GetLockStatusResponse>(responseInternal)
                    .Returns(expectedResponse);

                _benefitChecker
               .When(x => x.EnsureValidBenefitAsync())
               .Do(_ => throw new NoBenefitException("Test Exception", "X999"));

                var response = await _externalController.Get(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be(403);

                _mapper.DidNotReceive().Map<GetCustomerRequest>(request);
                _mapper.DidNotReceive().Map<ExternalModel.GetLockStatusResponse>(Arg.Any<InternalResponseModel.GetLockStatusResponse>());

                _benefitChecker.Received(1).EnsureValidBenefitAsync().Wait();

                await _creditLockServiceCustomerManager.DidNotReceive().GetCustomerAsync(getLockStatusRequest);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.Invoked)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.DownstreamAuthenticationException)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.Complete)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.CustomerNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.AutoMapperMappingException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.BenefitCheckFail)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.BenefitsInvalidOperationException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task GetRequest_BenefitsInvalidOperationException_ReturnStatusCode500()
            {
                var request = new GetStatusRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4"
                };

                var responseInternal = new InternalResponseModel.GetLockStatusResponse
                {
                    LockStatus = "ON"
                };

                var expectedResponse = new ExternalModel.GetLockStatusResponse
                {
                    LockStatus = "ON"
                };

                var getLockStatusRequest = new GetCustomerRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4"
                };

                _mapper.Map<GetCustomerRequest>(request)
                    .Returns(getLockStatusRequest);

                _mapper.Map<ExternalModel.GetLockStatusResponse>(responseInternal)
                    .Returns(expectedResponse);

                _benefitChecker
                .When(x => x.EnsureValidBenefitAsync())
                .Do(_ => throw new BenefitsInvalidOperationException());

                var response = await _externalController.Get(request) as ObjectResult;

                response.Should().BeOfType<ApiErrorResult>()
                    .Which.StatusCode.Should().Be(500);

                _mapper.DidNotReceive().Map<GetCustomerRequest>(request);
                _mapper.DidNotReceive().Map<ExternalModel.GetLockStatusResponse>(Arg.Any<InternalResponseModel.GetLockStatusResponse>());

                _benefitChecker.Received(1).EnsureValidBenefitAsync().Wait();

                await _creditLockServiceCustomerManager.DidNotReceive().GetCustomerAsync(getLockStatusRequest);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.Invoked)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.DownstreamAuthenticationException)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.Complete)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.CustomerNotFoundException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.DownstreamMaintenanceException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.AutoMapperMappingException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(Arg.Any<LogLevel>(), Arg.Any<EventId>(),
                   Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.BenefitCheckFail)), null,
                   Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.ExternalController.Get.BenefitsInvalidOperationException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }
        }
    }
}