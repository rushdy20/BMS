﻿using AutoMapper;
using Experian.HttpClient.Services.Customers.Exception;
using Experian.HttpClient.Services.Customers.Internal.GET;
using Experian.HttpClient.Services.Customers.Models.External;
using EXPN.DataLayer.CreditLockService.Customers;
using EXPN.DataLayer.CreditLockService.Customers.Constants;
using EXPN.Models.CreditLockService.Internal.Get.Response;
using FluentAssertions;
using Microsoft.Extensions.Logging;
using NSubstitute;
using NSubstitute.ExceptionExtensions;
using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using Xunit;

namespace EXPN.UnitTest.CreditLockService.DataLayer.Customers
{
    public class CustomersClientProxyTests
    {
        private readonly ILogger<CustomersClientProxy> _logger;
        private readonly IGetCustomerProfile _getCustomerProfile;
        private readonly IMapper _mapper;
        private readonly ICustomersClientProxy _customersClientProxy;

        public CustomersClientProxyTests()
        {
            _logger = Substitute.For<ILogger<CustomersClientProxy>>();
            _getCustomerProfile = Substitute.For<IGetCustomerProfile>();
            _mapper = Substitute.For<IMapper>();

            _customersClientProxy = new CustomersClientProxy(_logger, _getCustomerProfile, _mapper);
        }

        public class Constructor
        {
            public static IEnumerable<object[]> NullParameters()
            {
                yield return new object[]
                {
                    null,
                    Substitute.For<IGetCustomerProfile>(),
                    Substitute.For<IMapper>(),
                    "logger"
                };

                yield return new object[]
                {
                    Substitute.For<ILogger<CustomersClientProxy>>(),
                    null,
                    Substitute.For<IMapper>(),
                    "getCustomerProfile"
                };

                yield return new object[]
                {
                    Substitute.For<ILogger<CustomersClientProxy>>(),
                    Substitute.For<IGetCustomerProfile>(),
                    null,
                    "mapper"
                };
            }

            [Theory]
            [MemberData(nameof(NullParameters))]
            public void NullRequiredConstructorParameter_ThrowsArgumentNullException(
                ILogger<CustomersClientProxy> logger,
                IGetCustomerProfile getCustomerProfile,
                IMapper mapper,
                string expectedErrorParameter
            )
            {
                var action = () =>
                {
                    var unused = new CustomersClientProxy(logger, getCustomerProfile, mapper);
                };

                action.Should()
                    .Throw<ArgumentNullException>()
                    .Where(x => x.ParamName == expectedErrorParameter);
            }
        }

        public class GetCustomerProfile : CustomersClientProxyTests
        {
            public static IEnumerable<object[]> GetCustomerProfileArgumentException()
            {
                yield return new object[]
                {
                    null
                };

                yield return new object[]
                {
                    string.Empty
                };

                yield return new object[]
                {
                    string.Empty.PadLeft(100)
                };
            }

            [Theory]
            [MemberData(nameof(GetCustomerProfileArgumentException))]
            public void GetCustomerProfileCustomerIdInvalid_ThrowsArgumentException(string customerId)
            {
                Func<Task> task = async () =>
                {
                    await _customersClientProxy.GetCustomerProfile(customerId);
                };

                task.Should()
                    .Throw<ArgumentException>()
                    .Where(x => x.Message == "customerId cannot be null or whitespace (Parameter 'customerId')");
            }

            [Fact]
            public async Task GetCustomerProfile_ValidCustomerId_HappyPath_Success()
            {
                const string customerId = "ABC";

                var customerProfile = new CustomerProfile
                {
                    CustomerId = customerId
                };

                _getCustomerProfile.GetAsync(customerId)
                    .Returns(customerProfile);

                var getResponseCustomerProfile = new GetResponseCustomerProfile
                {
                    CustomerId = customerId
                };

                _mapper.Map<GetResponseCustomerProfile>(customerProfile)
                    .Returns(getResponseCustomerProfile);

                var response = await _customersClientProxy.GetCustomerProfile(customerId);

                response.Should().Be(getResponseCustomerProfile);

                await _getCustomerProfile.Received(1).GetAsync(customerId);

                _mapper.Received(1).Map<GetResponseCustomerProfile>(customerProfile);

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.Customers.GetCustomerProfile.CustomerNotFound)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.Customers.GetCustomerProfile.BadRequest)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.Customers.GetCustomerProfile.UnsuccessfulRequest)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.Customers.GetCustomerProfile.RequestException)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task GetCustomerProfile_ValidCustomerId_CustomersExceptionNotFound_ThrowNoException_returnNull()
            {
                const string customerId = "ABC";

                var ex = new CustomersException("Test Message", (int)HttpStatusCode.NotFound, null);

                _getCustomerProfile.GetAsync(customerId)
                    .Throws(ex);

               var customerProfile = await _customersClientProxy.GetCustomerProfile(customerId);
               customerProfile.Should().BeNull();
           
                await _getCustomerProfile.Received(1).GetAsync(customerId);

                _mapper.DidNotReceive().Map<GetResponseCustomerProfile>(Arg.Any<CustomerProfile>());
                
                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.Customers.GetCustomerProfile.BadRequest)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.Customers.GetCustomerProfile.UnsuccessfulRequest)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.Customers.GetCustomerProfile.RequestException)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task GetCustomerProfile_ValidCustomerId_ThrowsCustomersException_StatusCodeBadRequest_Failure()
            {
                const string customerId = "ABC";

                var ex = new CustomersException("Test Message", (int)HttpStatusCode.BadRequest, null);

                _getCustomerProfile.GetAsync(customerId)
                    .Throws(ex);

                Func<Task> task = async () =>
                {
                    await _customersClientProxy.GetCustomerProfile(customerId);
                };

                task.Should()
                    .Throw<CustomersException>()
                    .WithMessage("Test Message")
                    .Where(x => x.StatusCode == (int)HttpStatusCode.BadRequest);

                await _getCustomerProfile.Received(1).GetAsync(customerId);

                _mapper.DidNotReceive().Map<GetResponseCustomerProfile>(Arg.Any<CustomerProfile>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.Customers.GetCustomerProfile.CustomerNotFound)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
             
                _logger.Received(1).Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.Customers.GetCustomerProfile.UnsuccessfulRequest)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.Customers.GetCustomerProfile.RequestException)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task GetCustomerProfile_ValidCustomerId_ThrowsCustomersException_StatusCodeUnsuccessfulRequest_Failure()
            {
                const string customerId = "ABC";

                var ex = new CustomersException("Test Message", (int)HttpStatusCode.ServiceUnavailable, null);

                _getCustomerProfile.GetAsync(customerId)
                    .Throws(ex);

                var task = async () =>
                {
                    await _customersClientProxy.GetCustomerProfile(customerId);
                };

                task.Should()
                    .Throw<CustomersException>()
                    .WithMessage("Test Message")
                    .Where(x => x.StatusCode == (int)HttpStatusCode.ServiceUnavailable);

                await _getCustomerProfile.Received(1).GetAsync(customerId);

                _mapper.DidNotReceive().Map<GetResponseCustomerProfile>(Arg.Any<CustomerProfile>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.Customers.GetCustomerProfile.CustomerNotFound)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.Customers.GetCustomerProfile.BadRequest)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.Customers.GetCustomerProfile.UnsuccessfulRequest)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.Customers.GetCustomerProfile.RequestException)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }
        }
    }
}