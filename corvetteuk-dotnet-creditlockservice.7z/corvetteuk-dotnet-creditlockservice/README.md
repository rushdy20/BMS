# CreditLock Service

## Overview
This service exposes endpoints to allow customers to Lock or Unlock their credit file.

## Copyright Licence
Copyright © 2021, Experian Ltd. All rights reserved.