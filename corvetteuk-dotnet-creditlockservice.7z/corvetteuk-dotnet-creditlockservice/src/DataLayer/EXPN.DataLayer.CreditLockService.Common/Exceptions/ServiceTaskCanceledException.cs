﻿using System;
using System.Runtime.Serialization;

namespace EXPN.DataLayer.CreditLockService.Common.Exceptions
{
    [Serializable]
   public class ServiceTaskCanceledException : Exception
    {
        protected ServiceTaskCanceledException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }

        public ServiceTaskCanceledException()
        {
        }

        public ServiceTaskCanceledException(string message)
            : base(message)
        {
        }

        public ServiceTaskCanceledException(string message, Exception innerException)
            : base(message, innerException)
        {
        }
    }
}