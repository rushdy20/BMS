﻿
namespace EXPN.Models.CreditLockService.Internal.Delete.Request
{
 public  class DeleteCustomerRequest
    {
        public string CustomerId { get; set; }
        public string CustomerNumber { get; set; }
        public string IdpRefId { get; set; }
        public string TenantId { get; set; }
    }
}