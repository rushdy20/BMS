﻿using System;
using System.Runtime.Serialization;

namespace EXPN.DataLayer.CreditLockService.Common.Exceptions
{
    [Serializable]
    public class CustomerGetRequestException : Exception
    {
        protected CustomerGetRequestException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }

        public CustomerGetRequestException()
        {
        }

        public CustomerGetRequestException(string message)
            : base(message)
        {
        }

        public CustomerGetRequestException(string message, Exception innerException)
            : base(message, innerException)
        {
        }
    }
}