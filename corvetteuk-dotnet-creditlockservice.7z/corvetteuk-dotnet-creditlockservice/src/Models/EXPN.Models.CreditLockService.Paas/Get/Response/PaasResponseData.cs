﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EXPN.Models.CreditLockService.Paas.Get.Response
{
  public class PaasResponseData
    {
        public IEnumerable<GetCustomerResponse> Data { get; set; }
    }
}
