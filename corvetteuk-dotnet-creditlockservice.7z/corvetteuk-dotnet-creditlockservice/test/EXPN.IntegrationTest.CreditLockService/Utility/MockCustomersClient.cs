﻿using Experian.HttpClient.Services.Customers.Exception;
using Experian.HttpClient.Services.Customers.Internal.GET;
using Experian.HttpClient.Services.Customers.Models.External;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace EXPN.IntegrationTest.CreditLockService.Utility
{
    public class MockCustomersClient : IGetCustomerProfile
    {
        public Task<CustomerProfile> GetAsync(string customerId)
        {
            var testCaseNotFound = new CustomerProfile
            {
                CustomerId = customerId,
                DOB = "1980/12/25",
                IconRef = "12345404",
                CustomerNumber = "12345404"
            };

            var testCaseDownstreamMaintenance = new CustomerProfile
            {
                CustomerId = customerId,
                DOB = "1980/12/25",
                IconRef = "1234561",
                CustomerNumber = "1234561"
            };

            var happyPathTestCase = new CustomerProfile
            {
                CustomerId = customerId,
                DOB = "1980/12/25",
                IconRef = "1234567a",
                CustomerNumber = "1234567a"
            };

            var testServiceDown = new CustomerProfile
            {
                CustomerId = customerId,
                DOB = "1980/12/25",
                IconRef = "1234503",
                CustomerNumber = "1234503"
            };

            var GetLockStatusTest1 = new CustomerProfile
            {
                CustomerId = customerId,
                DOB = "1980/12/25",
                IconRef = "1234501",
                CustomerNumber = "1234501"
            };

            var GetLockStatusTest2 = new CustomerProfile
            {
                CustomerId = customerId,
                DOB = "1980/12/25",
                IconRef = "1234502",
                CustomerNumber = "1234502"
            };

            var GetLockStatusTest3 = new CustomerProfile
            {
                CustomerId = customerId,
                DOB = "1980/12/25",
                IconRef = "1234513",
                CustomerNumber = "1234513"
            };

            var GetLockStatusTest4 = new CustomerProfile
            {
                CustomerId = customerId,
                DOB = "1980/12/25",
                IconRef = "1234504",
                CustomerNumber = "1234504"
            };

            var GetLockStatusTest5 = new CustomerProfile
            {
                CustomerId = customerId,
                DOB = "1980/12/25",
                IconRef = "1234505",
                CustomerNumber = "1234505"
            };

            var GetLockStatusTest6 = new CustomerProfile
            {
                CustomerId = customerId,
                DOB = "1980/12/25",
                IconRef = "1234506",
                CustomerNumber = "1234506"
            };

            var GetLockStatusTest7 = new CustomerProfile
            {
                CustomerId = customerId,
                DOB = "1980/12/25",
                IconRef = "1234507",
                CustomerNumber = "1234507"
            };

            var GetLockStatusTest8 = new CustomerProfile
            {
                CustomerId = customerId,
                DOB = "1980/12/25",
                IconRef = "1234508",
                CustomerNumber = "1234508"
            };

            var GetLockStatusTest9 = new CustomerProfile
            {
                CustomerId = customerId,
                DOB = "1980/12/25",
                IconRef = "1234509",
                CustomerNumber = "1234509"
            };

            var GetLockStatusTest10 = new CustomerProfile
            {
                CustomerId = customerId,
                DOB = "1980/12/25",
                IconRef = "1234510",
                CustomerNumber = "1234510"
            };

            var GetLockStatus_Off_Pinning_Problem_Test1 = new CustomerProfile
            {
                CustomerId = customerId,
                DOB = "1980/12/25",
                IconRef = "1234601",
                CustomerNumber = "1234601"
            };

            var GetLockStatus_Off_Pinning_Problem_Test2 = new CustomerProfile
            {
                CustomerId = customerId,
                DOB = "1980/12/25",
                IconRef = "1234602",
                CustomerNumber = "1234602"
            };

            var GetLockStatus_Off_Pinning_Problem_Test3 = new CustomerProfile
            {
                CustomerId = customerId,
                DOB = "1980/12/25",
                IconRef = "1234603",
                CustomerNumber = "1234603"
            };

            var GetLockStatus_Off_Pinning_Problem_Test4 = new CustomerProfile
            {
                CustomerId = customerId,
                DOB = "1980/12/25",
                IconRef = "1234604",
                CustomerNumber = "1234604"
            };

            var GetLockStatus_Off_Pinning_Problem_Test5 = new CustomerProfile
            {
                CustomerId = customerId,
                DOB = "1980/12/25",
                IconRef = "1234605",
                CustomerNumber = "1234605"
            };

            var GetLockStatus_Off_Pinning_Problem_Test6 = new CustomerProfile
            {
                CustomerId = customerId,
                DOB = "1980/12/25",
                IconRef = "1234606",
                CustomerNumber = "1234606"
            };

            var GetLockStatus_Off_Pinning_Problem_Test7 = new CustomerProfile
            {
                CustomerId = customerId,
                DOB = "1980/12/25",
                IconRef = "1234607",
                CustomerNumber = "1234607"
            };

            var GetLockStatus_Off_Pinning_Update_Test1 = new CustomerProfile
            {
                CustomerId = customerId,
                DOB = "1980/12/25",
                IconRef = "1234701",
                CustomerNumber = "1234701"
            };

            var GetLockStatus_Off_Pinning_Update_Test2 = new CustomerProfile
            {
                CustomerId = customerId,
                DOB = "1980/12/25",
                IconRef = "1234702",
                CustomerNumber = "1234702"
            };

            var GetLockStatus_Off_Pinning_Update_Test3 = new CustomerProfile
            {
                CustomerId = customerId,
                DOB = "1980/12/25",
                IconRef = "1234703",
                CustomerNumber = "1234703"
            };

            var GetLockStatus_Off_Pinning_Update_Test4 = new CustomerProfile
            {
                CustomerId = customerId,
                DOB = "1980/12/25",
                IconRef = "1234704",
                CustomerNumber = "1234704"
            };

            var GetLockStatus_Off_Pinning_Update_Test5 = new CustomerProfile
            {
                CustomerId = customerId,
                DOB = "1980/12/25",
                IconRef = "1234705",
                CustomerNumber = "1234705"
            };

            var GetLockStatus_Off_Pinning_Update_Test6 = new CustomerProfile
            {
                CustomerId = customerId,
                DOB = "1980/12/25",
                IconRef = "1234706",
                CustomerNumber = "1234706"
            };

            var GetLockStatus_Off_Pinning_Update_Test7 = new CustomerProfile
            {
                CustomerId = customerId,
                DOB = "1980/12/25",
                IconRef = "1234707",
                CustomerNumber = "1234707"
            };

            var GetLockStatus_ON_Test = new CustomerProfile
            {
                CustomerId = customerId,
                DOB = "1980/12/25",
                IconRef = "2234700",
                CustomerNumber = "2234700"
            };

            var GetLockStatus_ON_Test1 = new CustomerProfile
            {
                CustomerId = customerId,
                DOB = "1980/12/25",
                IconRef = "2234701",
                CustomerNumber = "2234701"
            };

            var GetLockStatus_ON_Test2 = new CustomerProfile
            {
                CustomerId = customerId,
                DOB = "1980/12/25",
                IconRef = "2234702",
                CustomerNumber = "2234702"
            };

            var GetLockStatus_ON_Test3 = new CustomerProfile
            {
                CustomerId = customerId,
                DOB = "1980/12/25",
                IconRef = "22347003",
                CustomerNumber = "22347003"
            };

            var GetLockStatus_ON_Test4 = new CustomerProfile
            {
                CustomerId = customerId,
                DOB = "1980/12/25",
                IconRef = "2234704",
                CustomerNumber = "2234704"
            };

            var GetLockStatus_ON_Test5 = new CustomerProfile
            {
                CustomerId = customerId,
                DOB = "1980/12/25",
                IconRef = "2234705",
                CustomerNumber = "2234705"
            };

            var GetLockStatus_ON_Test6 = new CustomerProfile
            {
                CustomerId = customerId,
                DOB = "1980/12/25",
                IconRef = "2234706",
                CustomerNumber = "2234706"
            };

            var GetLockStatus_ON_Test7 = new CustomerProfile
            {
                CustomerId = customerId,
                DOB = "1980/12/25",
                IconRef = "2234707",
                CustomerNumber = "2234707"
            };

            var GetLockStatus_ON_Pinning_ProblemTest1 = new CustomerProfile
            {
                CustomerId = customerId,
                DOB = "1980/12/25",
                IconRef = "3234701",
                CustomerNumber = "3234701"
            };

            var GetLockStatus_ON_Pinning_ProblemTest2 = new CustomerProfile
            {
                CustomerId = customerId,
                DOB = "1980/12/25",
                IconRef = "3234702",
                CustomerNumber = "3234702"
            };

            var GetLockStatus_ON_Pinning_ProblemTest3 = new CustomerProfile
            {
                CustomerId = customerId,
                DOB = "1980/12/25",
                IconRef = "3234703",
                CustomerNumber = "3234703"
            };

            var GetLockStatus_ON_Pinning_ProblemTest4 = new CustomerProfile
            {
                CustomerId = customerId,
                DOB = "1980/12/25",
                IconRef = "3234704",
                CustomerNumber = "3234704"
            };

            var GetLockStatus_ON_Pinning_ProblemTest5 = new CustomerProfile
            {
                CustomerId = customerId,
                DOB = "1980/12/25",
                IconRef = "3234705",
                CustomerNumber = "3234705"
            };

            var GetLockStatus_ON_Pinning_ProblemTest6 = new CustomerProfile
            {
                CustomerId = customerId,
                DOB = "1980/12/25",
                IconRef = "3234706",
                CustomerNumber = "3234706"
            };

            var GetLockStatus_On_And_Updating_Test1 = new CustomerProfile
            {
                CustomerId = customerId,
                DOB = "1980/12/25",
                IconRef = "4234701",
                CustomerNumber = "4234701"
            };

            var GetLockStatus_On_And_Updating_Test2 = new CustomerProfile
            {
                CustomerId = customerId,
                DOB = "1980/12/25",
                IconRef = "4234702",
                CustomerNumber = "4234702"
            };

            var GetLockStatus_On_And_Updating_Test3 = new CustomerProfile
            {
                CustomerId = customerId,
                DOB = "1980/12/25",
                IconRef = "4234703",
                CustomerNumber = "4234703"
            };

            var GetLockStatus_On_And_Updating_Test4 = new CustomerProfile
            {
                CustomerId = customerId,
                DOB = "1980/12/25",
                IconRef = "4234704",
                CustomerNumber = "4234704"
            };

            var GetLockStatus_FailInvalidLockStatus_Test5 = new CustomerProfile
            {
                CustomerId = customerId,
                DOB = "1980/12/25",
                IconRef = "4234705",
                CustomerNumber = "4234705"
            };

            var GetLockStatus_FailInvalidPinStatus_Test6 = new CustomerProfile
            {
                CustomerId = customerId,
                DOB = "1980/12/25",
                IconRef = "4234706",
                CustomerNumber = "4234706"
            };

            var PutLockStatus_NoContent_Test6 = new CustomerProfile
            {
                CustomerId = customerId,
                DOB = "1980/12/25",
                IconRef = "6234701",
                CustomerNumber = "6234701"
            };

            var UpdateCustomerProfiler = new CustomerProfile
            {
                CustomerId = customerId,
                DOB = "1980/12/25",
                IconRef = "9999999",
                CustomerNumber = "9999999",
                Address = new List<AddressModel>
                {
                  new AddressModel
                  {
                      AddressType = "address type",
                      Abroad = true,
                      City = "city",
                      Country = "Country",
                      FromDt = new DateTime(),
                      ToDt = new DateTime()
                  }
                }
            };

            var deactivateInstantAlert = new CustomerProfile
            {
                CustomerId = customerId,
                CustomerNumber = "1000022",
                IconRef = "1000022",
                DOB = "1980/12/25"
            };

            var PutLockStatus_AddressNotPinned_Test1 = new CustomerProfile
            {
                CustomerId = customerId,
                CustomerNumber = "9999199",
                IconRef = "9999199",
                DOB = "1980/12/25"
            };

            var DownStreamAuthorizationFailedTest = new CustomerProfile
            {
                CustomerId = customerId,
                CustomerNumber = "9992000",
                IconRef = "9992000",
                DOB = "1980/12/25"
            };

            var BenefitNullTestCase = new CustomerProfile
            {
                CustomerId = customerId,
                DOB = "1980/12/25",
                IconRef = "454545a",
                CustomerNumber = "454545a"
            };

            var CustomerProfileWithOverseasAddress = new CustomerProfile
            {
                CustomerId = customerId,
                CustomerNumber = "9992000",
                IconRef = "9992000",
                DOB = "1980/12/25",
                Address = new List<AddressModel>
                {
                    new()
                    {
                        Abroad = true,
                        AddressType = string.Empty,
                        City = string.Empty,
                        Country = string.Empty,
                        County = string.Empty,
                        District = string.Empty,
                        Flat = string.Empty,
                        HouseName = string.Empty,
                        HouseNumber = string.Empty,
                        FromDt = new DateTime(2020,1,1),
                        ToDt = new DateTime(2020, 6, 30)
                    },
                    new()
                    {
                        Abroad = false,
                        AddressType = "C",
                        City = "city",
                        Country = "country",
                        County = "county",
                        District = "district",
                        Flat = "flat",
                        HouseName = "houseName",
                        HouseNumber = "houseNumber",
                        FromDt = new DateTime(2020,7,1),
                        ToDt = new DateTime()
                    }
                }
            };

            var GetLockStatusWithRetryTest = new CustomerProfile
            {
                CustomerId = customerId,
                CustomerNumber = "6000001",
                IconRef = "10000006",
                DOB = "1980/12/25"
            };

            switch (customerId)
            {
                case "4a1f51c5-e902-4efb-8399-816e29e78999":
                    return Task.FromResult<CustomerProfile>(null);

                case "4a1f51c5-e902-4efb-8399-816e29e77555":
                    return Task.FromResult(deactivateInstantAlert);

                case "4a1f51c5-e902-4efb-8399-816e29e78555":
                    throw new CustomersException("BadRequest", 400, null);

                case "4a1f51c5-e902-4efb-8366-816e29e78404":
                    return Task.FromResult(testCaseNotFound);

                case "4a1f51c5-e902-4efb-8366-816e29e78561":
                    return Task.FromResult(testCaseDownstreamMaintenance);

                case "4a1f51c5-e902-4efb-8366-816e29e78503":
                    return Task.FromResult(testServiceDown);

                case "4a1f51c5-e902-4efb-8366-816e29e78001":
                    return Task.FromResult(GetLockStatusTest1);

                case "4a1f51c5-e902-4efb-8366-816e29e78002":
                    return Task.FromResult(GetLockStatusTest2);

                case "4a1f51c5-e902-4efb-8366-816e29e78003":
                    return Task.FromResult(GetLockStatusTest3);

                case "4a1f51c5-e902-4efb-8366-816e29e78004":
                    return Task.FromResult(GetLockStatusTest4);

                case "4a1f51c5-e902-4efb-8366-816e29e78005":
                    return Task.FromResult(GetLockStatusTest5);

                case "4a1f51c5-e902-4efb-8366-816e29e78006":
                    return Task.FromResult(GetLockStatusTest6);

                case "4a1f51c5-e902-4efb-8366-816e29e78007":
                    return Task.FromResult(GetLockStatusTest7);

                case "4a1f51c5-e902-4efb-8366-816e29e78008":
                    return Task.FromResult(GetLockStatusTest8);

                case "4a1f51c5-e902-4efb-8366-816e29e78009":
                    return Task.FromResult(GetLockStatusTest9);

                case "4a1f51c5-e902-4efb-8366-816e29e78010":
                    return Task.FromResult(GetLockStatusTest10);

                case "4a1f51c5-e902-4efb-8366-816e29e79001":
                    return Task.FromResult(GetLockStatus_Off_Pinning_Problem_Test1);

                case "4a1f51c5-e902-4efb-8366-816e29e79002":
                    return Task.FromResult(GetLockStatus_Off_Pinning_Problem_Test2);

                case "4a1f51c5-e902-4efb-8366-816e29e79003":
                    return Task.FromResult(GetLockStatus_Off_Pinning_Problem_Test3);

                case "4a1f51c5-e902-4efb-8366-816e29e79004":
                    return Task.FromResult(GetLockStatus_Off_Pinning_Problem_Test4);

                case "4a1f51c5-e902-4efb-8366-816e29e79005":
                    return Task.FromResult(GetLockStatus_Off_Pinning_Problem_Test5);

                case "4a1f51c5-e902-4efb-8366-816e29e79006":
                    return Task.FromResult(GetLockStatus_Off_Pinning_Problem_Test6);

                case "4a1f51c5-e902-4efb-8366-816e29e79007":
                    return Task.FromResult(GetLockStatus_Off_Pinning_Problem_Test7);

                case "4a1f51c5-e902-4efb-8366-816e29e89001":
                    return Task.FromResult(GetLockStatus_Off_Pinning_Update_Test1);

                case "4a1f51c5-e902-4efb-8366-816e29e89002":
                    return Task.FromResult(GetLockStatus_Off_Pinning_Update_Test2);

                case "4a1f51c5-e902-4efb-8366-816e29e89003":
                    return Task.FromResult(GetLockStatus_Off_Pinning_Update_Test3);

                case "4a1f51c5-e902-4efb-8366-816e29e89004":
                    return Task.FromResult(GetLockStatus_Off_Pinning_Update_Test4);

                case "4a1f51c5-e902-4efb-8366-816e29e89005":
                    return Task.FromResult(GetLockStatus_Off_Pinning_Update_Test5);

                case "4a1f51c5-e902-4efb-8366-816e29e89006":
                    return Task.FromResult(GetLockStatus_Off_Pinning_Update_Test6);

                case "4a1f51c5-e902-4efb-8366-816e29e89007":
                    return Task.FromResult(GetLockStatus_Off_Pinning_Update_Test7);

                case "5a1f51c5-e902-4efb-8366-816e29e89000":
                    return Task.FromResult(GetLockStatus_ON_Test);

                case "5a1f51c5-e902-4efb-8366-816e29e89001":
                    return Task.FromResult(GetLockStatus_ON_Test1);

                case "5a1f51c5-e902-4efb-8366-816e29e89002":
                    return Task.FromResult(GetLockStatus_ON_Test2);

                case "5a1f51c5-e902-4efb-8366-816e29e89003":
                    return Task.FromResult(GetLockStatus_ON_Test3);

                case "5a1f51c5-e902-4efb-8366-816e29e89004":
                    return Task.FromResult(GetLockStatus_ON_Test4);

                case "5a1f51c5-e902-4efb-8366-816e29e89005":
                    return Task.FromResult(GetLockStatus_ON_Test5);

                case "5a1f51c5-e902-4efb-8366-816e29e89006":
                    return Task.FromResult(GetLockStatus_ON_Test6);

                case "5a1f51c5-e902-4efb-8366-816e29e89007":
                    return Task.FromResult(GetLockStatus_ON_Test7);

                case "5a1f51c5-e902-4efb-8366-816e29e81001":
                    return Task.FromResult(GetLockStatus_ON_Pinning_ProblemTest1);

                case "5a1f51c5-e902-4efb-8366-816e29e81002":
                    return Task.FromResult(GetLockStatus_ON_Pinning_ProblemTest2);

                case "5a1f51c5-e902-4efb-8366-816e29e81003":
                    return Task.FromResult(GetLockStatus_ON_Pinning_ProblemTest3);

                case "5a1f51c5-e902-4efb-8366-816e29e81004":
                    return Task.FromResult(GetLockStatus_ON_Pinning_ProblemTest4);

                case "5a1f51c5-e902-4efb-8366-816e29e81005":
                    return Task.FromResult(GetLockStatus_ON_Pinning_ProblemTest5);

                case "5a1f51c5-e902-4efb-8366-816e29e81006":
                    return Task.FromResult(GetLockStatus_ON_Pinning_ProblemTest6);

                case "5a1f51c5-e902-4efb-8366-816e29e82001":
                    return Task.FromResult(GetLockStatus_On_And_Updating_Test1);

                case "5a1f51c5-e902-4efb-8366-816e29e82002":
                    return Task.FromResult(GetLockStatus_On_And_Updating_Test2);

                case "5a1f51c5-e902-4efb-8366-816e29e82003":
                    return Task.FromResult(GetLockStatus_On_And_Updating_Test3);

                case "5a1f51c5-e902-4efb-8366-816e29e82004":
                    return Task.FromResult(GetLockStatus_On_And_Updating_Test4);

                case "5a1f51c5-e902-4efb-8366-816e29e82005":
                    return Task.FromResult(GetLockStatus_FailInvalidLockStatus_Test5);

                case "5a1f51c5-e902-4efb-8366-816e29e82006":
                    return Task.FromResult(GetLockStatus_FailInvalidPinStatus_Test6);

                case "4b1f51c5-e902-4efb-8366-816e29e788e7":
                    return Task.FromResult(PutLockStatus_NoContent_Test6);

                case "4a1f51c5-e902-5efb-8366-816e29e78561":
                    return Task.FromResult<CustomerProfile>(null);

                case "4a1f51c5-e902-5efb-8366-816e29e78562":
                    return Task.FromResult(UpdateCustomerProfiler);

                case "4a1f51c5-e902-4efb-8399-816e29e80000":
                    return Task.FromResult(UpdateCustomerProfiler);

                case "4b1f51c5-e902-4efb-8366-816e29e798e7":
                    return Task.FromResult(PutLockStatus_AddressNotPinned_Test1);

                case "4a1f51c5-e902-4efb-8400-816e29e78999":
                    return Task.FromResult(DownStreamAuthorizationFailedTest);

                case "2ae528b8-37a5-499e-8bdf-547f706a880c":
                    return Task.FromResult(CustomerProfileWithOverseasAddress);

                case "b3766399-d34f-4619-8c93-94eb8091cfc5":
                    return Task.FromResult(GetLockStatusWithRetryTest);
                case "9009758b-62f8-42d4-8f93-1dec01772ccf":
                    return Task.FromResult(BenefitNullTestCase);

                default:
                    return Task.FromResult(happyPathTestCase);
            }
        }
    }
}