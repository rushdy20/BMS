﻿namespace EXPN.Models.CreditLockService.Paas.Get.Response
{
    public class AddressResponse : Address
    {
        public string Din { get; set; }
        public string PinStatus { get; set; }
        public string PinErrorCode { get; set; }
    }
}