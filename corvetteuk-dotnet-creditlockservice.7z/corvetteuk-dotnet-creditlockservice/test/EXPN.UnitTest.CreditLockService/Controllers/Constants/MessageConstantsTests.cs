﻿using EXPN.Controllers.CreditLockService.Constants;
using FluentAssertions;
using Xunit;

namespace EXPN.UnitTest.CreditLockService.Controllers.Constants
{
    public class MessageConstantsTests
    {
        [Fact]
        public void MessageConstantTests_ReturnAsExpected()
        {
            var expected = "Downstream Service Authentication Failed";

            var downstreamAuthenticationFailed = MessageConstants.DownstreamAuthenticationFailed;

            downstreamAuthenticationFailed.Should().BeEquivalentTo(expected);
        }
    }
}