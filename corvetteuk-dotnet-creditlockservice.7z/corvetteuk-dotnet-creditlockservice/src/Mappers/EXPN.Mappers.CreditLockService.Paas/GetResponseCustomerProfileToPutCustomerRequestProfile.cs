﻿using AutoMapper;
using EXPN.Models.CreditLockService.Internal.Get.Response;
using EXPN.Models.CreditLockService.Paas;
using EXPN.Models.CreditLockService.Paas.Put.Request;

namespace EXPN.Mappers.CreditLockService.Paas
{
    public class GetResponseCustomerProfileToPutCustomerRequestProfile : Profile
    {
        private const string ClientId = "ECS";

        public GetResponseCustomerProfileToPutCustomerRequestProfile()
        {
            AllowNullDestinationValues = true;
            AllowNullCollections = true;

            CreateMap<GetResponseCustomerProfile, PutCustomerRequest>(MemberList.None)
                .ForMember(d => d.CustomerId, m => m.MapFrom(s => s.IconRef))
                .ForMember(d => d.ClientId, m => m.MapFrom(s => ClientId))
                .ForMember(d => d.Dob, m => m.MapFrom(s => s.DOB))
                .ForMember(d => d.Name, m => m.MapFrom(s => s))
                .ForMember(d => d.AddressesToAdd, m => m.MapFrom(s => s.Address))
                .ForMember(d => d.AddressesToDelete, m => m.MapFrom(s => s.Address))
                .ForMember(d => d.AddressFromCorvetteProfiler, m => m.MapFrom(s => s.Address));

            CreateMap<GetResponseCustomerProfile, CustomerName>(MemberList.None)
                .ForMember(d => d.FirstName, m => m.MapFrom(s => s.FirstName))
                .ForMember(d => d.LastName, m => m.MapFrom(s => s.LastName))
                .ForMember(d => d.OtherName, m => m.MapFrom(s => s.MiddleName))
                .ForMember(d => d.Title, m => m.MapFrom(s => s.Title));

            CreateMap<GetResponseCustomerAddressModel, string>()
                .ConstructUsing(s => s.PostCode);
        }
    }
}