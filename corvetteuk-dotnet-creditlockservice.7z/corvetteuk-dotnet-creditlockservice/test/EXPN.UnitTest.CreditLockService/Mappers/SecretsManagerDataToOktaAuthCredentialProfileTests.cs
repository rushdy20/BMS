﻿using AutoMapper;
using EXPN.Mappers.CreditLockService.Paas;
using EXPN.Models.CreditLockService.Internal;
using EXPN.Models.CreditLockService.Paas;
using FluentAssertions;
using System.Collections.Generic;
using Xunit;

namespace EXPN.UnitTest.CreditLockService.Mappers
{
    public class SecretsManagerDataToOktaAuthCredentialProfileTests
    {
        [Fact]
        public void ExternalModelProfile_AssertConfiguration_IsValid()
        {
            var mapperConfiguration = new MapperConfiguration(cfg => cfg.AddProfile<SecretsManagerDataToOktaAuthCredentialProfile>());
            mapperConfiguration.AssertConfigurationIsValid();
        }

        [Theory]
        [MemberData(nameof(MappingData))]
        public void ExternalModelProfile_ExampleInput_MapsCorrectly(SecretsManagerData input, OktaAuthCredentials expected)
        {
            var mapper = new MapperConfiguration(cfg => cfg.AddProfile<SecretsManagerDataToOktaAuthCredentialProfile>()).CreateMapper();

            var result = mapper.Map<OktaAuthCredentials>(input);

            result.Should().BeEquivalentTo(expected);
        }

        public static IEnumerable<object[]> MappingData()
        {
            yield return new object[]
            {
                null,
                null
            };

            yield return new object[]
            {
                new SecretsManagerData
                {
                    ClientId = "clientId",
                    Endpoint = "endpoint",
                    GrantType = "grantType",
                    KeyName = "keyName",
                    Password = "password",
                    Scope = "scope",
                    ServiceEndpoint = "serviceEndpoint",
                    SharedSecret = "secrets",
                    Username = "username"
                },

                new OktaAuthCredentials
                {
                    ClientId = "clientId",
                    Endpoint = "endpoint",
                    GrantType = "grantType",
                    KeyName = "keyName",
                    Password = "password",
                    Scope = "scope",
                    ServiceEndpoint = "serviceEndpoint",
                    SharedSecret = "secrets",
                    Username = "username"
                }
            };
        }
    }
}