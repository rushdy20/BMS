﻿using System.Threading.Tasks;

namespace EXPN.BusinessLayer.CreditLockService;

public interface IBenefitChecker
{
    Task EnsureValidBenefitAsync();
}