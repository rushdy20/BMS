﻿using Newtonsoft.Json;
using System;

namespace EXPN.Models.CreditLockService.Paas
{
    public class Customer
    {       
        public string CustomerId { get; set; }
        public string ClientId { get; set; }
        public DateTime? Dob { get; set; }
        public CustomerName Name { get; set; }
        public string IconRef { get; set; }
        public string CustomerRef { get; set; }
    }
}