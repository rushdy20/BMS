﻿using EXPN.DataLayer.CreditLockService.Common.Exceptions;
using EXPN.UnitTest.CreditLockService.Common.Extension;
using FluentAssertions;
using System;
using System.Collections.Generic;
using Xunit;

namespace EXPN.UnitTest.CreditLockService.Common.Exceptions
{
    public class RequestBodyNullExceptionTests
    {
        [Fact]
        public void DefaultConstructor_CreatesException()
        {
            var exception = new RequestBodyNullException();

            exception.Message.Should().Be("Exception of type 'EXPN.DataLayer.CreditLockService.Common.Exceptions.RequestBodyNullException' was thrown.");
        }

        public static IEnumerable<object[]> SingleParams()
        {
            yield return new object[]
            {
                string.Empty
            };

            yield return new object[]
            {
                "test message"
            };
        }

        [Theory]
        [MemberData(nameof(SingleParams))]
        public void SingleParamConstructor_CreatesException(string message)
        {
            var exception = new RequestBodyNullException(message);

            exception.Message.Should().Be(message);
        }

        public static IEnumerable<object[]> DoubleParams()
        {
            yield return new object[]
            {
                null,
                null,
                "Exception of type 'EXPN.DataLayer.CreditLockService.Common.Exceptions.RequestBodyNullException' was thrown."
            };

            yield return new object[]
            {
                string.Empty,
                null,
                string.Empty
            };

            yield return new object[]
            {
                "test message",
                null,
                "test message"
            };

            yield return new object[]
            {
                "test message",
                new RequestBodyNullException("bad op"),
                "test message"
            };
        }

        [Theory]
        [MemberData(nameof(DoubleParams))]
        public void DoubleParamConstructor_CreatesException(string message, Exception innerException, string expectedMessage)
        {
            var exception = new RequestBodyNullException(message, innerException);

            exception.Message.Should().Be(expectedMessage);
            exception.InnerException.Should().BeEquivalentTo(innerException);
        }

        [Fact]
        public void Serialization_CreatesException()
        {
            const string expectedMsg = "Test Serialization RequestBodyNullException";
            var ex = new RequestBodyNullException(expectedMsg);

            var actual = ex.SerializeAndDeserialize();

            actual.Should().BeEquivalentTo(ex);
        }
    }
}