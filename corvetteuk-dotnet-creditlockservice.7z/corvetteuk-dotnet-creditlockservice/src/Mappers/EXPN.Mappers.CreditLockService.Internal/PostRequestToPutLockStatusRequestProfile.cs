﻿using AutoMapper;
using EXPN.Models.CreditLockService.External.Post.Request;
using EXPN.Models.CreditLockService.Internal.Put.Request;

namespace EXPN.Mappers.CreditLockService.Internal
{
    public class PostRequestToPutLockStatusRequestProfile : Profile
    {
        public PostRequestToPutLockStatusRequestProfile()
        {
            CreateMap<PostRequest, PutLockStatusRequest>()
                .ForMember(d => d.CustomerId, m => m.MapFrom(s => s.CustomerId))
                .ForMember(d => d.LockStatus, m => m.MapFrom(s => false))
                .ForMember(d => d.SalesForceUserId, m => m.MapFrom<string>(s => null));
        }
    }
}