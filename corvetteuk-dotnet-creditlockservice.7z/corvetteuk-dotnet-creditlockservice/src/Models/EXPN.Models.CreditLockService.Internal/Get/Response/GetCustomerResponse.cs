﻿using System;
using System.Collections.Generic;

namespace EXPN.Models.CreditLockService.Internal.Get.Response
{
    public class GetCustomerResponse
    {
        public string ClientId { get; set; }
        public string CustomerId { get; set; }
        public DateTime Dob { get; set; }
        public GetResponsePaasCustomerName CustomerName { get; set; }
        public string LockStatus { get; set; }
        public string AlertsStatus { get; set; }
        public IEnumerable<GetResponsePaasAddressResponse> Addresses { get; set; }
    }
}