﻿using System.Diagnostics.CodeAnalysis;
using Microsoft.AspNetCore.Mvc;

namespace EXPN.Models.CreditLockService.External.Put.Request
{
    [ExcludeFromCodeCoverage]
    public class PutStatusAgentRequest
    {
        [FromHeader(Name = "x-customerId")] 
        public string CustomerId { get; set; }

        [FromBody]
        public PutStatusAgentRequestBody Body { get; set; }
    }
}