﻿using System;
using System.Runtime.Serialization;

namespace EXPN.DataLayer.CreditLockService.Common.Exceptions
{
    [Serializable]
    public  class HttpServiceRequestException : Exception
  {
      protected HttpServiceRequestException(SerializationInfo info, StreamingContext context)
          : base(info, context)
      {
      }

      public HttpServiceRequestException()
      {
      }

      public HttpServiceRequestException(string message)
          : base(message)
      {
      }

      public HttpServiceRequestException(string message, Exception innerException)
          : base(message, innerException)
      {
      }
  }
}