﻿using EXPN.DataLayer.CreditLockService.Common.Exceptions;
using EXPN.UnitTest.CreditLockService.Common.Extension;
using FluentAssertions;
using System;
using System.Runtime.Serialization;
using Xunit;

namespace EXPN.UnitTest.CreditLockService.Common.Binders
{
    public class CreditLockCommonExceptionsBinderTests
    {
        [Fact]
        public void ValidObjectSerialization_Deserialized()
        {
            const string expectedMsg = "Test";
            var ex = new CustomerPostRequestException(expectedMsg);

            var actual = ex.SerializeAndDeserialize();

            actual.Should().BeEquivalentTo(ex);
        }

        [Fact]
        public void InvalidObjectSerialization_ThrowsException()
        {
            var ex = new InvalidOperationException("Test Message");

            Action action = () =>
            {
                ex.SerializeAndDeserialize();
            };

            action.Should()
                .Throw<SerializationException>()
                .WithMessage("System.InvalidOperationException is not a recognized type");
        }
    }
}