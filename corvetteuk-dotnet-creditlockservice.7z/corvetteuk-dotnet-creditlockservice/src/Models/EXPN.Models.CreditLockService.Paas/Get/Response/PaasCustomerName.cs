﻿namespace EXPN.Models.CreditLockService.Paas.Get.Response
{
  public class PaasCustomerName
    {
        public string Title { get; set; }
        public string Forename { get; set; }
        public string MiddleName { get; set; }
        public string Surname { get; set; }
        public string Suffix { get; set; }
    }
}
