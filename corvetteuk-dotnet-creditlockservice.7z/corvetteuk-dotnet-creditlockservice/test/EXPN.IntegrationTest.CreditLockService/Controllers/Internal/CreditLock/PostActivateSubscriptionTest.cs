﻿using EXPN.DataLayer.CreditLockService.Paas.HttpClient;
using EXPN.IntegrationTest.CreditLockService.Utility;
using EXPN.IntegrationTest.CreditLockService.Utility.MessageHandlers;
using EXPN.Models.CreditLockService.Paas.Get.Response;
using FluentAssertions;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Xunit;


namespace EXPN.IntegrationTest.CreditLockService.Controllers.Internal.CreditLock
{
    public class PostActivateSubscriptionTest
    {
        private readonly IHostBuilder _hostBuilder;

        public PostActivateSubscriptionTest()
        {
            _hostBuilder = new HostBuilder()
                .UseIntegrationTestSettings()
                .ConfigureServices(s =>
                    s.AddHttpClient<ICreditLockPaasClient, CreditLockPaasClient>(c =>
                    {
                        c.DefaultRequestHeaders
                            .Accept
                            .Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    }).AddHttpMessageHandler<DynamicHttpMessagesHandler>());
        }

        public static IEnumerable<object[]> GetReportData()
        {
            yield return new object[]
            {
                "4a1f51c5-e902-4efb-8399-816e29e80000",
                (HttpStatusCode)204,
                null,
                new[]
                {
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.NoContent
                    },
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.NoContent
                    }
                }
            };

            yield return new object[]
            {
                "2ae528b8-37a5-499e-8bdf-547f706a880c",
                (HttpStatusCode)204,
                null,
                new[]
                {
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.NoContent
                    },
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.NoContent
                    }
                }
            };

            yield return new object[]
            {
                "4a1f51c5-e902-4efb-8399-816e29e80000",
                (HttpStatusCode) 204,
                null,
                new[]
                {
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.Conflict
                    },
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.OK,
                        Content = new StringContent(JsonConvert.SerializeObject(new PaasResponseData
                        {
                            Data = new List<GetCustomerResponse>
                            {
                                new()
                                {
                                    CustomerId = "Customer IDs are opaque",
                                    AlertsStatus = "Y",
                                    ClientId = "ECS",
                                    DateOfBirth = new DateTime(1990, 12, 31),
                                    LockStatus = "Y",
                                    Name = new PaasCustomerName
                                    {
                                        Forename = "Howard",
                                        Title = "Lord",
                                        Surname = "Lovecraft",
                                        MiddleName = "Phillips",
                                        Suffix = "Jnr"
                                    },
                                    Addresses = new[]
                                    {
                                        new AddressResponse
                                        {
                                            County = "Homeshire",
                                            Din = "202100011234567891",
                                            HouseNumber = "42",
                                            PinErrorCode = "",
                                            PinStatus = "3",
                                            Postcode = "AB1 23X",
                                            Street = "Green Lane",
                                            Town = "Bigton"
                                        }
                                    }
                                }
                            }
                        }), Encoding.UTF8, "application/json")
                    },
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.NoContent
                    },
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.NoContent
                    }
                }
            };

            yield return new object[]
            {
                "not a valid id",
                (HttpStatusCode) 400,
                "{\"fieldErrors\": {\"CustomerId\": \"'CustomerId' is not in valid format\"},\"status\": 400,\"message\": null}",
                null
            };

            yield return new object[]
            {
                "4a1f51c5-e902-4efb-8399-816e29e78555",
                (HttpStatusCode) 500,
                "{\"fieldErrors\": {},\"status\": 500,\"message\": null}",
                null
            };
        }

        [Theory]
        [MemberData(nameof(GetReportData))]
        public async Task PostActivateSubscription_ResponseExpectedStatusCode(string customerId, HttpStatusCode expectedStatusCode, string expectedServiceResponseJsonStr, HttpResponseMessage[] testResponses)
        {
            const string endPoint = "/internal/creditlock/activate";

            DynamicHttpMessagesHandler.TestResponses = null;
            DynamicHttpMessagesHandler.TestResponses = testResponses;

            var actualServiceResponse = await CommonIntegrationFunctions.PostRequest(endPoint, customerId, _hostBuilder);
            var actualServiceResponseStatusCode = (int)actualServiceResponse.StatusCode;

            actualServiceResponseStatusCode.Should().Be((int)expectedStatusCode);

            if (expectedServiceResponseJsonStr != null)
            {
                var actualServiceResponseJsonStr = await actualServiceResponse.Content.ReadAsStringAsync();

                JToken.DeepEquals(JObject.Parse(actualServiceResponseJsonStr),
                    JObject.Parse(expectedServiceResponseJsonStr)).Should().BeTrue(actualServiceResponseJsonStr);
            }
        }
    }
}