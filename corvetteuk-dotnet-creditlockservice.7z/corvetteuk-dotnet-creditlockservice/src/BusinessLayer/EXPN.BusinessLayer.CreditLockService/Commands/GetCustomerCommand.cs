﻿using AutoMapper;
using Experian.AWS.Logging.Extensions;
using EXPN.BusinessLayer.CreditLockService.Constants;
using EXPN.DataLayer.CreditLockService.Paas.HttpClient;
using EXPN.Models.CreditLockService.Internal.Get.Request;
using EXPN.Models.CreditLockService.Internal.Get.Response;
using Microsoft.Extensions.Logging;
using System;
using PaaSRequest = EXPN.Models.CreditLockService.Paas.Get.Request;

namespace EXPN.BusinessLayer.CreditLockService.Commands
{
    public class GetCustomerCommand<TRequest, TResponse> : ICommand<TRequest, TResponse>
       where TRequest : GetCustomerRequest
       where TResponse : GetCustomerResponse
    {
        private readonly ICreditLockPaasClient _creditLockPaasClient;
        private readonly ILogger<GetCustomerCommand<TRequest, TResponse>> _logger;
        private readonly IMapper _mapper;

        public GetCustomerCommand(ICreditLockPaasClient creditLockPaasClient, 
            ILogger<GetCustomerCommand<TRequest, TResponse>> logger,
            IMapper mapper)
        {
            _creditLockPaasClient = creditLockPaasClient ?? throw new ArgumentNullException(nameof(creditLockPaasClient));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        }

        public string Id => "CUSTOMER-GET";

        public TResponse Execute(TRequest request, GetResponseCustomerProfile customerProfile)
        {
            _logger.LogAsInformation(LogEventNames.GetCustomerCommand.Execute.Enter);

            if (request == null)
                throw new ArgumentNullException(nameof(request));
            
            if (customerProfile == null)
                throw new ArgumentNullException(nameof(customerProfile));

            if (string.IsNullOrWhiteSpace(request.CustomerId))
                throw new ArgumentException($"{nameof(request.CustomerId)} cannot be null or whitespace", nameof(request));

            var getCustomerRequest = _mapper.Map<PaaSRequest.GetCustomerRequest>(customerProfile);

            var response = _creditLockPaasClient.GetPaasCustomerAsync(getCustomerRequest).Result;

            _logger.LogAsInformation(LogEventNames.GetCustomerCommand.Execute.Exit);

            return (TResponse)_mapper.Map<GetCustomerResponse>(response); 
        }
    }
}