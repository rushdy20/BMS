﻿using AutoMapper;
using EXPN.BusinessLayer.CreditLockService.Commands;
using EXPN.BusinessLayer.CreditLockService.Constants;
using EXPN.DataLayer.CreditLockService.Paas.HttpClient;
using EXPN.Models.CreditLockService.Internal.Get.Request;
using EXPN.Models.CreditLockService.Internal.Get.Response;
using EXPN.Models.CreditLockService.Paas.Post.Request;
using FluentAssertions;
using Microsoft.Extensions.Logging;
using NSubstitute;
using NSubstitute.ExceptionExtensions;
using System;
using System.Collections.Generic;
using Xunit;

namespace EXPN.UnitTest.CreditLockService.BusinessLayer.Commands
{
    public class GetCustomerCommandTests
    {
        private readonly ICreditLockPaasClient _creditLockPaaSClient;
        private readonly ILogger<GetCustomerCommand<GetCustomerRequest, GetCustomerResponse>> _logger; 
        private readonly IMapper _mapper;

        private readonly ICommand<GetCustomerRequest, GetCustomerResponse> _getCustomerCommand;

        public GetCustomerCommandTests()
        {
            _creditLockPaaSClient = Substitute.For<ICreditLockPaasClient>();
            _logger = Substitute.For<ILogger<GetCustomerCommand<GetCustomerRequest, GetCustomerResponse>>>();
            _mapper = Substitute.For<IMapper>();
            _getCustomerCommand = Substitute.For<ICommand<GetCustomerRequest, GetCustomerResponse>>();

            _getCustomerCommand = new GetCustomerCommand<GetCustomerRequest, GetCustomerResponse>(_creditLockPaaSClient, _logger, _mapper);
        }

        public class Constructor
        {
            public static IEnumerable<object[]> NullParameters()
            {
                yield return new object[]
                {
                    null,
                    Substitute.For<ILogger<GetCustomerCommand<GetCustomerRequest, GetCustomerResponse>>>(),
                    Substitute.For<IMapper>(),
                    "creditLockPaasClient"
                };

                yield return new object[]
                {
                    Substitute.For<ICreditLockPaasClient>(),
                    null,
                    Substitute.For<IMapper>(),
                    "logger"
                };

                yield return new object[]
                {
                    Substitute.For<ICreditLockPaasClient>(),
                    Substitute.For<ILogger<GetCustomerCommand<GetCustomerRequest, GetCustomerResponse>>>(),
                    null,
                    "mapper"
                };
            }

            [Theory]
            [MemberData(nameof(NullParameters))]
            public void NullRequiredConstructorParameter_ThrowsArgumentNullException(
                ICreditLockPaasClient paasHttpClient,
                ILogger<GetCustomerCommand<GetCustomerRequest, GetCustomerResponse>> logger,
                IMapper mapper,
                string expectedErrorParameter)
            {
                Action action = () => {
                    new GetCustomerCommand<GetCustomerRequest, GetCustomerResponse>(paasHttpClient, logger, mapper);
                };

                action.Should().Throw<ArgumentNullException>()
                    .Where(x => x.ParamName == expectedErrorParameter);
            }

            [Fact]
            public void Id_IsCorrect()
            {
                new GetCustomerCommand<GetCustomerRequest, GetCustomerResponse>(
                    Substitute.For<ICreditLockPaasClient>(),
                    Substitute.For<ILogger<GetCustomerCommand<GetCustomerRequest, GetCustomerResponse>>>(),
                    Substitute.For<IMapper>()).Id.Should().Be("CUSTOMER-GET");
            }
        }

        public class Execute : GetCustomerCommandTests
        {
            public static IEnumerable<object[]> LogInformationMessages()
            {
                yield return new object[]
                {
                    LogEventNames.GetCustomerCommand.Execute.Enter
                };

                yield return new object[]
                {
                    LogEventNames.GetCustomerCommand.Execute.Exit
                };
            }

            [Theory]
            [MemberData(nameof(LogInformationMessages))]
            public void HappyPathInformationLogged(string loggerMessage)
            {
                const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

                var getResponseCustomerProfile = new GetResponseCustomerProfile
                {
                    CustomerId = customerId
                };

                var postCustomerRequest = new PostCustomerRequest
                {
                    CustomerId = customerId
                };

                _mapper.Map<PostCustomerRequest>(getResponseCustomerProfile)
                    .Returns(postCustomerRequest);

                var customerRequest = new GetCustomerRequest()
                {
                    CustomerId = customerId
                };

                _getCustomerCommand.Execute(customerRequest, getResponseCustomerProfile);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(loggerMessage)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public void ExecuteCustomerRequestNull_ThrowsArgumentNullException()
            {
                Action action = () =>
                {
                    _getCustomerCommand.Execute(null, null);
                };

                action.Should().Throw<ArgumentNullException>()
                    .Where(x => x.ParamName == "request");
            }

            [Fact]
            public void ExecuteCustomerCustomerProfileNull_ThrowsArgumentNullException()
            {
                Action action = () =>
                {
                    _getCustomerCommand.Execute(new GetCustomerRequest(), null);
                };

                action.Should().Throw<ArgumentNullException>()
                    .Where(x => x.ParamName == "customerProfile");
            }

            public static IEnumerable<object[]> CustomerRequestArgumentException()
            {
                yield return new object[]
                {
                    new GetCustomerRequest
                    {
                        CustomerId = null
                    }
                };

                yield return new object[]
                {
                    new GetCustomerRequest
                    {
                        CustomerId = string.Empty
                    }
                };

                yield return new object[]
                {
                    new GetCustomerRequest
                    {
                        CustomerId = string.Empty.PadLeft(10)
                    }
                };
            }

            [Theory]
            [MemberData(nameof(CustomerRequestArgumentException))]
            public void ExecuteCustomerRequestInvalid_ThrowsArgumentNullException(GetCustomerRequest getCustomerRequest)
            {
                Action action = () =>
                {
                    _getCustomerCommand.Execute(getCustomerRequest, new GetResponseCustomerProfile());
                };

                action.Should().Throw<ArgumentException>()
                    .Where(x => x.Message == "CustomerId cannot be null or whitespace (Parameter 'request')");
            }

            [Fact]
            public void ValidCustomerId_Execute_HappyPath_Success()
            {
                const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

                var getResponseCustomerProfile = new GetResponseCustomerProfile
                {
                    CustomerId = customerId
                };

                var customerRequest = new GetCustomerRequest
                {
                    CustomerId = customerId
                };

                var getCustomerPaasResponse = new EXPN.Models.CreditLockService.Paas.Get.Response.GetCustomerResponse
                {
                    LockStatus = "ON"
                };

                var getCustomerInternalResponse = new GetCustomerResponse
                {
                    LockStatus = "ON"
                };

                var getCustomerRequest = new Models.CreditLockService.Paas.Get.Request.GetCustomerRequest
                {
                    CustomerRef = customerId
                };

                _mapper.Map<Models.CreditLockService.Paas.Get.Request.GetCustomerRequest>(getResponseCustomerProfile)
                    .Returns(getCustomerRequest);

                _creditLockPaaSClient.GetPaasCustomerAsync(getCustomerRequest)
                    .Returns(getCustomerPaasResponse);

                _mapper.Map<GetCustomerResponse>(getCustomerPaasResponse)
                    .Returns(getCustomerInternalResponse);

                _getCustomerCommand.Execute(customerRequest, getResponseCustomerProfile);

                _mapper.Received(1).Map<Models.CreditLockService.Paas.Get.Request.GetCustomerRequest>(getResponseCustomerProfile);

                _mapper.Received(1).Map<GetCustomerResponse>(getCustomerPaasResponse);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.GetCustomerCommand.Execute.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.GetCustomerCommand.Execute.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public void ValidCustomerId_Execute_ThrowsOutOfMemoryException()
            {
                const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

                var expectedEx = new OutOfMemoryException("Test Exception Message");

                var getResponseCustomerProfile = new GetResponseCustomerProfile
                {
                    CustomerId = customerId
                };

                var customerRequest = new GetCustomerRequest
                {
                    CustomerId = customerId
                };

                _mapper.Map<Models.CreditLockService.Paas.Get.Request.GetCustomerRequest>(getResponseCustomerProfile)
                    .Throws(expectedEx);

                Action action = () =>
                {
                    _getCustomerCommand.Execute(customerRequest, getResponseCustomerProfile);
                };

                action.Should().Throw<OutOfMemoryException>()
                    .Where(x => x.Message == expectedEx.Message);

                _mapper.Received(1).Map <Models.CreditLockService.Paas.Get.Request.GetCustomerRequest>(getResponseCustomerProfile);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.GetCustomerCommand.Execute.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.GetCustomerCommand.Execute.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }
        }
    }
}