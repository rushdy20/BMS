﻿using AutoMapper;
using EXPN.Mappers.CreditLockService.Paas.Extensions;
using EXPN.Models.CreditLockService.Internal.Get.Response;
using EXPN.Models.CreditLockService.Paas.Put.Request;
using System.Collections.Generic;
using System.Linq;

namespace EXPN.Mappers.CreditLockService.Paas.Resolvers
{
    public class PutRequestDeleteAddressResolver : IMemberValueResolver<GetCustomerResponse, PutCustomerRequest, IEnumerable<GetResponsePaasAddressResponse>, IEnumerable<string>>
    {
        private readonly IEnumerable<string> _exclusionList = new List<string> { "District", "IsCurrent" };

        public IEnumerable<string> Resolve(
            GetCustomerResponse source,
            PutCustomerRequest destination,
            IEnumerable<GetResponsePaasAddressResponse> sourceMember,
            IEnumerable<string> destMember,
            ResolutionContext context)
        {
            if (sourceMember == null)
                return null;

            if (destMember == null)
                return null;

            var sourceAddressList = sourceMember.Select(x => { x.Postcode = x.Postcode?.Replace(" ", string.Empty).ToUpper(); return x; }).ToArray();

            var destAddressList = destination.AddressFromCorvetteProfiler.Select(x => { x.Postcode = x.Postcode?.Replace(" ", string.Empty).ToUpper(); return x; }).ToArray();

            return (from getResponsePaasAddressResponse in sourceAddressList
                    let isRemoved = destAddressList.All(putCustomerAddressRequest => !ExtensionMethods.AreMatchingStringPropertiesSame(getResponsePaasAddressResponse, putCustomerAddressRequest, _exclusionList))
                    where isRemoved
                    select getResponsePaasAddressResponse.Din).ToList();
        }
    }
}