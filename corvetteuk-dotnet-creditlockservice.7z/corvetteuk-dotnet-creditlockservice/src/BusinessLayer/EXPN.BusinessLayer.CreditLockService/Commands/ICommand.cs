﻿using EXPN.Models.CreditLockService.Internal.Get.Response;

namespace EXPN.BusinessLayer.CreditLockService.Commands
{
    public interface ICommand<in TRequest, out TResponse>
    {
        string Id { get; }

        TResponse Execute(TRequest request, GetResponseCustomerProfile customerProfile);
    }
}