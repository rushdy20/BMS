﻿using AutoMapper;
using Experian.AWS.Logging.Extensions;
using EXPN.BusinessLayer.CreditLockService.Constants;
using EXPN.DataLayer.CreditLockService.Paas.HttpClient;
using EXPN.Models.CreditLockService.Internal.Get.Response;
using EXPN.Models.CreditLockService.Internal.Put.Response;
using Microsoft.Extensions.Logging;
using System;
using EXPN.BusinessLayer.CreditLockService.Exceptions;
using EXPN.Models.CreditLockService.Internal.Put.Request;
using PaaSRequest = EXPN.Models.CreditLockService.Paas.Get.Request;
using PaaSPutRequest = EXPN.Models.CreditLockService.Paas.Put.Request;
using EXPN.BusinessLayer.CreditLockService.Extension;
using System.Linq;

namespace EXPN.BusinessLayer.CreditLockService.Commands
{
    public class SyncCustomerCommand<TRequest, TResponse> : ICommand<TRequest, TResponse>
       where TRequest : PutCustomerRequest
       where TResponse : PutCustomerResponse
    {
        private readonly ICreditLockPaasClient _creditLockPaasClient;
        private readonly ILogger<SyncCustomerCommand<TRequest, TResponse>> _logger;
        private readonly IMapper _mapper;

        public SyncCustomerCommand(ICreditLockPaasClient creditLockPaasClient, 
                                    ILogger<SyncCustomerCommand<TRequest, TResponse>> logger,
                                    IMapper mapper)
        {
            _creditLockPaasClient = creditLockPaasClient ?? throw new ArgumentNullException(nameof(creditLockPaasClient));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        }

        public string Id => "CUSTOMER-SYNC";

        public TResponse Execute(TRequest request, GetResponseCustomerProfile customerProfile)
        {
            _logger.LogAsInformation(LogEventNames.SyncCustomerCommand.Execute.Enter);

            if (request == null)
                throw new ArgumentNullException(nameof(request));
            
            if (customerProfile == null)
                throw new ArgumentNullException(nameof(customerProfile));

            if (string.IsNullOrWhiteSpace(request.CustomerId))
                throw new ArgumentException($"{nameof(request.CustomerId)} cannot be null or whitespace", nameof(request));

            var getCustomerRequest = _mapper.Map<PaaSRequest.GetCustomerRequest>(customerProfile);

            var paaSGetCustomerResponse = _mapper.Map<GetCustomerResponse>(_creditLockPaasClient.GetPaasCustomerAsync(getCustomerRequest).Result);

             var putCustomerRequest =
                _mapper.Map<GetResponseCustomerProfile, GetCustomerResponse, PaaSPutRequest.PutCustomerRequest>(customerProfile, paaSGetCustomerResponse);
            
            var hasChanged = putCustomerRequest.IsChanged();

            if (hasChanged)
            {
                if (paaSGetCustomerResponse.IsPinning())
                    throw new SyncCustomerPinningException();

                _logger.LogAsInformation(LogEventNames.SyncCustomerCommand.Execute.HasChanges,
                    new System.Collections.Generic.Dictionary<string, object>() { 
                        { "Number of addresses to add", putCustomerRequest.AddressesToAdd.Count() },
                        { "Number of addresses to delete", putCustomerRequest.AddressesToDelete.Count() }
                    });

                _creditLockPaasClient.Put(putCustomerRequest).Wait();
            }
            else
                _logger.LogAsInformation(LogEventNames.SyncCustomerCommand.Execute.NoChanges);

            var response = new PutCustomerResponse
            {
                HasMadeSyncRequest = hasChanged
            };

            _logger.LogAsInformation(LogEventNames.SyncCustomerCommand.Execute.Exit);

            return (TResponse)response; 
        }
    }
}