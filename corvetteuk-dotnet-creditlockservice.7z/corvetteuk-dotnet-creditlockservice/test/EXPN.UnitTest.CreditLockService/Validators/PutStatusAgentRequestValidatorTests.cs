﻿using System;
using System.Collections.Generic;
using System.Linq;
using EXPN.Models.CreditLockService.External.Put.Request;
using EXPN.Validators.CreditLockService.Put;
using FluentAssertions;
using FluentValidation;
using FluentValidation.Results;
using NSubstitute;
using Xunit;

namespace EXPN.UnitTest.CreditLockService.Validators
{
  public  class PutStatusAgentRequestValidatorTests
    {
        private readonly IValidator<PutStatusAgentRequestBody> _putStatusAgentRequestBodyValidator;

        public PutStatusAgentRequestValidatorTests()
        {
            _putStatusAgentRequestBodyValidator = Substitute.For<IValidator<PutStatusAgentRequestBody>>();

            _putStatusAgentRequestBodyValidator.Validate(Arg.Any<ValidationContext<PutStatusAgentRequestBody>>())
                .Returns(new ValidationResult());
        }

        [Fact]
        public void Constructor_RequiredParameterNull_ThrowsArgumentNullException()
        {
            Action action = () =>
            {
                var unused = new PutStatusAgentRequestValidator(null);
            };

            action.Should().Throw<ArgumentNullException>()
                .And.ParamName.Should().Be("requestBodyValidator");
        }

        [Fact]
        public void PutStatusAgentRequestValidator_ValidRequest_IsValidShouldBeTrue()
        {
            var putStatusAgentRequest = new PutStatusAgentRequest
            {
                CustomerId = Guid.NewGuid().ToString(),
                Body = new PutStatusAgentRequestBody()
            };

            var result = new PutStatusAgentRequestValidator(_putStatusAgentRequestBodyValidator)
                .Validate(putStatusAgentRequest);

            result.IsValid.Should().BeTrue();
        }

        [Fact]
        public void PutStatusAgentRequestValidator_ChildValidatorFails_IsValidShouldBeFalse()
        {
            var putStatusAgentRequest = new PutStatusAgentRequest
            {
                CustomerId = Guid.NewGuid().ToString(),
                Body = new PutStatusAgentRequestBody()
            };

            _putStatusAgentRequestBodyValidator.Validate(Arg.Any<ValidationContext<PutStatusAgentRequestBody>>())
                .Returns(new ValidationResult(new[]
                    {
                        new ValidationFailure("InvalidPropertyName", "InvalidError")
                    }));

            var result = new PutStatusAgentRequestValidator(_putStatusAgentRequestBodyValidator)
                .Validate(putStatusAgentRequest);

            result.IsValid.Should().BeFalse();
            result.Errors.Should().HaveCount(1);
            result.Errors.Select(x => x.ErrorMessage).FirstOrDefault().Should().BeEquivalentTo("InvalidError");
            result.Errors.Select(x => x.PropertyName).FirstOrDefault().Should().BeEquivalentTo("InvalidPropertyName");
        }

        public static IEnumerable<object[]> InvalidPostStatusRequestData()
        {
            yield return new object[]
            {
                new PutStatusAgentRequest
                {
                    CustomerId = null,
                    Body = new PutStatusAgentRequestBody()
                },
                "'Customer Id' must not be empty."
            };

            yield return new object[]
            {
                new PutStatusAgentRequest
                {
                    CustomerId = string.Empty,
                    Body = new PutStatusAgentRequestBody()
                },
                "'Customer Id' must not be empty."
            };

            yield return new object[]
            {
                new PutStatusAgentRequest
                {
                    CustomerId = string.Empty.PadLeft(100),
                    Body = new PutStatusAgentRequestBody()
                },
                "'Customer Id' must not be empty."
            };

            yield return new object[]
            {
                new PutStatusAgentRequest
                {
                    CustomerId = "Not a GUID",
                    Body = new PutStatusAgentRequestBody()
                },
                "'CustomerId' is not in valid format."
            };

            yield return new object[]
            {
                new PutStatusAgentRequest
                {
                    CustomerId = Guid.NewGuid().ToString(),
                    Body = null
                },
                "'Body' must not be empty."
            };
        }

        [Theory]
        [MemberData(nameof(InvalidPostStatusRequestData))]
        public void PutStatusAgentRequestValidator_InvalidRequest_ShouldBeFalse(PutStatusAgentRequest putStatusAgentRequest, string errorMessage)
        {
            var result = new PutStatusAgentRequestValidator(_putStatusAgentRequestBodyValidator)
                .Validate(putStatusAgentRequest);

            result.IsValid.Should().BeFalse();
            result.Errors.Should().HaveCount(1);
            result.Errors.Select(x => x.ErrorMessage).FirstOrDefault().Should().BeEquivalentTo(errorMessage);
        }
    }
}