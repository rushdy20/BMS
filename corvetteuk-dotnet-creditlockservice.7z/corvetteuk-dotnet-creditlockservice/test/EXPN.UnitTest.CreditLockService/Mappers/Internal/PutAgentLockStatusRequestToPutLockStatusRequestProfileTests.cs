﻿using System.Collections.Generic;
using AutoMapper;
using EXPN.Mappers.CreditLockService.Internal;
using EXPN.Models.CreditLockService.External.Post.Request;
using EXPN.Models.CreditLockService.External.Put.Request;
using EXPN.Models.CreditLockService.Internal.Put.Request;
using FluentAssertions;
using Xunit;

namespace EXPN.UnitTest.CreditLockService.Mappers.Internal
{
  public class PutAgentLockStatusRequestToPutLockStatusRequestProfileTests
    {
        private readonly MapperConfiguration _mapperConfiguration;
        public PutAgentLockStatusRequestToPutLockStatusRequestProfileTests()
        {
            _mapperConfiguration = new MapperConfiguration(
                cfg =>
                {
                    cfg.AddProfile<PutAgentLockStatusRequestToPutLockStatusRequestProfile>();
                    cfg.AddProfile<PutAgentLockStatusBodyToPutLockStatusRequestProfile>();
                });
        }

        [Fact]
        public void ModelProfile_AssertConfiguration_IsValid()
        {
            _mapperConfiguration.AssertConfigurationIsValid();
        }

        public static IEnumerable<object[]> MappingData()
        {
           yield return new object[]
            {
                new PutStatusAgentRequest
                {
                    CustomerId = "customerId",
                    Body = new PutStatusAgentRequestBody
                    {
                        Status = "OFF"
                    }
                },
                new PutLockStatusRequest
                {
                    CustomerId = "customerId",
                    LockStatus = false
                }
            };

            yield return new object[]
            {
                new PutStatusAgentRequest
                {
                    CustomerId = "customerId",
                    Body = new PutStatusAgentRequestBody
                    {
                        Status = "ON"
                    }
                },
                new PutLockStatusRequest
                {
                    CustomerId = "customerId",
                    LockStatus = true
                }
            };

            yield return new object[]
            {
                new PutStatusAgentRequest
                {
                    CustomerId = "customerId",
                    Body = new PutStatusAgentRequestBody
                    {
                        Status = "ON",
                        SalesforceUserId = "SalesForceId"
                    }
                },
                new PutLockStatusRequest
                {
                    CustomerId = "customerId",
                    LockStatus = true,
                    SalesForceUserId = "SalesForceId"
                }
            };
        }

        [Theory]
        [MemberData(nameof(MappingData))]
        public void ExternalModelProfile_ExampleInput_MapsCorrectly(PutStatusAgentRequest input, PutLockStatusRequest expected)
        {
            var mapper = _mapperConfiguration.CreateMapper();
            var result = mapper.Map<PutLockStatusRequest>(input);
           var putLockStatsAgent =  mapper.Map(input.Body, result);

           putLockStatsAgent.Should().BeEquivalentTo(expected);
        }
    }
}
