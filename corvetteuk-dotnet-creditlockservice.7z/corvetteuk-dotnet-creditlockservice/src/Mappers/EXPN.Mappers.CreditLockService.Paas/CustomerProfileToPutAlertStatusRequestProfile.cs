﻿using AutoMapper;
using EXPN.Models.CreditLockService.Internal.Get.Response;
using EXPN.Models.CreditLockService.Paas.PutAlertStatus.Request;

namespace EXPN.Mappers.CreditLockService.Paas
{
    public class CustomerProfileToPutAlertStatusRequestProfile : Profile
    {
        public CustomerProfileToPutAlertStatusRequestProfile()
        {
            CreateMap<GetResponseCustomerProfile, PutAlertStatusRequest>(MemberList.None)
                .ForMember(d => d.CustomerRef, m => m.MapFrom(s => s.CustomerRef))
                .ForMember(d => d.Status, m => m.MapFrom(s => "N"))
                .ForMember(d => d.CustomerId, m => m.MapFrom(s => s.CustomerId));

        }
    }
}