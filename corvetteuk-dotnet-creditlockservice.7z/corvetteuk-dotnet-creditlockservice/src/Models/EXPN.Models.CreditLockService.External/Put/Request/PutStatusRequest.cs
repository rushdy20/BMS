﻿using System.Diagnostics.CodeAnalysis;
using Microsoft.AspNetCore.Mvc;

namespace EXPN.Models.CreditLockService.External.Put.Request
{
    [ExcludeFromCodeCoverage]
    public class PutStatusRequest
    {
        [FromHeader(Name = "x-customerId")] 
        public string CustomerId { get; set; }

        [FromBody]
        public PutStatusRequestBody Body { get; set; }
    }
}