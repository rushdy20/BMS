﻿using EXPN.Models.CreditLockService.External.Put.Request;
using FluentAssertions;
using FluentValidation;
using FluentValidation.Results;
using NSubstitute;
using System;
using System.Collections.Generic;
using System.Linq;
using EXPN.Validators.CreditLockService.Put.Customer;
using Xunit;

namespace EXPN.UnitTest.CreditLockService.Validators
{
    public class PostStatusRequestValidatorTests
    {
        private readonly IValidator<PutStatusRequestBody> _postStatusRequestBodyValidator;

        public PostStatusRequestValidatorTests()
        {
            _postStatusRequestBodyValidator = Substitute.For<IValidator<PutStatusRequestBody>>();

            _postStatusRequestBodyValidator.Validate(Arg.Any<ValidationContext<PutStatusRequestBody>>())
                .Returns(new ValidationResult());
        }

        [Fact]
        public void Constructor_RequiredParameterNull_ThrowsArgumentNullException()
        {
            Action action = () =>
            {
                var unused = new PutStatusRequestValidator(null);
            };

            action.Should().Throw<ArgumentNullException>()
                .And.ParamName.Should().Be("externalPubRequestBodyValidator");
        }

        [Fact]
        public void PostStatusRequestValidator_ValidRequest_IsValidShouldBeTrue()
        {
            var postStatusRequest = new PutStatusRequest
            {
                CustomerId = Guid.NewGuid().ToString(),
                Body = new PutStatusRequestBody()
            };

            var result = new PutStatusRequestValidator(_postStatusRequestBodyValidator)
                .Validate(postStatusRequest);

            result.IsValid.Should().BeTrue();
        }

        [Fact]
        public void PostStatusRequestValidator_ChildValidatorFails_IsValidShouldBeFalse()
        {
            var postStatusRequest = new PutStatusRequest
            {
                CustomerId = Guid.NewGuid().ToString(),
                Body = new PutStatusRequestBody()
            };

            _postStatusRequestBodyValidator.Validate(Arg.Any<ValidationContext<PutStatusRequestBody>>())
                .Returns(new ValidationResult(new[]
                    {
                        new ValidationFailure("InvalidPropertyName", "InvalidError")
                    }));

            var result = new PutStatusRequestValidator(_postStatusRequestBodyValidator)
                .Validate(postStatusRequest);

            result.IsValid.Should().BeFalse();
            result.Errors.Should().HaveCount(1);
            result.Errors.Select(x => x.ErrorMessage).FirstOrDefault().Should().BeEquivalentTo("InvalidError");
            result.Errors.Select(x => x.PropertyName).FirstOrDefault().Should().BeEquivalentTo("InvalidPropertyName");
        }

        public static IEnumerable<object[]> InvalidPostStatusRequestData()
        {
            yield return new object[]
            {
                new PutStatusRequest
                {
                    CustomerId = null,
                    Body = new PutStatusRequestBody()
                },
                "'Customer Id' must not be empty."
            };

            yield return new object[]
            {
                new PutStatusRequest
                {
                    CustomerId = string.Empty,
                    Body = new PutStatusRequestBody()
                },
                "'Customer Id' must not be empty."
            };

            yield return new object[]
            {
                new PutStatusRequest
                {
                    CustomerId = string.Empty.PadLeft(100),
                    Body = new PutStatusRequestBody()
                },
                "'Customer Id' must not be empty."
            };

            yield return new object[]
            {
                new PutStatusRequest
                {
                    CustomerId = "Not a GUID",
                    Body = new PutStatusRequestBody()
                },
                "'CustomerId' is not in valid format."
            };

            yield return new object[]
            {
                new PutStatusRequest
                {
                    CustomerId = Guid.NewGuid().ToString(),
                    Body = null
                },
                "'Body' must not be empty."
            };
        }

        [Theory]
        [MemberData(nameof(InvalidPostStatusRequestData))]
        public void PostStatusRequestValidator_InvalidRequest_ShouldBeFalse(PutStatusRequest postStatusRequest, string errorMessage)
        {
            var result = new PutStatusRequestValidator(_postStatusRequestBodyValidator)
                .Validate(postStatusRequest);

            result.IsValid.Should().BeFalse();
            result.Errors.Should().HaveCount(1);
            result.Errors.Select(x => x.ErrorMessage).FirstOrDefault().Should().BeEquivalentTo(errorMessage);
        }
    }
}