﻿using AutoMapper;
using Experian.AWS.Logging.Extensions;
using Experian.HttpClient.Services.Customers.Exception;
using Experian.HttpClient.Services.Customers.Internal.GET;
using Experian.HttpClient.Services.Customers.Models.External;
using EXPN.DataLayer.CreditLockService.Customers.Constants;
using EXPN.Models.CreditLockService.Internal.Get.Response;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;

namespace EXPN.DataLayer.CreditLockService.Customers
{
    public class CustomersClientProxy : ICustomersClientProxy
    {
        private readonly ILogger<CustomersClientProxy> _logger;
        private readonly IGetCustomerProfile _getCustomerProfile;
        private readonly IMapper _mapper;

        public CustomersClientProxy(ILogger<CustomersClientProxy> logger, IGetCustomerProfile getCustomerProfile, IMapper mapper)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _getCustomerProfile = getCustomerProfile ?? throw new ArgumentNullException(nameof(getCustomerProfile));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        }

        public Task<GetResponseCustomerProfile> GetCustomerProfile(string customerId)
        {
            if (string.IsNullOrWhiteSpace(customerId))
                throw new ArgumentException($"{nameof(customerId)} cannot be null or whitespace", nameof(customerId));

            return GetResponseCustomerProfile(customerId);
        }

        private async Task<GetResponseCustomerProfile> GetResponseCustomerProfile(string customerId)
        {
            try
            {
                var externalCustomerProfile = await _getCustomerProfile.GetAsync(customerId);
                return _mapper.Map<GetResponseCustomerProfile>(externalCustomerProfile);
            }
            catch (CustomersException e) when ((HttpStatusCode)e.StatusCode == HttpStatusCode.NotFound)
            {
                return null;
            }
            catch (CustomersException e) when ((HttpStatusCode)e.StatusCode != HttpStatusCode.NotFound)
            {
                var extraData = new Dictionary<string, object>
                {
                    { LogEventKeys.CustomerId, customerId },
                    {
                        LogEventKeys.Context, new Dictionary<string, object>
                        {
                            { LogEventKeys.StatusCode, e.StatusCode },
                            { LogEventKeys.Content, e.Content }
                        }
                    }
                };

                _logger.LogAsWarning(LogEventNames.Customers.GetCustomerProfile.UnsuccessfulRequest, extraData);

                throw;
            }
        }
    }
}