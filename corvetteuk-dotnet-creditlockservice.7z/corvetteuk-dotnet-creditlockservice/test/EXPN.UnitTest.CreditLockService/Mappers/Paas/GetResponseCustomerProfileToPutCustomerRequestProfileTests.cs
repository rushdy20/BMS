﻿using System;
using System.Collections.Generic;
using AutoMapper;
using EXPN.Mappers.CreditLockService.Paas;
using EXPN.Models.CreditLockService.Internal.Get.Response;
using EXPN.Models.CreditLockService.Paas;
using EXPN.Models.CreditLockService.Paas.Put.Request;
using FluentAssertions;
using Xunit;

namespace EXPN.UnitTest.CreditLockService.Mappers.Paas
{
    public class GetResponseCustomerProfileToPutCustomerRequestProfileTests
    {
        private readonly MapperConfiguration _mapperConfiguration;

        public GetResponseCustomerProfileToPutCustomerRequestProfileTests()
        {
            _mapperConfiguration = new MapperConfiguration(
                cfg =>
                {
                    cfg.AddProfile<GetResponseCustomerProfileToPutCustomerRequestProfile>();
                    cfg.AddProfile<GetResponseCustomerAddressModelToPutCustomerAddressRequestProfile>();
                });
        }

        [Fact]
        public void ModelProfile_AssertConfiguration_IsValid()
        {
            _mapperConfiguration.AssertConfigurationIsValid();
        }

        public static IEnumerable<object[]> MappingData()
        {
            yield return new object[]
            {
                null,
                null
            };

            yield return new object[]
            {
                new GetResponseCustomerProfile(),
                new PutCustomerRequest
                {
                    ClientId = "ECS",
                    Name = new CustomerName()
                }
            };

            yield return new object[]
            {
                new GetResponseCustomerProfile
                {
                    IconRef = "customerId"
                },
                new PutCustomerRequest
                {
                    ClientId = "ECS",
                    CustomerId = "customerId",
                    Name = new CustomerName(),
                    IconRef = "customerId"
                }
            };

            yield return new object[]
            {
                new GetResponseCustomerProfile
                {
                    IconRef = "customerId",
                    DOB = "1990-12-31"
                },
                new PutCustomerRequest
                {
                    ClientId = "ECS",
                    CustomerId = "customerId",
                    Dob = new DateTime(1990, 12, 31),
                    Name = new CustomerName(),
                    IconRef = "customerId"
                }
            };

            yield return new object[]
            {
                new GetResponseCustomerProfile
                {
                    IconRef = "customerId",
                    DOB = "1990-12-31",
                    Title = "title",
                    MiddleName = "otherName",
                    FirstName = "firstName",
                    LastName = "lastName"
                },
                new PutCustomerRequest
                {
                    ClientId = "ECS",
                    CustomerId = "customerId",
                    Dob = new DateTime(1990, 12, 31),
                    Name = new CustomerName
                    {
                        FirstName = "firstName",
                        Suffix = null,
                        LastName = "lastName",
                        OtherName = "otherName",
                        Title = "title"
                    },
                    IconRef = "customerId"
                }
            };

            yield return new object[]
            {
                new GetResponseCustomerProfile
                {
                    IconRef = "customerId",
                    DOB = "1990-12-31",
                    Title = "title",
                    MiddleName = "otherName",
                    FirstName = "firstName",
                    LastName = "lastName",
                    Address = new List<GetResponseCustomerAddressModel>()
                },
                new PutCustomerRequest
                {
                    ClientId = "ECS",
                    CustomerId = "customerId",
                    Dob = new DateTime(1990, 12, 31),
                    Name = new CustomerName
                    {
                        FirstName = "firstName",
                        Suffix = null,
                        LastName = "lastName",
                        OtherName = "otherName",
                        Title = "title"
                    },
                    AddressesToAdd = new List<PutCustomerAddressRequest>(),
                    AddressesToDelete = new List<string>(),
                    IconRef = "customerId",
                    AddressFromCorvetteProfiler = new List<PutCustomerAddressRequest>()
                }
            };

            yield return new object[]
            {
                new GetResponseCustomerProfile
                {
                    IconRef = "customerId",
                    DOB = "1990-12-31",
                    Title = "title",
                    MiddleName = "otherName",
                    FirstName = "firstName",
                    LastName = "lastName",
                    Address = new List<GetResponseCustomerAddressModel>
                    {
                        new GetResponseCustomerAddressModel
                        {
                            Abroad = false,
                            AddressType = "C",
                            County = "county",
                            Country = "country",
                            City = "city",
                            District = "district",
                            Flat = "flat",
                            HouseName = "houseName",
                            HouseNumber = "houseNumber",
                            PostCode = "postcode",
                            Street = "street",
                            IsVerified = true,
                            FromDt = new DateTime(2010, 12, 31),
                            LastUpdatedDt = new DateTime(2021, 4, 30),
                            ToDt = null,
                            Manual = false
                        }
                    }
                },
                new PutCustomerRequest
                {
                    ClientId = "ECS",
                    CustomerId = "customerId",
                    Dob = new DateTime(1990, 12, 31),
                    Name = new CustomerName
                    {
                        FirstName = "firstName",
                        Suffix = null,
                        LastName = "lastName",
                        OtherName = "otherName",
                        Title = "title"
                    },
                    AddressesToAdd = new List<PutCustomerAddressRequest>
                    {
                        new PutCustomerAddressRequest
                        {
                            County = "county",
                            District = "district",
                            HouseName = "houseName",
                            HouseNumber = "houseNumber",
                            Flat = "flat",
                            Postcode = "postcode",
                            Town = "city",
                            Street = "street",
                            IsCurrent = true
                        }
                    },
                    AddressesToDelete = new List<string> {"postcode"},
                    IconRef = "customerId",
                    AddressFromCorvetteProfiler = new List<PutCustomerAddressRequest>
                    {
                        new PutCustomerAddressRequest
                        {
                            County = "county",
                            District = "district",
                            HouseName = "houseName",
                            HouseNumber = "houseNumber",
                            Flat = "flat",
                            Postcode = "postcode",
                            Town = "city",
                            Street = "street",
                            IsCurrent = true
                        }
                    }
                }
            };
        }

        [Theory]
        [MemberData(nameof(MappingData))]
        public void InternalModelProfile_ExampleInput_MapsCorrectly(GetResponseCustomerProfile input, PutCustomerRequest expected)
        {
            var mapper = _mapperConfiguration.CreateMapper();
            var result = mapper.Map<PutCustomerRequest>(input);

            result.Should().BeEquivalentTo(expected);
        }

        public static IEnumerable<object[]> InvalidDobMappingData()
        {
            yield return new object[]
            {
                new GetResponseCustomerProfile
                {
                    DOB = "date of birth"
                }
            };

            yield return new object[]
            {
                new GetResponseCustomerProfile
                {
                    DOB = "1990-04-31"
                }
            };

            yield return new object[]
            {
                new GetResponseCustomerProfile
                {
                    DOB = "1990-13-01"
                }
            };

            yield return new object[]
            {
                new GetResponseCustomerProfile
                {
                    DOB = "90-12-31"
                }
            };

            yield return new object[]
            {
                new GetResponseCustomerProfile
                {
                    CustomerId = "customerId",
                    DOB = "1990-02-29"
                }
            };
        }

        [Theory]
        [MemberData(nameof(InvalidDobMappingData))]
        public void InternalModelProfile_ExampleInputInvalidDob_ThrowsException(GetResponseCustomerProfile input)
        {
            var mapper = _mapperConfiguration.CreateMapper();

            Action action = () => { mapper.Map<PutCustomerRequest>(input); };

            action.Should()
                .Throw<AutoMapperMappingException>()
                .Where(x => x.Message.Contains("Error mapping types") && x.Message.Contains("Dob"));
        }
    }
}