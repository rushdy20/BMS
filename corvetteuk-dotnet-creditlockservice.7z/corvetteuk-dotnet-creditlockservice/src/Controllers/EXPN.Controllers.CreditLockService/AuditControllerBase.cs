﻿using System;
using System.Threading.Tasks;
using EXPN.Controllers.CreditLockService.DateTime;
using EXPN.Controllers.CreditLockService.Messaging;
using Microsoft.AspNetCore.Mvc;

namespace EXPN.Controllers.CreditLockService
{
    public abstract class AuditControllerBase : ControllerBase
    {
        private readonly IMessaging _messaging;
        private readonly IDateTime _dateTime;

        protected AuditControllerBase(IMessaging messaging, IDateTime dateTime)
        {
            _messaging = messaging ?? throw new ArgumentNullException(nameof(messaging));
            _dateTime = dateTime ?? throw new ArgumentNullException(nameof(dateTime));
        }

        protected async Task RaiseEvent(string requestType, int statusCode, string statusText, string salesForceUserId = null)
        {
            const string eventName = "auditCreditLockRequest";

            var creditLockEventContent = new CreditLockEventContent
            {
                RequestType = requestType,
                RequestDt = _dateTime.Now,
                SalesforceUserId = salesForceUserId,
                ResponseStatusCode = statusCode.ToString(),
                ResponseStatusDescription = statusText
            };

            await _messaging.PublishEventAsync(eventName, creditLockEventContent);
        }
    }
}