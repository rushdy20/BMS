﻿using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace EXPN.UnitTest.CreditLockService.DataLayer.Paas.Helper
{
    public class TaskCanceledExceptionHandler : DelegatingHandler
    {
        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            throw new TaskCanceledException("Test Message");
        }
    }
}