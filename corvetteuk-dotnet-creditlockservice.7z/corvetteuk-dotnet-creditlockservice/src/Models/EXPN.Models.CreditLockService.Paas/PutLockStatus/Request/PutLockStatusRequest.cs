﻿using System.Diagnostics.CodeAnalysis;
using Newtonsoft.Json;

namespace EXPN.Models.CreditLockService.Paas.PutLockStatus.Request
{
    [ExcludeFromCodeCoverage]
    public class PutLockStatusRequest
    {
        [JsonIgnore]
        public string CustomerRef { get; set; }

        [JsonIgnore]
        public string CustomerId { get; set; }

        [JsonProperty]
        public string Status { get; set; }
    }
}