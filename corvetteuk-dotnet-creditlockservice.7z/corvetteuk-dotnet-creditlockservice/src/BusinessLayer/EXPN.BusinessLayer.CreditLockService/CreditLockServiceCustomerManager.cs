using AutoMapper;
using Experian.AWS.Logging.Extensions;
using EXPN.BusinessLayer.CreditLockService.Commands;
using EXPN.BusinessLayer.CreditLockService.Constants;
using EXPN.DataLayer.CreditLockService.Common.Exceptions;
using EXPN.DataLayer.CreditLockService.Customers;
using EXPN.Models.CreditLockService.Internal;
using EXPN.Models.CreditLockService.Internal.Delete.Request;
using EXPN.Models.CreditLockService.Internal.Delete.Response;
using EXPN.Models.CreditLockService.Internal.Get.Response;
using EXPN.Models.CreditLockService.Internal.Post.Request;
using EXPN.Models.CreditLockService.Internal.Post.Response;
using EXPN.Models.CreditLockService.Internal.Put.Request;
using EXPN.Models.CreditLockService.Internal.Put.Response;
using Microsoft.Extensions.Logging;
using System;
using System.Threading.Tasks;
using InternalGetModel = EXPN.Models.CreditLockService.Internal.Get;

namespace EXPN.BusinessLayer.CreditLockService
{
    public class CreditLockServiceCustomerManager : ICreditLockServiceCustomerManager
    {
        private readonly ILogger<CreditLockServiceCustomerManager> _logger;
        private readonly ICustomersClientProxy _customersClientProxy;
        private readonly ICommand<CustomerRequest, PostCustomerResponse> _createCustomerCommand;
        private readonly ICommand<InternalGetModel.Request.GetCustomerRequest, GetCustomerResponse> _getCustomerCommand;
        private readonly ICommand<PutLockStatusRequest, PutLockStatusResponse> _putLockStatusCommand;
        private readonly ICommand<DeleteCustomerRequest, DeleteCustomerResponse> _deleteCustomerCommand;
        private readonly ICommand<PostDeactivateInstantAlertRequest, PostDeactivateInstantAlertResponse> _deactivateInstantAlertCommand;
        private readonly ICommand<PostActivateInstantAlertRequest, PostActivateInstantAlertResponse> _activateInstantAlertCommand;
        private readonly ICommand<PutCustomerRequest, PutCustomerResponse> _syncCustomerCommand;
        private readonly IMapper _mapper;

        public CreditLockServiceCustomerManager(
            ILogger<CreditLockServiceCustomerManager> logger,
            ICommand<CustomerRequest, PostCustomerResponse> createCustomerCommand,
            ICommand<InternalGetModel.Request.GetCustomerRequest, GetCustomerResponse> getCustomerCommand,
            ICommand<PutLockStatusRequest, PutLockStatusResponse> putLockStatusCommand,
            ICommand<DeleteCustomerRequest, DeleteCustomerResponse> deleteCustomerCommand,
            ICommand<PostDeactivateInstantAlertRequest, PostDeactivateInstantAlertResponse> deactivateInstantAlertCommand,
            ICommand<PutCustomerRequest, PutCustomerResponse> syncCustomerCommand,
            ICommand<PostActivateInstantAlertRequest, PostActivateInstantAlertResponse> activateInstantAlertCommand,
            ICustomersClientProxy customersClientProxy,
            IMapper mapper)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _createCustomerCommand = createCustomerCommand ?? throw new ArgumentNullException(nameof(createCustomerCommand));
            _getCustomerCommand = getCustomerCommand ?? throw new ArgumentNullException(nameof(getCustomerCommand));
            _putLockStatusCommand = putLockStatusCommand ?? throw new ArgumentNullException(nameof(putLockStatusCommand));
            _deleteCustomerCommand = deleteCustomerCommand ?? throw new ArgumentNullException(nameof(deleteCustomerCommand));
            _deactivateInstantAlertCommand = deactivateInstantAlertCommand ?? throw new ArgumentNullException(nameof(deactivateInstantAlertCommand));
            _syncCustomerCommand = syncCustomerCommand ?? throw new ArgumentNullException(nameof(syncCustomerCommand));
            _activateInstantAlertCommand = activateInstantAlertCommand ?? throw new ArgumentNullException(nameof(activateInstantAlertCommand));
            _customersClientProxy = customersClientProxy ?? throw new ArgumentNullException(nameof(customersClientProxy));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        }

        public async Task ActivateAsync(CustomerRequest customerRequest)
        {
            _logger.LogAsInformation(LogEventNames.CreditLockServiceCustomerManager.Activate.Enter);

            if (customerRequest == null)
            {
                throw new ArgumentNullException(nameof(customerRequest));
            }

            if (string.IsNullOrWhiteSpace(customerRequest.CustomerId))
            {
                throw new ArgumentException($"{nameof(customerRequest.CustomerId)} cannot be null or whitespace", nameof(customerRequest));
            }

            await ActivateAsyncProcessing(customerRequest);

            _logger.LogAsInformation(LogEventNames.CreditLockServiceCustomerManager.Activate.Exit);
        }

        private async Task ActivateAsyncProcessing(CustomerRequest customerRequest)
        {
            var isReactivate = false;
            var customerProfile = await GetCustomerProfile(customerRequest.CustomerId);

            try
            {
                _createCustomerCommand.Execute(customerRequest, customerProfile);
            }
            catch (AggregateException ae)
            {
                ae.Handle(ex =>
                {
                    if (ex is not CustomerPostRequestConflictException)
                    {
                        throw ex;
                    }

                    isReactivate = true;
                    return true;
                });
            }

            if (isReactivate)
            {
                SyncCustomer(_mapper.Map<PutCustomerRequest>(customerRequest), customerProfile);
            }
        }

        public async Task<GetCustomerResponse> GetCustomerAsync(InternalGetModel.Request.GetCustomerRequest getCustomerRequest)
        {
            _logger.LogAsInformation(LogEventNames.CreditLockServiceCustomerManager.GetCustomer.Enter);

            if (getCustomerRequest == null)
            {
                throw new ArgumentNullException(nameof(getCustomerRequest));
            }

            if (string.IsNullOrWhiteSpace(getCustomerRequest.CustomerId))
            {
                throw new ArgumentException($"{nameof(getCustomerRequest.CustomerId)} cannot be null or whitespace", nameof(getCustomerRequest));
            }

            var customerProfile = await GetCustomerProfile(getCustomerRequest.CustomerId);

            var getCustomer = new GetCustomerResponse();
            try
            {
                getCustomer = _getCustomerCommand.Execute(getCustomerRequest, customerProfile);

                _logger.LogAsInformation(LogEventNames.CreditLockServiceCustomerManager.GetCustomer.Exit);
            }
            catch (AggregateException ae)
            {
                ae.Handle(ex => throw ex);
            }

            return getCustomer;
        }

        public async Task PutLockStatus(PutLockStatusRequest putLockStatusRequest)
        {
            _logger.LogAsInformation(LogEventNames.CreditLockServiceCustomerManager.PutLockStatus.Enter);

            if (putLockStatusRequest == null)
            {
                throw new ArgumentNullException(nameof(putLockStatusRequest));
            }

            if (string.IsNullOrWhiteSpace(putLockStatusRequest.CustomerId))
            {
                throw new ArgumentException($"{nameof(putLockStatusRequest.CustomerId)} cannot be null or whitespace", nameof(putLockStatusRequest));
            }

            var customerProfile = await GetCustomerProfile(putLockStatusRequest.CustomerId);

            try
            {
                if (putLockStatusRequest.LockStatus)
                {
                    SyncCustomer(_mapper.Map<PutCustomerRequest>(putLockStatusRequest), customerProfile);
                }

                _putLockStatusCommand.Execute(putLockStatusRequest, customerProfile);

                _logger.LogAsInformation(LogEventNames.CreditLockServiceCustomerManager.PutLockStatus.Exit);
            }
            catch (AggregateException ae)
            {
                ae.Handle(ex => throw ex);
            }
        }

        public Task DeleteCustomer(DeleteCustomerRequest deleteCustomerRequest)
        {
            _logger.LogAsInformation(LogEventNames.CreditLockServiceCustomerManager.DeleteCustomer.Enter);

            if (deleteCustomerRequest == null)
            {
                throw new ArgumentNullException(nameof(deleteCustomerRequest));
            }

            if (string.IsNullOrWhiteSpace(deleteCustomerRequest.CustomerId))
            {
                throw new ArgumentException($"{nameof(deleteCustomerRequest.CustomerId)} cannot be null or whitespace", nameof(deleteCustomerRequest));
            }

            try
            {
                _deleteCustomerCommand.Execute(deleteCustomerRequest, null);

                _logger.LogAsInformation(LogEventNames.CreditLockServiceCustomerManager.DeleteCustomer.Exit);
            }
            catch (AggregateException ae)
            {
                ae.Handle(ex => throw ex);
            }

            return Task.CompletedTask;
        }

        public async Task DeactivateInstantAlert(PostDeactivateInstantAlertRequest postDeactivateInstantAlertRequest)
        {
            _logger.LogAsInformation(LogEventNames.CreditLockServiceCustomerManager.DeactivateInstantAlert.Enter);

            if (postDeactivateInstantAlertRequest == null)
            {
                throw new ArgumentNullException(nameof(postDeactivateInstantAlertRequest));
            }

            if (string.IsNullOrWhiteSpace(postDeactivateInstantAlertRequest.CustomerId))
            {
                throw new ArgumentException($"{nameof(postDeactivateInstantAlertRequest.CustomerId)} cannot be null or whitespace", nameof(postDeactivateInstantAlertRequest));
            }

            var customerProfile = await GetCustomerProfile(postDeactivateInstantAlertRequest.CustomerId);

            try
            {
                _deactivateInstantAlertCommand.Execute(postDeactivateInstantAlertRequest, customerProfile);

                _logger.LogAsInformation(LogEventNames.CreditLockServiceCustomerManager.DeactivateInstantAlert.Exit);
            }
            catch (AggregateException ae)
            {
                ae.Handle(ex => throw ex);
            }
        }

        public async Task UpdateCustomer(PutCustomerRequest putCustomerRequest)
        {
            _logger.LogAsInformation(LogEventNames.CreditLockServiceCustomerManager.Update.Enter);

            if (putCustomerRequest == null)
            {
                throw new ArgumentNullException(nameof(putCustomerRequest));
            }

            if (string.IsNullOrWhiteSpace(putCustomerRequest.CustomerId))
            {
                throw new ArgumentException($"{nameof(putCustomerRequest.CustomerId)} cannot be null or whitespace", nameof(putCustomerRequest));
            }

            var customerProfile = await GetCustomerProfile(putCustomerRequest.CustomerId);

            SyncCustomer(putCustomerRequest, customerProfile);

            _logger.LogAsInformation(LogEventNames.CreditLockServiceCustomerManager.Update.Exit);
        }

        private void SyncCustomer(PutCustomerRequest putCustomerRequest, GetResponseCustomerProfile customerProfile)
        {
            _logger.LogAsInformation(LogEventNames.CreditLockServiceCustomerManager.Sync.Enter);

            var putCustomerResponse = new PutCustomerResponse();

            try
            {
                putCustomerResponse = _syncCustomerCommand.Execute(putCustomerRequest, customerProfile);
            }
            catch (AggregateException ae)
            {
                ae.Handle(ex =>
                {
                    putCustomerResponse.HasMadeSyncRequest = true;

                    throw ex;
                });
            }

            _logger.LogAsInformation(LogEventNames.CreditLockServiceCustomerManager.Sync.Exit);
        }

        public async Task ActivateInstantAlert(PostActivateInstantAlertRequest postActivateInstantAlertRequest)
        {
            _logger.LogAsInformation(LogEventNames.CreditLockServiceCustomerManager.ActivateInstantAlert.Enter);

            if (postActivateInstantAlertRequest == null)
            {
                throw new ArgumentNullException(nameof(postActivateInstantAlertRequest));
            }

            if (string.IsNullOrWhiteSpace(postActivateInstantAlertRequest.CustomerId))
            {
                throw new ArgumentException($"{nameof(postActivateInstantAlertRequest.CustomerId)} cannot be null or whitespace", nameof(postActivateInstantAlertRequest));
            }

            var customerProfile = await GetCustomerProfile(postActivateInstantAlertRequest.CustomerId);

            try
            {
                _activateInstantAlertCommand.Execute(postActivateInstantAlertRequest, customerProfile);

                _logger.LogAsInformation(LogEventNames.CreditLockServiceCustomerManager.ActivateInstantAlert.Exit);
            }
            catch (AggregateException ae)
            {
                ae.Handle(ex => throw ex);
            }
        }

        private async Task<GetResponseCustomerProfile> GetCustomerProfile(string customerId)
        {
            var getResponseCustomerProfile = await _customersClientProxy.GetCustomerProfile(customerId);

            if (getResponseCustomerProfile == null)
                throw new CustomerProfileNotFoundException($"{customerId} customer profile not found");

            return getResponseCustomerProfile;
        }
    }
}