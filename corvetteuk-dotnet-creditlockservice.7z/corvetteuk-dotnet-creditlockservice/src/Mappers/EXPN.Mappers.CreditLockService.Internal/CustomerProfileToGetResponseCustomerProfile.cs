﻿using AutoMapper;
using EXPN.Mappers.CreditLockService.Internal.Extensions;
using EXPN.Models.CreditLockService.Internal.Get.Response;

namespace EXPN.Mappers.CreditLockService.Internal
{
    public class CustomerProfileToGetResponseCustomerProfile : Profile
    {

        public CustomerProfileToGetResponseCustomerProfile()
        {
            CreateMap<Experian.HttpClient.Services.Customers.Models.External.CustomerProfile, GetResponseCustomerProfile>()
                .ForMember(d => d.Address, m => m.MapFrom(s => Utility.TakeOnlylastNineNonOverseasAddress(s.Address)))
                .ForMember(d => d.CustomerRef, m => m.MapFrom(s => s.CustomerNumber));
        }
    }
}