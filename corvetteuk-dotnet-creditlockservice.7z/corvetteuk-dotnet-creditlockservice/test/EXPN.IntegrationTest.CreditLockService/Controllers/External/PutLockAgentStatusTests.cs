using EXPN.DataLayer.CreditLockService.Paas.HttpClient;
using EXPN.IntegrationTest.CreditLockService.Utility;
using EXPN.Models.CreditLockService.External.Put.Request;
using FluentAssertions;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using System.Net;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Xunit;

namespace EXPN.IntegrationTest.CreditLockService.Controllers.External
{
    public class PutLockAgentStatusTests
    {
        private readonly IHostBuilder _hostBuilder;

        public PutLockAgentStatusTests()
        {
            _hostBuilder = new HostBuilder()
                .UseIntegrationTestSettings()
                .ConfigureServices(s =>
                    s.AddHttpClient<ICreditLockPaasClient, CreditLockPaasClient>(c =>
                    {
                        c.DefaultRequestHeaders
                            .Accept
                            .Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    }).AddHttpMessageHandler<MockPaasHttpClientHandler>());
        }

        public static IEnumerable<object[]> GetReportData()
        {
            yield return new object[]
            {
                null,
                "ON",
                "A1234567890",
                (HttpStatusCode) 400,
               "{\"fieldErrors\":{\"CustomerId\":\"'Customer Id' must not be empty.\"},\"status\":400,\"message\":null}"
            };

            yield return new object[]
            {
                "4b1f51c5-e902-4efb-8366-816e29e788e7",
                "ON",
                null,
                (HttpStatusCode) 400,
                "{\"fieldErrors\":{\"body.salesforceUserId\":\"'Salesforce User Id' should not be null\"},\"status\":400,\"message\":null}"
            };

            yield return new object[]
            {
                "4b1f51c5-e902-4efb-8366-816e29e798e7",
                "ON",
                "A1234567890",
                (HttpStatusCode) 409,
                null
            };

            yield return new object[]
            {
                "4a1f51c5-e902-4efb-8366-816e29e78561",
                "OFF",
                "A1234567890",
                (HttpStatusCode) 561,
                "{\"fieldErrors\":{},\"status\":561,\"message\":null}"
            };

            yield return new object[]
            {
                "4a1f51c5-e902-4efb-8366-816e29e78503",
                "OFF",
                "A1234567890",
                (HttpStatusCode) 503,
                "{\"fieldErrors\":{},\"status\":503,\"message\":null}"
            };

            yield return new object[]
            {
                "4a1f51c5-e902-4efb-8366-816e29e78404",
                "OFF",
                "A1234567890",
                (HttpStatusCode) 404,
                "{\"fieldErrors\":{},\"status\":404,\"message\":null}"
            };

            yield return new object[]
            {
                "9009758b-62f8-42d4-8f93-1dec01772a6f",
                "OFF",
                "A1234567890",
                (HttpStatusCode) 403,
                "{\"fieldErrors\":{},\"status\":403,\"message\":\"Benefit could not be fulfilled\"}"
            };

            yield return new object[]
            {
                "9009758b-62f8-42d4-8f93-1dec01772ccf",
                "OFF",
                "A1234567890",
                (HttpStatusCode) 500,
                "{\"fieldErrors\":{},\"status\":500,\"message\":\"Upstream service subscriptions returned no data.\"}"
            };
        }

        [Theory]
        [MemberData(nameof(GetReportData))]
        public async Task PutExternalController_ResponseExpected(string customerId, string status, string salesforceUserId, HttpStatusCode expectedStatusCode, string expectedServiceResponseJsonStr)
        {
            var requestBody = new PutStatusAgentRequestBody
            {
                SalesforceUserId = salesforceUserId,
                Status = status
            };

            var jsonString = JsonConvert.SerializeObject(requestBody);

            var actualServiceResponse = await CommonIntegrationFunctions.PutAgentExternalController(customerId, jsonString, _hostBuilder);

            actualServiceResponse.StatusCode.Should().Be(expectedStatusCode);

            if (expectedServiceResponseJsonStr != null)
            {
                var actualServiceResponseJsonStr = await actualServiceResponse.Content.ReadAsStringAsync();

                JToken.DeepEquals(JObject.Parse(actualServiceResponseJsonStr),
                    JObject.Parse(expectedServiceResponseJsonStr)).Should().BeTrue();
            }
        }
    }
}