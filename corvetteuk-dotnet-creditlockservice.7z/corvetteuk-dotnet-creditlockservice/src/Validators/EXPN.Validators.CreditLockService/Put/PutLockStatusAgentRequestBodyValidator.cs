﻿using EXPN.Models.CreditLockService.External.Put.Request;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;

namespace EXPN.Validators.CreditLockService.Put
{
    public class PutLockStatusAgentRequestBodyValidator : AbstractValidator<PutStatusAgentRequestBody>
    {
        private readonly List<string> _statusType = new List<string> { "ON", "OFF" };

        public PutLockStatusAgentRequestBodyValidator()
        {
            RuleFor(x => x)
                .NotNull()
                .WithName(nameof(PutStatusAgentRequestBody))
                .DependentRules(() =>
                {
                    RuleFor(x => x.Status)
                        .Cascade(CascadeMode.StopOnFirstFailure)
                        .NotEmpty()
                        .Must(x => _statusType.Contains(x, StringComparer.OrdinalIgnoreCase))
                        .WithMessage("'{PropertyValue}' is not a valid Status type.");

                    RuleFor(instance => instance.SalesforceUserId)
                        .Cascade(CascadeMode.StopOnFirstFailure)
                        .NotEmpty()
                        .WithMessage("'{PropertyName}' should not be null");
                });
        }
    }
}