﻿using EXPN.BusinessLayer.CreditLockService;
using EXPN.DataLayer.CreditLockService.Paas;
using EXPN.Validators.CreditLockService;
using Microsoft.Extensions.DependencyInjection;
using System.Diagnostics.CodeAnalysis;
using EXPN.Controllers.CreditLockService;
using EXPN.Controllers.CreditLockService.Messaging;
using EXPN.DataLayer.CreditLockService.Customers;
using EXPN.DataLayer.CreditLockService.Subscriptions;

namespace EXPN.ServiceHost.CreditLockService
{
    [ExcludeFromCodeCoverage]
    public static class ServiceHostModule
    {
        public static IServiceCollection AddServiceHostModule(this IServiceCollection services)
        {
            services.RegisterValidatorsModule();
            services.AddControllerLayerModule();
            services.AddBusinessLayerModule();
            services.AddMessagingModule();
            services.AddCustomersDataLayerModule();
            services.AddPaasDataLayerModule();
            services.AddSubscriptionsDataLayerModule();
            
            return services;
        }
    }
}
