﻿using System;
using System.Runtime.Serialization;

namespace EXPN.DataLayer.CreditLockService.Common.Exceptions
{
    [Serializable]
    public class CustomerPostRequestException : Exception
    {
        protected CustomerPostRequestException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }

        public CustomerPostRequestException()
        {
        }

        public CustomerPostRequestException(string message)
            : base(message)
        {
        }

        public CustomerPostRequestException(string message, Exception innerException)
            : base(message, innerException)
        {
        }
    }
}