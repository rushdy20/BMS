using Experian.HttpClient.Handlers.InternalService.Certificates;
using Experian.HttpClient.Handlers.InternalService.ClientHandlers.AllowExperianCertificates;
using Experian.HttpClient.Handlers.InternalService.MessageHandlers.ForwardHeaders;
using Experian.HttpClient.Handlers.RequestTimer.Factories;
using Experian.HttpClient.Handlers.RequestTimer.Handlers;
using EXPN.DataLayer.CreditLockService.Paas.HttpClient;
using EXPN.DataLayer.CreditLockService.Paas.Settings;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Net.Http;
using System.Net.Http.Headers;
using Policy = Polly.Policy;

namespace EXPN.DataLayer.CreditLockService.Paas
{
    [ExcludeFromCodeCoverage]
    public static class PaasDataLayerModule
    {
        public static IServiceCollection AddPaasDataLayerModule(this IServiceCollection services)
        {
            services.AddSingleton<ICertificateNames, CertificateNames>();
            services.AddSingleton<ISecretsManager, SecretsManager>();
            services.AddTransient<AllowExperianCertificatesHttpMessageHandler>();
            services.AddTransient<ForwardHeadersHttpMessageHandler>();
            services.AddTransient<IStopwatchFactory, StopwatchFactory>();
            services.AddTransient<RequestTimerHandler>();

            services
                .AddHttpClient<IOktaClient, OktaClient>(c =>
                {
                    c.DefaultRequestHeaders
                        .Accept
                        .Add(new MediaTypeWithQualityHeaderValue("application/json"));
                })
                .AddPolicyHandler(Policy.TimeoutAsync<HttpResponseMessage>(TimeSpan.FromSeconds(30)))
                .AddHttpMessageHandler<RequestTimerHandler>();

            services
                .AddHttpClient<ICreditLockPaasClient, CreditLockPaasClient>(c =>
                {
                    c.DefaultRequestHeaders
                        .Accept
                        .Add(new MediaTypeWithQualityHeaderValue("application/json"));
                })
                .AddPolicyHandler(Policy.TimeoutAsync<HttpResponseMessage>(TimeSpan.FromSeconds(30)))
                .AddHttpMessageHandler<RequestTimerHandler>();

            return services;
        }
    }
}