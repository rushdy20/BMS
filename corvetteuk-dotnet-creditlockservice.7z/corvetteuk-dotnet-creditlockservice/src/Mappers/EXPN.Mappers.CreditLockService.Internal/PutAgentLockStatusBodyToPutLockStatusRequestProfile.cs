﻿using System;
using System.Diagnostics.CodeAnalysis;
using AutoMapper;
using EXPN.Models.CreditLockService.External.Put.Request;
using EXPN.Models.CreditLockService.Internal.Put.Request;

namespace EXPN.Mappers.CreditLockService.Internal
{
    [ExcludeFromCodeCoverage]
    public class PutAgentLockStatusBodyToPutLockStatusRequestProfile : Profile
    {
        public PutAgentLockStatusBodyToPutLockStatusRequestProfile()
        {
            CreateMap<PutStatusAgentRequestBody, PutLockStatusRequest>()
                .ForMember(d => d.LockStatus, m => m.MapFrom(s => s.Status.Equals("ON", StringComparison.OrdinalIgnoreCase)))
                .ForMember(d => d.SalesForceUserId, m => m.MapFrom(s => s.SalesforceUserId))
                .ForMember(d => d.CustomerId, opt => opt.Ignore());
        }
    }
} 