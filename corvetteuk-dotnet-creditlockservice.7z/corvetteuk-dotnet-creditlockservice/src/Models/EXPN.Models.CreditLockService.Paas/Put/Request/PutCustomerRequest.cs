﻿using System.Collections.Generic;
using System.Xml.Serialization;
using Newtonsoft.Json;

namespace EXPN.Models.CreditLockService.Paas.Put.Request
{
    public class PutCustomerRequest : Customer
    {
        public IEnumerable<PutCustomerAddressRequest> AddressesToAdd { get; set; }
        public IEnumerable<string> AddressesToDelete { get; set; }
        [JsonIgnore]
        public IEnumerable<PutCustomerAddressRequest> AddressFromCorvetteProfiler { get; set; }
    }
}