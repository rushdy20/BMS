using EXPN.DataLayer.CreditLockService.Paas.HttpClient;
using EXPN.IntegrationTest.CreditLockService.Utility;
using EXPN.Models.CreditLockService.External.Put.Request;
using FluentAssertions;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using System.Net;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Xunit;

namespace EXPN.IntegrationTest.CreditLockService.Controllers.External
{
    public class PutLockStatusTests
    {
        private readonly IHostBuilder _hostBuilder;

        public PutLockStatusTests()
        {
            _hostBuilder = new HostBuilder()
                .UseIntegrationTestSettings()
                .ConfigureServices(s =>
                    s.AddHttpClient<ICreditLockPaasClient, CreditLockPaasClient>(c =>
                    {
                        c.DefaultRequestHeaders
                            .Accept
                            .Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    }).AddHttpMessageHandler<MockPaasHttpClientHandler>());
        }

        public static IEnumerable<object[]> GetReportData()
        {
            yield return new object[]
            {
                "4b1f51c5-e902-4efb-8366-816e29e798e7",
                "ON",
                (HttpStatusCode) 409,
                null
            };

            yield return new object[]
            {
                "not a valid id",
                "ON",
                (HttpStatusCode) 400,
                "{\"fieldErrors\": {\"CustomerId\": \"'CustomerId' is not in valid format.\"},\"status\": 400,\"message\": null}"
            };

            yield return new object[]
            {
                "4a1f51c5-e902-4efb-8366-816e29e788e7",
                "Not valid",
                (HttpStatusCode) 400,
                "{\"fieldErrors\":{\"body.status\":\"'Not valid' is not a valid Status type.\"},\"status\":400,\"message\":null}"
            };

            yield return new object[]
            {
                "4b1f51c5-e902-4efb-8366-816e29e788e7",
                "OFF",
                (HttpStatusCode) 204,
                null
            };

            yield return new object[]
            {
                "4a1f51c5-e902-4efb-8366-816e29e78561",
                "OFF",
                (HttpStatusCode) 561,
                "{\"fieldErrors\":{},\"status\":561,\"message\":null}"
            };

            yield return new object[]
            {
                "4a1f51c5-e902-4efb-8366-816e29e78503",
                "OFF",
                (HttpStatusCode) 503,
                "{\"fieldErrors\":{},\"status\":503,\"message\":null}"
            };

            yield return new object[]
            {
                "4a1f51c5-e902-4efb-8366-816e29e78404",
                "OFF",
                (HttpStatusCode) 404,
                "{\"fieldErrors\":{},\"status\":404,\"message\":null}"
            };

            yield return new object[]
            {
                "9009758b-62f8-42d4-8f93-1dec01772a6f",
                 "OFF",
                (HttpStatusCode) 403,
                "{\"fieldErrors\":{},\"status\":403,\"message\":\"Benefit could not be fulfilled\"}"
            };

            yield return new object[]
            {
                "9009758b-62f8-42d4-8f93-1dec01772ccf",
                "OFF",
                (HttpStatusCode) 500,
                "{\"fieldErrors\":{},\"status\":500,\"message\":\"Upstream service subscriptions returned no data.\"}"
            };
        }

        [Theory]
        [MemberData(nameof(GetReportData))]
        public async Task PutExternalController_ResponseExpected(string customerId, string status, HttpStatusCode expectedStatusCode, string expectedServiceResponseJsonStr)
        {
            var requestBody = new PutStatusRequestBody
            {
                Status = status
            };

            var jsonString = JsonConvert.SerializeObject(requestBody);

            var actualServiceResponse = await CommonIntegrationFunctions.PutExternalController(customerId, jsonString, _hostBuilder);

            actualServiceResponse.StatusCode.Should().Be(expectedStatusCode);

            if (expectedServiceResponseJsonStr != null)
            {
                var actualServiceResponseJsonStr = await actualServiceResponse.Content.ReadAsStringAsync();

                JToken.DeepEquals(JObject.Parse(actualServiceResponseJsonStr),
                    JObject.Parse(expectedServiceResponseJsonStr)).Should().BeTrue();
            }
        }
    }
}