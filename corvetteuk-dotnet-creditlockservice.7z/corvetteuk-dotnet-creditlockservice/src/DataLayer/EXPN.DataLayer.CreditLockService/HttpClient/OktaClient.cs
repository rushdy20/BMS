﻿using Experian.AWS.Logging.Extensions;
using EXPN.DataLayer.CreditLockService.Common.Exceptions;
using EXPN.DataLayer.CreditLockService.Paas.Constants;
using EXPN.DataLayer.CreditLockService.Paas.Extension;
using EXPN.Models.CreditLockService.External.OktaService;
using EXPN.Models.CreditLockService.Paas;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace EXPN.DataLayer.CreditLockService.Paas.HttpClient
{
    public class OktaClient : IOktaClient
    {
        private readonly System.Net.Http.HttpClient _httpClient;
        private readonly ILogger<OktaClient> _logger;
        private readonly OktaAuthCredentials _oktaAuthCredentials;
        private readonly IMemoryCache _memoryCache;

        private const string PaasOktaToken = "PaasOktaToken";

        public OktaClient(System.Net.Http.HttpClient httpClient,
            ILogger<OktaClient> logger,
            IOptions<OktaAuthCredentials> oktaAuthCredentials,
            IMemoryCache memoryCache
        )
        {
            _httpClient = httpClient ?? throw new ArgumentNullException(nameof(httpClient));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _memoryCache = memoryCache ?? throw new ArgumentNullException(nameof(memoryCache));

            if (oktaAuthCredentials == null)
                throw new ArgumentNullException(nameof(oktaAuthCredentials));

            _oktaAuthCredentials = oktaAuthCredentials.Value ?? throw new ArgumentException($"{nameof(oktaAuthCredentials.Value)} cannot be null", nameof(oktaAuthCredentials));
        }

        public async Task<string> GetAuthTokenAsync(bool refreshToken = false)
        {
            if (refreshToken)
            {
                _logger.LogAsInformation( LogEventNames.OktaClient.GetAuthTokenAsync.RemoveOktaTokenFromMemoryCache);
                _memoryCache.Remove(PaasOktaToken);
            }

            if (_memoryCache.TryGetValue<string>(PaasOktaToken, out var token))
            {
                _logger.LogAsInformation(LogEventNames.OktaClient.GetAuthTokenAsync.RetrievedOktaTokenFromMemoryCache);
                return token;
            }

            var requestMessage = BuildOktaRequest();

            var response = await _httpClient.SendAsync(requestMessage);

            if (!response.IsSuccessStatusCode)
            {
                var extraData = new Dictionary<string, object>
                {
                    {LogEventKeys.Context, new Dictionary<string, object>
                        {
                            {LogEventKeys.StatusCode, response.StatusCode},
                            {LogEventKeys.Content, response.Content}
                        }
                    }
                };

                _logger.LogAsWarning(LogEventNames.OktaClient.GetAuthTokenAsync.AuthRequestFail, extraData);

                throw new OktaException($"Response does not indicate success - Status Code: {(int)response.StatusCode}");
            }

            var jsonResponseString = await response.Content.ReadAsStringAsync();
            var oktaTokenResponse = JsonConvert.DeserializeObject<OktaAuthTokenResponse>(jsonResponseString);

            _logger.LogAsInformation(LogEventNames.OktaClient.GetAuthTokenAsync.AuthRequestSuccess);

            if (oktaTokenResponse.ExpiresIn <= 0)
            {
                return oktaTokenResponse.AccessToken;
            }

            try
            {
                _logger.LogAsInformation(LogEventNames.OktaClient.GetAuthTokenAsync.AddOktaTokenToMemoryCache);

                _memoryCache.Set(
                    PaasOktaToken,
                    oktaTokenResponse.AccessToken,
                    DateTimeOffset.UtcNow.AddSeconds(oktaTokenResponse.ExpiresIn * 0.9));
            }
            catch
            {
                _logger.LogAsWarning(LogEventNames.OktaClient.GetAuthTokenAsync.FailedToStoreOktaTokenInMemoryCache);
            }

            return oktaTokenResponse.AccessToken;
        }

        private HttpRequestMessage BuildOktaRequest()
        {
            if (string.IsNullOrWhiteSpace(_oktaAuthCredentials.Endpoint))
            {
                throw new OktaCredentialsEndpointNullException();
            }

            var encodedSecret = EncodeSecret(_oktaAuthCredentials.ClientId, _oktaAuthCredentials.SharedSecret);

            return new HttpRequestMessage
            {
                RequestUri = new Uri(_oktaAuthCredentials.Endpoint),
                Content = new FormUrlEncodedContent(GetFormContent(_oktaAuthCredentials)),
                Method = HttpMethod.Post,
                Headers =
                {
                    Authorization = new AuthenticationHeaderValue(Enum.GetName(typeof(AuthenticationSchemes), AuthenticationSchemes.Basic), encodedSecret)
                }
            };
        }

        internal string EncodeSecret(string clientId, string sharedSecret)
        {
            var encodedBytes = Encoding.UTF8.GetBytes($"{clientId}:{sharedSecret}");

            return Convert.ToBase64String(encodedBytes);
        }

        private static IEnumerable<KeyValuePair<string, string>> GetFormContent(OktaAuthCredentials authDetails)
        {
            return new List<KeyValuePair<string, string>>
            {
                new KeyValuePair<string, string>("grant_type", authDetails.GrantType),
                new KeyValuePair<string, string>("scope", authDetails.Scope),
                new KeyValuePair<string, string>("username", authDetails.Username),
                new KeyValuePair<string, string>("password", authDetails.Password)
            };
        }
    }
}