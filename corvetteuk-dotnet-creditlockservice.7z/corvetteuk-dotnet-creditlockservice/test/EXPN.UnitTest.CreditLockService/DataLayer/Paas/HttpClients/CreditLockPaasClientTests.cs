﻿using EXPN.DataLayer.CreditLockService.Common.Exceptions;
using EXPN.DataLayer.CreditLockService.Paas.Constants;
using EXPN.DataLayer.CreditLockService.Paas.HttpClient;
using EXPN.Models.CreditLockService.Paas;
using EXPN.Models.CreditLockService.Paas.Delete.Request;
using EXPN.Models.CreditLockService.Paas.Get.Request;
using EXPN.Models.CreditLockService.Paas.Post.Request;
using EXPN.Models.CreditLockService.Paas.Put.Request;
using EXPN.Models.CreditLockService.Paas.PutAlertStatus.Request;
using EXPN.Models.CreditLockService.Paas.PutLockStatus.Request;
using EXPN.UnitTest.CreditLockService.DataLayer.Paas.Helper;
using FluentAssertions;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using NSubstitute;
using NSubstitute.ReturnsExtensions;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace EXPN.UnitTest.CreditLockService.DataLayer.Paas.HttpClients
{
    public class CreditLockPaasClientTests
    {
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly ILogger<CreditLockPaasClient> _logger;
        private readonly IOktaClient _oktaClient;
        private readonly IOptions<OktaAuthCredentials> _optionsOktaAuthCredentials;

        private ICreditLockPaasClient _creditLockPaasClient;

        public CreditLockPaasClientTests()
        {
            _httpClientFactory = Substitute.For<IHttpClientFactory>();
            _logger = Substitute.For<ILogger<CreditLockPaasClient>>();
            _oktaClient = Substitute.For<IOktaClient>();
            _optionsOktaAuthCredentials = Substitute.For<IOptions<OktaAuthCredentials>>();

            _optionsOktaAuthCredentials.Value
                .Returns(new OktaAuthCredentials
                {
                    ServiceEndpoint = "http://testendpoint.com"
                });

            var responses = new[]
            {
                new HttpResponseMessage
                {
                    StatusCode = HttpStatusCode.NoContent,
                    Content = new StringContent("test", Encoding.UTF8, "application/json")
                }
            };

            var fakeHttpMessageHandler = new FakeHttpMessagesHandler(responses);

            _httpClientFactory.CreateClient()
                .Returns(new HttpClient(fakeHttpMessageHandler));

            _creditLockPaasClient = new CreditLockPaasClient(_httpClientFactory.CreateClient(), _logger, _oktaClient,
                _optionsOktaAuthCredentials);
        }

        public class Constructor : CreditLockPaasClientTests
        {
            public static IEnumerable<object[]> NullParameters()
            {
                yield return new object[]
                {
                    null,
                    Substitute.For<ILogger<CreditLockPaasClient>>(),
                    Substitute.For<IOktaClient>(),
                    Substitute.For<IOptions<OktaAuthCredentials>>(),
                    "httpClient"
                };

                yield return new object[]
                {
                    Substitute.For<HttpClient>(),
                    null,
                    Substitute.For<IOktaClient>(),
                    Substitute.For<IOptions<OktaAuthCredentials>>(),
                    "logger"
                };

                yield return new object[]
                {
                    Substitute.For<HttpClient>(),
                    Substitute.For<ILogger<CreditLockPaasClient>>(),
                    null,
                    Substitute.For<IOptions<OktaAuthCredentials>>(),
                    "oktaClient"
                };

                yield return new object[]
                {
                    Substitute.For<HttpClient>(),
                    Substitute.For<ILogger<CreditLockPaasClient>>(),
                    Substitute.For<IOktaClient>(),
                    null,
                    "oktaAuthCredentials"
                };
            }

            [Theory]
            [MemberData(nameof(NullParameters))]
            public void NullRequiredConstructorParameter_ThrowsArgumentNullException(HttpClient httpClient,
                ILogger<CreditLockPaasClient> logger,
                IOktaClient oktaClient,
                IOptions<OktaAuthCredentials> optionsOktaAuthCredentials,
                string expectedErrorParameter
            )
            {
                Action action = () =>
                {
                    var unused = new CreditLockPaasClient(httpClient, logger, oktaClient, optionsOktaAuthCredentials);
                };

                action.Should()
                    .Throw<ArgumentNullException>()
                    .Where(x => x.ParamName == expectedErrorParameter);
            }

            [Fact]
            public void NullRequiredOktaAuthCredentialsValueInConstructor_ThrowsArgumentException()
            {
                _optionsOktaAuthCredentials.Value
                    .Returns(_ => null);

                Action action = () =>
                {
                    var unused = new CreditLockPaasClient(_httpClientFactory.CreateClient(), _logger, _oktaClient,
                        _optionsOktaAuthCredentials);
                };

                action.Should()
                    .Throw<ArgumentException>()
                    .WithMessage("Value cannot be null (Parameter 'oktaAuthCredentials')");
            }
        }

        public class ExceptionHandling : CreditLockPaasClientTests
        {
            [Fact]
            public async Task PostRequest_ThrowsHttpRequestException_CatchesHttpServiceRequestException()
            {
                var fakeHttpMessageHandler = new HttpRequestExceptionHandler();

                _httpClientFactory.CreateClient()
                    .Returns(new HttpClient(fakeHttpMessageHandler));

                var creditLockPaasClient = new CreditLockPaasClient(_httpClientFactory.CreateClient(), _logger, _oktaClient,
                    _optionsOktaAuthCredentials);

                _oktaClient.GetAuthTokenAsync()
                    .Returns("abcdef");

                var task = async () =>
                {
                    await creditLockPaasClient.Post(new PostCustomerRequest());
                };

                task.Should()
                    .Throw<HttpServiceRequestException>()
                    .WithMessage("PaaS Service not reached: Base Message");

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.DidNotReceive().GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(3).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(2).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PostRequest_RetryHttpRequestException_Success()
            {
                var fakeHttpMessageHandler = new HttpRequestExceptionThenSuccessHandler();

                _httpClientFactory.CreateClient()
                    .Returns(new HttpClient(fakeHttpMessageHandler));

                var creditLockPaasClient = new CreditLockPaasClient(_httpClientFactory.CreateClient(), _logger, _oktaClient,
                    _optionsOktaAuthCredentials);

                _oktaClient.GetAuthTokenAsync()
                    .Returns("abcdef");

                await creditLockPaasClient.Post(new PostCustomerRequest());

                await _oktaClient.Received(1).GetAuthTokenAsync();
                await _oktaClient.DidNotReceive().GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PostRequest_ThrowsTaskCanceledException_CatchesHttpServiceRequestException()
            {
                var fakeHttpMessageHandler = new TaskCanceledExceptionHandler();

                _httpClientFactory.CreateClient()
                    .Returns(new HttpClient(fakeHttpMessageHandler));

                var creditLockPaasClient = new CreditLockPaasClient(_httpClientFactory.CreateClient(), _logger, _oktaClient,
                    _optionsOktaAuthCredentials);

                _oktaClient.GetAuthTokenAsync()
                    .Returns("abcdef");

                Func<Task> task = async () =>
                {
                    await creditLockPaasClient.Post(new PostCustomerRequest());
                };

                task.Should()
                    .Throw<ServiceTaskCanceledException>()
                    .WithMessage("PaaS Service Task Canceled: Test Message");

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.DidNotReceive().GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }
        }

        public class Post : CreditLockPaasClientTests
        {
            [Fact]
            public void GetCustomerProfileCustomerIdInvalid_ThrowsArgumentException()
            {
                Func<Task> task = async () => { await _creditLockPaasClient.Post(null); };

                task.Should()
                    .Throw<ArgumentException>()
                    .Where(x => x.Message == "Value cannot be null. (Parameter 'postCustomerRequest')");
            }

            public static IEnumerable<object[]> LogInformationMessages()
            {
                yield return new object[]
                {
                    LogEventNames.CreditLockPaasClient.Post.Enter
                };

                yield return new object[]
                {
                    LogEventNames.CreditLockPaasClient.Post.Exit
                };
            }

            [Theory]
            [MemberData(nameof(LogInformationMessages))]
            public async Task HappyPathInformationLogged(string loggerMessage)
            {
                _oktaClient.GetAuthTokenAsync()
                    .Returns("abcdef");

                await _creditLockPaasClient.Post(new PostCustomerRequest());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(loggerMessage)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task Get_GetCustomerRequest_HappyPath_Success()
            {
                _oktaClient.GetAuthTokenAsync()
                    .Returns("abcdef");

                await _creditLockPaasClient.Post(new PostCustomerRequest());

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.DidNotReceive().GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task Post_PostCustomerRequest_NullToken_ThrowsOktaTokenNullException()
            {
                _oktaClient.GetAuthTokenAsync()
                    .ReturnsNull();

                Func<Task> task = async () =>
                {
                    await _creditLockPaasClient.Post(new PostCustomerRequest());
                };

                task.Should()
                    .Throw<OktaTokenNullException>()
                    .WithMessage("oktaToken cannot be null or whitespace");

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.DidNotReceive().GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task Post_PostCustomerRequest_StringEmptyToken_ThrowsOktaTokenNullException()
            {
                _oktaClient.GetAuthTokenAsync()
                    .Returns(string.Empty);

                Func<Task> task = async () =>
                {
                    await _creditLockPaasClient.Post(new PostCustomerRequest());
                };

                task.Should()
                    .Throw<OktaTokenNullException>()
                    .WithMessage("oktaToken cannot be null or whitespace");

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.DidNotReceive().GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task Post_PostCustomerRequest_StringWhitespace_ThrowsOktaTokenNullException()
            {
                _oktaClient.GetAuthTokenAsync()
                    .Returns(string.Empty.PadLeft(10));

                Func<Task> task = async () =>
                {
                    await _creditLockPaasClient.Post(new PostCustomerRequest());
                };

                task.Should()
                    .Throw<OktaTokenNullException>()
                    .WithMessage("oktaToken cannot be null or whitespace");

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.DidNotReceive().GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task Post_PostCustomerRequest_InitialRequestForbidden_Success()
            {
                var httpClientFactory = Substitute.For<IHttpClientFactory>();

                var responses = new[]
                {
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.Forbidden,
                        Content = new StringContent("test", Encoding.UTF8, "application/json")
                    },
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.NoContent,
                        Content = new StringContent("test", Encoding.UTF8, "application/json")
                    }
                };

                var fakeHttpMessageHandler = new FakeHttpMessagesHandler(responses);

                httpClientFactory.CreateClient()
                    .Returns(new HttpClient(fakeHttpMessageHandler));

                _oktaClient.GetAuthTokenAsync()
                    .Returns("abcdef");

                _oktaClient.GetAuthTokenAsync(true)
                    .Returns("xyz");

                var creditLockPaasClient = new CreditLockPaasClient(httpClientFactory.CreateClient(), _logger,
                    _oktaClient, _optionsOktaAuthCredentials);

                await creditLockPaasClient.Post(new PostCustomerRequest());

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.Received(1).GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task Post_PostCustomerRequest_InitialRequestForbidden_SecondReturnsNullToken_ThrowsOktaTokenNullException()
            {
                var httpClientFactory = Substitute.For<IHttpClientFactory>();

                var responses = new[]
                {
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.Forbidden,
                        Content = new StringContent("test", Encoding.UTF8, "application/json")
                    },
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.NoContent,
                        Content = new StringContent("test", Encoding.UTF8, "application/json")
                    }
                };

                var fakeHttpMessageHandler = new FakeHttpMessagesHandler(responses);

                httpClientFactory.CreateClient()
                    .Returns(new HttpClient(fakeHttpMessageHandler));

                _oktaClient.GetAuthTokenAsync()
                    .Returns("abcdef");

                _oktaClient.GetAuthTokenAsync(true)
                    .ReturnsNull();

                var creditLockPaasClient = new CreditLockPaasClient(httpClientFactory.CreateClient(), _logger,
                    _oktaClient, _optionsOktaAuthCredentials);

                Func<Task> task = async () =>
                {
                    await creditLockPaasClient.Post(new PostCustomerRequest());
                };

                task.Should()
                    .Throw<OktaTokenNullException>()
                    .WithMessage("oktaToken cannot be null or whitespace");

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.Received(1).GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task Post_PostCustomerRequest_InitialRequestForbidden_SecondReturnsStringEmptyToken_ThrowsOktaTokenNullException()
            {
                var httpClientFactory = Substitute.For<IHttpClientFactory>();

                var responses = new[]
                {
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.Forbidden,
                        Content = new StringContent("test", Encoding.UTF8, "application/json")
                    },
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.NoContent,
                        Content = new StringContent("test", Encoding.UTF8, "application/json")
                    }
                };

                var fakeHttpMessageHandler = new FakeHttpMessagesHandler(responses);

                httpClientFactory.CreateClient()
                    .Returns(new HttpClient(fakeHttpMessageHandler));

                _oktaClient.GetAuthTokenAsync()
                    .Returns("abcdef");

                _oktaClient.GetAuthTokenAsync(true)
                    .Returns(string.Empty);

                var creditLockPaasClient = new CreditLockPaasClient(httpClientFactory.CreateClient(), _logger,
                    _oktaClient, _optionsOktaAuthCredentials);

                Func<Task> task = async () => { await creditLockPaasClient.Post(new PostCustomerRequest()); };

                task.Should()
                    .Throw<OktaTokenNullException>()
                    .WithMessage("oktaToken cannot be null or whitespace");

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.Received(1).GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task Post_PostCustomerRequest_InitialRequestForbidden_SecondReturnsWhitespaceToken_ThrowsOktaTokenNullException()
            {
                var httpClientFactory = Substitute.For<IHttpClientFactory>();

                var responses = new[]
                {
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.Forbidden,
                        Content = new StringContent("test", Encoding.UTF8, "application/json")
                    },
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.NoContent,
                        Content = new StringContent("test", Encoding.UTF8, "application/json")
                    }
                };

                var fakeHttpMessageHandler = new FakeHttpMessagesHandler(responses);

                httpClientFactory.CreateClient()
                    .Returns(new HttpClient(fakeHttpMessageHandler));

                _oktaClient.GetAuthTokenAsync()
                    .Returns("abcdef");

                _oktaClient.GetAuthTokenAsync(true)
                    .Returns(string.Empty.PadLeft(10));

                var creditLockPaasClient = new CreditLockPaasClient(httpClientFactory.CreateClient(), _logger,
                    _oktaClient, _optionsOktaAuthCredentials);

                Func<Task> task = async () => { await creditLockPaasClient.Post(new PostCustomerRequest()); };

                task.Should()
                    .Throw<OktaTokenNullException>()
                    .WithMessage("oktaToken cannot be null or whitespace");

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.Received(1).GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task Post_PostCustomerRequest_SendRequestFailsConflict_ThrowsCustomerPostRequestConflictException()
            {
                _oktaClient.GetAuthTokenAsync()
                    .Returns("abc");

                var responses = new[]
                {
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.Conflict,
                        Content = new StringContent("test", Encoding.UTF8, "application/json")
                    }
                };

                var fakeHttpMessageHandler = new FakeHttpMessagesHandler(responses);

                var httpClientFactory = Substitute.For<IHttpClientFactory>();

                httpClientFactory.CreateClient()
                    .Returns(new HttpClient(fakeHttpMessageHandler));

                var creditLockPaasClient = new CreditLockPaasClient(httpClientFactory.CreateClient(), _logger,
                    _oktaClient, _optionsOktaAuthCredentials);

                Func<Task> task = async () => { await creditLockPaasClient.Post(new PostCustomerRequest()); };

                task.Should()
                    .Throw<CustomerPostRequestConflictException>();

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.DidNotReceive().GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
                
                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task Post_PostCustomerRequest_SendRequestFailsBadRequest_ThrowsCustomerPostRequestException()
            {
                _oktaClient.GetAuthTokenAsync()
                    .Returns("abc");

                var responses = new[]
                {
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.BadRequest,
                        Content = new StringContent("test", Encoding.UTF8, "application/json")
                    }
                };

                var fakeHttpMessageHandler = new FakeHttpMessagesHandler(responses);

                var httpClientFactory = Substitute.For<IHttpClientFactory>();

                httpClientFactory.CreateClient()
                    .Returns(new HttpClient(fakeHttpMessageHandler));

                var creditLockPaasClient = new CreditLockPaasClient(httpClientFactory.CreateClient(), _logger,
                    _oktaClient, _optionsOktaAuthCredentials);

                Func<Task> task = async () => { await creditLockPaasClient.Post(new PostCustomerRequest()); };

                task.Should()
                    .Throw<RequestBodyNullException> ();

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.DidNotReceive().GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.ResponseInvalidStatusCode)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }


            [Fact]
            public async Task Post_PostCustomerRequest_SendRequestFails_ThrowsInternalServerException()
            {
                _oktaClient.GetAuthTokenAsync()
                    .Returns("abc");

                var responses = new[]
                {
                    new HttpResponseMessage
                    {
                        StatusCode = (HttpStatusCode) 561,
                        Content = new StringContent("test", Encoding.UTF8, "application/json")
                    }
                };

                var fakeHttpMessageHandler = new FakeHttpMessagesHandler(responses);

                var httpClientFactory = Substitute.For<IHttpClientFactory>();

                httpClientFactory.CreateClient()
                    .Returns(new HttpClient(fakeHttpMessageHandler));

                var creditLockPaasClient = new CreditLockPaasClient(httpClientFactory.CreateClient(), _logger,
                    _oktaClient, _optionsOktaAuthCredentials);

                Func<Task> task = async () => { await creditLockPaasClient.Post(new PostCustomerRequest()); };

                task.Should()
                    .Throw<DownstreamMaintenanceException>();

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.DidNotReceive().GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
               
                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task Post_PostCustomerRequest_ServiceDown_ThrowsServiceUnavailableException()
            {
                _oktaClient.GetAuthTokenAsync()
                    .Returns("abc");

                var responses = new[]
                {
                    new HttpResponseMessage
                    {
                        StatusCode = (HttpStatusCode) 503,
                        Content = new StringContent("test", Encoding.UTF8, "application/json")
                    }
                };

                var fakeHttpMessageHandler = new FakeHttpMessagesHandler(responses);

                var httpClientFactory = Substitute.For<IHttpClientFactory>();

                httpClientFactory.CreateClient()
                    .Returns(new HttpClient(fakeHttpMessageHandler));

                var creditLockPaasClient = new CreditLockPaasClient(httpClientFactory.CreateClient(), _logger,
                    _oktaClient, _optionsOktaAuthCredentials);

                Func<Task> task = async () => { await creditLockPaasClient.Post(new PostCustomerRequest()); };

                task.Should()
                    .Throw<ServiceUnavailableException>();

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.DidNotReceive().GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
               
                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task Post_PostCustomerRequest_DownstreamBadResponseException_ThrowsStatusCode562()
            {
                _oktaClient.GetAuthTokenAsync()
                    .Returns("abc");

                var responses = new[]
                {
                    new HttpResponseMessage
                    {
                        StatusCode = (HttpStatusCode) 562,
                        Content = new StringContent("test", Encoding.UTF8, "application/json")
                    }
                };

                var fakeHttpMessageHandler = new FakeHttpMessagesHandler(responses);

                var httpClientFactory = Substitute.For<IHttpClientFactory>();

                httpClientFactory.CreateClient()
                    .Returns(new HttpClient(fakeHttpMessageHandler));

                var creditLockPaasClient = new CreditLockPaasClient(httpClientFactory.CreateClient(), _logger,
                    _oktaClient, _optionsOktaAuthCredentials);

                Func<Task> task = async () => { await creditLockPaasClient.Post(new PostCustomerRequest()); };

                task.Should()
                    .Throw<DownstreamBadResponseException>();

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.DidNotReceive().GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }


            [Fact]
            public async Task Post_PostCustomerRequest_CustomerPostRequestException_ThrowsStatusCode562()
            {
                _oktaClient.GetAuthTokenAsync()
                    .Returns("abc");

                var responses = new[]
                {
                    new HttpResponseMessage
                    {
                        StatusCode = (HttpStatusCode) 402,
                        Content = new StringContent("test", Encoding.UTF8, "application/json")
                    }
                };

                var fakeHttpMessageHandler = new FakeHttpMessagesHandler(responses);

                var httpClientFactory = Substitute.For<IHttpClientFactory>();

                httpClientFactory.CreateClient()
                    .Returns(new HttpClient(fakeHttpMessageHandler));

                var creditLockPaasClient = new CreditLockPaasClient(httpClientFactory.CreateClient(), _logger,
                    _oktaClient, _optionsOktaAuthCredentials);

                Func<Task> task = async () => { await creditLockPaasClient.Post(new PostCustomerRequest()); };

                task.Should()
                    .Throw<CustomerPostRequestException>();

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.DidNotReceive().GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Post.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }
        }
        
        public class Get : CreditLockPaasClientTests
        {
            public Get()
            {
                var jsonResponse ="{\"data\":[{\"clientId\":\"ECS\",\"customerId\":\"a69e102d-d776-490a-a0a1-dfe25c791df9\",\"lockStatus\":\"ON\",\"alertsStatus\":\"ON\",\"dob\":\"1990-12-31T00:00:00\",\"name\":{\"title\":\"Lord\",\"firstName\":\"Howard\",\"otherName\":\"Phillips\",\"lastName\":\"Lovecraft\",\"suffix\":\"Jr\"},\"addresses\":[{\"din\":\"202100011234567891\",\"pinStatus\":\"OK\",\"pinErrorCode\":\"\",\"pinErrorMessage\":\"\",\"flat\":null,\"houseName\":null,\"houseNumber\":\"42\",\"street\":\"Green Lane\",\"town\":\"Bigton\",\"county\":\"Homeshire\",\"postcode\":\"AB1 23X\"},{\"din\":\"202100011234567892\",\"pinStatus\":\"PENDING\",\"pinErrorCode\":\"\",\"pinErrorMessage\":\"\",\"flat\":\"4\",\"houseName\":null,\"houseNumber\":\"2\",\"street\":\"Brown Lane\",\"town\":\"Smalltown\",\"county\":\"Topplace On Tees\",\"postcode\":\"AC12 1PX\"},{\"din\":\"202100011234567893\",\"pinStatus\":\"FAIL\",\"pinErrorCode\":\"0xf00f\",\"pinErrorMessage\":\"lp0 on fire\",\"flat\":null,\"houseName\":null,\"houseNumber\":\"42\",\"street\":\"Media Circus\",\"town\":\"Pencastle\",\"county\":\"The North\",\"postcode\":\"this is not a valid postcode\"}]}]}";


                var responses = new[]
                {
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.OK,
                        Content = new StringContent(jsonResponse, Encoding.UTF8, "application/json")
                    }
                };

                var fakeHttpMessageHandler = new FakeHttpMessagesHandler(responses);

                _httpClientFactory.CreateClient()
                    .Returns(new HttpClient(fakeHttpMessageHandler));

                _creditLockPaasClient = new CreditLockPaasClient(_httpClientFactory.CreateClient(), _logger, _oktaClient,
                    _optionsOktaAuthCredentials);
            }

            [Fact]
            public void Get_NullRequest_ThrowsArgumentException()
            {
                Func<Task> task = async () =>
                {
                    await _creditLockPaasClient.GetPaasCustomerAsync(null);
                };

                task.Should()
                    .Throw<ArgumentException>()
                    .Where(x => x.Message == "Value cannot be null. (Parameter 'getCustomerRequest')");
            }

            public static IEnumerable<object[]> GetCustomerRequestArgumentException()
            {
                yield return new object[]
                {
                    new GetCustomerRequest
                    {
                        CustomerRef = null
                    }
                };

                yield return new object[]
                {
                    new GetCustomerRequest
                    {
                        CustomerRef = string.Empty
                    }
                };

                yield return new object[]
                {
                    new GetCustomerRequest
                    {
                        CustomerRef= string.Empty.PadLeft(10)
                    }
                };
            }

            [Theory]
            [MemberData(nameof(GetCustomerRequestArgumentException))]
            public void GetRequestCustomerIdNull_ThrowsArgumentNullException(GetCustomerRequest getCustomerRequest)
            {
                Func<Task> task = async () =>
                {
                    await _creditLockPaasClient.GetPaasCustomerAsync(getCustomerRequest);
                };

                task.Should()
                    .Throw<ArgumentException>()
                    .Where(x => x.Message == "CustomerRef cannot be null or whitespace (Parameter 'getCustomerRequest')");
            }

            public static IEnumerable<object[]> LogInformationMessages()
            {
                yield return new object[]
                {
                    LogEventNames.CreditLockPaasClient.Get.Enter
                };

                yield return new object[]
                {
                    LogEventNames.CreditLockPaasClient.Get.Exit
                };
            }

            [Theory]
            [MemberData(nameof(LogInformationMessages))]
            public async Task HappyPathInformationLogged(string loggerMessage)
            {
                _oktaClient.GetAuthTokenAsync()
                    .Returns("valid token");

                await _creditLockPaasClient.GetPaasCustomerAsync(new GetCustomerRequest
                {
                    CustomerRef = "customerId"
                });

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(loggerMessage)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task Get_GetCustomerRequest_HappyPath_Success()
            {
                _oktaClient.GetAuthTokenAsync()
                    .Returns("valid token");

                var response = await _creditLockPaasClient.GetPaasCustomerAsync(new GetCustomerRequest
                {
                    CustomerRef = "1234566A"
                });

                response.Should().NotBeNull();

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.DidNotReceive().GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Get.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Get.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Get.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Get.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            public static IEnumerable<object[]> AuthTokenFailValues()
            {
                yield return new object[]
                {
                    null
                };

                yield return new object[]
                {
                    string.Empty
                };

                yield return new object[]
                {
                    string.Empty.PadLeft(100)
                };
            }

            [Theory]
            [MemberData(nameof(AuthTokenFailValues))]
            public async Task Get_GetCustomerRequest_NullToken_ThrowsOktaTokenNullException(string token)
            {
                _oktaClient.GetAuthTokenAsync()
                    .Returns(token);

                Func<Task> task = async () =>
                {
                    await _creditLockPaasClient.GetPaasCustomerAsync(new GetCustomerRequest{ CustomerRef = "customerId"});
                };

                task.Should()
                    .Throw<OktaTokenNullException>()
                    .WithMessage("oktaToken cannot be null or whitespace");

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.DidNotReceive().GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Get.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Get.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Get.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Get.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task Get_GetCustomerRequest_InitialRequestForbidden_Success()
            {
                var mockResponseContent =
                    "{\"data\":[{\"clientId\":\"ECS\",\"customerId\":\"a69e102d-d776-490a-a0a1-dfe25c791df9\",\"lockStatus\":\"ON\",\"alertsStatus\":\"ON\",\"dob\":\"1990-12-31T00:00:00\",\"name\":{\"title\":\"Lord\",\"firstName\":\"Howard\",\"otherName\":\"Phillips\",\"lastName\":\"Lovecraft\",\"suffix\":\"Jr\"},\"addresses\":[{\"din\":\"202100011234567891\",\"pinStatus\":\"OK\",\"pinErrorCode\":\"\",\"pinErrorMessage\":\"\",\"flat\":null,\"houseName\":null,\"houseNumber\":\"42\",\"street\":\"Green Lane\",\"town\":\"Bigton\",\"county\":\"Homeshire\",\"postcode\":\"AB1 23X\"},{\"din\":\"202100011234567892\",\"pinStatus\":\"PENDING\",\"pinErrorCode\":\"\",\"pinErrorMessage\":\"\",\"flat\":\"4\",\"houseName\":null,\"houseNumber\":\"2\",\"street\":\"Brown Lane\",\"town\":\"Smalltown\",\"county\":\"Topplace On Tees\",\"postcode\":\"AC12 1PX\"},{\"din\":\"202100011234567893\",\"pinStatus\":\"FAIL\",\"pinErrorCode\":\"0xf00f\",\"pinErrorMessage\":\"lp0 on fire\",\"flat\":null,\"houseName\":null,\"houseNumber\":\"42\",\"street\":\"Media Circus\",\"town\":\"Pencastle\",\"county\":\"The North\",\"postcode\":\"this is not a valid postcode\"}]}]}";

                var httpClientFactory = Substitute.For<IHttpClientFactory>();

                var responses = new[]
                {
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.Forbidden,
                        Content = new StringContent("test", Encoding.UTF8, "application/json")
                    },
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.OK,
                        Content = new StringContent(mockResponseContent, Encoding.UTF8, "application/json")
                    }
                };

                var fakeHttpMessageHandler = new FakeHttpMessagesHandler(responses);

                httpClientFactory.CreateClient()
                    .Returns(new HttpClient(fakeHttpMessageHandler));

                _oktaClient.GetAuthTokenAsync()
                    .Returns("abcdef");

                _oktaClient.GetAuthTokenAsync(true)
                    .Returns("xyz");

                var creditLockPaasClient = new CreditLockPaasClient(httpClientFactory.CreateClient(), _logger,
                    _oktaClient, _optionsOktaAuthCredentials);

                await creditLockPaasClient.GetPaasCustomerAsync(new GetCustomerRequest
                {
                    CustomerRef = "customerId"
                });

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.Received(1).GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Get.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Get.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Get.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Get.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task Get_GetCustomerRequest_InitialRequestForbidden_SecondReturnsNullToken_ThrowsOktaTokenNullException()
            {
                var httpClientFactory = Substitute.For<IHttpClientFactory>();

                var responses = new[]
                {
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.Forbidden,
                        Content = new StringContent("test", Encoding.UTF8, "application/json")
                    },
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.OK,
                        Content = new StringContent("{\"clientId\":\"Client IDs are opaque\"}", Encoding.UTF8, "application/json")
                    }
                };

                var fakeHttpMessageHandler = new FakeHttpMessagesHandler(responses);

                httpClientFactory.CreateClient()
                    .Returns(new HttpClient(fakeHttpMessageHandler));

                _oktaClient.GetAuthTokenAsync()
                    .Returns("abcdef");

                _oktaClient.GetAuthTokenAsync(true)
                    .ReturnsNull();

                var creditLockPaasClient = new CreditLockPaasClient(httpClientFactory.CreateClient(), _logger, _oktaClient, _optionsOktaAuthCredentials);

                Func<Task> task = async () =>
                {
                    await creditLockPaasClient.GetPaasCustomerAsync(new GetCustomerRequest
                    {
                        CustomerRef = "customerId"
                    });
                };

                task.Should()
                    .Throw<OktaTokenNullException>()
                    .WithMessage("oktaToken cannot be null or whitespace");

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.Received(1).GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Get.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Get.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Get.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Get.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task Get_GetCustomerRequest_InitialRequestForbidden_SecondReturnsStringEmptyToken_ThrowsOktaTokenNullException()
            {
                var httpClientFactory = Substitute.For<IHttpClientFactory>();

                var responses = new[]
                {
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.Forbidden,
                        Content = new StringContent("test", Encoding.UTF8, "application/json")
                    },
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.OK,
                        Content = new StringContent("test", Encoding.UTF8, "application/json")
                    }
                };

                var fakeHttpMessageHandler = new FakeHttpMessagesHandler(responses);

                httpClientFactory.CreateClient()
                    .Returns(new HttpClient(fakeHttpMessageHandler));

                _oktaClient.GetAuthTokenAsync()
                    .Returns("abcdef");

                _oktaClient.GetAuthTokenAsync(true)
                    .Returns(string.Empty);

                var creditLockPaasClient = new CreditLockPaasClient(httpClientFactory.CreateClient(), _logger,
                    _oktaClient, _optionsOktaAuthCredentials);

                Func<Task> task = async () =>
                {
                    await creditLockPaasClient.GetPaasCustomerAsync(new GetCustomerRequest { CustomerRef = "customerId"});
                };

                task.Should()
                    .Throw<OktaTokenNullException>()
                    .WithMessage("oktaToken cannot be null or whitespace");

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.Received(1).GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Get.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Get.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Get.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Get.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task Get_GetCustomerRequest_InitialRequestForbidden_SecondReturnsWhitespaceToken_ThrowsOktaTokenNullException()
            {
                var httpClientFactory = Substitute.For<IHttpClientFactory>();

                var responses = new[]
                {
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.Forbidden,
                        Content = new StringContent("test", Encoding.UTF8, "application/json")
                    },
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.OK,
                        Content = new StringContent("test", Encoding.UTF8, "application/json")
                    }
                };

                var fakeHttpMessageHandler = new FakeHttpMessagesHandler(responses);

                httpClientFactory.CreateClient()
                    .Returns(new HttpClient(fakeHttpMessageHandler));

                _oktaClient.GetAuthTokenAsync()
                    .Returns("abcdef");

                _oktaClient.GetAuthTokenAsync(true)
                    .Returns(string.Empty.PadLeft(10));

                var creditLockPaasClient = new CreditLockPaasClient(httpClientFactory.CreateClient(), _logger, _oktaClient, _optionsOktaAuthCredentials);

                Func<Task> task = async () =>
                {
                    await creditLockPaasClient.GetPaasCustomerAsync(new GetCustomerRequest { CustomerRef = "customerId" });
                };

                task.Should()
                    .Throw<OktaTokenNullException>()
                    .WithMessage("oktaToken cannot be null or whitespace");

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.Received(1).GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Get.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Get.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Get.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Get.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task Get_GetCustomerRequest_SendRequestReturnNoValidResponse_ThrowsCustomerPostRequestException()
            {
                _oktaClient.GetAuthTokenAsync()
                    .Returns("abc");

                var responses = new[]
                {
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.OK,
                        Content = new StringContent(string.Empty, Encoding.UTF8, "application/json")
                    }
                };

                var fakeHttpMessageHandler = new FakeHttpMessagesHandler(responses);

                var httpClientFactory = Substitute.For<IHttpClientFactory>();

                httpClientFactory.CreateClient()
                    .Returns(new HttpClient(fakeHttpMessageHandler));

                var creditLockPaasClient = new CreditLockPaasClient(httpClientFactory.CreateClient(), _logger, _oktaClient, _optionsOktaAuthCredentials);

                Func<Task> task = async () =>
                {
                    await creditLockPaasClient.GetPaasCustomerAsync(new GetCustomerRequest
                    {
                        CustomerRef = "customerId"
                    });
                };

                task.Should()
                    .Throw<CustomerGetRequestException>();

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.DidNotReceive().GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Get.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Get.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Get.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Get.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Get.InvalidResponse)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task GetCustomerRequest_CustomerNotFound_ThrowsCustomerNotFoundException()
            {
                _oktaClient.GetAuthTokenAsync()
                    .Returns("abc");

                var responses = new[]
                {
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.NotFound,
                        Content = new StringContent("Test", Encoding.UTF8, "application/json")
                    }
                };

                var fakeHttpMessageHandler = new FakeHttpMessagesHandler(responses);

                var httpClientFactory = Substitute.For<IHttpClientFactory>();

                httpClientFactory.CreateClient()
                    .Returns(new HttpClient(fakeHttpMessageHandler));

                var creditLockPaasClient = new CreditLockPaasClient(httpClientFactory.CreateClient(), _logger, _oktaClient, _optionsOktaAuthCredentials);

                Func<Task> task = async () =>
                {
                    await creditLockPaasClient.GetPaasCustomerAsync(new GetCustomerRequest
                    {
                        CustomerRef = "customerId"
                    });
                };

                task.Should()
                    .Throw<CustomerNotFoundException>();

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.DidNotReceive().GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Get.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Get.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Get.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Get.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

        }

        public class Delete : CreditLockPaasClientTests
        {
            [Fact]
            public void DeleteCustomerProfileCustomerIdInvalid_ThrowsArgumentException()
            {
                Func<Task> task = async () => { await _creditLockPaasClient.Delete(null); };

                task.Should()
                    .Throw<ArgumentException>()
                    .WithMessage("Value cannot be null. (Parameter 'deleteCustomerRequest')");
            }

            [Fact]
            public void DeleteCustomerProfileIconRefNull_ThrowsArgumentException()
            {
                Func<Task> task = async () => { await _creditLockPaasClient.Delete(new DeleteCustomerRequest()); };

                task.Should()
                    .Throw<ArgumentException>()
                    .WithMessage("Value cannot be null. (Parameter 'CustomerRef')");
            }

            public static IEnumerable<object[]> LogInformationMessages()
            {
                yield return new object[]
                {
                    LogEventNames.CreditLockPaasClient.Delete.Enter
                };

                yield return new object[]
                {
                    LogEventNames.CreditLockPaasClient.Delete.Exit
                };
            }

            [Theory]
            [MemberData(nameof(LogInformationMessages))]
            public async Task HappyPathInformationLogged(string loggerMessage)
            {
                _oktaClient.GetAuthTokenAsync()
                    .Returns("abcdef");

                var deleteCustomer = new DeleteCustomerRequest
                {
                    CustomerRef = "123466a"
                };

                await _creditLockPaasClient.Delete(deleteCustomer);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(loggerMessage)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task DeleteCustomerRequest_HappyPath_Success()
            {
                _oktaClient.GetAuthTokenAsync()
                    .Returns("abcdef");

                var deleteCustomer = new DeleteCustomerRequest
                {
                    CustomerRef = "123466a"
                };

                await _creditLockPaasClient.Delete(deleteCustomer);

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.DidNotReceive().GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Delete.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Delete.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Delete.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Delete.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task DeleteCustomerRequest_NullToken_ThrowsOktaTokenNullException()
            {
                _oktaClient.GetAuthTokenAsync()
                    .ReturnsNull();

                var deleteCustomer = new DeleteCustomerRequest
                {
                    CustomerRef = "123466a"
                };

                Func<Task> task = async () =>
                {
                    await _creditLockPaasClient.Delete(deleteCustomer);
                };

                task.Should()
                    .Throw<OktaTokenNullException>()
                    .WithMessage("oktaToken cannot be null or whitespace");

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.DidNotReceive().GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Delete.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Delete.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Delete.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Delete.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task DeleteCustomerRequest_StringEmptyToken_ThrowsOktaTokenNullException()
            {
                _oktaClient.GetAuthTokenAsync()
                    .Returns(string.Empty);

                var deleteCustomer = new DeleteCustomerRequest
                {
                    CustomerRef = "123466a"
                };

                Func<Task> task = async () =>
                {
                    await _creditLockPaasClient.Delete(deleteCustomer);
                };


                task.Should()
                    .Throw<OktaTokenNullException>()
                    .WithMessage("oktaToken cannot be null or whitespace");

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.DidNotReceive().GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Delete.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Delete.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Delete.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Delete.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task DeleteCustomerRequest_StringWhitespace_ThrowsOktaTokenNullException()
            {
                _oktaClient.GetAuthTokenAsync()
                    .Returns(string.Empty.PadLeft(10));

                var deleteCustomer = new DeleteCustomerRequest
                {
                    CustomerRef = "123466a"
                };

                Func<Task> task = async () =>
                {
                    await _creditLockPaasClient.Delete(deleteCustomer);
                };


                task.Should()
                    .Throw<OktaTokenNullException>()
                    .WithMessage("oktaToken cannot be null or whitespace");

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.DidNotReceive().GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Delete.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Delete.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Delete.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Delete.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task DeleteCustomerRequest_InitialRequestForbidden_Success()
            {
                var httpClientFactory = Substitute.For<IHttpClientFactory>();

                var responses = new[]
                {
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.Forbidden,
                        Content = new StringContent("test", Encoding.UTF8, "application/json")
                    },
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.NoContent,
                        Content = new StringContent("test", Encoding.UTF8, "application/json")
                    }
                };

                var fakeHttpMessageHandler = new FakeHttpMessagesHandler(responses);

                httpClientFactory.CreateClient()
                    .Returns(new HttpClient(fakeHttpMessageHandler));

                _oktaClient.GetAuthTokenAsync()
                    .Returns("abcdef");

                _oktaClient.GetAuthTokenAsync(true)
                    .Returns("xyz");

                var creditLockPaasClient = new CreditLockPaasClient(httpClientFactory.CreateClient(), _logger,
                    _oktaClient, _optionsOktaAuthCredentials);

                var deleteCustomer = new DeleteCustomerRequest
                {
                    CustomerRef = "123466a"
                };

                await creditLockPaasClient.Delete(deleteCustomer);

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.Received(1).GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Delete.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Delete.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Delete.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Delete.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task DeleteCustomerRequest_InitialRequestForbidden_SecondReturnsNullToken_ThrowsOktaTokenNullException()
            {
                var httpClientFactory = Substitute.For<IHttpClientFactory>();

                var responses = new[]
                {
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.Forbidden,
                        Content = new StringContent("test", Encoding.UTF8, "application/json")
                    },
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.OK,
                        Content = new StringContent("test", Encoding.UTF8, "application/json")
                    }
                };

                var fakeHttpMessageHandler = new FakeHttpMessagesHandler(responses);

                httpClientFactory.CreateClient()
                    .Returns(new HttpClient(fakeHttpMessageHandler));

                _oktaClient.GetAuthTokenAsync()
                    .Returns("abcdef");

                _oktaClient.GetAuthTokenAsync(true)
                    .Returns(string.Empty.PadLeft(10));

                var creditLockPaasClient = new CreditLockPaasClient(httpClientFactory.CreateClient(), _logger, _oktaClient, _optionsOktaAuthCredentials);
                
                var deleteCustomer = new DeleteCustomerRequest
                {
                    CustomerRef = "123466a"
                };

                Func<Task> task = async () =>
                {
                    await creditLockPaasClient.Delete(deleteCustomer);
                };

                task.Should()
                    .Throw<OktaTokenNullException>()
                    .WithMessage("oktaToken cannot be null or whitespace");

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.Received(1).GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Delete.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Delete.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Delete.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Delete.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task DeleteCustomerRequest_InitialRequestForbidden_SecondReturnsStringEmptyToken_ThrowsOktaTokenNullException()
            {
                var httpClientFactory = Substitute.For<IHttpClientFactory>();

                var responses = new[]
                {
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.Forbidden,
                        Content = new StringContent("test", Encoding.UTF8, "application/json")
                    },
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.NoContent,
                        Content = new StringContent("test", Encoding.UTF8, "application/json")
                    }
                };

                var fakeHttpMessageHandler = new FakeHttpMessagesHandler(responses);

                httpClientFactory.CreateClient()
                    .Returns(new HttpClient(fakeHttpMessageHandler));

                _oktaClient.GetAuthTokenAsync()
                    .Returns("abcdef");

                _oktaClient.GetAuthTokenAsync(true)
                    .Returns(string.Empty);

                var creditLockPaasClient = new CreditLockPaasClient(httpClientFactory.CreateClient(), _logger,
                    _oktaClient, _optionsOktaAuthCredentials);

                var deleteCustomer = new DeleteCustomerRequest
                {
                    CustomerRef = "123466a"
                };

                Func<Task> task = async () =>
                {
                    await creditLockPaasClient.Delete(deleteCustomer);
                };


                task.Should()
                    .Throw<OktaTokenNullException>()
                    .WithMessage("oktaToken cannot be null or whitespace");

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.Received(1).GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Delete.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Delete.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Delete.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Delete.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task DeleteCustomerRequest_InitialRequestForbidden_SecondReturnsWhitespaceToken_ThrowsOktaTokenNullException()
            {
                var httpClientFactory = Substitute.For<IHttpClientFactory>();

                var responses = new[]
                {
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.Forbidden,
                        Content = new StringContent("test", Encoding.UTF8, "application/json")
                    },
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.NoContent,
                        Content = new StringContent("test", Encoding.UTF8, "application/json")
                    }
                };

                var fakeHttpMessageHandler = new FakeHttpMessagesHandler(responses);

                httpClientFactory.CreateClient()
                    .Returns(new HttpClient(fakeHttpMessageHandler));

                _oktaClient.GetAuthTokenAsync()
                    .Returns("abcdef");

                _oktaClient.GetAuthTokenAsync(true)
                    .Returns(string.Empty.PadLeft(10));

                var creditLockPaasClient = new CreditLockPaasClient(httpClientFactory.CreateClient(), _logger,
                    _oktaClient, _optionsOktaAuthCredentials);

                var deleteCustomer = new DeleteCustomerRequest
                {
                    CustomerRef = "123466a"
                };

                Func<Task> task = async () =>
                {
                    await creditLockPaasClient.Delete(deleteCustomer);
                };


                task.Should()
                    .Throw<OktaTokenNullException>()
                    .WithMessage("oktaToken cannot be null or whitespace");

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.Received(1).GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Delete.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Delete.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Delete.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Delete.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task DeleteCustomerRequest_SendRequestFailsBadRequest_ThrowsCustomerPutRequestException()
            {
                _oktaClient.GetAuthTokenAsync()
                    .Returns("abc");

                var responses = new[]
                {
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.BadRequest,
                        Content = new StringContent("test", Encoding.UTF8, "application/json")
                    }
                };

                var fakeHttpMessageHandler = new FakeHttpMessagesHandler(responses);

                var httpClientFactory = Substitute.For<IHttpClientFactory>();

                httpClientFactory.CreateClient()
                    .Returns(new HttpClient(fakeHttpMessageHandler));

                var creditLockPaasClient = new CreditLockPaasClient(httpClientFactory.CreateClient(), _logger,
                    _oktaClient, _optionsOktaAuthCredentials);

                var deleteCustomer = new DeleteCustomerRequest
                {
                    CustomerRef = "123466a"
                };

                Func<Task> task = async () =>
                {
                    await creditLockPaasClient.Delete(deleteCustomer);
                };


                task.Should()
                    .Throw<RequestBodyNullException>();

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.DidNotReceive().GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Delete.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Delete.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Delete.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Delete.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Delete.ResponseInvalidStatusCode)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }
        }

        public class Put : CreditLockPaasClientTests
        {
            [Fact]
            public void PutCustomerProfileCustomerIdInvalid_ThrowsArgumentException()
            {
                Func<Task> task = async () => { await _creditLockPaasClient.Put(null); };

                task.Should()
                    .Throw<ArgumentException>()
                    .Where(x => x.Message == "Value cannot be null. (Parameter 'putCustomerRequest')");
            }

            public static IEnumerable<object[]> LogInformationMessages()
            {
                yield return new object[]
                {
                    LogEventNames.CreditLockPaasClient.Put.Enter
                };

                yield return new object[]
                {
                    LogEventNames.CreditLockPaasClient.Put.Exit
                };
            }

            [Theory]
            [MemberData(nameof(LogInformationMessages))]
            public async Task HappyPathInformationLogged(string loggerMessage)
            {
                _oktaClient.GetAuthTokenAsync()
                    .Returns("abcdef");

                await _creditLockPaasClient.Put(new PutCustomerRequest());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(loggerMessage)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PutCustomerRequest_HappyPath_Success()
            {
                _oktaClient.GetAuthTokenAsync()
                    .Returns("abcdef");

                await _creditLockPaasClient.Put(new PutCustomerRequest());

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.DidNotReceive().GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Put.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Put.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Put.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Put.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PutCustomerRequest_NullToken_ThrowsOktaTokenNullException()
            {
                _oktaClient.GetAuthTokenAsync()
                    .ReturnsNull();

                Func<Task> task = async () =>
                {
                    await _creditLockPaasClient.Put(new PutCustomerRequest());
                };

                task.Should()
                    .Throw<OktaTokenNullException>()
                    .WithMessage("oktaToken cannot be null or whitespace");

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.DidNotReceive().GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Put.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Put.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Put.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Put.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PutCustomerRequest_StringEmptyToken_ThrowsOktaTokenNullException()
            {
                _oktaClient.GetAuthTokenAsync()
                    .Returns(string.Empty);

                Func<Task> task = async () =>
                {
                    await _creditLockPaasClient.Put(new PutCustomerRequest());
                };

                task.Should()
                    .Throw<OktaTokenNullException>()
                    .WithMessage("oktaToken cannot be null or whitespace");

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.DidNotReceive().GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Put.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Put.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Put.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Put.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PutCustomerRequest_StringWhitespace_ThrowsOktaTokenNullException()
            {
                _oktaClient.GetAuthTokenAsync()
                    .Returns(string.Empty.PadLeft(10));

                Func<Task> task = async () =>
                {
                    await _creditLockPaasClient.Put(new PutCustomerRequest());
                };

                task.Should()
                    .Throw<OktaTokenNullException>()
                    .WithMessage("oktaToken cannot be null or whitespace");

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.DidNotReceive().GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Put.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Put.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Put.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Put.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PutCustomerRequest_InitialRequestForbidden_Success()
            {
                var httpClientFactory = Substitute.For<IHttpClientFactory>();

                var responses = new[]
                {
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.Forbidden,
                        Content = new StringContent("test", Encoding.UTF8, "application/json")
                    },
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.NoContent,
                        Content = new StringContent("test", Encoding.UTF8, "application/json")
                    }
                };

                var fakeHttpMessageHandler = new FakeHttpMessagesHandler(responses);

                httpClientFactory.CreateClient()
                    .Returns(new HttpClient(fakeHttpMessageHandler));

                _oktaClient.GetAuthTokenAsync()
                    .Returns("abcdef");

                _oktaClient.GetAuthTokenAsync(true)
                    .Returns("xyz");

                var creditLockPaasClient = new CreditLockPaasClient(httpClientFactory.CreateClient(), _logger,
                    _oktaClient, _optionsOktaAuthCredentials);

                await creditLockPaasClient.Put(new PutCustomerRequest());

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.Received(1).GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Put.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Put.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Put.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Put.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PutCustomerRequest_InitialRequestForbidden_SecondReturnsNullToken_ThrowsOktaTokenNullException()
            {
                var httpClientFactory = Substitute.For<IHttpClientFactory>();

                var responses = new[]
                {
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.Forbidden,
                        Content = new StringContent("test", Encoding.UTF8, "application/json")
                    },
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.NoContent,
                        Content = new StringContent("test", Encoding.UTF8, "application/json")
                    }
                };

                var fakeHttpMessageHandler = new FakeHttpMessagesHandler(responses);

                httpClientFactory.CreateClient()
                    .Returns(new HttpClient(fakeHttpMessageHandler));

                _oktaClient.GetAuthTokenAsync()
                    .Returns("abcdef");

                _oktaClient.GetAuthTokenAsync(true)
                    .ReturnsNull();

                var creditLockPaasClient = new CreditLockPaasClient(httpClientFactory.CreateClient(), _logger,
                    _oktaClient, _optionsOktaAuthCredentials);

                Func<Task> task = async () =>
                {
                    await creditLockPaasClient.Put(new PutCustomerRequest());
                };

                task.Should()
                    .Throw<OktaTokenNullException>()
                    .WithMessage("oktaToken cannot be null or whitespace");

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.Received(1).GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Put.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Put.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Put.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Put.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PutCustomerRequest_InitialRequestForbidden_SecondReturnsStringEmptyToken_ThrowsOktaTokenNullException()
            {
                var httpClientFactory = Substitute.For<IHttpClientFactory>();

                var responses = new[]
                {
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.Forbidden,
                        Content = new StringContent("test", Encoding.UTF8, "application/json")
                    },
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.NoContent,
                        Content = new StringContent("test", Encoding.UTF8, "application/json")
                    }
                };

                var fakeHttpMessageHandler = new FakeHttpMessagesHandler(responses);

                httpClientFactory.CreateClient()
                    .Returns(new HttpClient(fakeHttpMessageHandler));

                _oktaClient.GetAuthTokenAsync()
                    .Returns("abcdef");

                _oktaClient.GetAuthTokenAsync(true)
                    .Returns(string.Empty);

                var creditLockPaasClient = new CreditLockPaasClient(httpClientFactory.CreateClient(), _logger,
                    _oktaClient, _optionsOktaAuthCredentials);

                Func<Task> task = async () => { await creditLockPaasClient.Put(new PutCustomerRequest()); };

                task.Should()
                    .Throw<OktaTokenNullException>()
                    .WithMessage("oktaToken cannot be null or whitespace");

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.Received(1).GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Put.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Put.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Put.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Put.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PutCustomerRequest_InitialRequestForbidden_SecondReturnsWhitespaceToken_ThrowsOktaTokenNullException()
            {
                var httpClientFactory = Substitute.For<IHttpClientFactory>();

                var responses = new[]
                {
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.Forbidden,
                        Content = new StringContent("test", Encoding.UTF8, "application/json")
                    },
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.NoContent,
                        Content = new StringContent("test", Encoding.UTF8, "application/json")
                    }
                };

                var fakeHttpMessageHandler = new FakeHttpMessagesHandler(responses);

                httpClientFactory.CreateClient()
                    .Returns(new HttpClient(fakeHttpMessageHandler));

                _oktaClient.GetAuthTokenAsync()
                    .Returns("abcdef");

                _oktaClient.GetAuthTokenAsync(true)
                    .Returns(string.Empty.PadLeft(10));

                var creditLockPaasClient = new CreditLockPaasClient(httpClientFactory.CreateClient(), _logger,
                    _oktaClient, _optionsOktaAuthCredentials);

                Func<Task> task = async () => { await creditLockPaasClient.Put(new PutCustomerRequest()); };

                task.Should()
                    .Throw<OktaTokenNullException>()
                    .WithMessage("oktaToken cannot be null or whitespace");

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.Received(1).GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Put.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Put.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Put.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Put.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PutCustomerRequest_SendRequestFailsBadRequest_ThrowsCustomerPutRequestException()
            {
                _oktaClient.GetAuthTokenAsync()
                    .Returns("abc");

                var responses = new[]
                {
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.BadRequest,
                        Content = new StringContent("test", Encoding.UTF8, "application/json")
                    }
                };

                var fakeHttpMessageHandler = new FakeHttpMessagesHandler(responses);

                var httpClientFactory = Substitute.For<IHttpClientFactory>();

                httpClientFactory.CreateClient()
                    .Returns(new HttpClient(fakeHttpMessageHandler));

                var creditLockPaasClient = new CreditLockPaasClient(httpClientFactory.CreateClient(), _logger,
                    _oktaClient, _optionsOktaAuthCredentials);

                Func<Task> task = async () => { await creditLockPaasClient.Put(new PutCustomerRequest()); };

                task.Should()
                    .Throw<RequestBodyNullException>();

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.DidNotReceive().GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Put.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Put.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Put.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Put.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Put.ResponseInvalidStatusCode)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }
        }
        
        public class PutLockStatus : CreditLockPaasClientTests
        {
            [Fact]
            public void PutLockStatusRequestInvalid_ThrowsArgumentException()
            {
                Func<Task> task = async () => { await _creditLockPaasClient.PutLockStatus(null); };

                task.Should()
                    .Throw<ArgumentException>()
                    .Where(x => x.Message == "Value cannot be null. (Parameter 'putLockStatusRequest')");
            }

            public static IEnumerable<object[]> LogInformationMessages()
            {
                yield return new object[]
                {
                    LogEventNames.CreditLockPaasClient.PutLockStatus.Enter
                };

                yield return new object[]
                {
                    LogEventNames.CreditLockPaasClient.PutLockStatus.Exit
                };
            }

            [Theory]
            [MemberData(nameof(LogInformationMessages))]
            public async Task HappyPathInformationLogged(string loggerMessage)
            {
                _oktaClient.GetAuthTokenAsync()
                    .Returns("abcdef");

                var request = new PutLockStatusRequest
                {
                    CustomerRef = "ABC12345",
                    Status = "Y"
                };

                await _creditLockPaasClient.PutLockStatus(request);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(loggerMessage)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PutLockStatusRequest_HappyPath_Success()
            {
                _oktaClient.GetAuthTokenAsync()
                    .Returns("abcdef");

                var request = new PutLockStatusRequest
                {
                    CustomerRef = "ABC12345",
                    Status = "Y"
                };

                await _creditLockPaasClient.PutLockStatus(request);

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.DidNotReceive().GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PutLockStatus.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PutLockStatus.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PutLockStatus.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PutLockStatus.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PutLockStatusRequest_NullToken_ThrowsOktaTokenNullException()
            {
                _oktaClient.GetAuthTokenAsync()
                    .ReturnsNull();

                var request = new PutLockStatusRequest
                {
                    CustomerRef = "ABC12345",
                    Status = "Y"
                };

                Func<Task> task = async () =>
                {
                    await _creditLockPaasClient.PutLockStatus(request);
                };

                task.Should()
                    .Throw<OktaTokenNullException>()
                    .WithMessage("oktaToken cannot be null or whitespace");

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.DidNotReceive().GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PutLockStatus.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PutLockStatus.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PutLockStatus.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PutLockStatus.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PutLockStatusRequest_StringEmptyToken_ThrowsOktaTokenNullException()
            {
                _oktaClient.GetAuthTokenAsync()
                    .Returns(string.Empty);

                var request = new PutLockStatusRequest
                {
                    CustomerRef = "ABC12345",
                    Status = "Y"
                };

                Func<Task> task = async () =>
                {
                    await _creditLockPaasClient.PutLockStatus(request);
                };

                task.Should()
                    .Throw<OktaTokenNullException>()
                    .WithMessage("oktaToken cannot be null or whitespace");

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.DidNotReceive().GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PutLockStatus.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PutLockStatus.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PutLockStatus.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PutLockStatus.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PutLockStatusRequest_StringWhitespaceToken_ThrowsOktaTokenNullException()
            {
                _oktaClient.GetAuthTokenAsync()
                    .Returns(string.Empty.PadLeft(10));

                var request = new PutLockStatusRequest
                {
                    CustomerRef = "ABC12345",
                    Status = "Y"
                };

                Func<Task> task = async () =>
                {
                    await _creditLockPaasClient.PutLockStatus(request);
                };

                task.Should()
                    .Throw<OktaTokenNullException>()
                    .WithMessage("oktaToken cannot be null or whitespace");

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.DidNotReceive().GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PutLockStatus.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PutLockStatus.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PutLockStatus.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PutLockStatus.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PutLockStatusRequest_InitialRequestForbidden_Success()
            {
                var httpClientFactory = Substitute.For<IHttpClientFactory>();

                var responses = new[]
                {
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.Forbidden,
                        Content = new StringContent("test", Encoding.UTF8, "application/json")
                    },
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.NoContent,
                        Content = new StringContent("test", Encoding.UTF8, "application/json")
                    }
                };

                var fakeHttpMessageHandler = new FakeHttpMessagesHandler(responses);

                httpClientFactory.CreateClient()
                    .Returns(new HttpClient(fakeHttpMessageHandler));

                _oktaClient.GetAuthTokenAsync()
                    .Returns("abcdef");

                _oktaClient.GetAuthTokenAsync(true)
                    .Returns("xyz");

                var creditLockPaasClient = new CreditLockPaasClient(httpClientFactory.CreateClient(), _logger,
                    _oktaClient, _optionsOktaAuthCredentials);

                var request = new PutLockStatusRequest
                {
                    CustomerRef = "ABC12345",
                    Status = "Y"
                };
                
                await creditLockPaasClient.PutLockStatus(request);

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.Received(1).GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PutLockStatus.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PutLockStatus.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PutLockStatus.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PutLockStatus.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PutLockStatusRequest_InitialRequestForbidden_SecondReturnsNullToken_ThrowsOktaTokenNullException()
            {
                var httpClientFactory = Substitute.For<IHttpClientFactory>();

                var responses = new[]
                {
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.Forbidden,
                        Content = new StringContent("test", Encoding.UTF8, "application/json")
                    },
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.NoContent,
                        Content = new StringContent("test", Encoding.UTF8, "application/json")
                    }
                };

                var fakeHttpMessageHandler = new FakeHttpMessagesHandler(responses);

                httpClientFactory.CreateClient()
                    .Returns(new HttpClient(fakeHttpMessageHandler));

                _oktaClient.GetAuthTokenAsync()
                    .Returns("abcdef");

                _oktaClient.GetAuthTokenAsync(true)
                    .ReturnsNull();

                var creditLockPaasClient = new CreditLockPaasClient(httpClientFactory.CreateClient(), _logger,
                    _oktaClient, _optionsOktaAuthCredentials);

                var request = new PutLockStatusRequest
                {
                    CustomerRef = "ABC12345",
                    Status = "Y"
                };

                Func<Task> task = async () =>
                {
                    await creditLockPaasClient.PutLockStatus(request);
                };

                task.Should()
                    .Throw<OktaTokenNullException>()
                    .WithMessage("oktaToken cannot be null or whitespace");

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.Received(1).GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PutLockStatus.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PutLockStatus.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PutLockStatus.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PutLockStatus.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PutLockStatusRequest_InitialRequestForbidden_SecondReturnsStringEmptyToken_ThrowsOktaTokenNullException()
            {
                var httpClientFactory = Substitute.For<IHttpClientFactory>();

                var responses = new[]
                {
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.Forbidden,
                        Content = new StringContent("test", Encoding.UTF8, "application/json")
                    },
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.NoContent,
                        Content = new StringContent("test", Encoding.UTF8, "application/json")
                    }
                };

                var fakeHttpMessageHandler = new FakeHttpMessagesHandler(responses);

                httpClientFactory.CreateClient()
                    .Returns(new HttpClient(fakeHttpMessageHandler));

                _oktaClient.GetAuthTokenAsync()
                    .Returns("abcdef");

                _oktaClient.GetAuthTokenAsync(true)
                    .Returns(string.Empty);

                var creditLockPaasClient = new CreditLockPaasClient(httpClientFactory.CreateClient(), _logger,
                    _oktaClient, _optionsOktaAuthCredentials);

                var request = new PutLockStatusRequest
                {
                    CustomerRef = "ABC12345",
                    Status = "Y"
                };

                Func<Task> task = async () =>
                {
                    await creditLockPaasClient.PutLockStatus(request);
                };

                task.Should()
                    .Throw<OktaTokenNullException>()
                    .WithMessage("oktaToken cannot be null or whitespace");

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.Received(1).GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PutLockStatus.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PutLockStatus.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PutLockStatus.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.Delete.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PutLockStatusRequest_InitialRequestForbidden_SecondReturnsWhitespaceToken_ThrowsOktaTokenNullException()
            {
                var httpClientFactory = Substitute.For<IHttpClientFactory>();

                var responses = new[]
                {
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.Forbidden,
                        Content = new StringContent("test", Encoding.UTF8, "application/json")
                    },
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.NoContent,
                        Content = new StringContent("test", Encoding.UTF8, "application/json")
                    }
                };

                var fakeHttpMessageHandler = new FakeHttpMessagesHandler(responses);

                httpClientFactory.CreateClient()
                    .Returns(new HttpClient(fakeHttpMessageHandler));

                _oktaClient.GetAuthTokenAsync()
                    .Returns("abcdef");

                _oktaClient.GetAuthTokenAsync(true)
                    .Returns(string.Empty.PadLeft(10));

                var creditLockPaasClient = new CreditLockPaasClient(httpClientFactory.CreateClient(), _logger,
                    _oktaClient, _optionsOktaAuthCredentials);

                var request = new PutLockStatusRequest
                {
                    CustomerRef = "ABC12345",
                    Status = "Y"
                };

                Func<Task> task = async () =>
                {
                    await creditLockPaasClient.PutLockStatus(request);
                };

                task.Should()
                    .Throw<OktaTokenNullException>()
                    .WithMessage("oktaToken cannot be null or whitespace");

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.Received(1).GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PutLockStatus.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PutLockStatus.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PutLockStatus.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PutLockStatus.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PutLockStatusrRequest_SendRequestFailsBadRequest_ThrowsLockStatusPutRequestException()
            {
                _oktaClient.GetAuthTokenAsync()
                    .Returns("abc");

                var responses = new[]
                {
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.BadRequest,
                        Content = new StringContent("test", Encoding.UTF8, "application/json")
                    }
                };

                var fakeHttpMessageHandler = new FakeHttpMessagesHandler(responses);

                var httpClientFactory = Substitute.For<IHttpClientFactory>();

                httpClientFactory.CreateClient()
                    .Returns(new HttpClient(fakeHttpMessageHandler));

                var creditLockPaasClient = new CreditLockPaasClient(httpClientFactory.CreateClient(), _logger,
                    _oktaClient, _optionsOktaAuthCredentials);

                var request = new PutLockStatusRequest
                {
                    CustomerRef = "ABC12345",
                    Status = "Y"
                };

                Func<Task> task = async () =>
                {
                    await creditLockPaasClient.PutLockStatus(request);
                };

                task.Should()
                    .Throw<RequestBodyNullException>();

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.DidNotReceive().GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PutLockStatus.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PutLockStatus.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PutLockStatus.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PutLockStatus.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PutLockStatus.ResponseInvalidStatusCode)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }
        }

        public class PutAlertStatus : CreditLockPaasClientTests
        {
            [Fact]
            public void PostDeactivateInstantAlertRequestInvalid_ThrowsArgumentException()
            {
                Func<Task> task = async () => { await _creditLockPaasClient.PutAlertStatus(null); };

                task.Should()
                    .Throw<ArgumentException>()
                    .Where(x => x.Message == "Value cannot be null. (Parameter 'putAlertStatusRequest')");
            }

            public static IEnumerable<object[]> LogInformationMessages()
            {
                yield return new object[]
                {
                    LogEventNames.CreditLockPaasClient.PostAlertStatus.Enter
                };

                yield return new object[]
                {
                    LogEventNames.CreditLockPaasClient.PostAlertStatus.Exit
                };
            }

            [Theory]
            [MemberData(nameof(LogInformationMessages))]
            public async Task HappyPathInformationLogged(string loggerMessage)
            {
                _oktaClient.GetAuthTokenAsync()
                    .Returns("abcdef");

                var request = new PutAlertStatusRequest
                {
                    CustomerRef = "ABC12345",
                    Status = "N"
                };

                await _creditLockPaasClient.PutAlertStatus(request);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(loggerMessage)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PutAlertStatusRequest_HappyPath_Success()
            {
                _oktaClient.GetAuthTokenAsync()
                    .Returns("abcdef");

                var request = new PutAlertStatusRequest
                {
                    CustomerRef = "ABC12345",
                    Status = "Y"
                };

                await _creditLockPaasClient.PutAlertStatus(request);

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.DidNotReceive().GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PostAlertStatus.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PostAlertStatus.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PostAlertStatus.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PostAlertStatus.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PutAlertStatusRequest_NullToken_ThrowsOktaTokenNullException()
            {
                _oktaClient.GetAuthTokenAsync()
                    .ReturnsNull();

                var request = new PutAlertStatusRequest
                {
                    CustomerRef = "ABC12345",
                    Status = "Y"
                };

                Func<Task> task = async () =>
                {
                    await _creditLockPaasClient.PutAlertStatus(request);
                };

                task.Should()
                    .Throw<OktaTokenNullException>()
                    .WithMessage("oktaToken cannot be null or whitespace");

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.DidNotReceive().GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PostAlertStatus.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PostAlertStatus.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PostAlertStatus.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PostAlertStatus.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PutAlertStatusRequest_StringEmptyToken_ThrowsOktaTokenNullException()
            {
                _oktaClient.GetAuthTokenAsync()
                    .Returns(string.Empty);

                var request = new PutAlertStatusRequest
                {
                    CustomerRef = "ABC12345",
                    Status = "Y"
                };

                Func<Task> task = async () =>
                {
                    await _creditLockPaasClient.PutAlertStatus(request);
                };

                task.Should()
                    .Throw<OktaTokenNullException>()
                    .WithMessage("oktaToken cannot be null or whitespace");

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.DidNotReceive().GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PostAlertStatus.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PostAlertStatus.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PostAlertStatus.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PostAlertStatus.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PutAlertStatusRequest_StringWhitespaceToken_ThrowsOktaTokenNullException()
            {
                _oktaClient.GetAuthTokenAsync()
                    .Returns(string.Empty.PadLeft(10));

                var request = new PutAlertStatusRequest
                {
                    CustomerRef = "ABC12345",
                    Status = "Y"
                };

                Func<Task> task = async () =>
                {
                    await _creditLockPaasClient.PutAlertStatus(request);
                };

                task.Should()
                    .Throw<OktaTokenNullException>()
                    .WithMessage("oktaToken cannot be null or whitespace");

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.DidNotReceive().GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PostAlertStatus.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PostAlertStatus.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PostAlertStatus.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PostAlertStatus.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PutAlertStatusRequest_InitialRequestForbidden_Success()
            {
                var httpClientFactory = Substitute.For<IHttpClientFactory>();

                var responses = new[]
                {
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.Forbidden,
                        Content = new StringContent("test", Encoding.UTF8, "application/json")
                    },
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.NoContent,
                        Content = new StringContent("test", Encoding.UTF8, "application/json")
                    }
                };

                var fakeHttpMessageHandler = new FakeHttpMessagesHandler(responses);

                httpClientFactory.CreateClient()
                    .Returns(new HttpClient(fakeHttpMessageHandler));

                _oktaClient.GetAuthTokenAsync()
                    .Returns("abcdef");

                _oktaClient.GetAuthTokenAsync(true)
                    .Returns("xyz");

                var creditLockPaasClient = new CreditLockPaasClient(httpClientFactory.CreateClient(), _logger,
                    _oktaClient, _optionsOktaAuthCredentials);

                var request = new PutAlertStatusRequest
                {
                    CustomerRef = "ABC12345",
                    Status = "Y"
                };

                await creditLockPaasClient.PutAlertStatus(request);

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.Received(1).GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PostAlertStatus.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PostAlertStatus.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PostAlertStatus.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PostAlertStatus.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PutAlertStatusRequest_InitialRequestForbidden_SecondReturnsNullToken_ThrowsOktaTokenNullException()
            {
                var httpClientFactory = Substitute.For<IHttpClientFactory>();

                var responses = new[]
                {
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.Forbidden,
                        Content = new StringContent("test", Encoding.UTF8, "application/json")
                    },
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.NoContent,
                        Content = new StringContent("test", Encoding.UTF8, "application/json")
                    }
                };

                var fakeHttpMessageHandler = new FakeHttpMessagesHandler(responses);

                httpClientFactory.CreateClient()
                    .Returns(new HttpClient(fakeHttpMessageHandler));

                _oktaClient.GetAuthTokenAsync()
                    .Returns("abcdef");

                _oktaClient.GetAuthTokenAsync(true)
                    .ReturnsNull();

                var creditLockPaasClient = new CreditLockPaasClient(httpClientFactory.CreateClient(), _logger,
                    _oktaClient, _optionsOktaAuthCredentials);

                var request = new PutAlertStatusRequest
                {
                    CustomerRef = "ABC12345",
                    Status = "Y"
                };

                Func<Task> task = async () =>
                {
                    await creditLockPaasClient.PutAlertStatus(request);
                };

                task.Should()
                    .Throw<OktaTokenNullException>()
                    .WithMessage("oktaToken cannot be null or whitespace");

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.Received(1).GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PostAlertStatus.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PostAlertStatus.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PostAlertStatus.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PostAlertStatus.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PutAlertStatusRequest_InitialRequestForbidden_SecondReturnsStringEmptyToken_ThrowsOktaTokenNullException()
            {
                var httpClientFactory = Substitute.For<IHttpClientFactory>();

                var responses = new[]
                {
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.Forbidden,
                        Content = new StringContent("test", Encoding.UTF8, "application/json")
                    },
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.NoContent,
                        Content = new StringContent("test", Encoding.UTF8, "application/json")
                    }
                };

                var fakeHttpMessageHandler = new FakeHttpMessagesHandler(responses);

                httpClientFactory.CreateClient()
                    .Returns(new HttpClient(fakeHttpMessageHandler));

                _oktaClient.GetAuthTokenAsync()
                    .Returns("abcdef");

                _oktaClient.GetAuthTokenAsync(true)
                    .Returns(string.Empty);

                var creditLockPaasClient = new CreditLockPaasClient(httpClientFactory.CreateClient(), _logger,
                    _oktaClient, _optionsOktaAuthCredentials);

                var request = new PutAlertStatusRequest
                {
                    CustomerRef = "ABC12345",
                    Status = "Y"
                };

                Func<Task> task = async () =>
                {
                    await creditLockPaasClient.PutAlertStatus(request);
                };

                task.Should()
                    .Throw<OktaTokenNullException>()
                    .WithMessage("oktaToken cannot be null or whitespace");

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.Received(1).GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PostAlertStatus.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PostAlertStatus.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PostAlertStatus.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PostAlertStatus.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PutAlertStatusRequest_InitialRequestForbidden_SecondReturnsWhitespaceToken_ThrowsOktaTokenNullException()
            {
                var httpClientFactory = Substitute.For<IHttpClientFactory>();

                var responses = new[]
                {
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.Forbidden,
                        Content = new StringContent("test", Encoding.UTF8, "application/json")
                    },
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.NoContent,
                        Content = new StringContent("test", Encoding.UTF8, "application/json")
                    }
                };

                var fakeHttpMessageHandler = new FakeHttpMessagesHandler(responses);

                httpClientFactory.CreateClient()
                    .Returns(new HttpClient(fakeHttpMessageHandler));

                _oktaClient.GetAuthTokenAsync()
                    .Returns("abcdef");

                _oktaClient.GetAuthTokenAsync(true)
                    .Returns(string.Empty.PadLeft(10));

                var creditLockPaasClient = new CreditLockPaasClient(httpClientFactory.CreateClient(), _logger,
                    _oktaClient, _optionsOktaAuthCredentials);

                var request = new PutAlertStatusRequest
                {
                    CustomerRef = "ABC12345",
                    Status = "Y"
                };

                Func<Task> task = async () =>
                {
                    await creditLockPaasClient.PutAlertStatus(request);
                };

                task.Should()
                    .Throw<OktaTokenNullException>()
                    .WithMessage("oktaToken cannot be null or whitespace");

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.Received(1).GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PostAlertStatus.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PostAlertStatus.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PostAlertStatus.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PostAlertStatus.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public async Task PutAlertStatusrRequest_SendRequestFailsBadRequest_ThrowsLockStatusPutRequestException()
            {
                _oktaClient.GetAuthTokenAsync()
                    .Returns("abc");

                var responses = new[]
                {
                    new HttpResponseMessage
                    {
                        StatusCode = HttpStatusCode.BadRequest,
                        Content = new StringContent("test", Encoding.UTF8, "application/json")
                    }
                };

                var fakeHttpMessageHandler = new FakeHttpMessagesHandler(responses);

                var httpClientFactory = Substitute.For<IHttpClientFactory>();

                httpClientFactory.CreateClient()
                    .Returns(new HttpClient(fakeHttpMessageHandler));

                var creditLockPaasClient = new CreditLockPaasClient(httpClientFactory.CreateClient(), _logger,
                    _oktaClient, _optionsOktaAuthCredentials);

                var request = new PutAlertStatusRequest
                {
                    CustomerRef = "ABC12345",
                    Status = "Y"
                };

                Func<Task> task = async () =>
                {
                    await creditLockPaasClient.PutAlertStatus(request);
                };

                task.Should()
                    .Throw<RequestBodyNullException>();

                await _oktaClient.Received(1).GetAuthTokenAsync();

                await _oktaClient.DidNotReceive().GetAuthTokenAsync(true);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PostAlertStatus.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PostAlertStatus.SendRequest)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PostAlertStatus.SendRequestRegenToken)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PostAlertStatus.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.PostAlertStatus.ResponseInvalidStatusCode)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                    Arg.Any<Dictionary<string, object>>(), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.CheckRetry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.HttpRequestException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.Retry)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Warning, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockPaasClient.SendRequestToPaaS.TaskCanceledException)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

        }
    }
}