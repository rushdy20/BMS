﻿using System;
using System.Collections.Generic;
using AutoMapper;
using Experian.AWS.HostInformation;
using EXPN.DataLayer.CreditLockService.Paas;
using EXPN.Mappers.CreditLockService.Paas;
using EXPN.Models.CreditLockService.Internal;
using EXPN.Models.CreditLockService.Paas;
using FluentAssertions;
using NSubstitute;
using Xunit;

namespace EXPN.UnitTest.CreditLockService.DataLayer.Paas
{
    public class CredentialsConfigurationTests
    {
        private readonly ISecretsManager _secretsManager;
        private readonly IHostInformation _hostInformation;
        private readonly IMapper _mapper;

        public CredentialsConfigurationTests()
        {
            _secretsManager = Substitute.For<ISecretsManager>();
            _hostInformation = Substitute.For<IHostInformation>();
            _mapper = new MapperConfiguration(cfg => { cfg.AddProfile<SecretsManagerDataToOktaAuthCredentialProfile>(); }).CreateMapper();
        }

        public class Constructor
        {
            public static IEnumerable<object[]> NullParameters()
            {
                yield return new object[]
                {
                    null,
                    Substitute.For<IMapper>(),
                    "secretsManager"
                };

                yield return new object[]
                {
                    Substitute.For<ISecretsManager>(),
                    null,
                    "mapper"
                };
            }

            [Theory]
            [MemberData(nameof(NullParameters))]
            public void NullRequiredConstructorParameter_ThrowsArgumentNullException(ISecretsManager secretsManager,
                IMapper mapper,
                string expectedErrorParameter)
            {
                Action action = () => { new CredentialsConfiguration(secretsManager, mapper); };

                action.Should().Throw<ArgumentNullException>()
                    .Where(x => x.ParamName == expectedErrorParameter);
            }
        }

        [Fact]
        public void ValidCredential_MapsCorrectly()
        {
            _secretsManager.GetSecretAsync<SecretsManagerData>(Arg.Any<string>())
                .Returns(new SecretsManagerData
                            {
                                ClientId = "clientId",
                                Endpoint = "endpoint",
                                GrantType = "grantType",
                                KeyName = "keyName",
                                Password = "password",
                                Scope = "scope",
                                ServiceEndpoint = "serviceEndpoint",
                                SharedSecret = "secrets",
                                Username = "username"
                            });

            _hostInformation.GetHostTags().Returns(new Dictionary<string, string>
            {
                {"Environment", "test"}
            });

            var expectedValue = new OktaAuthCredentials
            {
                ClientId = "clientId",
                Endpoint = "endpoint",
                GrantType = "grantType",
                KeyName = "keyName",
                Password = "password",
                Scope = "scope",
                ServiceEndpoint = "serviceEndpoint",
                SharedSecret = "secrets",
                Username = "username"
            };

            var credentialsConfiguration = new CredentialsConfiguration(_secretsManager, _mapper);

            var oktaAuthCredentials = new OktaAuthCredentials();

            credentialsConfiguration.Configure(oktaAuthCredentials);

            oktaAuthCredentials.Should().BeEquivalentTo(expectedValue);
        }
    }
}