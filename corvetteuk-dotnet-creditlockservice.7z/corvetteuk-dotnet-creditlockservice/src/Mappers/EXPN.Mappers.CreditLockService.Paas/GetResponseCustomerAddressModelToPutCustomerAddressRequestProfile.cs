﻿using System;
using AutoMapper;
using EXPN.Models.CreditLockService.Internal.Get.Response;
using EXPN.Models.CreditLockService.Paas.Put.Request;

namespace EXPN.Mappers.CreditLockService.Paas
{
    public class GetResponseCustomerAddressModelToPutCustomerAddressRequestProfile : Profile
    {
        private const string CurrentAddressIndicator = "C";
        public GetResponseCustomerAddressModelToPutCustomerAddressRequestProfile()
        {
            AllowNullDestinationValues = true;

            CreateMap<GetResponseCustomerAddressModel, PutCustomerAddressRequest>(MemberList.Destination)
                .ForMember(d => d.County, m => m.MapFrom(s => s.County))
                .ForMember(d => d.District, m => m.MapFrom(s => s.District))
                .ForMember(d => d.Flat, m => m.MapFrom(s => s.Flat))
                .ForMember(d => d.HouseName, m => m.MapFrom(s => s.HouseName))
                .ForMember(d => d.HouseNumber, m => m.MapFrom(s => s.HouseNumber))
                .ForMember(d => d.IsCurrent, m => m.MapFrom(s => s.AddressType.Equals(CurrentAddressIndicator, StringComparison.OrdinalIgnoreCase)))
                .ForMember(d => d.Postcode, m => m.MapFrom(s => s.PostCode))
                .ForMember(d => d.Street, m => m.MapFrom(s => s.Street))
                .ForMember(d => d.Town, m => m.MapFrom(s => s.City));
        }
    }
}