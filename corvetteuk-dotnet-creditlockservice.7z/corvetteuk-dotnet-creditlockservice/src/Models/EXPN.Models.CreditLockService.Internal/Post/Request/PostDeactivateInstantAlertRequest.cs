﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EXPN.Models.CreditLockService.Internal.Post.Request
{
  public  class PostDeactivateInstantAlertRequest
    {
        public string CustomerId { get; set; }
    }
}
