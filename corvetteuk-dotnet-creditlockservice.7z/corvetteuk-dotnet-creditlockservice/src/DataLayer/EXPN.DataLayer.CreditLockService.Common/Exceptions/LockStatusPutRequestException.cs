﻿using System;
using System.Runtime.Serialization;

namespace EXPN.DataLayer.CreditLockService.Common.Exceptions
{
    [Serializable]
    public class LockStatusPutRequestException : Exception
    {
        protected LockStatusPutRequestException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }

        public LockStatusPutRequestException()
        {
        }

        public LockStatusPutRequestException(string message)
            : base(message)
        {
        }

        public LockStatusPutRequestException(string message, Exception innerException)
            : base(message, innerException)
        {
        }
    }
}