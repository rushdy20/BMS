﻿using System;
using System.Runtime.Serialization;

namespace EXPN.DataLayer.CreditLockService.Common.Exceptions
{
    [Serializable]
    public class OktaTokenNullException : Exception
    {
        protected OktaTokenNullException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }

        public OktaTokenNullException()
        {
        }

        public OktaTokenNullException(string message)
            : base(message)
        {
        }

        public OktaTokenNullException(string message, Exception innerException)
            : base(message, innerException)
        {
        }
    }
}