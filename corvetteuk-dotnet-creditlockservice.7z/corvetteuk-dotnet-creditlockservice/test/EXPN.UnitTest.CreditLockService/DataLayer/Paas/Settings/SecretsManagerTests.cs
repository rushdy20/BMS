﻿using Amazon.SecretsManager;
using Amazon.SecretsManager.Model;
using Experian.AWS.Config;
using Experian.AWS.HostInformation;
using EXPN.DataLayer.CreditLockService.Paas;
using EXPN.DataLayer.CreditLockService.Paas.Settings;
using FluentAssertions;
using NSubstitute;
using System;
using System.Collections.Generic;
using Xunit;

namespace EXPN.UnitTest.CreditLockService.DataLayer.Paas.Settings
{
    public class SecretsManagerTests
    {
        private readonly IAmazonSecretsManager _amazonSecretsManager;
        private readonly IHostInformation _hostInformation;
        private readonly IServiceConfig _serviceConfig;
        private readonly ISecretsManager _secretsManager;

        public SecretsManagerTests()
        {
            _amazonSecretsManager = Substitute.For<IAmazonSecretsManager>();

            _hostInformation = Substitute.For<IHostInformation>();

            var hostTags = new Dictionary<string, string>
            {
                {"Environment", "test"}
            };

            _hostInformation.GetHostTags()
                .Returns(hostTags);

            _serviceConfig = Substitute.For<IServiceConfig>();

            _serviceConfig.ServiceName
                .Returns("testServiceName");

            _secretsManager = new SecretsManager(
                _amazonSecretsManager,
                _hostInformation, 
                _serviceConfig);
        }

        public class Constructor
        {
            public static IEnumerable<object[]> NullParameters()
            {
                yield return new object[]
                {
                    null,
                    Substitute.For<IHostInformation>(),
                    Substitute.For<IServiceConfig>(),
                    "secretsManager"
                };

                yield return new object[]
                {
                    Substitute.For<IAmazonSecretsManager>(),
                    null,
                    Substitute.For<IServiceConfig>(),
                    "hostInformation"
                };

                yield return new object[]
                {
                    Substitute.For<IAmazonSecretsManager>(),
                    Substitute.For<IHostInformation>(),
                    null,
                    "serviceConfig"
                };
            }

            [Theory]
            [MemberData(nameof(NullParameters))]
            public void NullRequiredConstructorParameter_ThrowsArgumentNullException(IAmazonSecretsManager amazonSecretsManager,
                IHostInformation hostInformation,
                IServiceConfig serviceConfig,
                string expectedErrorParameter)
            {
                Action action = () => { new SecretsManager(amazonSecretsManager, hostInformation, serviceConfig); };

                action.Should().Throw<ArgumentNullException>()
                    .Where(x => x.ParamName == expectedErrorParameter);
            }
        }

        public class GetSecretAsync : SecretsManagerTests
        {
            [Fact]
            public async void GetSecretAsync_ValidKey_ReturnsSerializedObject()
            {
                var expected = new TestSerializedObject
                {
                    Amount = 100,
                    Message = "Test Message"
                };

                _amazonSecretsManager.GetSecretValueAsync(Arg.Is<GetSecretValueRequest>(x => x.SecretId == "test/testServiceName/test_key"))
                    .Returns(new GetSecretValueResponse
                    {
                        SecretString = "{ \"amount\": \"100\", \"message\": \"Test Message\"}"
                    });

                var obj = await _secretsManager.GetSecretAsync<TestSerializedObject>("test_key");

                obj.Should().BeEquivalentTo(expected);
            }

            [Fact]
            public void GetSecretAsync_InvalidKey_ThrowsInvalidOperationException()
            {
                var task = async () => { await _secretsManager.GetSecretAsync<TestSerializedObject>("missing_key"); };

                task.Should().Throw<InvalidOperationException>()
                    .Where(x => x.Message == "Unable to retrieve key: missing_key");
            }
        }

        protected class TestSerializedObject
        {
            public int Amount { get; set; }
            public string Message { get; set; }
        }
    }
}
