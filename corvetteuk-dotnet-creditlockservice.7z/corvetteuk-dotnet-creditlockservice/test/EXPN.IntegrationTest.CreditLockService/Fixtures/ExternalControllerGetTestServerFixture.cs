using EXPN.IntegrationTest.CreditLockService.Utility;
using Microsoft.AspNetCore.TestHost;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Mime;
using Microsoft.Extensions.Hosting;
using Xunit;
using System.Threading.Tasks;

namespace EXPN.IntegrationTest.CreditLockService.Fixtures
{
    public class ExternalControllerGetTestServerFixture : IAsyncLifetime
    {
        private readonly IHostBuilder _hostbuilder;

        public HttpResponseMessage HttpResponseMessage;

        public ExternalControllerGetTestServerFixture()
        {
            _hostbuilder = new HostBuilder()
                .UseIntegrationTestSettings();
        }

        public async Task InitializeAsync()
        {
            using (var host = _hostbuilder.Start())
            {
                var webClient = host.GetTestClient();
                webClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(MediaTypeNames.Application.Json));

                HttpResponseMessage = await webClient.GetAsync("/api/creditlock");
            }
        }

        public Task DisposeAsync()
        {
            return Task.CompletedTask;
        }
    }
}
