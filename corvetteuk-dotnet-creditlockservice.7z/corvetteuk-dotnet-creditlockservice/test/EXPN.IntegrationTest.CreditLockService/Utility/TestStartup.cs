using Amazon;
using Amazon.SimpleNotificationService;
using Amazon.SimpleNotificationService.Model;
using Experian.AWS.Config;
using Experian.AWS.Cryptography;
using Experian.AWS.HostInformation;
using Experian.Events.MessageBuilder.Helios;
using Experian.HttpClient.Services.Customers;
using Experian.HttpClient.Services.Customers.Internal.GET;
using EXPN.Controllers.CreditLockService;
using EXPN.IntegrationTest.CreditLockService.Utility.MessageHandlers;
using EXPN.Models.CreditLockService.Paas;
using EXPN.ServiceHost.CreditLockService;
using FluentValidation.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.OpenApi.Models;
using Newtonsoft.Json;
using NSubstitute;
using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using Experian.HttpClient.Services.Subscriptions;

namespace EXPN.IntegrationTest.CreditLockService.Utility
{
    public class TestStartup : Startup
    {
        public TestStartup(IWebHostEnvironment env) : base(env)
        {
        }

        public void ConfigureIntegrationServices(IServiceCollection services)
        {
            var hostInformation = Substitute.For<IHostInformation>();
            hostInformation.GetHostTags().Returns(new Dictionary<string, string>
            {
                {"Environment", "test"},
                {"DNSZoneName", "test"}
            });
            hostInformation.Region.Returns(RegionEndpoint.EUWest1);
            services.AddSingleton(hostInformation);

            var config = new
            {
                api_dependencies = new object[]
                {
                    new
                    {
                        logicalid = "customers",
                        protocol = "HTTPS://",
                        version = "3.0.0",
                        name = "subscriptions"
                    },
                    new
                    {
                        status = "10",
                        logicalid = "keybroker",
                        protocol = "HTTPS://",
                        name = "keybroker",
                        version = "3.0.0"
                    },
                    new
                    {
                        logicalid = "subscriptions",
                        protocol = "HTTPS://",
                        version = "3.0.0",
                        name = "subscriptions"
                    }
                },
            };

            var serviceConfig = JsonConvert.DeserializeObject<ConsolidatedConfig>(JsonConvert.SerializeObject(config));

            if (serviceConfig != null)
            {
                services.AddSingleton<IServiceConfig>(serviceConfig);
                services.AddSingleton<ITopicConfig>(serviceConfig);
                services.AddSingleton<ICryptographyConfig>(serviceConfig);
            }

            services.AddSingleton<ICryptographyProvider, MockCryptoProvider>();
            services.AddSingleton(HeliosMessageBuilder.FactoryMethod);
            services.AddSingleton(GetAmazonSnsSettings);

            services.AddControllers()
                .AddApplicationPart(typeof(InternalCreditLockController).Assembly)
                .AddNewtonsoftJson();

            services.Configure<ApiBehaviorOptions>(options =>
            {
                options.SuppressConsumesConstraintForFormFileParameters = true;
                options.SuppressInferBindingSourcesForParameters = true;
                options.SuppressModelStateInvalidFilter = true;
            });

            services.AddSwaggerGen(c => { c.SwaggerDoc("v3.0.0", new OpenApiInfo {Title = "testservice Service", Description = "A RESTful API.", Version = "3.0.0"}); });
            services.AddSwaggerGenNewtonsoftSupport();

            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();

            services.AddTransient<IOptions<OktaAuthCredentials>, TestOktaAuthCredential>();

            services.AddHealthChecks();

            services.AddLogging(builder =>
            {
                builder.AddConsole();
                builder.AddDebug();
            });

            services.AddServiceHostModule();
            services.AddAutoMapper();
            services.AddCustomersClient();

            services.AddTransient<IGetCustomerProfile, MockCustomersClient>();
            services.AddTransient<IMemoryCache, MockMemoryCache>();
            services.AddTransient<DynamicHttpMessagesHandler>();
            services.AddTransient<MockPaasHttpClientHandler>();
            services.AddTransient<SubscriptionsMockHandler>();

            services.AddHttpClient<ISubscriptionsClient, SubscriptionsClient>()
                .AddHttpMessageHandler<SubscriptionsMockHandler>();

            services.AddControllers()
                .AddApplicationPart(typeof(InternalCreditLockController).Assembly)
                .AddNewtonsoftJson()
                .AddFluentValidation();
        }

        private static IAmazonSimpleNotificationService GetAmazonSnsSettings(IServiceProvider sp)
        {
            var amazonSimpleNotificationService = Substitute.For<IAmazonSimpleNotificationService>();

            var publishResponse = new PublishResponse
            {
                HttpStatusCode = HttpStatusCode.OK
            };

            amazonSimpleNotificationService.PublishAsync(Arg.Any<string>(), Arg.Any<string>())
                .Returns(Task.FromResult(publishResponse));

            return amazonSimpleNotificationService;
        }
    }
}