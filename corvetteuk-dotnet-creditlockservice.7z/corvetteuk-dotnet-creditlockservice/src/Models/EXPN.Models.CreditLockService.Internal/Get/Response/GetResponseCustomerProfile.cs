﻿using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace EXPN.Models.CreditLockService.Internal.Get.Response
{
    [ExcludeFromCodeCoverage]
    public class GetResponseCustomerProfile
    {
        public string CustomerId { get; set; }

        public string CorrelationId { get; set; }

        public string Title { get; set; }

        public string FirstName { get; set; }

        public string MiddleName { get; set; }

        public string LastName { get; set; }

        public string DOB { get; set; }

        public string IconRef { get; set; }

        public string CustomerRef { get; set; }

        public IEnumerable<GetResponseCustomerAddressModel> Address { get; set; }
    }
}