﻿namespace EXPN.Models.CreditLockService.Internal.Get.Request
{
    public class GetCustomerRequest
    {
        public string CustomerId { get; set; }
    }
}