﻿using FluentAssertions;
using System.Collections.Generic;
using System.Linq;
using EXPN.Models.CreditLockService.External.Get.Customer.Request;
using EXPN.Validators.CreditLockService.Get;
using Xunit;

namespace EXPN.UnitTest.CreditLockService.Validators
{
    public  class GetStatusRequestModelValidatorTests
    {
        public static IEnumerable<object[]> LoadingCustomerRequestData()
        {
            yield return new object[]
            {
                new GetStatusRequest(),
                false,
                "'Customer Id' must not be empty."
            };

            yield return new object[]
            {
                new GetStatusRequest
                {
                    CustomerId = string.Empty
                },
                false,
                "'Customer Id' must not be empty."
            };

            yield return new object[]
            {
                new GetStatusRequest
                {
                    CustomerId = string.Empty.PadLeft(1)
                },
                false,
                "'Customer Id' must not be empty."
            };

            yield return new object[]
            {
                new GetStatusRequest
                {
                    CustomerId = "Test"
                },
                false,
                "'CustomerId' is not in valid format"
            };

            yield return new object[]
            {
                new GetStatusRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4"
                },
                true,
                null,
            };
        }

        [Theory]
        [MemberData(nameof(LoadingCustomerRequestData))]
        public void LoadingCustomerValidator_ValidRequest_ShouldBeSameAsExpected(GetStatusRequest loadCustomerRequest, bool expected, string errorMessage)
        {
            var result = new GetStatusRequestModelValidator()
                .Validate(loadCustomerRequest);

            if (expected)
            {
                result.IsValid.Should().BeTrue();
                result.Errors.Should().HaveCount(0);
            }
            else
            {
                result.IsValid.Should().BeFalse();
                result.Errors.Should().HaveCount(1);
                result.Errors.Select(x => x.ErrorMessage).FirstOrDefault().Should().BeEquivalentTo(errorMessage);
            }
        }
    }
}
