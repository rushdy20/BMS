﻿using EXPN.Mappers.CreditLockService.External.Resolver;
using FluentAssertions;
using System;
using System.Collections.Generic;
using Xunit;
using InternalModel = EXPN.Models.CreditLockService.Internal.Get.Response;

namespace EXPN.UnitTest.CreditLockService.Mappers.External.Resolver
{
    public class LockStatusResolverTests
    {
        public static IEnumerable<object[]> ResolveData()
        {
            yield return new object[]
            {
                new InternalModel.GetCustomerResponse
                {
                    LockStatus = "N",
                    Addresses = new List<InternalModel.GetResponsePaasAddressResponse>
                    {
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "3"
                        }
                    }
                },
               "OFF"
            };

            yield return new object[]
            {
                new InternalModel.GetCustomerResponse
                {
                    LockStatus = "N",
                    Addresses = new List<InternalModel.GetResponsePaasAddressResponse>
                    {
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "3"
                        },
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "4"
                        },
                    }
                },
                "OFF"
            };

            yield return new object[]
            {
                new InternalModel.GetCustomerResponse
                {
                    LockStatus = "N",
                    Addresses = new List<InternalModel.GetResponsePaasAddressResponse>
                    {
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "4"
                        },
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "1"
                        },
                    }
                },
                "OFF_AND_UPDATING"
            };

            yield return new object[]
            {
                new InternalModel.GetCustomerResponse
                {
                    LockStatus = "N",
                    Addresses = new List<InternalModel.GetResponsePaasAddressResponse>
                    {
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "3"
                        },
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "2"
                        },
                    }
                },
                "OFF_AND_UPDATING"
            };

            yield return new object[]
            {
                new InternalModel.GetCustomerResponse
                {
                    LockStatus = "N",
                    Addresses = new List<InternalModel.GetResponsePaasAddressResponse>
                    {
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "D"
                        }
                    }
                },
                "OFF_PINNING_PROBLEM"
            };

            yield return new object[]
            {
                new InternalModel.GetCustomerResponse
                {
                    LockStatus = "N",
                    Addresses = new List<InternalModel.GetResponsePaasAddressResponse>
                    {
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "P"
                        }
                    }
                },
                "OFF_PINNING_PROBLEM"
            };

            yield return new object[]
            {
                new InternalModel.GetCustomerResponse
                {
                    LockStatus = "N",
                    Addresses = new List<InternalModel.GetResponsePaasAddressResponse>
                    {
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "E"
                        }
                    }
                },
                "OFF_PINNING_PROBLEM"
            };

            yield return new object[]
            {
                new InternalModel.GetCustomerResponse
                {
                    LockStatus = "N",
                    Addresses = new List<InternalModel.GetResponsePaasAddressResponse>
                    {
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "D"
                        },
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "D"
                        }
                    }
                },
                "OFF_PINNING_PROBLEM"
            };

            yield return new object[]
            {
                new InternalModel.GetCustomerResponse
                {
                    LockStatus = "N",
                    Addresses = new List<InternalModel.GetResponsePaasAddressResponse>
                    {
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "D"
                        },
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "3"
                        }
                    }
                },
                "OFF_PINNING_PROBLEM"
            };

            yield return new object[]
            {
                new InternalModel.GetCustomerResponse
                {
                    LockStatus = "N",
                    Addresses = new List<InternalModel.GetResponsePaasAddressResponse>
                    {
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "D"
                        },
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "3"
                        },
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "4"
                        }
                    }
                },
                "OFF_PINNING_PROBLEM"
            };

            yield return new object[]
            {
                new InternalModel.GetCustomerResponse
                {
                    LockStatus = "N",
                    Addresses = new List<InternalModel.GetResponsePaasAddressResponse>
                    {
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "0"
                        }
                    }
                },
                "OFF_AND_UPDATING"
            };

            yield return new object[]
            {
                new InternalModel.GetCustomerResponse
                {
                    LockStatus = "N",
                    Addresses = new List<InternalModel.GetResponsePaasAddressResponse>
                    {
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "N"
                        }
                    }
                },
                "OFF_AND_UPDATING"
            };

            yield return new object[]
            {
                new InternalModel.GetCustomerResponse
                {
                    LockStatus = "N",
                    Addresses = new List<InternalModel.GetResponsePaasAddressResponse>
                    {
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "4"
                        },
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "N"
                        },
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "1"
                        }
                    }
                },
                "OFF_AND_UPDATING"
            };

            yield return new object[]
            {
                new InternalModel.GetCustomerResponse
                {
                    LockStatus = "N",
                    Addresses = new List<InternalModel.GetResponsePaasAddressResponse>
                    {
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "1"
                        }
                    }
                },
                "OFF_AND_UPDATING"
            };

            yield return new object[]
            {
                new InternalModel.GetCustomerResponse
                {
                    LockStatus = "N",
                    Addresses = new List<InternalModel.GetResponsePaasAddressResponse>
                    {
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "2"
                        }
                    }
                },
                "OFF_AND_UPDATING"
            };

            yield return new object[]
            {
                new InternalModel.GetCustomerResponse
                {
                    LockStatus = "Y",
                    Addresses = new List<InternalModel.GetResponsePaasAddressResponse>
                    {
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "3"
                        }
                    }
                },
               "ON"
            };

            yield return new object[]
            {
                new InternalModel.GetCustomerResponse
                {
                    LockStatus = "Y",
                    Addresses = new List<InternalModel.GetResponsePaasAddressResponse>
                    {
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "3"
                        },
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "4"
                        },
                    }
                },
                "ON"
            };

            yield return new object[]
            {
                new InternalModel.GetCustomerResponse
                {
                    LockStatus = "Y",
                    Addresses = new List<InternalModel.GetResponsePaasAddressResponse>
                    {
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "4"
                        },
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "1"
                        },
                    }
                },
                "ON_AND_UPDATING"
            };

            yield return new object[]
            {
                new InternalModel.GetCustomerResponse
                {
                    LockStatus = "Y",
                    Addresses = new List<InternalModel.GetResponsePaasAddressResponse>
                    {
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "3"
                        },
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "2"
                        },
                    }
                },
                "ON_AND_UPDATING"
            };

            yield return new object[] 
            {
                new InternalModel.GetCustomerResponse
                {
                    LockStatus = "Y",
                    Addresses = new List<InternalModel.GetResponsePaasAddressResponse>
                    {
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "D"
                        }
                    }
                },
                "ON_PINNING_PROBLEM"
            };

            yield return new object[]
            {
                new InternalModel.GetCustomerResponse
                {
                    LockStatus = "Y",
                    Addresses = new List<InternalModel.GetResponsePaasAddressResponse>
                    {
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "P"
                        }
                    }
                },
                "ON_PINNING_PROBLEM"
            };

            yield return new object[]
            {
                new InternalModel.GetCustomerResponse
                {
                    LockStatus = "Y",
                    Addresses = new List<InternalModel.GetResponsePaasAddressResponse>
                    {
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "E"
                        }
                    }
                },
                "ON_PINNING_PROBLEM"
            };

            yield return new object[]
            {
                new InternalModel.GetCustomerResponse
                {
                    LockStatus = "Y",
                    Addresses = new List<InternalModel.GetResponsePaasAddressResponse>
                    {
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "D"
                        },
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                        PinStatus = "D"
                    }
                    }
                },
                "ON_PINNING_PROBLEM"
            };

            yield return new object[]
            {
                new InternalModel.GetCustomerResponse
                {
                    LockStatus = "Y",
                    Addresses = new List<InternalModel.GetResponsePaasAddressResponse>
                    {
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "D"
                        },
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "3"
                        }
                    }
                },
                "ON_PINNING_PROBLEM"
            };

            yield return new object[]
            {
                new InternalModel.GetCustomerResponse
                {
                    LockStatus = "Y",
                    Addresses = new List<InternalModel.GetResponsePaasAddressResponse>
                    {
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "D"
                        },
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "3"
                        },
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "4"
                        }
                    }
                },
                "ON_PINNING_PROBLEM"
            };

            yield return new object[]
            {
                new InternalModel.GetCustomerResponse
                {
                    LockStatus = "Y",
                    Addresses = new List<InternalModel.GetResponsePaasAddressResponse>
                    {
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "0"
                        }
                    }
                },
                "ON_AND_UPDATING"
            };

            yield return new object[]
            {
                new InternalModel.GetCustomerResponse
                {
                    LockStatus = "Y",
                    Addresses = new List<InternalModel.GetResponsePaasAddressResponse>
                    {
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "N"
                        }
                    }
                },
                "ON_AND_UPDATING"
            };

            yield return new object[]
            {
                new InternalModel.GetCustomerResponse
                {
                    LockStatus = "Y",
                    Addresses = new List<InternalModel.GetResponsePaasAddressResponse>
                    {
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "4"
                        },
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "N"
                        },
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "1"
                        }
                    }
                },
                "ON_AND_UPDATING"
            };

            yield return new object[]
            {
                new InternalModel.GetCustomerResponse
                {
                    LockStatus = "Y",
                    Addresses = new List<InternalModel.GetResponsePaasAddressResponse>
                    {
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "1"
                        }
                    }
                },
                "ON_AND_UPDATING"
            };

            yield return new object[]
            {
                new InternalModel.GetCustomerResponse
                {
                    LockStatus = "Y",
                    Addresses = new List<InternalModel.GetResponsePaasAddressResponse>
                    {
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "2"
                        }
                    }
                },
                "ON_AND_UPDATING"
            };
        }

        [Theory]
        [MemberData(nameof(ResolveData))]
        public void Resolve_Returns_CorrectLockStatus(InternalModel.GetCustomerResponse source, string expectedResult)
        {
            var result = new LockStatusResolver().Resolve(source, null, null,null);

            result.Should().BeEquivalentTo(expectedResult);
        }

        public static IEnumerable<object[]> InvalidData()
        {
            yield return new object[]
            {
                new InternalModel.GetCustomerResponse
                {
                    LockStatus = null
                },
                new InvalidOperationException("Lock Status cannot be null, empty or whitespace")
            };

            yield return new object[]
            {
                new InternalModel.GetCustomerResponse
                {
                    LockStatus = string.Empty
                },
                new InvalidOperationException("Lock Status cannot be null, empty or whitespace")
            };

            yield return new object[]
            {
                new InternalModel.GetCustomerResponse
                {
                    LockStatus = string.Empty.PadLeft(10)
                },
                new InvalidOperationException("Lock Status cannot be null, empty or whitespace")
            };

            yield return new object[]
            {
                new InternalModel.GetCustomerResponse
                {
                    LockStatus = "n"
                },
                new InvalidOperationException("Lock Status is an unrecognized value")
            };

            yield return new object[]
            {
                new InternalModel.GetCustomerResponse
                {
                    LockStatus = "y"
                },
                new InvalidOperationException("Lock Status is an unrecognized value")
            };

            yield return new object[]
            {
                new InternalModel.GetCustomerResponse
                {
                    LockStatus = "1"
                },
                new InvalidOperationException("Lock Status is an unrecognized value")
            };

            yield return new object[]
            {
                new InternalModel.GetCustomerResponse
                {
                    LockStatus = "A"
                },
                new InvalidOperationException("Lock Status is an unrecognized value")
            };

            yield return new object[]
            {
                new InternalModel.GetCustomerResponse
                {
                    LockStatus = "£"
                },
                new InvalidOperationException("Lock Status is an unrecognized value")
            };
            
            yield return new object[]
            {
                new InternalModel.GetCustomerResponse
                {
                    LockStatus = "N",
                    Addresses = null
                },
                new InvalidOperationException("Addresses cannot be null")
            };

            yield return new object[]
            {
                new InternalModel.GetCustomerResponse
                {
                    LockStatus = "N",
                    Addresses = new List<InternalModel.GetResponsePaasAddressResponse>()
                },
                new InvalidOperationException("Addresses cannot be empty")
            };

            yield return new object[]
            {
                new InternalModel.GetCustomerResponse
                {
                    LockStatus = "N",
                    Addresses = new List<InternalModel.GetResponsePaasAddressResponse>
                    {
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = null
                        }
                    }
                },
                new InvalidOperationException("Addresses contain one or more Pin Statuses with an unrecognized value")
            };

            yield return new object[]
            {
                new InternalModel.GetCustomerResponse
                {
                    LockStatus = "N",
                    Addresses = new List<InternalModel.GetResponsePaasAddressResponse>
                    {
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = string.Empty
                        }
                    }
                },
                new InvalidOperationException("Addresses contain one or more Pin Statuses with an unrecognized value")
            };

            yield return new object[]
            {
                new InternalModel.GetCustomerResponse
                {
                    LockStatus = "N",
                    Addresses = new List<InternalModel.GetResponsePaasAddressResponse>
                    {
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = string.Empty.PadLeft(10)
                        }
                    }
                },
                new InvalidOperationException("Addresses contain one or more Pin Statuses with an unrecognized value")
            };

            yield return new object[]
            {
                new InternalModel.GetCustomerResponse
                {
                    LockStatus = "N",
                    Addresses = new List<InternalModel.GetResponsePaasAddressResponse>
                    {
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "X"
                        }
                    }
                },
                new InvalidOperationException("Addresses contain one or more Pin Statuses with an unrecognized value")
            };

            yield return new object[]
            {
                new InternalModel.GetCustomerResponse
                {
                    LockStatus = "N",
                    Addresses = new List<InternalModel.GetResponsePaasAddressResponse>
                    {
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "5"
                        }
                    }
                },
                new InvalidOperationException("Addresses contain one or more Pin Statuses with an unrecognized value")
            };

            yield return new object[]
            {
                new InternalModel.GetCustomerResponse
                {
                    LockStatus = "N",
                    Addresses = new List<InternalModel.GetResponsePaasAddressResponse>
                    {
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "0"
                        },
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "X"
                        }
                    }
                },
                new InvalidOperationException("Addresses contain one or more Pin Statuses with an unrecognized value")
            };

            yield return new object[]
            {
                new InternalModel.GetCustomerResponse
                {
                    LockStatus = "N",
                    Addresses = new List<InternalModel.GetResponsePaasAddressResponse>
                    {
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "0"
                        },
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "1"
                        },
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "X"
                        }
                    }
                },
                new InvalidOperationException("Addresses contain one or more Pin Statuses with an unrecognized value")
            };

            yield return new object[]
            {
                new InternalModel.GetCustomerResponse
                {
                    LockStatus = "N",
                    Addresses = new List<InternalModel.GetResponsePaasAddressResponse>
                    {
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "3"
                        },
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "3"
                        },
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "3"
                        },
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "X"
                        }
                    }
                },
                new InvalidOperationException("Addresses contain one or more Pin Statuses with an unrecognized value")
            };

            yield return new object[]
            {
                new InternalModel.GetCustomerResponse
                {
                    LockStatus = "N",
                    Addresses = new List<InternalModel.GetResponsePaasAddressResponse>
                    {
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "0"
                        },
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "1"
                        },
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "2"
                        },
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "3"
                        },
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "4"
                        },
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "N"
                        },
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "D"
                        },
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "P"
                        },
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "E"
                        },
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "X"
                        }
                    }
                },
                new InvalidOperationException("Addresses contain one or more Pin Statuses with an unrecognized value")
            };

            yield return new object[]
{
                new InternalModel.GetCustomerResponse
                {
                    LockStatus = "N",
                    Addresses = new List<InternalModel.GetResponsePaasAddressResponse>
                    {
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "0"
                        },
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "1"
                        },
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "2"
                        },
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "3"
                        },
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "4"
                        },
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "N"
                        },
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "D"
                        },
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "P"
                        },
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = "E"
                        },
                        new InternalModel.GetResponsePaasAddressResponse
                        {
                            PinStatus = string.Empty
                        }
                    }
                },
                new InvalidOperationException("Addresses contain one or more Pin Statuses with an unrecognized value")
};
        }

        [Theory]
        [MemberData(nameof(InvalidData))]
        public void Resolve_InvalidModel_ThrowsException(InternalModel.GetCustomerResponse source, Exception expectedEx)
        {
            Action action = () =>
            {
                var unused = new LockStatusResolver().Resolve(source, null, null, null);
            };

            var expectedExType = expectedEx.GetType();

            action.Should().Throw<Exception>()
                .Where(x => x.GetType() == expectedExType)
                .And.Message.Should().Be(expectedEx.Message);
        }

        [Fact]
        public void NullSourceInConstructor_ThrowsArgumentNullException()
        {
            Action action = () =>
            {
                var unused = new LockStatusResolver().Resolve(null, null, null, null);
            };

            action.Should().Throw<ArgumentNullException>()
                .WithMessage("Value cannot be null. (Parameter 'source')")
                .Where(x => x.ParamName == "source");
        }
    }
}
