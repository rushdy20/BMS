﻿using AutoMapper;
using EXPN.Models.CreditLockService.Internal.Put.Request;
using System.Diagnostics.CodeAnalysis;
using PaasModel = EXPN.Models.CreditLockService.Paas.PutLockStatus.Request;

namespace EXPN.Mappers.CreditLockService.Paas
{
    [ExcludeFromCodeCoverage]
    public class PutLockStatusRequestToPutLockStatusRequestProfile : Profile
    {
        public PutLockStatusRequestToPutLockStatusRequestProfile()
        {
            CreateMap<PutLockStatusRequest, PaasModel.PutLockStatusRequest>(MemberList.None)
                .ForMember(d => d.CustomerRef, m => m.MapFrom(s => string.Empty))
                .ForMember(d => d.Status, m => m.MapFrom(s => s.LockStatus ? "Y" : "N"));
        }
    }
}