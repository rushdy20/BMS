﻿using EXPN.DataLayer.CreditLockService.Paas.HttpClient;
using EXPN.IntegrationTest.CreditLockService.Utility;
using FluentAssertions;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using System.Net;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Xunit;

namespace EXPN.IntegrationTest.CreditLockService.Controllers.External
{
    public class GetLockStatusTests
    {
        private readonly IHostBuilder _hostBuilder;

        public GetLockStatusTests()
        {
            _hostBuilder = new HostBuilder()
                .UseIntegrationTestSettings()
                .ConfigureServices(s =>
                    s.AddHttpClient<ICreditLockPaasClient, CreditLockPaasClient>(c =>
                    {
                        c.DefaultRequestHeaders
                            .Accept
                            .Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    }).AddHttpMessageHandler<MockPaasHttpClientHandler>());
        }

        public static IEnumerable<object[]> GetReportData()
        {
            yield return new object[]
            {
                "4a1f51c5-e902-4efb-8366-816e29e788e7",
                (HttpStatusCode) 200,
                "{\"lockStatus\":\"ON\"}"
            };

            yield return new object[]
            {
                "not a valid id",
                (HttpStatusCode) 400,
                "{\"fieldErrors\": {\"CustomerId\": \"'CustomerId' is not in valid format\"},\"status\": 400,\"message\": null}"
            };

            yield return new object[]
            {
                "4a1f51c5-e902-4efb-8366-816e29e78404",
                (HttpStatusCode) 404,
                "{\"fieldErrors\":{},\"status\":404,\"message\":null}"
            };

            yield return new object[]
            {
                "4a1f51c5-e902-4efb-8366-816e29e78561",
                (HttpStatusCode) 561,
                "{\"fieldErrors\":{},\"status\":561,\"message\":null}"
            };

            yield return new object[]
            {
                "4a1f51c5-e902-4efb-8366-816e29e78503",
                (HttpStatusCode) 503,
                "{\"fieldErrors\":{},\"status\":503,\"message\":null}"
            };

            yield return new object[]
            {
                "4a1f51c5-e902-4efb-8366-816e29e78001",
                (HttpStatusCode) 200,
                "{\"lockStatus\":\"OFF\"}"
            };

            yield return new object[]
            {
                "4a1f51c5-e902-4efb-8366-816e29e78002",
                (HttpStatusCode) 200,
                "{\"lockStatus\":\"OFF\"}"
            };

            yield return new object[]
            {
                "4a1f51c5-e902-4efb-8366-816e29e78003",
                (HttpStatusCode) 200,
                "{\"lockStatus\":\"OFF\"}"
            };

            yield return new object[]
            {
                "4a1f51c5-e902-4efb-8366-816e29e78004",
                (HttpStatusCode) 200,
                "{\"lockStatus\":\"OFF\"}"
            };

            yield return new object[]
            {
                "4a1f51c5-e902-4efb-8366-816e29e78005",
                (HttpStatusCode) 200,
                "{\"lockStatus\":\"OFF\"}"
            };

            yield return new object[]
            {
                "4a1f51c5-e902-4efb-8366-816e29e78006",
                (HttpStatusCode) 200,
                "{\"lockStatus\":\"OFF\"}"
            };

            yield return new object[]
            {
                "4a1f51c5-e902-4efb-8366-816e29e78007",
                (HttpStatusCode) 200,
                "{\"lockStatus\":\"OFF\"}"
            };

            yield return new object[]
            {
                "4a1f51c5-e902-4efb-8366-816e29e78008",
                (HttpStatusCode) 200,
                "{\"lockStatus\":\"OFF\"}"
            };

            yield return new object[]
            {
                "4a1f51c5-e902-4efb-8366-816e29e78009",
                (HttpStatusCode) 200,
                "{\"lockStatus\":\"OFF_AND_UPDATING\"}"
            };

            yield return new object[]
            {
                "4a1f51c5-e902-4efb-8366-816e29e78010",
                (HttpStatusCode) 200,
                "{\"lockStatus\":\"ON_AND_UPDATING\"}"
            };

            yield return new object[]
            {
                "4a1f51c5-e902-4efb-8366-816e29e79001",
                (HttpStatusCode) 200,
                "{\"lockStatus\":\"OFF_PINNING_PROBLEM\"}"
            };

            yield return new object[]
            {
                "4a1f51c5-e902-4efb-8366-816e29e79002",
                (HttpStatusCode) 200,
                "{\"lockStatus\":\"OFF_PINNING_PROBLEM\"}"
            };

            yield return new object[]
            {
                "4a1f51c5-e902-4efb-8366-816e29e79003",
                (HttpStatusCode) 200,
                "{\"lockStatus\":\"OFF_PINNING_PROBLEM\"}"
            };

            yield return new object[]
            {
                "4a1f51c5-e902-4efb-8366-816e29e79004",
                (HttpStatusCode) 200,
                "{\"lockStatus\":\"OFF_PINNING_PROBLEM\"}"
            };

            yield return new object[]
            {
                "4a1f51c5-e902-4efb-8366-816e29e79005",
                (HttpStatusCode) 200,
                "{\"lockStatus\":\"OFF_PINNING_PROBLEM\"}"
            };

            yield return new object[]
            {
                "4a1f51c5-e902-4efb-8366-816e29e79006",
                (HttpStatusCode) 200,
                "{\"lockStatus\":\"OFF_PINNING_PROBLEM\"}"
            };

            yield return new object[]
            {
                "4a1f51c5-e902-4efb-8366-816e29e79007",
                (HttpStatusCode) 200,
                "{\"lockStatus\":\"OFF_PINNING_PROBLEM\"}"
            };

            yield return new object[]
            {
                "4a1f51c5-e902-4efb-8366-816e29e89001",
                (HttpStatusCode) 200,
                "{\"lockStatus\":\"OFF_AND_UPDATING\"}"
            };

            yield return new object[]
            {
                "4a1f51c5-e902-4efb-8366-816e29e89002",
                (HttpStatusCode) 200,
                "{\"lockStatus\":\"OFF_AND_UPDATING\"}"
            };

            yield return new object[]
            {
                "4a1f51c5-e902-4efb-8366-816e29e89003",
                (HttpStatusCode) 200,
                "{\"lockStatus\":\"OFF_AND_UPDATING\"}"
            };

            yield return new object[]
            {
                "4a1f51c5-e902-4efb-8366-816e29e89004",
                (HttpStatusCode) 200,
                "{\"lockStatus\":\"OFF_AND_UPDATING\"}"
            };

            yield return new object[]
            {
                "4a1f51c5-e902-4efb-8366-816e29e89005",
                (HttpStatusCode) 200,
                "{\"lockStatus\":\"OFF_AND_UPDATING\"}"
            };

            yield return new object[]
            {
                "4a1f51c5-e902-4efb-8366-816e29e89006",
                (HttpStatusCode) 200,
                "{\"lockStatus\":\"OFF_AND_UPDATING\"}"
            };

            yield return new object[]
            {
                "4a1f51c5-e902-4efb-8366-816e29e89007",
                (HttpStatusCode) 200,
                "{\"lockStatus\":\"OFF_AND_UPDATING\"}"
            };

            yield return new object[]
            {
                "5a1f51c5-e902-4efb-8366-816e29e89001",
                (HttpStatusCode) 200,
                "{\"lockStatus\":\"ON\"}"
            };

            yield return new object[]
            {
                "5a1f51c5-e902-4efb-8366-816e29e89002",
                (HttpStatusCode) 200,
                "{\"lockStatus\":\"ON\"}"
            };

            yield return new object[]
            {
                "5a1f51c5-e902-4efb-8366-816e29e89003",
                (HttpStatusCode) 200,
                "{\"lockStatus\":\"ON\"}"
            };

            yield return new object[]
            {
                "5a1f51c5-e902-4efb-8366-816e29e89004",
                (HttpStatusCode) 200,
                "{\"lockStatus\":\"ON\"}"
            };

            yield return new object[]
            {
                "5a1f51c5-e902-4efb-8366-816e29e89005",
                (HttpStatusCode) 200,
                "{\"lockStatus\":\"ON\"}"
            };

            yield return new object[]
            {
                "5a1f51c5-e902-4efb-8366-816e29e89006",
                (HttpStatusCode) 200,
                "{\"lockStatus\":\"ON\"}"
            };

            yield return new object[]
            {
                "5a1f51c5-e902-4efb-8366-816e29e89007",
                (HttpStatusCode) 200,
                "{\"lockStatus\":\"ON\"}"
            };

            yield return new object[]
            {
                "4a1f51c5-e902-4efb-8366-816e29e89001",
                (HttpStatusCode) 200,
                "{\"lockStatus\":\"OFF_AND_UPDATING\"}"
            };

            yield return new object[]
            {
                "4a1f51c5-e902-4efb-8366-816e29e89002",
                (HttpStatusCode) 200,
                "{\"lockStatus\":\"OFF_AND_UPDATING\"}"
            };

            yield return new object[]
            {
                "4a1f51c5-e902-4efb-8366-816e29e89003",
                (HttpStatusCode) 200,
                "{\"lockStatus\":\"OFF_AND_UPDATING\"}"
            };

            yield return new object[]
            {
                "4a1f51c5-e902-4efb-8366-816e29e89004",
                (HttpStatusCode) 200,
                "{\"lockStatus\":\"OFF_AND_UPDATING\"}"
            };

            yield return new object[]
            {
                "4a1f51c5-e902-4efb-8366-816e29e89005",
                (HttpStatusCode) 200,
                "{\"lockStatus\":\"OFF_AND_UPDATING\"}"
            };

            yield return new object[]
            {
                "4a1f51c5-e902-4efb-8366-816e29e89006",
                (HttpStatusCode) 200,
                "{\"lockStatus\":\"OFF_AND_UPDATING\"}"
            };

            yield return new object[]
            {
                "4a1f51c5-e902-4efb-8366-816e29e89007",
                (HttpStatusCode) 200,
                "{\"lockStatus\":\"OFF_AND_UPDATING\"}"
            };

            yield return new object[]
            {
                "5a1f51c5-e902-4efb-8366-816e29e81001",
                (HttpStatusCode) 200,
                "{\"lockStatus\":\"ON_PINNING_PROBLEM\"}"
            };

            yield return new object[]
            {
                "5a1f51c5-e902-4efb-8366-816e29e81002",
                (HttpStatusCode) 200,
                "{\"lockStatus\":\"ON_PINNING_PROBLEM\"}"
            };

            yield return new object[]
            {
                "5a1f51c5-e902-4efb-8366-816e29e81003",
                (HttpStatusCode) 200,
                "{\"lockStatus\":\"ON_PINNING_PROBLEM\"}"
            };

            yield return new object[]
            {
                "5a1f51c5-e902-4efb-8366-816e29e81004",
                (HttpStatusCode) 200,
                "{\"lockStatus\":\"ON_PINNING_PROBLEM\"}"
            };

            yield return new object[]
            {
                "5a1f51c5-e902-4efb-8366-816e29e81005",
                (HttpStatusCode) 200,
                "{\"lockStatus\":\"ON_PINNING_PROBLEM\"}"
            };

            yield return new object[]
            {
                "5a1f51c5-e902-4efb-8366-816e29e81006",
                (HttpStatusCode) 200,
                "{\"lockStatus\":\"ON_PINNING_PROBLEM\"}"
            };

            yield return new object[]
            {
                "5a1f51c5-e902-4efb-8366-816e29e82001",
                (HttpStatusCode) 200,
                "{\"lockStatus\":\"ON_AND_UPDATING\"}"
            };

            yield return new object[]
            {
                "5a1f51c5-e902-4efb-8366-816e29e82002",
                (HttpStatusCode) 200,
                "{\"lockStatus\":\"ON_AND_UPDATING\"}"
            };

            yield return new object[]
            {
                "5a1f51c5-e902-4efb-8366-816e29e82003",
                (HttpStatusCode) 200,
                "{\"lockStatus\":\"ON_AND_UPDATING\"}"
            };

            yield return new object[]
            {
                "5a1f51c5-e902-4efb-8366-816e29e82004",
                (HttpStatusCode) 200,
                "{\"lockStatus\":\"ON_AND_UPDATING\"}"
            };

            yield return new object[]
            {
                "5a1f51c5-e902-4efb-8366-816e29e82005",
                (HttpStatusCode) 500,
                "{\"fieldErrors\":{},\"status\":500,\"message\":\"Lock Status is an unrecognized value\"}"
            };

            yield return new object[]
            {
                "5a1f51c5-e902-4efb-8366-816e29e82006",
                (HttpStatusCode) 500,
                "{\"fieldErrors\":{},\"status\":500,\"message\":\"Addresses contain one or more Pin Statuses with an unrecognized value\"}"
            };

            yield return new object[]
            {
                "b3766399-d34f-4619-8c93-94eb8091cfc5",
                (HttpStatusCode) 200,
                "{\"lockStatus\":\"ON\"}"
            };

            yield return new object[]
            {
                "9009758b-62f8-42d4-8f93-1dec01772a6f",
                (HttpStatusCode) 403,
                "{\"fieldErrors\":{},\"status\":403,\"message\":\"Benefit could not be fulfilled\"}"
            };

            yield return new object[]
            {
                "9009758b-62f8-42d4-8f93-1dec01772ccf",
                (HttpStatusCode) 500,
                "{\"fieldErrors\":{},\"status\":500,\"message\":\"Upstream service subscriptions returned no data.\"}"
            };
        }

        [Theory]
        [MemberData(nameof(GetReportData))]
        public async Task GetExternalController_ResponseExpected(string customerId, HttpStatusCode expectedStatusCode, string expectedServiceResponseJsonStr)
        {
            var actualServiceResponse = await CommonIntegrationFunctions.GetExternalController(customerId, _hostBuilder);

            actualServiceResponse.StatusCode.Should().Be(expectedStatusCode, $"customer id: {customerId}");

            if (expectedServiceResponseJsonStr != null)
            {
                var actualServiceResponseJsonStr = await actualServiceResponse.Content.ReadAsStringAsync();

                JToken.DeepEquals(JObject.Parse(actualServiceResponseJsonStr),
                    JObject.Parse(expectedServiceResponseJsonStr)).Should().BeTrue($"Customer Id: {customerId}");
            }
        }
    }
}