﻿using AutoMapper;
using EXPN.Models.CreditLockService.External.Post.Request;
using EXPN.Models.CreditLockService.Internal.Put.Request;
using System.Diagnostics.CodeAnalysis;

namespace EXPN.Mappers.CreditLockService.Internal
{
    [ExcludeFromCodeCoverage]
    public class PostRequestToPutCustomerRequestProfile: Profile
    {
       public PostRequestToPutCustomerRequestProfile()
        {
            CreateMap<PostRequest, PutCustomerRequest>();
        }
    }
}