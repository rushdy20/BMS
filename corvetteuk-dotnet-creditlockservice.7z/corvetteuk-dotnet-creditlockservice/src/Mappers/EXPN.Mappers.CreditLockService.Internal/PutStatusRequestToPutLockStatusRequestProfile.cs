﻿using System.Diagnostics.CodeAnalysis;
using AutoMapper;
using EXPN.Models.CreditLockService.External.Put.Request;
using EXPN.Models.CreditLockService.Internal.Put.Request;

namespace EXPN.Mappers.CreditLockService.Internal
{
    [ExcludeFromCodeCoverage]
    public class PutStatusRequestToPutLockStatusRequestProfile : Profile
    {
        public PutStatusRequestToPutLockStatusRequestProfile()
        {
            CreateMap<PutStatusRequest, PutLockStatusRequest>();
        }
    }
}