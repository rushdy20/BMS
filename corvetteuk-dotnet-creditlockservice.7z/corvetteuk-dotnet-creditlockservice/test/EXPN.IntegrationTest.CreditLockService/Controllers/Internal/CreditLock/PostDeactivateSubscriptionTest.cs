﻿using EXPN.DataLayer.CreditLockService.Paas.HttpClient;
using EXPN.IntegrationTest.CreditLockService.Utility;
using FluentAssertions;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using System.Net;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Xunit;

namespace EXPN.IntegrationTest.CreditLockService.Controllers.Internal.CreditLock
{
    public class PostDeactivateSubscriptionTest
    {
        private readonly IHostBuilder _hostBuilder;

        public PostDeactivateSubscriptionTest()
        {
            _hostBuilder = new HostBuilder()
                .UseIntegrationTestSettings()
                .ConfigureServices(s =>
                    s.AddHttpClient<ICreditLockPaasClient, CreditLockPaasClient>(c =>
                    {
                        c.DefaultRequestHeaders
                            .Accept
                            .Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    }).AddHttpMessageHandler<MockPaasHttpClientHandler>());
        }

        public static IEnumerable<object[]> DeactivateData()
        {
            yield return new object[]
            {
                "4b1f51c5-e902-4efb-8366-816e29e788e7",
                (HttpStatusCode) 204,
                null
            };

            yield return new object[]
            {
                "not a guid",
                (HttpStatusCode) 400,
                null
            };

            // Customer Not Found in VIP
            yield return new object[]
            {
                "4a1f51c5-e902-4efb-8366-816e29e78404",
                (HttpStatusCode) 204,
                null
            };

            yield return new object[]
            {
                "4a1f51c5-e902-4efb-8366-816e29e78561",
                (HttpStatusCode) 561,
                "{\"fieldErrors\":{},\"status\":561,\"message\":null}"
            };

            yield return new object[]
            {
                "4a1f51c5-e902-4efb-8400-816e29e78999",
                (HttpStatusCode) 563,
                "{\"fieldErrors\": {},\"status\": 563,\"message\": null}"
            };

            yield return new object[]
            {
                "4a1f51c5-e902-4efb-8366-816e29e78503",
                (HttpStatusCode) 503,
                "{\"fieldErrors\":{},\"status\":503,\"message\":null}"
            };
        }

        [Theory]
        [MemberData(nameof(DeactivateData))]
        public async Task PostDeactivateSubscription_ResponseExpectedStatusCode(string customerId, HttpStatusCode expectedStatusCode, string expectedServiceResponseJsonStr)
        {
            const string endPoint = "/internal/creditlock/deactivate";

            var actualServiceResponse = await CommonIntegrationFunctions.PostRequest(endPoint, customerId, _hostBuilder);

            actualServiceResponse.StatusCode.Should().Be(expectedStatusCode);

            if (expectedServiceResponseJsonStr != null)
            {
                var actualServiceResponseJsonStr = await actualServiceResponse.Content.ReadAsStringAsync();

                JToken.DeepEquals(JObject.Parse(actualServiceResponseJsonStr),
                    JObject.Parse(expectedServiceResponseJsonStr)).Should().BeTrue();
            }
        }
    }
}