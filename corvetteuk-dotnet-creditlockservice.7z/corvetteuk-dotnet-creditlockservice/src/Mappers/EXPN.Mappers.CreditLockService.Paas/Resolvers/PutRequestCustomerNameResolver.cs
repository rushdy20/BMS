﻿using AutoMapper;
using EXPN.Mappers.CreditLockService.Paas.Extensions;
using EXPN.Models.CreditLockService.Internal.Get.Response;
using EXPN.Models.CreditLockService.Paas;
using System.Collections.Generic;

namespace EXPN.Mappers.CreditLockService.Paas.Resolvers
{
    public class PutRequestCustomerNameResolver : IMemberValueResolver<object, object, GetResponsePaasCustomerName, CustomerName>
    {
        private readonly IEnumerable<string> _exclusionList = new List<string> { "Title" };

        public CustomerName Resolve(
            object source,
            object destination,
            GetResponsePaasCustomerName sourceMember,
            CustomerName destMember,
            ResolutionContext context)
        {
            if (sourceMember == null)
                return null;

            if (destMember == null)
                return null;

            return ExtensionMethods.AreMatchingStringPropertiesSame(sourceMember, destMember, _exclusionList) ? null : destMember;
        }
    }
}