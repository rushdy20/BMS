﻿using EXPN.Models.CreditLockService.Paas.Get.Response;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace EXPN.IntegrationTest.CreditLockService.Utility
{
    [ExcludeFromCodeCoverage]
    public class MockPaasHttpClientHandler : DelegatingHandler
    {
        private int RetryCount;

        private readonly HttpResponseMessage _mockResponse;
        private readonly HttpResponseMessage _mockAddressNotPinnedResponse;
        private readonly HttpResponseMessage _mockResponseDeactivate;
        private readonly HttpResponseMessage _mockNoContent;
        private readonly HttpResponseMessage _mockReturnNotFound;
        private readonly HttpResponseMessage _mockReturnDownstreamMaintenanceStatusCode;
        private readonly HttpResponseMessage _mockServiceDown;
        private readonly HttpResponseMessage _mockDownstreamAuthorisationFailed;

        private readonly PaasResponseData _mockGetCustomerTest_1;
        private readonly PaasResponseData _mockGetCustomerTest_2;
        private readonly PaasResponseData _mockGetCustomerTest_3;
        private readonly PaasResponseData _mockGetCustomerTest_4;
        private readonly PaasResponseData _mockGetCustomerTest_5;
        private readonly PaasResponseData _mockGetCustomerTest_6;
        private readonly PaasResponseData _mockGetCustomerTest_7;
        private readonly PaasResponseData _mockGetCustomerTest_8;
        private readonly PaasResponseData _mockGetCustomerTest_9;
        private readonly PaasResponseData _mockGetCustomerTest_10;
        private readonly PaasResponseData _mockGetCustomerForOff_Pinning_ProblemTest_1;
        private readonly PaasResponseData _mockGetCustomerForOff_Pinning_ProblemTest_2;
        private readonly PaasResponseData _mockGetCustomerForOff_Pinning_ProblemTest_3;
        private readonly PaasResponseData _mockGetCustomerForOff_Pinning_ProblemTest_4;
        private readonly PaasResponseData _mockGetCustomerForOff_Pinning_ProblemTest_5;
        private readonly PaasResponseData _mockGetCustomerForOff_Pinning_ProblemTest_6;
        private readonly PaasResponseData _mockGetCustomerForOff_Pinning_ProblemTest_7;
        private readonly PaasResponseData _mockGetCustomerForOff_Pin_UpdatingTest_1;
        private readonly PaasResponseData _mockGetCustomerForOff_Pin_UpdatingTest_2;
        private readonly PaasResponseData _mockGetCustomerForOff_Pin_UpdatingTest_3;
        private readonly PaasResponseData _mockGetCustomerForOff_Pin_UpdatingTest_4;
        private readonly PaasResponseData _mockGetCustomerForOff_Pin_UpdatingTest_5;
        private readonly PaasResponseData _mockGetCustomerForOff_Pin_UpdatingTest_6;
        private readonly PaasResponseData _mockGetCustomerForOff_Pin_UpdatingTest_7;
        private readonly PaasResponseData _mockGetCustomerForON_LockStatusTest0;
        private readonly PaasResponseData _mockGetCustomerForON_LockStatusTest1;
        private readonly PaasResponseData _mockGetCustomerForON_LockStatusTest2;
        private readonly PaasResponseData _mockGetCustomerForON_LockStatusTest3;
        private readonly PaasResponseData _mockGetCustomerForON_LockStatusTest4;
        private readonly PaasResponseData _mockGetCustomerForON_LockStatusTest5;
        private readonly PaasResponseData _mockGetCustomerForON_LockStatusTest6;
        private readonly PaasResponseData _mockGetCustomerForON_LockStatusTest7;
        private readonly PaasResponseData _mockGetCustomerForOn_Pinning_ProblemTest_1;
        private readonly PaasResponseData _mockGetCustomerForOn_Pinning_ProblemTest_2;
        private readonly PaasResponseData _mockGetCustomerForOn_Pinning_ProblemTest_3;
        private readonly PaasResponseData _mockGetCustomerForOn_Pinning_ProblemTest_4;
        private readonly PaasResponseData _mockGetCustomerForOn_Pinning_ProblemTest_5;
        private readonly PaasResponseData _mockGetCustomerForOn_Pinning_ProblemTest_6;
        private readonly PaasResponseData _mockGetCustomerForOn_And_UpdatingTest_1;
        private readonly PaasResponseData _mockGetCustomerForOn_And_UpdatingTest_2;
        private readonly PaasResponseData _mockGetCustomerForOn_And_UpdatingTest_3;
        private readonly PaasResponseData _mockGetCustomerForOn_And_UpdatingTest_4;
        private readonly PaasResponseData _mockGetCustomerForOn_And_UpdatingTest_5;
        private readonly PaasResponseData _mockGetCustomerForOn_And_UpdatingTest_6;

        public MockPaasHttpClientHandler()
        {
            var getCustomerResponse = new PaasResponseData
            {
                Data = new List<GetCustomerResponse>
                {
                    new GetCustomerResponse
                    {
                        CustomerId = "Customer IDs are opaque",
                        AlertsStatus = "Y",
                        ClientId = "ECS",
                        DateOfBirth = new DateTime(1990, 12, 31),
                        LockStatus = "Y",
                        Name = new PaasCustomerName
                        {
                            Forename = "Howard",
                            Title = "Lord",
                            Surname = "Lovecraft",
                            MiddleName = "Phillips",
                            Suffix = "Jnr"
                        },
                        Addresses = new[]
                        {
                            new AddressResponse
                            {
                                County = "Homeshire",
                                Din = "202100011234567891",
                                HouseNumber = "42",
                                PinErrorCode = "",
                                PinStatus = "3",
                                Postcode = "AB1 23X",
                                Street = "Green Lane",
                                Town = "Bigton"
                            }
                        }
                    }
                }
            };

            var getCustomerAddressNotPinnedResponse = new PaasResponseData
            {
                Data = new List<GetCustomerResponse>
                {
                    new GetCustomerResponse
                    {
                        CustomerId = "Customer IDs are opaque",
                        AlertsStatus = "Y",
                        ClientId = "ECS",
                        DateOfBirth = new DateTime(1990, 12, 31),
                        LockStatus = "Y",
                        Name = new PaasCustomerName
                        {
                            Forename = "Howard",
                            Title = "Lord",
                            Surname = "Lovecraft",
                            MiddleName = "Phillips",
                            Suffix = "Jnr"
                        },
                        Addresses = new[]
                        {
                            new AddressResponse
                            {
                                County = "Homeshire",
                                Din = "202100011234567891",
                                HouseNumber = "42",
                                PinErrorCode = "",
                                PinStatus = "0",
                                Postcode = "AB1 23X",
                                Street = "Green Lane",
                                Town = "Bigton"
                            }
                        }
                    }
                }
            };

            var getCustomerResponse_DeactivateInstantAlert = new PaasResponseData
            {
                Data = new List<GetCustomerResponse>
                {
                    new GetCustomerResponse
                    {
                        CustomerId = "Customer IDs are opaque",
                        AlertsStatus = "Y",
                        ClientId = "ECS",
                        DateOfBirth = new DateTime(1990, 12, 31),
                        LockStatus = "N",
                        Name = new PaasCustomerName
                        {
                            Forename = "Howard",
                            Title = "Lord",
                            Surname = "Lovecraft",
                            MiddleName = "Phillips",
                            Suffix = "Jnr"
                        },
                        Addresses = new[]
                        {
                            new AddressResponse
                            {
                                County = "Homeshire",
                                Din = "202100011234567891",
                                HouseNumber = "42",
                                PinErrorCode = "",
                                PinStatus = "3",
                                Postcode = "AB1 23X",
                                Street = "Green Lane",
                                Town = "Bigton"
                            }
                        }
                    }
                }
            };

            _mockAddressNotPinnedResponse = new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.OK,
                Content = new StringContent(JsonConvert.SerializeObject(getCustomerAddressNotPinnedResponse), Encoding.UTF8, "application/json")
            };

            _mockNoContent = new HttpResponseMessage
            {
                StatusCode = (HttpStatusCode)204,
                Content = new StringContent(JsonConvert.SerializeObject(string.Empty), Encoding.UTF8, "application/json")
            };

            _mockResponse = new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.OK,
                Content = new StringContent(JsonConvert.SerializeObject(getCustomerResponse), Encoding.UTF8, "application/json")
            };

            _mockResponseDeactivate = new HttpResponseMessage
            {
                StatusCode = (HttpStatusCode)204,
                Content = new StringContent(JsonConvert.SerializeObject(getCustomerResponse_DeactivateInstantAlert), Encoding.UTF8, "application/json")
            };

            _mockReturnNotFound = new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.NotFound,
                Content = new StringContent(JsonConvert.SerializeObject(string.Empty), Encoding.UTF8, "application/json")
            };

            _mockDownstreamAuthorisationFailed = new HttpResponseMessage
            {
                StatusCode = (HttpStatusCode)563,
                Content = new StringContent(JsonConvert.SerializeObject(string.Empty), Encoding.UTF8, "application/json")
            };

            _mockReturnDownstreamMaintenanceStatusCode = new HttpResponseMessage
            {
                StatusCode = (HttpStatusCode)561,
                Content = new StringContent(JsonConvert.SerializeObject(string.Empty), Encoding.UTF8, "application/json")
            };

            _mockServiceDown = new HttpResponseMessage
            {
                StatusCode = (HttpStatusCode)503,
                Content = new StringContent(JsonConvert.SerializeObject(string.Empty), Encoding.UTF8, "application/json")
            };

            _mockGetCustomerTest_1 = new PaasResponseData
            {
                Data = new List<GetCustomerResponse>
                {
                    new GetCustomerResponse
                    {
                        LockStatus = "N",
                        Addresses = new[]
                        {
                            new AddressResponse
                            {
                                PinStatus = "3"
                            }
                        }
                    }
                }
            };

            _mockGetCustomerTest_2 = new PaasResponseData
            {
                Data = new List<GetCustomerResponse>
                {
                    new GetCustomerResponse
                    {
                        LockStatus = "N",
                        Addresses = new[]
                        {
                            new AddressResponse
                            {
                                PinStatus = "3"
                            },
                            new AddressResponse
                            {
                                PinStatus = "3"
                            }
                        }
                    }
                }
            };

            _mockGetCustomerTest_3 = new PaasResponseData
            {
                Data = new List<GetCustomerResponse>
                {
                    new GetCustomerResponse
                    {
                        LockStatus = "N",
                        Addresses = new[]
                        {
                            new AddressResponse
                            {
                                PinStatus = "3"
                            },
                            new AddressResponse
                            {
                                PinStatus = "3"
                            },
                            new AddressResponse
                            {
                                PinStatus = "3"
                            }
                        }
                    }
                }
            };

            _mockGetCustomerTest_4 = new PaasResponseData
            {
                Data = new List<GetCustomerResponse>
                {
                    new GetCustomerResponse
                    {
                        LockStatus = "N",
                        Addresses = new[]
                        {
                            new AddressResponse
                            {
                                PinStatus = "4"
                            }
                        }
                    }
                }
            };

            _mockGetCustomerTest_5 = new PaasResponseData
            {
                Data = new List<GetCustomerResponse>
                {
                    new GetCustomerResponse
                    {
                        LockStatus = "N",
                        Addresses = new[]
                        {
                            new AddressResponse
                            {
                                PinStatus = "4"
                            },
                            new AddressResponse
                            {
                                PinStatus = "4"
                            }
                        }
                    }
                }
            };

            _mockGetCustomerTest_6 = new PaasResponseData
            {
                Data = new List<GetCustomerResponse>
                {
                    new GetCustomerResponse
                    {
                        LockStatus = "N",
                        Addresses = new[]
                        {
                            new AddressResponse
                            {
                                PinStatus = "4"
                            },
                            new AddressResponse
                            {
                                PinStatus = "4"
                            },
                            new AddressResponse
                            {
                                PinStatus = "4"
                            }
                        }
                    }
                }
            };

            _mockGetCustomerTest_7 = new PaasResponseData
            {
                Data = new List<GetCustomerResponse>
                {
                    new GetCustomerResponse
                    {
                        LockStatus = "N",
                        Addresses = new[]
                        {
                            new AddressResponse
                            {
                                PinStatus = "4"
                            },
                            new AddressResponse
                            {
                                PinStatus = "4"
                            },
                            new AddressResponse
                            {
                                PinStatus = "4"
                            },
                            new AddressResponse
                            {
                                PinStatus = "3"
                            },
                            new AddressResponse
                            {
                                PinStatus = "3"
                            },
                            new AddressResponse
                            {
                                PinStatus = "3"
                            }
                        }
                    }
                }
            };

            _mockGetCustomerTest_8 = new PaasResponseData
            {
                Data = new List<GetCustomerResponse>
                {
                    new GetCustomerResponse
                    {
                        LockStatus = "N",
                        Addresses = new[]
                        {
                            new AddressResponse
                            {
                                PinStatus = "4"
                            },
                            new AddressResponse
                            {
                                PinStatus = "4"
                            },
                            new AddressResponse
                            {
                                PinStatus = "4"
                            },
                            new AddressResponse
                            {
                                PinStatus = "3"
                            },
                            new AddressResponse
                            {
                                PinStatus = "3"
                            },
                            new AddressResponse
                            {
                                PinStatus = "3"
                            }
                        }
                    }
                }
            };

            _mockGetCustomerTest_9 = new PaasResponseData
            {
                Data = new List<GetCustomerResponse>
                {
                    new GetCustomerResponse
                    {
                        LockStatus = "N",
                        Addresses = new[]
                        {
                            new AddressResponse
                            {
                                PinStatus = "1"
                            },
                            new AddressResponse
                            {
                                PinStatus = "4"
                            },
                            new AddressResponse
                            {
                                PinStatus = "4"
                            },
                            new AddressResponse
                            {
                                PinStatus = "3"
                            },
                            new AddressResponse
                            {
                                PinStatus = "3"
                            },
                            new AddressResponse
                            {
                                PinStatus = "3"
                            }
                        }
                    }
                }
            };

            _mockGetCustomerTest_10 = new PaasResponseData
            {
                Data = new List<GetCustomerResponse>
                {
                    new GetCustomerResponse
                    {
                        LockStatus = "Y",
                        Addresses = new[]
                        {
                            new AddressResponse
                            {
                                PinStatus = "1"
                            },
                            new AddressResponse
                            {
                                PinStatus = "4"
                            },
                            new AddressResponse
                            {
                                PinStatus = "4"
                            },
                            new AddressResponse
                            {
                                PinStatus = "3"
                            },
                            new AddressResponse
                            {
                                PinStatus = "2"
                            },
                            new AddressResponse
                            {
                                PinStatus = "3"
                            }
                        }
                    }
                }
            };

            _mockGetCustomerForOff_Pinning_ProblemTest_1 = new PaasResponseData
            {
                Data = new List<GetCustomerResponse>
                {
                    new GetCustomerResponse
                    {
                        LockStatus = "N",
                        Addresses = new[]
                        {
                            new AddressResponse
                            {
                                PinStatus = "D"
                            },
                            new AddressResponse
                            {
                                PinStatus = "3"
                            }
                        }
                    }
                }
            };

            _mockGetCustomerForOff_Pinning_ProblemTest_2 = new PaasResponseData
            {
                Data = new List<GetCustomerResponse>
                {
                    new GetCustomerResponse
                    {
                        LockStatus = "N",
                        Addresses = new[]
                        {
                            new AddressResponse
                            {
                                PinStatus = "E"
                            },
                            new AddressResponse
                            {
                                PinStatus = "3"
                            }
                        }
                    }
                }
            };

            _mockGetCustomerForOff_Pinning_ProblemTest_3 = new PaasResponseData
            {
                Data = new List<GetCustomerResponse>
                {
                    new GetCustomerResponse
                    {
                        LockStatus = "N",
                        Addresses = new[]
                        {
                            new AddressResponse
                            {
                                PinStatus = "P"
                            },
                            new AddressResponse
                            {
                                PinStatus = "3"
                            }
                        }
                    }
                }
            };

            _mockGetCustomerForOff_Pinning_ProblemTest_4 = new PaasResponseData
            {
                Data = new List<GetCustomerResponse>
                {
                    new GetCustomerResponse
                    {
                        LockStatus = "N",
                        Addresses = new[]
                        {
                            new AddressResponse
                            {
                                PinStatus = "D"
                            },
                            new AddressResponse
                            {
                                PinStatus = "D"
                            }
                        }
                    }
                }
            };

            _mockGetCustomerForOff_Pinning_ProblemTest_5 = new PaasResponseData
            {
                Data = new List<GetCustomerResponse>
                {
                    new GetCustomerResponse
                    {
                        LockStatus = "N",
                        Addresses = new[]
                        {
                            new AddressResponse
                            {
                                PinStatus = "E"
                            },
                            new AddressResponse
                            {
                                PinStatus = "P"
                            }
                        }
                    }
                }
            };

            _mockGetCustomerForOff_Pinning_ProblemTest_6 = new PaasResponseData
            {
                Data = new List<GetCustomerResponse>
                {
                    new GetCustomerResponse
                    {
                        LockStatus = "N",
                        Addresses = new[]
                        {
                            new AddressResponse
                            {
                                PinStatus = "E"
                            },
                            new AddressResponse
                            {
                                PinStatus = "P"
                            }
                        }
                    }
                }
            };

            _mockGetCustomerForOff_Pinning_ProblemTest_7 = new PaasResponseData
            {
                Data = new List<GetCustomerResponse>
                {
                    new GetCustomerResponse
                    {
                        LockStatus = "N",
                        Addresses = new[]
                        {
                            new AddressResponse
                            {
                                PinStatus = "D"
                            },
                            new AddressResponse
                            {
                                PinStatus = "D"
                            },
                            new AddressResponse
                            {
                                PinStatus = "E"
                            },
                            new AddressResponse
                            {
                                PinStatus = "E"
                            },
                            new AddressResponse
                            {
                                PinStatus = "E"
                            },
                            new AddressResponse
                            {
                                PinStatus = "P"
                            }
                        }
                    }
                }
            };

            _mockGetCustomerForOff_Pin_UpdatingTest_1 = new PaasResponseData
            {
                Data = new List<GetCustomerResponse>
                {
                    new GetCustomerResponse
                    {
                        LockStatus = "N",
                        Addresses = new[]
                        {
                            new AddressResponse
                            {
                                PinStatus = "N"
                            }
                        }
                    }
                }
            };

            _mockGetCustomerForOff_Pin_UpdatingTest_2 = new PaasResponseData
            {
                Data = new List<GetCustomerResponse>
                {
                    new GetCustomerResponse
                    {
                        LockStatus = "N",
                        Addresses = new[]
                        {
                            new AddressResponse
                            {
                                PinStatus = "N"
                            }
                        }
                    }
                }
            };

            _mockGetCustomerForOff_Pin_UpdatingTest_3 = new PaasResponseData
            {
                Data = new List<GetCustomerResponse>
                {
                    new GetCustomerResponse
                    {
                        LockStatus = "N",
                        Addresses = new[]
                        {
                            new AddressResponse
                            {
                                PinStatus = "1"
                            }
                        }
                    }
                }
            };

            _mockGetCustomerForOff_Pin_UpdatingTest_4 = new PaasResponseData
            {
                Data = new List<GetCustomerResponse>
                {
                    new GetCustomerResponse
                    {
                        LockStatus = "N",
                        Addresses = new[]
                        {
                            new AddressResponse
                            {
                                PinStatus = "2"
                            },
                            new AddressResponse
                            {
                                PinStatus = "N"
                            }
                        }
                    }
                }
            };

            _mockGetCustomerForOff_Pin_UpdatingTest_5 = new PaasResponseData
            {
                Data = new List<GetCustomerResponse>
                {
                    new GetCustomerResponse
                    {
                        LockStatus = "N",
                        Addresses = new[]
                        {
                            new AddressResponse
                            {
                                PinStatus = "N"
                            },
                            new AddressResponse
                            {
                                PinStatus = "1"
                            }
                        }
                    }
                }
            };

            _mockGetCustomerForOff_Pin_UpdatingTest_6 = new PaasResponseData
            {
                Data = new List<GetCustomerResponse>
                {
                    new GetCustomerResponse
                    {
                        LockStatus = "N",
                        Addresses = new[]
                        {
                            new AddressResponse
                            {
                                PinStatus = "N"
                            },
                            new AddressResponse
                            {
                                PinStatus = "1"
                            },
                            new AddressResponse
                            {
                                PinStatus = "2"
                            },
                            new AddressResponse
                            {
                                PinStatus = "3"
                            }
                        }
                    }
                }
            };

            _mockGetCustomerForOff_Pin_UpdatingTest_7 = new PaasResponseData
            {
                Data = new List<GetCustomerResponse>
                {
                    new GetCustomerResponse
                    {
                        LockStatus = "N",
                        Addresses = new[]
                        {
                            new AddressResponse
                            {
                                PinStatus = "1"
                            },
                            new AddressResponse
                            {
                                PinStatus = "3"
                            },
                            new AddressResponse
                            {
                                PinStatus = "4"
                            },
                            new AddressResponse
                            {
                                PinStatus = "4"
                            },
                            new AddressResponse
                            {
                                PinStatus = "4"
                            },
                            new AddressResponse
                            {
                                PinStatus = "3"
                            }
                        }
                    }
                }
            };

            _mockGetCustomerForON_LockStatusTest0 = new PaasResponseData
            {
                Data = new List<GetCustomerResponse>
                {
                    new GetCustomerResponse
                    {
                        LockStatus = "Y",
                        Addresses = new[]
                        {
                            new AddressResponse
                            {
                                PinStatus = "3"
                            }
                        }
                    }
                }
            };

            _mockGetCustomerForON_LockStatusTest1 = new PaasResponseData
            {
                Data = new List<GetCustomerResponse>
                {
                    new GetCustomerResponse
                    {
                        LockStatus = "Y",
                        Addresses = new[]
                        {
                            new AddressResponse
                            {
                                PinStatus = "3"
                            },
                            new AddressResponse
                            {
                                PinStatus = "3"
                            }
                        }
                    }
                }
            };

            _mockGetCustomerForON_LockStatusTest2 = new PaasResponseData
            {
                Data = new List<GetCustomerResponse>
                {
                    new GetCustomerResponse
                    {
                        LockStatus = "Y",
                        Addresses = new[]
                        {
                            new AddressResponse
                            {
                                PinStatus = "3"
                            },
                            new AddressResponse
                            {
                                PinStatus = "3"
                            },
                            new AddressResponse
                            {
                                PinStatus = "3"
                            }
                        }
                    }
                }
            };

            _mockGetCustomerForON_LockStatusTest3 = new PaasResponseData
            {
                Data = new List<GetCustomerResponse>
                {
                    new GetCustomerResponse
                    {
                        LockStatus = "Y",
                        Addresses = new[]
                        {
                            new AddressResponse
                            {
                                PinStatus = "4"
                            }
                        }
                    }
                }
            };

            _mockGetCustomerForON_LockStatusTest4 = new PaasResponseData
            {
                Data = new List<GetCustomerResponse>
                {
                    new GetCustomerResponse
                    {
                        LockStatus = "Y",
                        Addresses = new[]
                        {
                            new AddressResponse
                            {
                                PinStatus = "4"
                            },
                            new AddressResponse
                            {
                                PinStatus = "4"
                            }
                        }
                    }
                }
            };

            _mockGetCustomerForON_LockStatusTest5 = new PaasResponseData
            {
                Data = new List<GetCustomerResponse>
                {
                    new GetCustomerResponse
                    {
                        LockStatus = "Y",
                        Addresses = new[]
                        {
                            new AddressResponse
                            {
                                PinStatus = "4"
                            },
                            new AddressResponse
                            {
                                PinStatus = "4"
                            },
                            new AddressResponse
                            {
                                PinStatus = "4"
                            }
                        }
                    }
                }
            };

            _mockGetCustomerForON_LockStatusTest6 = new PaasResponseData
            {
                Data = new List<GetCustomerResponse>
                {
                    new GetCustomerResponse
                    {
                        LockStatus = "Y",
                        Addresses = new[]
                        {
                            new AddressResponse
                            {
                                PinStatus = "4"
                            },
                            new AddressResponse
                            {
                                PinStatus = "4"
                            },
                            new AddressResponse
                            {
                                PinStatus = "4"
                            },
                            new AddressResponse
                            {
                                PinStatus = "3"
                            },
                            new AddressResponse
                            {
                                PinStatus = "3"
                            },
                            new AddressResponse
                            {
                                PinStatus = "3"
                            }
                        }
                    }
                }
            };

            _mockGetCustomerForON_LockStatusTest7 = new PaasResponseData
            {
                Data = new List<GetCustomerResponse>
                {
                    new GetCustomerResponse
                    {
                        LockStatus = "Y",
                        Addresses = new[]
                        {
                            new AddressResponse
                            {
                                PinStatus = "4"
                            },
                            new AddressResponse
                            {
                                PinStatus = "4"
                            },
                            new AddressResponse
                            {
                                PinStatus = "4"
                            },
                            new AddressResponse
                            {
                                PinStatus = "3"
                            },
                            new AddressResponse
                            {
                                PinStatus = "3"
                            },
                            new AddressResponse
                            {
                                PinStatus = "3"
                            }
                        }
                    }
                }
            };

            _mockGetCustomerForOn_Pinning_ProblemTest_1 = new PaasResponseData
            {
                Data = new List<GetCustomerResponse>
                {
                    new GetCustomerResponse
                    {
                        LockStatus = "Y",
                        Addresses = new[]
                        {
                            new AddressResponse
                            {
                                PinStatus = "D"
                            },
                            new AddressResponse
                            {
                                PinStatus = "4"
                            }
                        }
                    }
                }
            };

            _mockGetCustomerForOn_Pinning_ProblemTest_2 = new PaasResponseData
            {
                Data = new List<GetCustomerResponse>
                {
                    new GetCustomerResponse
                    {
                        LockStatus = "Y",
                        Addresses = new[]
                        {
                            new AddressResponse
                            {
                                PinStatus = "E"
                            },
                            new AddressResponse
                            {
                                PinStatus = "3"
                            }
                        }
                    }
                }
            };

            _mockGetCustomerForOn_Pinning_ProblemTest_3 = new PaasResponseData
            {
                Data = new List<GetCustomerResponse>
                {
                    new GetCustomerResponse
                    {
                        LockStatus = "Y",
                        Addresses = new[]
                        {
                            new AddressResponse
                            {
                                PinStatus = "P"
                            },
                            new AddressResponse
                            {
                                PinStatus = "3"
                            }
                        }
                    }
                }
            };

            _mockGetCustomerForOn_Pinning_ProblemTest_4 = new PaasResponseData
            {
                Data = new List<GetCustomerResponse>
                {
                    new GetCustomerResponse
                    {
                        LockStatus = "Y",
                        Addresses = new[]
                        {
                            new AddressResponse
                            {
                                PinStatus = "P"
                            },
                            new AddressResponse
                            {
                                PinStatus = "D"
                            }
                        }
                    }
                }
            };

            _mockGetCustomerForOn_Pinning_ProblemTest_5 = new PaasResponseData
            {
                Data = new List<GetCustomerResponse>
                {
                    new GetCustomerResponse
                    {
                        LockStatus = "Y",
                        Addresses = new[]
                        {
                            new AddressResponse
                            {
                                PinStatus = "1"
                            },
                            new AddressResponse
                            {
                                PinStatus = "D"
                            }
                        }
                    }
                }
            };

            _mockGetCustomerForOn_Pinning_ProblemTest_5 = new PaasResponseData
            {
                Data = new List<GetCustomerResponse>
                {
                    new GetCustomerResponse
                    {
                        LockStatus = "Y",
                        Addresses = new[]
                        {
                            new AddressResponse
                            {
                                PinStatus = "1"
                            },
                            new AddressResponse
                            {
                                PinStatus = "0"
                            },
                            new AddressResponse
                            {
                                PinStatus = "4"
                            },
                            new AddressResponse
                            {
                                PinStatus = "3"
                            },
                            new AddressResponse
                            {
                                PinStatus = "D"
                            }
                        }
                    }
                }
            };

            _mockGetCustomerForOn_Pinning_ProblemTest_6 = new PaasResponseData
            {
                Data = new List<GetCustomerResponse>
                {
                    new GetCustomerResponse
                    {
                        LockStatus = "Y",
                        Addresses = new[]
                        {
                            new AddressResponse
                            {
                                PinStatus = "1"
                            },
                            new AddressResponse
                            {
                                PinStatus = "0"
                            },
                            new AddressResponse
                            {
                                PinStatus = "4"
                            },
                            new AddressResponse
                            {
                                PinStatus = "E"
                            },
                            new AddressResponse
                            {
                                PinStatus = "P"
                            }
                        }
                    }
                }
            };

            _mockGetCustomerForOn_And_UpdatingTest_1 = new PaasResponseData
            {
                Data = new List<GetCustomerResponse>
                {
                    new GetCustomerResponse
                    {
                        LockStatus = "Y",
                        Addresses = new[]
                        {
                            new AddressResponse
                            {
                                PinStatus = "0"
                            }
                        }
                    }
                }
            };

            _mockGetCustomerForOn_And_UpdatingTest_2 = new PaasResponseData
            {
                Data = new List<GetCustomerResponse>
                {
                    new GetCustomerResponse
                    {
                        LockStatus = "Y",
                        Addresses = new[]
                        {
                            new AddressResponse
                            {
                                PinStatus = "1"
                            }
                        }
                    }
                }
            };

            _mockGetCustomerForOn_And_UpdatingTest_3 = new PaasResponseData
            {
                Data = new List<GetCustomerResponse>
                {
                    new GetCustomerResponse
                    {
                        LockStatus = "Y",
                        Addresses = new[]
                        {
                            new AddressResponse
                            {
                                PinStatus = "1"
                            },
                            new AddressResponse
                            {
                                PinStatus = "2"
                            },
                            new AddressResponse
                            {
                                PinStatus = "3"
                            }
                        }
                    }
                }
            };

            _mockGetCustomerForOn_And_UpdatingTest_4 = new PaasResponseData
            {
                Data = new List<GetCustomerResponse>
                {
                    new GetCustomerResponse
                    {
                        LockStatus = "Y",
                        Addresses = new[]
                        {
                            new AddressResponse
                            {
                                PinStatus = "1"
                            },
                            new AddressResponse
                            {
                                PinStatus = "2"
                            },
                            new AddressResponse
                            {
                                PinStatus = "N"
                            }
                        }
                    }
                }
            };

            _mockGetCustomerForOn_And_UpdatingTest_5 = new PaasResponseData
            {
                Data = new List<GetCustomerResponse>
                {
                    new GetCustomerResponse
                    {
                        LockStatus = "Z",
                        Addresses = new[]
                        {
                            new AddressResponse
                            {
                                PinStatus = "1"
                            },
                            new AddressResponse
                            {
                                PinStatus = "2"
                            },
                            new AddressResponse
                            {
                                PinStatus = "N"
                            }
                        }
                    }
                }
            };

            _mockGetCustomerForOn_And_UpdatingTest_6 = new PaasResponseData
            {
                Data = new List<GetCustomerResponse>
                {
                    new GetCustomerResponse
                    {
                        LockStatus = "Y",
                        Addresses = new[]
                        {
                            new AddressResponse
                            {
                                PinStatus = "1"
                            },
                            new AddressResponse
                            {
                                PinStatus = "2"
                            },
                            new AddressResponse
                            {
                                PinStatus = "Z"
                            }
                        }
                    }
                }
            };
        }

        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {

            if (request.RequestUri != null && request.RequestUri.AbsolutePath.Split("/").Length == 4)
            {
                return await Task.FromResult(GetMockResponse(request.RequestUri.AbsolutePath.Split("/")[3]));
            }

            var content = request.Content;
            var jsonContent = content?.ReadAsStringAsync(cancellationToken).Result;
            var jObject = JObject.Parse(jsonContent ?? string.Empty);

            jObject.TryGetValue("IconRef", StringComparison.OrdinalIgnoreCase, out var iconRef);

            if (request.RequestUri != null && request.RequestUri.AbsolutePath.Split("/")[1] == "customer" && request.Method == HttpMethod.Put)
            {
                return await Task.FromResult(GetCustomerMockResponse(iconRef?.ToString()));
            }

            return await Task.FromResult(GetMockResponse(iconRef?.ToString()));
        }

        private HttpResponseMessage GetMockResponse(string customerId)
        {
            switch (customerId)
            {
                case "12345404":
                    return _mockReturnNotFound;

                case "1234561":
                    return _mockReturnDownstreamMaintenanceStatusCode;
                case "1234503":
                    return _mockServiceDown;
                case "9992000":
                    return _mockDownstreamAuthorisationFailed;
                case "1234501":
                case "1234502":
                case "1234513":
                case "1234504":
                case "1234505":
                case "1234506":
                case "1234507":
                case "1234508":
                case "1234509":
                case "1234510":
                case "1234601":
                case "1234602":
                case "1234603":
                case "1234604":
                case "1234605":
                case "1234606":
                case "1234607":
                case "1234701":
                case "1234702":
                case "1234703":
                case "1234704":
                case "1234705":
                case "1234706":
                case "1234707":
                case "2234700":
                case "2234701":
                case "2234702":
                case "2234703":
                case "2234704":
                case "2234705":
                case "2234706":
                case "2234707":
                case "3234701":
                case "3234702":
                case "3234703":
                case "3234704":
                case "3234705":
                case "3234706":
                case "4234701":
                case "4234702":
                case "4234703":
                case "4234704":
                case "4234705":
                case "4234706":
                    return GetCustomerMockResponse(customerId);
                case "6234701":
                    return _mockNoContent;
                case "9999999":
                    return _mockResponse;
                case "1000022":
                    return _mockResponseDeactivate;
                case "9999199":
                    return _mockAddressNotPinnedResponse;
                case "6000001":
                {
                    if (RetryCount < 3)
                        return _mockResponse;

                    RetryCount++;
                    throw new HttpRequestException("Test Message", new IOException("Base Message"));
                }
                default:
                    return _mockResponse;
            }
        }

        private HttpResponseMessage GetCustomerMockResponse(string IconRef)
        {
            switch (IconRef)
            {
                case "1234501":
                    return GetHttpResponseMessage(_mockGetCustomerTest_1);
                case "1234502":
                    return GetHttpResponseMessage(_mockGetCustomerTest_2);
                case "1234513":
                    return GetHttpResponseMessage(_mockGetCustomerTest_3);
                case "1234504":
                    return GetHttpResponseMessage(_mockGetCustomerTest_4);
                case "1234505":
                    return GetHttpResponseMessage(_mockGetCustomerTest_5);
                case "1234506":
                    return GetHttpResponseMessage(_mockGetCustomerTest_6);
                case "1234507":
                    return GetHttpResponseMessage(_mockGetCustomerTest_7);
                case "1234508":
                    return GetHttpResponseMessage(_mockGetCustomerTest_8);
                case "1234509":
                    return GetHttpResponseMessage(_mockGetCustomerTest_9);
                case "1234510":
                    return GetHttpResponseMessage(_mockGetCustomerTest_10);
                case "1234601":
                    return GetHttpResponseMessage(_mockGetCustomerForOff_Pinning_ProblemTest_1);
                case "1234602":
                    return GetHttpResponseMessage(_mockGetCustomerForOff_Pinning_ProblemTest_2);
                case "1234603":
                    return GetHttpResponseMessage(_mockGetCustomerForOff_Pinning_ProblemTest_3);
                case "1234604":
                    return GetHttpResponseMessage(_mockGetCustomerForOff_Pinning_ProblemTest_4);
                case "1234605":
                    return GetHttpResponseMessage(_mockGetCustomerForOff_Pinning_ProblemTest_5);
                case "1234606":
                    return GetHttpResponseMessage(_mockGetCustomerForOff_Pinning_ProblemTest_6);
                case "1234607":
                    return GetHttpResponseMessage(_mockGetCustomerForOff_Pinning_ProblemTest_7);
                case "1234701":
                    return GetHttpResponseMessage(_mockGetCustomerForOff_Pin_UpdatingTest_1);
                case "1234702":
                    return GetHttpResponseMessage(_mockGetCustomerForOff_Pin_UpdatingTest_2);
                case "1234703":
                    return GetHttpResponseMessage(_mockGetCustomerForOff_Pin_UpdatingTest_3);
                case "1234704":
                    return GetHttpResponseMessage(_mockGetCustomerForOff_Pin_UpdatingTest_4);
                case "1234705":
                    return GetHttpResponseMessage(_mockGetCustomerForOff_Pin_UpdatingTest_5);
                case "1234706":
                    return GetHttpResponseMessage(_mockGetCustomerForOff_Pin_UpdatingTest_6);
                case "1234707":
                    return GetHttpResponseMessage(_mockGetCustomerForOff_Pin_UpdatingTest_7);
                case "2234700":
                    return GetHttpResponseMessage(_mockGetCustomerForON_LockStatusTest0);
                case "2234701":
                    return GetHttpResponseMessage(_mockGetCustomerForON_LockStatusTest1);
                case "2234702":
                    return GetHttpResponseMessage(_mockGetCustomerForON_LockStatusTest2);
                case "2234703":
                    return GetHttpResponseMessage(_mockGetCustomerForON_LockStatusTest3);
                case "2234704":
                    return GetHttpResponseMessage(_mockGetCustomerForON_LockStatusTest4);
                case "2234705":
                    return GetHttpResponseMessage(_mockGetCustomerForON_LockStatusTest5);
                case "2234706":
                    return GetHttpResponseMessage(_mockGetCustomerForON_LockStatusTest6);
                case "2234707":
                    return GetHttpResponseMessage(_mockGetCustomerForON_LockStatusTest7);
                case "3234701":
                    return GetHttpResponseMessage(_mockGetCustomerForOn_Pinning_ProblemTest_1);
                case "3234702":
                    return GetHttpResponseMessage(_mockGetCustomerForOn_Pinning_ProblemTest_2);
                case "3234703":
                    return GetHttpResponseMessage(_mockGetCustomerForOn_Pinning_ProblemTest_3);
                case "3234704":
                    return GetHttpResponseMessage(_mockGetCustomerForOn_Pinning_ProblemTest_4);
                case "3234705":
                    return GetHttpResponseMessage(_mockGetCustomerForOn_Pinning_ProblemTest_5);
                case "3234706":
                    return GetHttpResponseMessage(_mockGetCustomerForOn_Pinning_ProblemTest_6);
                case "4234701":
                    return GetHttpResponseMessage(_mockGetCustomerForOn_And_UpdatingTest_1);
                case "4234702":
                    return GetHttpResponseMessage(_mockGetCustomerForOn_And_UpdatingTest_2);
                case "4234703":
                    return GetHttpResponseMessage(_mockGetCustomerForOn_And_UpdatingTest_3);
                case "4234704":
                    return GetHttpResponseMessage(_mockGetCustomerForOn_And_UpdatingTest_4);
                case "4234705":
                    return GetHttpResponseMessage(_mockGetCustomerForOn_And_UpdatingTest_5);
                case "4234706":
                    return GetHttpResponseMessage(_mockGetCustomerForOn_And_UpdatingTest_6);
                case "9999999":
                case "1000022":
                case "9999199":
                    return UpdateCustomerHttpResponseMessage();
                default:
                    return _mockResponse;
            }
        }

        private HttpResponseMessage GetHttpResponseMessage(PaasResponseData paasResponseData)
        {
            return new HttpResponseMessage
            {
                StatusCode = (HttpStatusCode)200,
                Content = new StringContent(JsonConvert.SerializeObject(paasResponseData), Encoding.UTF8, "application/json")
            };
        }

        private HttpResponseMessage UpdateCustomerHttpResponseMessage()
        {
            return new HttpResponseMessage
            {
                StatusCode = (HttpStatusCode)204
            };
        }
    }
}