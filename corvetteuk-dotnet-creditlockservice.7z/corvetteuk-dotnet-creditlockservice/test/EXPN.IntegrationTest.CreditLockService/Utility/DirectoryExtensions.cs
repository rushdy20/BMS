using System;
using System.IO;

namespace EXPN.IntegrationTest.CreditLockService.Utility
{
    public static class DirectoryExtensions
    {
        public static string GetAncestor(this string path, Func<string, bool> targetPredicate)
        {
            return targetPredicate(path) ? path : GetAncestor(Directory.GetParent(path).FullName, targetPredicate);
        }
    }
}