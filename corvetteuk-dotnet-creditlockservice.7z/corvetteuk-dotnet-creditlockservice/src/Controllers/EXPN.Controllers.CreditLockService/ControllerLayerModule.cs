﻿using EXPN.Controllers.CreditLockService.DateTime;
using Microsoft.Extensions.DependencyInjection;
using System.Diagnostics.CodeAnalysis;

namespace EXPN.Controllers.CreditLockService
{
    [ExcludeFromCodeCoverage]
    public static class ControllerLayerModule
    {
        public static IServiceCollection AddControllerLayerModule(this IServiceCollection services)
        {
            services
                .AddScoped<IDateTime, UtcDateTime>();

            return services;
        }
    }
}