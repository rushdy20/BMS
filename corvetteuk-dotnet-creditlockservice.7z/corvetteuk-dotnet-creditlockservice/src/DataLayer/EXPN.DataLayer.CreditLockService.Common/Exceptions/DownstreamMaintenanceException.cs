﻿using System;
using System.Runtime.Serialization;

namespace EXPN.DataLayer.CreditLockService.Common.Exceptions
{
    [Serializable]
    public class DownstreamMaintenanceException : Exception
    {
        protected DownstreamMaintenanceException(SerializationInfo info, StreamingContext context)
          : base(info, context)
        {
        }
        public DownstreamMaintenanceException()
        {
        }
        public DownstreamMaintenanceException(string message)
            : base(message)
        {
        }
        public DownstreamMaintenanceException(string message, Exception innerException)
          : base(message, innerException)
        {
        }
    }
}