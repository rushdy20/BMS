﻿using System.Linq;
using EXPN.Models.CreditLockService.Internal.Get.Response;
using EXPN.Models.CreditLockService.Paas.Put.Request;

namespace EXPN.BusinessLayer.CreditLockService.Extension
{
  public static  class SyncCustomerExtenstion
    {
        public static bool IsChanged(this PutCustomerRequest putCustomerRequest)
        {
            return  putCustomerRequest.Name?.FirstName != null || putCustomerRequest.Name?.LastName != null ||
                             putCustomerRequest.Name?.OtherName != null || putCustomerRequest.Name?.Title != null
                             || putCustomerRequest.Name?.Suffix != null || putCustomerRequest.Dob != null ||
                             putCustomerRequest.AddressesToAdd?.Any() == true || 
                             putCustomerRequest.AddressesToDelete?.Any() == true;
        }

        public static bool IsPinning(this GetCustomerResponse getCustomerResponse)
        {
            if (getCustomerResponse.Addresses == null)
                return false;

            return getCustomerResponse.Addresses.Any() && 
                   getCustomerResponse.Addresses.Any(address => address.PinStatus == "0" || 
                                                                address.PinStatus == "1" || 
                                                                address.PinStatus == "2" || 
                                                                address.PinStatus == "N");
        }
    }
}