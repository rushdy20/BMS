﻿using System.Diagnostics.CodeAnalysis;
using AutoMapper;
using ExternalModel = EXPN.Models.CreditLockService.External.Delete.Request;
using InternalModel = EXPN.Models.CreditLockService.Internal.Delete.Request;

namespace EXPN.Mappers.CreditLockService.Internal
{
    [ExcludeFromCodeCoverage]
    public class DeleteCustomerToDeleteCustomerProfile : Profile
    {
        public DeleteCustomerToDeleteCustomerProfile()
        {
            CreateMap<ExternalModel.DeleteCustomerRequest, InternalModel.DeleteCustomerRequest>()
                 .ForMember(d => d.CustomerId, m => m.MapFrom(s => s.CustomerId))
                 .ForMember(d => d.IdpRefId, m => m.MapFrom(s => s.Body.IdpRefId))
                 .ForMember(d => d.TenantId, m => m.MapFrom(s => s.Body.TenantId))
                 .ForMember(d => d.CustomerNumber, m => m.MapFrom(s => s.Body.CustomerNumber));
        }
    }
}