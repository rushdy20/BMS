﻿using System;
using System.Runtime.Serialization;

namespace EXPN.DataLayer.CreditLockService.Common.Exceptions
{
    [Serializable]
    public class CustomerPutRequestException : Exception
    {
        protected CustomerPutRequestException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }

        public CustomerPutRequestException()
        {
        }

        public CustomerPutRequestException(string message)
            : base(message)
        {
        }

        public CustomerPutRequestException(string message, Exception innerException)
            : base(message, innerException)
        {
        }
    }
}