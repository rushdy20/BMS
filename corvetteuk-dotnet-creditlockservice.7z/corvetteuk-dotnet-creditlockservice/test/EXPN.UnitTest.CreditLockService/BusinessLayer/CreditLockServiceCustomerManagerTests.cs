﻿using AutoMapper;
using EXPN.BusinessLayer.CreditLockService;
using EXPN.BusinessLayer.CreditLockService.Commands;
using EXPN.BusinessLayer.CreditLockService.Constants;
using EXPN.DataLayer.CreditLockService.Common.Exceptions;
using EXPN.DataLayer.CreditLockService.Customers;
using EXPN.Models.CreditLockService.Internal.Delete.Request;
using EXPN.Models.CreditLockService.Internal.Delete.Response;
using EXPN.Models.CreditLockService.Internal.Get.Request;
using EXPN.Models.CreditLockService.Internal.Get.Response;
using EXPN.Models.CreditLockService.Internal.Post.Request;
using EXPN.Models.CreditLockService.Internal.Post.Response;
using EXPN.Models.CreditLockService.Internal.Put.Request;
using EXPN.Models.CreditLockService.Internal.Put.Response;
using FluentAssertions;
using Microsoft.Extensions.Logging;
using NSubstitute;
using NSubstitute.ExceptionExtensions;
using NSubstitute.ReturnsExtensions;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;
using InternalModel = EXPN.Models.CreditLockService.Internal;

namespace EXPN.UnitTest.CreditLockService.BusinessLayer;

public class CreditLockServiceCustomerManagerTests
{
    private readonly ILogger<CreditLockServiceCustomerManager> _logger;
    private readonly ICommand<InternalModel.CustomerRequest, PostCustomerResponse> _createCustomerCommand;
    private readonly ICommand<GetCustomerRequest, GetCustomerResponse> _getCustomerCommand;
    private readonly ICommand<PutLockStatusRequest, PutLockStatusResponse> _putLockStatusCommand;
    private readonly ICommand<DeleteCustomerRequest, DeleteCustomerResponse> _deleteCustomerCommand;
    private readonly ICommand<PostDeactivateInstantAlertRequest, PostDeactivateInstantAlertResponse> _deactivateInstantAlertCommand;
    private readonly ICommand<PutCustomerRequest, PutCustomerResponse> _syncCustomerCommand;
    private readonly ICommand<PostActivateInstantAlertRequest, PostActivateInstantAlertResponse> _activateInstantAlertCommand;
    private readonly ICustomersClientProxy _customersClientProxy;
    private readonly IMapper _mapper;

    private readonly ICreditLockServiceCustomerManager _creditLockServiceCustomerManager;

    public CreditLockServiceCustomerManagerTests()
    {
        _logger = Substitute.For<ILogger<CreditLockServiceCustomerManager>>();
        _createCustomerCommand = Substitute.For<ICommand<InternalModel.CustomerRequest, PostCustomerResponse>>();
        _getCustomerCommand = Substitute.For<ICommand<GetCustomerRequest, GetCustomerResponse>>();
        _putLockStatusCommand = Substitute.For<ICommand<PutLockStatusRequest, PutLockStatusResponse>>();
        _deleteCustomerCommand = Substitute.For<ICommand<DeleteCustomerRequest, DeleteCustomerResponse>>();
        _deactivateInstantAlertCommand = Substitute.For<ICommand<PostDeactivateInstantAlertRequest, PostDeactivateInstantAlertResponse>>();
        _activateInstantAlertCommand = Substitute.For<ICommand<PostActivateInstantAlertRequest, PostActivateInstantAlertResponse>>();
        _syncCustomerCommand = Substitute.For<ICommand<PutCustomerRequest, PutCustomerResponse>>();
        _customersClientProxy = Substitute.For<ICustomersClientProxy>();
        _mapper = Substitute.For<IMapper>();

        _creditLockServiceCustomerManager = new CreditLockServiceCustomerManager(
            _logger,
            _createCustomerCommand,
            _getCustomerCommand,
            _putLockStatusCommand,
            _deleteCustomerCommand,
            _deactivateInstantAlertCommand,
            _syncCustomerCommand,
            _activateInstantAlertCommand,
            _customersClientProxy,
            _mapper
        );
    }

    public class Constructor
    {
        public static IEnumerable<object[]> NullParameters()
        {
            yield return new object[]
            {
                null,
                Substitute.For<ICommand<InternalModel.CustomerRequest, PostCustomerResponse>>(),
                Substitute.For<ICommand<GetCustomerRequest, GetCustomerResponse>>(),
                Substitute.For<ICommand<PutLockStatusRequest, PutLockStatusResponse>>(),
                Substitute.For<ICommand<DeleteCustomerRequest, DeleteCustomerResponse>>(),
                Substitute.For<ICommand<PostDeactivateInstantAlertRequest, PostDeactivateInstantAlertResponse>>(),
                Substitute.For<ICommand<PutCustomerRequest, PutCustomerResponse>>(),
                Substitute.For<ICommand<PostActivateInstantAlertRequest, PostActivateInstantAlertResponse>>(),
                Substitute.For<ICustomersClientProxy>(),
                Substitute.For<IMapper>(),
                "logger"
            };

            yield return new object[]
            {
                Substitute.For<ILogger<CreditLockServiceCustomerManager>>(),
                null,
                Substitute.For<ICommand<GetCustomerRequest, GetCustomerResponse>>(),
                Substitute.For<ICommand<PutLockStatusRequest, PutLockStatusResponse>>(),
                Substitute.For<ICommand<DeleteCustomerRequest, DeleteCustomerResponse>>(),
                Substitute.For<ICommand<PostDeactivateInstantAlertRequest, PostDeactivateInstantAlertResponse>>(),
                Substitute.For<ICommand<PutCustomerRequest, PutCustomerResponse>>(),
                Substitute.For<ICommand<PostActivateInstantAlertRequest, PostActivateInstantAlertResponse>>(),
                Substitute.For<ICustomersClientProxy>(),
                Substitute.For<IMapper>(),
                "createCustomerCommand"
            };

            yield return new object[]
            {
                Substitute.For<ILogger<CreditLockServiceCustomerManager>>(),
                Substitute.For<ICommand<InternalModel.CustomerRequest, PostCustomerResponse>>(),
                null,
                Substitute.For<ICommand<PutLockStatusRequest, PutLockStatusResponse>>(),
                Substitute.For<ICommand<DeleteCustomerRequest, DeleteCustomerResponse>>(),
                Substitute.For<ICommand<PostDeactivateInstantAlertRequest, PostDeactivateInstantAlertResponse>>(),
                Substitute.For<ICommand<PutCustomerRequest, PutCustomerResponse>>(),
                Substitute.For<ICommand<PostActivateInstantAlertRequest, PostActivateInstantAlertResponse>>(),
                Substitute.For<ICustomersClientProxy>(),
                Substitute.For<IMapper>(),
                "getCustomerCommand"
            };

            yield return new object[]
            {
                Substitute.For<ILogger<CreditLockServiceCustomerManager>>(),
                Substitute.For<ICommand<InternalModel.CustomerRequest, PostCustomerResponse>>(),
                Substitute.For<ICommand<GetCustomerRequest, GetCustomerResponse>>(),
                null,
                Substitute.For<ICommand<DeleteCustomerRequest, DeleteCustomerResponse>>(),
                Substitute.For<ICommand<PostDeactivateInstantAlertRequest, PostDeactivateInstantAlertResponse>>(),
                Substitute.For<ICommand<PutCustomerRequest, PutCustomerResponse>>(),
                Substitute.For<ICommand<PostActivateInstantAlertRequest, PostActivateInstantAlertResponse>>(),
                Substitute.For<ICustomersClientProxy>(),
                Substitute.For<IMapper>(),
                "putLockStatusCommand"
            };

            yield return new object[]
            {
                Substitute.For<ILogger<CreditLockServiceCustomerManager>>(),
                Substitute.For<ICommand<InternalModel.CustomerRequest, PostCustomerResponse>>(),
                Substitute.For<ICommand<GetCustomerRequest, GetCustomerResponse>>(),
                Substitute.For<ICommand<PutLockStatusRequest, PutLockStatusResponse>>(),
                null,
                Substitute.For<ICommand<PostDeactivateInstantAlertRequest, PostDeactivateInstantAlertResponse>>(),
                Substitute.For<ICommand<PutCustomerRequest, PutCustomerResponse>>(),
                Substitute.For<ICommand<PostActivateInstantAlertRequest, PostActivateInstantAlertResponse>>(),
                Substitute.For<ICustomersClientProxy>(),
                Substitute.For<IMapper>(),
                "deleteCustomerCommand"
            };

            yield return new object[]
            {
                Substitute.For<ILogger<CreditLockServiceCustomerManager>>(),
                Substitute.For<ICommand<InternalModel.CustomerRequest, PostCustomerResponse>>(),
                Substitute.For<ICommand<GetCustomerRequest, GetCustomerResponse>>(),
                Substitute.For<ICommand<PutLockStatusRequest, PutLockStatusResponse>>(),
                Substitute.For<ICommand<DeleteCustomerRequest, DeleteCustomerResponse>>(),
                Substitute.For<ICommand<PostDeactivateInstantAlertRequest, PostDeactivateInstantAlertResponse>>(),
                null,
                Substitute.For<ICommand<PostActivateInstantAlertRequest, PostActivateInstantAlertResponse>>(),
                Substitute.For<ICustomersClientProxy>(),
                Substitute.For<IMapper>(),
                "syncCustomerCommand"
            };

            yield return new object[]
            {
                Substitute.For<ILogger<CreditLockServiceCustomerManager>>(),
                Substitute.For<ICommand<InternalModel.CustomerRequest, PostCustomerResponse>>(),
                Substitute.For<ICommand<GetCustomerRequest, GetCustomerResponse>>(),
                Substitute.For<ICommand<PutLockStatusRequest, PutLockStatusResponse>>(),
                Substitute.For<ICommand<DeleteCustomerRequest, DeleteCustomerResponse>>(),
                null,
                Substitute.For<ICommand<PutCustomerRequest, PutCustomerResponse>>(),
                Substitute.For<ICommand<PostActivateInstantAlertRequest, PostActivateInstantAlertResponse>>(),
                Substitute.For<ICustomersClientProxy>(),
                Substitute.For<IMapper>(),
                "deactivateInstantAlertCommand"
            };

            yield return new object[]
            {
                Substitute.For<ILogger<CreditLockServiceCustomerManager>>(),
                Substitute.For<ICommand<InternalModel.CustomerRequest, PostCustomerResponse>>(),
                Substitute.For<ICommand<GetCustomerRequest, GetCustomerResponse>>(),
                Substitute.For<ICommand<PutLockStatusRequest, PutLockStatusResponse>>(),
                Substitute.For<ICommand<DeleteCustomerRequest, DeleteCustomerResponse>>(),
                Substitute.For<ICommand<PostDeactivateInstantAlertRequest, PostDeactivateInstantAlertResponse>>(),
                Substitute.For<ICommand<PutCustomerRequest, PutCustomerResponse>>(),
                null,
                Substitute.For<ICustomersClientProxy>(),
                Substitute.For<IMapper>(),
                "activateInstantAlertCommand"
            };


            yield return new object[]
            {
                Substitute.For<ILogger<CreditLockServiceCustomerManager>>(),
                Substitute.For<ICommand<InternalModel.CustomerRequest, PostCustomerResponse>>(),
                Substitute.For<ICommand<GetCustomerRequest, GetCustomerResponse>>(),
                Substitute.For<ICommand<PutLockStatusRequest, PutLockStatusResponse>>(),
                Substitute.For<ICommand<DeleteCustomerRequest, DeleteCustomerResponse>>(),
                Substitute.For<ICommand<PostDeactivateInstantAlertRequest, PostDeactivateInstantAlertResponse>>(),
                Substitute.For<ICommand<PutCustomerRequest, PutCustomerResponse>>(),
                Substitute.For<ICommand<PostActivateInstantAlertRequest, PostActivateInstantAlertResponse>>(),
                Substitute.For<ICustomersClientProxy>(),
                null,
                "mapper"
            };
        }

        [Theory]
        [MemberData(nameof(NullParameters))]
        public void NullRequiredConstructorParameter_ThrowsArgumentNullException(
            ILogger<CreditLockServiceCustomerManager> logger,
            ICommand<InternalModel.CustomerRequest, PostCustomerResponse> createCustomerCommand,
            ICommand<GetCustomerRequest, GetCustomerResponse> getCustomerCommand,
            ICommand<PutLockStatusRequest, PutLockStatusResponse> putLockStatusCommand,
            ICommand<DeleteCustomerRequest, DeleteCustomerResponse> deleteCustomerCommand,
            ICommand<PostDeactivateInstantAlertRequest, PostDeactivateInstantAlertResponse> deactivateInstantAlertCommand,
            ICommand<PutCustomerRequest, PutCustomerResponse> syncCustomerCommand,
            ICommand<PostActivateInstantAlertRequest, PostActivateInstantAlertResponse> activateInstantAlertCommand,
            ICustomersClientProxy customersClientProxy,
            IMapper mapper,
            string expectedErrorParameter)
        {
            var action = () =>
            {
                new CreditLockServiceCustomerManager(
                    logger, createCustomerCommand, getCustomerCommand, putLockStatusCommand,
                    deleteCustomerCommand, deactivateInstantAlertCommand, syncCustomerCommand, activateInstantAlertCommand,
                    customersClientProxy, mapper);
            };

            action.Should().Throw<ArgumentNullException>()
                .Where(x => x.ParamName == expectedErrorParameter);
        }
    }

    public class CreateCustomerManager : CreditLockServiceCustomerManagerTests
    {
        public static IEnumerable<object[]> LogInformationMessages()
        {
            yield return new object[]
            {
                LogEventNames.CreditLockServiceCustomerManager.Activate.Enter
            };

            yield return new object[]
            {
                LogEventNames.CreditLockServiceCustomerManager.Activate.Exit
            };
        }

        [Theory]
        [MemberData(nameof(LogInformationMessages))]
        public async Task HappyPathInformationLogged(string loggerMessage)
        {
            const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

            var customerRequest = new InternalModel.CustomerRequest
            {
                CustomerId = customerId
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = customerId
            };

            _customersClientProxy.GetCustomerProfile(customerId)
                .Returns(getResponseCustomerProfile);

            _createCustomerCommand.Execute(customerRequest, getResponseCustomerProfile)
                .Returns(new PostCustomerResponse());

            await _creditLockServiceCustomerManager.ActivateAsync(customerRequest);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(loggerMessage)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public void CreateCustomerRequestNull_ThrowsArgumentNullException()
        {
            var task = async () => { await _creditLockServiceCustomerManager.ActivateAsync(null); };

            task.Should().Throw<ArgumentNullException>()
                .Where(x => x.ParamName == "customerRequest");

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Activate.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Activate.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        public static IEnumerable<object[]> CustomerRequestArgumentException()
        {
            yield return new object[]
            {
                new InternalModel.CustomerRequest
                {
                    CustomerId = null
                }
            };

            yield return new object[]
            {
                new InternalModel.CustomerRequest
                {
                    CustomerId = string.Empty
                }
            };

            yield return new object[]
            {
                new InternalModel.CustomerRequest
                {
                    CustomerId = string.Empty.PadLeft(10)
                }
            };
        }

        [Theory]
        [MemberData(nameof(CustomerRequestArgumentException))]
        public void CreateCustomerRequestCustomerIdNull_ThrowsArgumentNullException(InternalModel.CustomerRequest customerRequest)
        {
            var task = async () => { await _creditLockServiceCustomerManager.ActivateAsync(customerRequest); };

            task.Should()
                .Throw<ArgumentException>()
                .WithMessage("CustomerId cannot be null or whitespace (Parameter 'customerRequest')");

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Activate.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Activate.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public async Task ValidCustomerId_Create_NoUpdate_Success()
        {
            const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = customerId
            };

            _customersClientProxy.GetCustomerProfile(customerId)
                .Returns(getResponseCustomerProfile);

            var customerRequest = new InternalModel.CustomerRequest
            {
                CustomerId = customerId
            };

            _customersClientProxy.GetCustomerProfile(customerId)
                .Returns(getResponseCustomerProfile);

            await _creditLockServiceCustomerManager.ActivateAsync(customerRequest);

            _createCustomerCommand.Received(1).Execute(customerRequest, getResponseCustomerProfile);

            _mapper.DidNotReceive().Map<PutCustomerRequest>(Arg.Any<InternalModel.CustomerRequest>());

            _syncCustomerCommand.DidNotReceive().Execute(Arg.Any<PutCustomerRequest>(), getResponseCustomerProfile);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Activate.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Activate.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public async Task ValidCustomerId_Create_PostThrowsCustomerPostRequestConflict_NoSync_Success()
        {
            const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

            var customerRequest = new InternalModel.CustomerRequest
            {
                CustomerId = customerId
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = customerId
            };

            _customersClientProxy.GetCustomerProfile(customerId)
                .Returns(getResponseCustomerProfile);

            _createCustomerCommand.Execute(customerRequest, getResponseCustomerProfile)
                .Throws(new AggregateException(
                    new CustomerPostRequestConflictException()
                ));

            var putCustomerRequest = new PutCustomerRequest
            {
                CustomerId = customerRequest.CustomerId
            };

            _mapper.Map<PutCustomerRequest>(customerRequest)
                .Returns(putCustomerRequest);

            _syncCustomerCommand.Execute(putCustomerRequest, getResponseCustomerProfile)
                .Returns(new PutCustomerResponse
                {
                    HasMadeSyncRequest = false
                });

            await _creditLockServiceCustomerManager.ActivateAsync(customerRequest);

            _createCustomerCommand.Received(1).Execute(customerRequest, getResponseCustomerProfile);

            _mapper.Received(1).Map<PutCustomerRequest>(customerRequest);

            _syncCustomerCommand.Received(1).Execute(putCustomerRequest, getResponseCustomerProfile);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Activate.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Activate.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public async Task ValidCustomerId_Create_PostThrowsCustomerPostRequestConflictException_Sync_Success()
        {
            const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

            var customerRequest = new InternalModel.CustomerRequest
            {
                CustomerId = customerId
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = customerId
            };

            _customersClientProxy.GetCustomerProfile(customerId)
                .Returns(getResponseCustomerProfile);

            _createCustomerCommand.Execute(customerRequest, getResponseCustomerProfile)
                .Throws(new AggregateException(
                    new CustomerPostRequestConflictException()
                ));

            var putCustomerRequest = new PutCustomerRequest
            {
                CustomerId = customerRequest.CustomerId
            };

            _mapper.Map<PutCustomerRequest>(customerRequest)
                .Returns(putCustomerRequest);

            _syncCustomerCommand.Execute(putCustomerRequest, getResponseCustomerProfile)
                .Returns(new PutCustomerResponse
                {
                    HasMadeSyncRequest = true
                });

            await _creditLockServiceCustomerManager.ActivateAsync(customerRequest);

            _createCustomerCommand.Received(1).Execute(customerRequest, getResponseCustomerProfile);

            _mapper.Received(1).Map<PutCustomerRequest>(customerRequest);

            _syncCustomerCommand.Received(1).Execute(putCustomerRequest, getResponseCustomerProfile);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Activate.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Activate.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public void ValidCustomerId_Create_PostThrowsOktaTokenNullException_Fails()
        {
            const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

            var customerRequest = new InternalModel.CustomerRequest
            {
                CustomerId = customerId
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = customerId
            };

            _customersClientProxy.GetCustomerProfile(customerId)
                .Returns(getResponseCustomerProfile);

            _createCustomerCommand.Execute(customerRequest, getResponseCustomerProfile)
                .Throws(new AggregateException(
                    new OktaTokenNullException("Test Message")
                ));

            var task = async () =>
            {
                await _creditLockServiceCustomerManager.ActivateAsync(customerRequest);
            };

            task.Should()
                .Throw<OktaTokenNullException>()
                .WithMessage("Test Message");

            _createCustomerCommand.Received(1).Execute(customerRequest, getResponseCustomerProfile);

            _mapper.DidNotReceive().Map<PutCustomerRequest>(Arg.Any<InternalModel.CustomerRequest>());

            _syncCustomerCommand.DidNotReceive().Execute(Arg.Any<PutCustomerRequest>(), getResponseCustomerProfile);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Activate.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Activate.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public void ValidCustomerId_Create_CommandThrowsException_Fails()
        {
            const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

            var customerRequest = new InternalModel.CustomerRequest
            {
                CustomerId = customerId
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = customerId
            };

            _customersClientProxy.GetCustomerProfile(customerId)
                .Returns(getResponseCustomerProfile);

            _createCustomerCommand.Execute(customerRequest, getResponseCustomerProfile)
                .Throws(new InvalidOperationException("Test Message"));

            var task = async () => { await _creditLockServiceCustomerManager.ActivateAsync(customerRequest); };

            task.Should()
                .Throw<InvalidOperationException>()
                .WithMessage("Test Message");

            _createCustomerCommand.Received(1).Execute(customerRequest, getResponseCustomerProfile);

            _mapper.DidNotReceive().Map<PutCustomerRequest>(Arg.Any<InternalModel.CustomerRequest>());

            _syncCustomerCommand.DidNotReceive().Execute(Arg.Any<PutCustomerRequest>(), getResponseCustomerProfile);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Activate.Enter)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Activate.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public void ValidCustomerId_Create_DownstreamMaintenanceException_Fails()
        {
            const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

            var customerRequest = new InternalModel.CustomerRequest
            {
                CustomerId = customerId
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = customerId
            };

            _customersClientProxy.GetCustomerProfile(customerId)
                .Returns(getResponseCustomerProfile);

            _createCustomerCommand.Execute(customerRequest, getResponseCustomerProfile)
                .Throws(new AggregateException(
                    new DownstreamMaintenanceException("Test Message")));

            var task = async () => { await _creditLockServiceCustomerManager.ActivateAsync(customerRequest); };

            task.Should()
                .Throw<DownstreamMaintenanceException>()
                .WithMessage("Test Message");

            _createCustomerCommand.Received(1).Execute(customerRequest, getResponseCustomerProfile);

            _mapper.DidNotReceive().Map<PutCustomerRequest>(Arg.Any<InternalModel.CustomerRequest>());

            _syncCustomerCommand.DidNotReceive().Execute(Arg.Any<PutCustomerRequest>(), getResponseCustomerProfile);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Activate.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Activate.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public void ValidCustomerId_Create_ServiceGatewayTimeoutException_Fails()
        {
            const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

            var customerRequest = new InternalModel.CustomerRequest
            {
                CustomerId = customerId
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = customerId
            };

            _customersClientProxy.GetCustomerProfile(customerId)
                .Returns(getResponseCustomerProfile);

            _createCustomerCommand.Execute(customerRequest, getResponseCustomerProfile)
                .Throws(new AggregateException(
                    new HttpServiceRequestException("Test Message")));

            var task = async () => { await _creditLockServiceCustomerManager.ActivateAsync(customerRequest); };

            task.Should()
                .Throw<HttpServiceRequestException>()
                .WithMessage("Test Message");

            _createCustomerCommand.Received(1).Execute(customerRequest, getResponseCustomerProfile);

            _mapper.DidNotReceive().Map<PutCustomerRequest>(Arg.Any<InternalModel.CustomerRequest>());

            _syncCustomerCommand.DidNotReceive().Execute(Arg.Any<PutCustomerRequest>(), getResponseCustomerProfile);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Activate.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Activate.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public void ValidCustomerId_Create_ServiceUnavailableException_Fails()
        {
            const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

            var customerRequest = new InternalModel.CustomerRequest
            {
                CustomerId = customerId
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = customerId
            };

            _customersClientProxy.GetCustomerProfile(customerId)
                .Returns(getResponseCustomerProfile);

            _createCustomerCommand.Execute(customerRequest, getResponseCustomerProfile)
                .Throws(new AggregateException(
                    new ServiceUnavailableException("Test Message")));

            var task = async () => { await _creditLockServiceCustomerManager.ActivateAsync(customerRequest); };

            task.Should()
                .Throw<ServiceUnavailableException>()
                .WithMessage("Test Message");

            _createCustomerCommand.Received(1).Execute(customerRequest, getResponseCustomerProfile);

            _mapper.DidNotReceive().Map<PutCustomerRequest>(Arg.Any<InternalModel.CustomerRequest>());

            _syncCustomerCommand.DidNotReceive().Execute(Arg.Any<PutCustomerRequest>(), getResponseCustomerProfile);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Activate.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Activate.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public void ValidCustomerId_Create_DownstreamBadResponse_Fails()
        {
            const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

            var customerRequest = new InternalModel.CustomerRequest
            {
                CustomerId = customerId
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = customerId
            };

            _customersClientProxy.GetCustomerProfile(customerId)
                .Returns(getResponseCustomerProfile);

            _createCustomerCommand.Execute(customerRequest, getResponseCustomerProfile)
                .Throws(new AggregateException(
                    new DownstreamBadResponseException("Test Message")));

            var task = async () => { await _creditLockServiceCustomerManager.ActivateAsync(customerRequest); };

            task.Should()
                .Throw<DownstreamBadResponseException>()
                .WithMessage("Test Message");

            _createCustomerCommand.Received(1).Execute(customerRequest, getResponseCustomerProfile);

            _mapper.DidNotReceive().Map<PutCustomerRequest>(Arg.Any<InternalModel.CustomerRequest>());

            _syncCustomerCommand.DidNotReceive().Execute(Arg.Any<PutCustomerRequest>(), getResponseCustomerProfile);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Activate.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public void ValidCustomerId_Create_ThrowsCustomerProfileNotFoundException_Fails()
        {
            const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

            var customerRequest = new InternalModel.CustomerRequest
            {
                CustomerId = customerId
            };

            _customersClientProxy.GetCustomerProfile(customerId)
                .ReturnsNull();

            var task = async () => { await _creditLockServiceCustomerManager.ActivateAsync(customerRequest); };

            task.Should()
                .Throw<CustomerProfileNotFoundException>()
                .WithMessage($"{customerId} customer profile not found");

            _createCustomerCommand.DidNotReceive().Execute(Arg.Any<InternalModel.CustomerRequest>(), Arg.Any<GetResponseCustomerProfile>());

            _mapper.DidNotReceive().Map<PutCustomerRequest>(Arg.Any<InternalModel.CustomerRequest>());

            _syncCustomerCommand.DidNotReceive().Execute(Arg.Any<PutCustomerRequest>(), Arg.Any<GetResponseCustomerProfile>());

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Activate.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Activate.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }
    }

    public class GetCustomerManager : CreditLockServiceCustomerManagerTests
    {
        public static IEnumerable<object[]> GetCustomerLogInformationMessages()
        {
            yield return new object[]
            {
                LogEventNames.CreditLockServiceCustomerManager.GetCustomer.Enter
            };

            yield return new object[]
            {
                LogEventNames.CreditLockServiceCustomerManager.GetCustomer.Exit
            };
        }

        [Theory]
        [MemberData(nameof(GetCustomerLogInformationMessages))]
        public async Task HappyPathInformationLogged(string loggerMessage)
        {
            var getCustomerRequest = new GetCustomerRequest
            {
                CustomerId = "a69e102d-d776-490a-a0a1-dfe25c791df9"
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = getCustomerRequest.CustomerId
            };

            _customersClientProxy.GetCustomerProfile(getCustomerRequest.CustomerId)
                .Returns(getResponseCustomerProfile);

            await _creditLockServiceCustomerManager.GetCustomerAsync(getCustomerRequest);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(loggerMessage)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public void GetCustomerCustomerRequestNull_ThrowsArgumentNullException()
        {
            var task = async () => { await _creditLockServiceCustomerManager.GetCustomerAsync(null); };

            task.Should()
                .Throw<ArgumentNullException>()
                .Where(x => x.ParamName == "getCustomerRequest");
        }

        public static IEnumerable<object[]> GetCustomerRequestArgumentException()
        {
            yield return new object[]
            {
                new GetCustomerRequest
                {
                    CustomerId = null
                }
            };

            yield return new object[]
            {
                new GetCustomerRequest
                {
                    CustomerId = string.Empty
                }
            };

            yield return new object[]
            {
                new GetCustomerRequest
                {
                    CustomerId = string.Empty.PadLeft(10)
                }
            };
        }

        [Theory]
        [MemberData(nameof(GetCustomerRequestArgumentException))]
        public void GetCustomerRequestCustomerIdNull_ThrowsArgumentNullException(GetCustomerRequest getCustomerRequest)
        {
            var task = async () => { await _creditLockServiceCustomerManager.GetCustomerAsync(getCustomerRequest); };

            task.Should()
                .Throw<ArgumentException>()
                .WithMessage("CustomerId cannot be null or whitespace (Parameter 'getCustomerRequest')");

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.GetCustomer.Enter)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.GetCustomer.Exit)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public async Task ValidCustomerId_GetCustomer_Success()
        {
            const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

            var getLockStatusRequest = new GetCustomerRequest
            {
                CustomerId = customerId
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = customerId
            };

            _customersClientProxy.GetCustomerProfile(customerId)
                .Returns(getResponseCustomerProfile);

            var getCustomerResponse = new GetCustomerResponse
            {
                LockStatus = "ON"
            };

            _getCustomerCommand.Execute(getLockStatusRequest, getResponseCustomerProfile)
                .Returns(getCustomerResponse);

            var response = await _creditLockServiceCustomerManager.GetCustomerAsync(getLockStatusRequest);

            response.Should().NotBeNull();

            _getCustomerCommand.Received(1).Execute(getLockStatusRequest, getResponseCustomerProfile);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.GetCustomer.Enter)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.GetCustomer.Exit)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public void ValidCustomerId_GetCustomer_GetThrowsOktaTokenNullException_Fails()
        {
            const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

            var getLockStatusRequest = new GetCustomerRequest
            {
                CustomerId = customerId
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = customerId
            };

            _customersClientProxy.GetCustomerProfile(customerId)
                .Returns(getResponseCustomerProfile);

            _getCustomerCommand.Execute(getLockStatusRequest, getResponseCustomerProfile)
                .Throws(new AggregateException(
                    new OktaTokenNullException("Test Message")
                ));

            var task = async () => { await _creditLockServiceCustomerManager.GetCustomerAsync(getLockStatusRequest); };

            task.Should()
                .Throw<OktaTokenNullException>()
                .WithMessage("Test Message");

            _getCustomerCommand.Received(1).Execute(getLockStatusRequest, getResponseCustomerProfile);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.GetCustomer.Enter)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.GetCustomer.Exit)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public void ValidCustomerId_GetCustomer_TaskCanceledException_Fails()
        {
            const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

            var getLockStatusRequest = new GetCustomerRequest
            {
                CustomerId = customerId
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = customerId
            };

            _customersClientProxy.GetCustomerProfile(customerId)
                .Returns(getResponseCustomerProfile);

            _getCustomerCommand.Execute(getLockStatusRequest, getResponseCustomerProfile)
                .Throws(new AggregateException(
                    new TaskCanceledException("Test Message")
                ));

            var task = async () => { await _creditLockServiceCustomerManager.GetCustomerAsync(getLockStatusRequest); };

            task.Should().Throw<TaskCanceledException>();

            _getCustomerCommand.Received(1).Execute(getLockStatusRequest, getResponseCustomerProfile);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.GetCustomer.Enter)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

            _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.GetCustomer.Exit)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public void ValidCustomerId_GetCustomer_HttpServiceRequestException_Fails()
        {
            const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

            var getLockStatusRequest = new GetCustomerRequest
            {
                CustomerId = customerId
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = customerId
            };

            _customersClientProxy.GetCustomerProfile(customerId)
                .Returns(getResponseCustomerProfile);

            _getCustomerCommand.Execute(getLockStatusRequest, getResponseCustomerProfile)
                .Throws(new AggregateException(
                    new HttpServiceRequestException("Test Message")
                ));

            var task = async () => { await _creditLockServiceCustomerManager.GetCustomerAsync(getLockStatusRequest); };

            task.Should()
                .Throw<HttpServiceRequestException>()
                .WithMessage("Test Message");

            _getCustomerCommand.Received(1).Execute(getLockStatusRequest, getResponseCustomerProfile);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.GetCustomer.Enter)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.GetCustomer.Exit)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public void ValidCustomerId_GetCustomer_DownstreamMaintenanceException_Fails()
        {
            const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

            var getLockStatusRequest = new GetCustomerRequest
            {
                CustomerId = customerId
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = customerId
            };

            _customersClientProxy.GetCustomerProfile(customerId)
                .Returns(getResponseCustomerProfile);

            _getCustomerCommand.Execute(getLockStatusRequest, getResponseCustomerProfile)
                .Throws(new AggregateException(
                    new DownstreamMaintenanceException("Test Message")
                ));

            var task = async () => { await _creditLockServiceCustomerManager.GetCustomerAsync(getLockStatusRequest); };

            task.Should()
                .Throw<DownstreamMaintenanceException>()
                .WithMessage("Test Message");

            _getCustomerCommand.Received(1).Execute(getLockStatusRequest, getResponseCustomerProfile);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.GetCustomer.Enter)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

            _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.GetCustomer.Exit)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public void ValidCustomerId_GetCustomer_ServiceUnavailableException_Fails()
        {
            const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

            var getLockStatusRequest = new GetCustomerRequest
            {
                CustomerId = customerId
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = customerId
            };

            _customersClientProxy.GetCustomerProfile(customerId)
                .Returns(getResponseCustomerProfile);

            _getCustomerCommand.Execute(getLockStatusRequest, getResponseCustomerProfile)
                .Throws(new AggregateException(
                    new ServiceUnavailableException("Test Message")
                ));

            var task = async () => { await _creditLockServiceCustomerManager.GetCustomerAsync(getLockStatusRequest); };

            task.Should()
                .Throw<ServiceUnavailableException>()
                .WithMessage("Test Message");

            _getCustomerCommand.Received(1).Execute(getLockStatusRequest, getResponseCustomerProfile);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.GetCustomer.Enter)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

            _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.GetCustomer.Exit)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public void ValidCustomerId_GetCustomer_OktaException_Fails()
        {
            const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

            var getLockStatusRequest = new GetCustomerRequest
            {
                CustomerId = customerId
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = customerId
            };

            _customersClientProxy.GetCustomerProfile(customerId)
                .Returns(getResponseCustomerProfile);

            _getCustomerCommand.Execute(getLockStatusRequest, getResponseCustomerProfile)
                .Throws(new AggregateException(
                    new OktaException("Test Message")
                ));

            var task = async () => { await _creditLockServiceCustomerManager.GetCustomerAsync(getLockStatusRequest); };

            task.Should()
                .Throw<OktaException>()
                .WithMessage("Test Message");

            _getCustomerCommand.Received(1).Execute(getLockStatusRequest, getResponseCustomerProfile);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.GetCustomer.Enter)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

            _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.GetCustomer.Exit)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public void ValidCustomerId_GetCustomer_DownstreamBadResponseException_Fails()
        {
            const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

            var getLockStatusRequest = new GetCustomerRequest
            {
                CustomerId = customerId
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = customerId
            };

            _customersClientProxy.GetCustomerProfile(customerId)
                .Returns(getResponseCustomerProfile);

            _getCustomerCommand.Execute(getLockStatusRequest, getResponseCustomerProfile)
                .Throws(new AggregateException(
                    new DownstreamBadResponseException("Test Message")
                ));

            var task = async () => { await _creditLockServiceCustomerManager.GetCustomerAsync(getLockStatusRequest); };

            task.Should()
                .Throw<DownstreamBadResponseException>()
                .WithMessage("Test Message");

            _getCustomerCommand.Received(1).Execute(getLockStatusRequest, getResponseCustomerProfile);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.GetCustomer.Enter)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

            _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.GetCustomer.Exit)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public void ValidCustomerId_GetCustomer_CustomerProfileNotFoundException_Fails()
        {
            const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

            var getLockStatusRequest = new GetCustomerRequest
            {
                CustomerId = customerId
            };

            _customersClientProxy.GetCustomerProfile(customerId)
                .ReturnsNull();

            var task = async () => { await _creditLockServiceCustomerManager.GetCustomerAsync(getLockStatusRequest); };

            task.Should()
                .Throw<CustomerProfileNotFoundException>()
                .WithMessage($"{customerId} customer profile not found");

            _getCustomerCommand.DidNotReceive().Execute(Arg.Any<GetCustomerRequest>(), Arg.Any<GetResponseCustomerProfile>());

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.GetCustomer.Enter)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

            _logger.DidNotReceive().Log(LogLevel.Error, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.GetCustomer.Exit)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

    }

    public class PutLockStatusCustomerManager : CreditLockServiceCustomerManagerTests
    {
        public static IEnumerable<object[]> PutLockStatusLogInformationMessages()
        {
            yield return new object[]
            {
                LogEventNames.CreditLockServiceCustomerManager.PutLockStatus.Enter
            };

            yield return new object[]
            {
                LogEventNames.CreditLockServiceCustomerManager.PutLockStatus.Exit
            };
        }

        [Theory]
        [MemberData(nameof(PutLockStatusLogInformationMessages))]
        public async Task HappyPathInformationLogged(string loggerMessage)
        {
            const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

            var putLockStatusRequest = new PutLockStatusRequest
            {
                CustomerId = customerId,
                LockStatus = true
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = putLockStatusRequest.CustomerId
            };

            _customersClientProxy.GetCustomerProfile(putLockStatusRequest.CustomerId)
                .Returns(getResponseCustomerProfile);

            _syncCustomerCommand.Execute(Arg.Any<PutCustomerRequest>(), Arg.Any<GetResponseCustomerProfile>())
                .Returns(new PutCustomerResponse
                {
                    HasMadeSyncRequest = false
                });

            await _creditLockServiceCustomerManager.PutLockStatus(putLockStatusRequest);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(loggerMessage)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public void PutLockStatus_RequestNull_ThrowsArgumentNullException()
        {
            var task = async () => { await _creditLockServiceCustomerManager.PutLockStatus(null); };

            task.Should()
                .Throw<ArgumentNullException>()
                .Where(x => x.ParamName == "putLockStatusRequest");

            _putLockStatusCommand.DidNotReceive().Execute(Arg.Any<PutLockStatusRequest>(), Arg.Any<GetResponseCustomerProfile>());

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.PutLockStatus.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.PutLockStatus.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Theory]
        [InlineData(null)]
        [InlineData("")]
        [InlineData("      ")]
        public void PutLockStatusRequestCustomerIdNull_ThrowsArgumentNullException(string customerId)
        {
            var putLockStatusRequest = new PutLockStatusRequest
            {
                CustomerId = customerId
            };

            var task = async () => { await _creditLockServiceCustomerManager.PutLockStatus(putLockStatusRequest); };

            task.Should()
                .Throw<ArgumentException>()
                .WithMessage("CustomerId cannot be null or whitespace (Parameter 'putLockStatusRequest')");

            _putLockStatusCommand.DidNotReceive().Execute(Arg.Any<PutLockStatusRequest>(), Arg.Any<GetResponseCustomerProfile>());

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.PutLockStatus.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.PutLockStatus.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public async Task ValidCustomerId_PutLockStatus_SetStatus_WithSync_Success()
        {
            const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

            var putLockStatusRequest = new PutLockStatusRequest
            {
                CustomerId = customerId,
                LockStatus = true
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = customerId
            };

            _customersClientProxy.GetCustomerProfile(customerId)
                .Returns(getResponseCustomerProfile);

            var putCustomerRequest = new PutCustomerRequest
            {
                CustomerId = putLockStatusRequest.CustomerId
            };

            _mapper.Map<PutCustomerRequest>(putLockStatusRequest)
                .Returns(putCustomerRequest);

            _syncCustomerCommand.Execute(putCustomerRequest, getResponseCustomerProfile)
                .Returns(new PutCustomerResponse
                {
                    HasMadeSyncRequest = false
                });

            await _creditLockServiceCustomerManager.PutLockStatus(putLockStatusRequest);

            _putLockStatusCommand.Received(1).Execute(putLockStatusRequest, getResponseCustomerProfile);

            _mapper.Received(1).Map<PutCustomerRequest>(putLockStatusRequest);

            _syncCustomerCommand.Received(1).Execute(putCustomerRequest, getResponseCustomerProfile);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.PutLockStatus.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.PutLockStatus.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public async Task ValidCustomerId_PutLockStatus_SetStatus_WithoutSync_Success()
        {
            const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

            var putLockStatusRequest = new PutLockStatusRequest
            {
                CustomerId = customerId,
                LockStatus = false
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = customerId
            };

            _customersClientProxy.GetCustomerProfile(customerId)
                .Returns(getResponseCustomerProfile);

            var putCustomerRequest = new PutCustomerRequest
            {
                CustomerId = putLockStatusRequest.CustomerId
            };

            await _creditLockServiceCustomerManager.PutLockStatus(putLockStatusRequest);

            _putLockStatusCommand.Received(1).Execute(putLockStatusRequest, getResponseCustomerProfile);

            _mapper.DidNotReceive().Map<PutCustomerRequest>(putLockStatusRequest);

            _syncCustomerCommand.DidNotReceive().Execute(putCustomerRequest, getResponseCustomerProfile);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.PutLockStatus.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.PutLockStatus.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public Task ValidCustomerId_PutLockStatus_WithSync_GetThrowsOktaTokenNullException_Fails()
        {
            const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

            var putLockStatusRequest = new PutLockStatusRequest
            {
                CustomerId = customerId,
                LockStatus = true
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = customerId
            };

            _customersClientProxy.GetCustomerProfile(customerId)
                .Returns(getResponseCustomerProfile);

            var putCustomerRequest = new PutCustomerRequest
            {
                CustomerId = putLockStatusRequest.CustomerId
            };

            _mapper.Map<PutCustomerRequest>(putLockStatusRequest)
                .Returns(putCustomerRequest);

            _syncCustomerCommand.Execute(putCustomerRequest, getResponseCustomerProfile)
                .Returns(new PutCustomerResponse
                {
                    HasMadeSyncRequest = false
                });

            _putLockStatusCommand.Execute(putLockStatusRequest, getResponseCustomerProfile)
                .Throws(new AggregateException(new OktaTokenNullException("Test OktaTokenNullException Message")));

            var task = async () =>
            {
                await _creditLockServiceCustomerManager.PutLockStatus(putLockStatusRequest);
            };

            task.Should()
                .Throw<OktaTokenNullException>()
                .WithMessage("Test OktaTokenNullException Message");

            _putLockStatusCommand.Received(1).Execute(putLockStatusRequest, getResponseCustomerProfile);

            _mapper.Received(1).Map<PutCustomerRequest>(putLockStatusRequest);

            _syncCustomerCommand.Received(1).Execute(putCustomerRequest, getResponseCustomerProfile);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.PutLockStatus.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.PutLockStatus.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            return Task.CompletedTask;
        }

        [Fact]
        public Task ValidCustomerIdPutLockStatusWithSyncTaskCanceledExceptionFails()
        {
            const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

            var putLockStatusRequest = new PutLockStatusRequest
            {
                CustomerId = customerId,
                LockStatus = true
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = customerId
            };

            _customersClientProxy.GetCustomerProfile(customerId)
                .Returns(getResponseCustomerProfile);

            var putCustomerRequest = new PutCustomerRequest
            {
                CustomerId = putLockStatusRequest.CustomerId
            };

            _mapper.Map<PutCustomerRequest>(putLockStatusRequest)
                .Returns(putCustomerRequest);

            _syncCustomerCommand.Execute(putCustomerRequest, getResponseCustomerProfile)
                .Returns(new PutCustomerResponse
                {
                    HasMadeSyncRequest = false
                });

            _putLockStatusCommand.Execute(putLockStatusRequest, getResponseCustomerProfile)
                .Throws(new AggregateException(new TaskCanceledException()));

            var task = async () =>
            {
                await _creditLockServiceCustomerManager.PutLockStatus(putLockStatusRequest);
            };

            task.Should()
                .Throw<TaskCanceledException>()
                .WithMessage("A task was canceled.");

            _putLockStatusCommand.Received(1).Execute(putLockStatusRequest, getResponseCustomerProfile);

            _mapper.Received(1).Map<PutCustomerRequest>(putLockStatusRequest);

            _syncCustomerCommand.Received(1).Execute(putCustomerRequest, getResponseCustomerProfile);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.PutLockStatus.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.PutLockStatus.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            return Task.CompletedTask;
        }

        [Fact]
        public Task ValidCustomerId_PutLockStatus_WithSync_HttpServiceRequestException_Fails()
        {
            const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

            var putLockStatusRequest = new PutLockStatusRequest
            {
                CustomerId = customerId,
                LockStatus = true
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = customerId
            };

            var putCustomerRequest = new PutCustomerRequest
            {
                CustomerId = putLockStatusRequest.CustomerId
            };

            _mapper.Map<PutCustomerRequest>(putLockStatusRequest)
                .Returns(putCustomerRequest);

            _syncCustomerCommand.Execute(putCustomerRequest, getResponseCustomerProfile)
                .Returns(new PutCustomerResponse
                {
                    HasMadeSyncRequest = false
                });

            _customersClientProxy.GetCustomerProfile(customerId)
                .Returns(getResponseCustomerProfile);

            _putLockStatusCommand.Execute(putLockStatusRequest, getResponseCustomerProfile)
                .Throws(new AggregateException(new HttpServiceRequestException("Test Message")));

            var task = async () =>
            {
                await _creditLockServiceCustomerManager.PutLockStatus(putLockStatusRequest);
            };

            task.Should()
                .Throw<HttpServiceRequestException>()
                .WithMessage("Test Message");

            _putLockStatusCommand.Received(1).Execute(putLockStatusRequest, getResponseCustomerProfile);

            _mapper.Received(1).Map<PutCustomerRequest>(putLockStatusRequest);

            _syncCustomerCommand.Received(1).Execute(putCustomerRequest, getResponseCustomerProfile);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.PutLockStatus.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.PutLockStatus.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            return Task.CompletedTask;
        }

        [Fact]
        public Task ValidCustomerId_PutLockStatus_WithSync_DownstreamMaintenanceException_Fails()
        {
            const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

            var putLockStatusRequest = new PutLockStatusRequest
            {
                CustomerId = customerId,
                LockStatus = true
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = customerId
            };

            var putCustomerRequest = new PutCustomerRequest
            {
                CustomerId = putLockStatusRequest.CustomerId
            };

            _mapper.Map<PutCustomerRequest>(putLockStatusRequest)
                .Returns(putCustomerRequest);

            _syncCustomerCommand.Execute(putCustomerRequest, getResponseCustomerProfile)
                .Returns(new PutCustomerResponse
                {
                    HasMadeSyncRequest = false
                });

            _customersClientProxy.GetCustomerProfile(customerId)
                .Returns(getResponseCustomerProfile);

            _putLockStatusCommand.Execute(putLockStatusRequest, getResponseCustomerProfile)
                .Throws(new AggregateException(new DownstreamMaintenanceException("Test Message")));

            var task = async () => { await _creditLockServiceCustomerManager.PutLockStatus(putLockStatusRequest); };

            task.Should()
                .Throw<DownstreamMaintenanceException>()
                .WithMessage("Test Message");

            _putLockStatusCommand.Received(1).Execute(putLockStatusRequest, getResponseCustomerProfile);

            _mapper.Received(1).Map<PutCustomerRequest>(putLockStatusRequest);

            _syncCustomerCommand.Received(1).Execute(putCustomerRequest, getResponseCustomerProfile);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.PutLockStatus.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.PutLockStatus.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            return Task.CompletedTask;
        }

        [Fact]
        public Task ValidCustomerId_PutLockStatus_WithSync_ServiceUnavailableException_Fails()
        {
            const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

            var putLockStatusRequest = new PutLockStatusRequest
            {
                CustomerId = customerId,
                LockStatus = true
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = customerId
            };

            var putCustomerRequest = new PutCustomerRequest
            {
                CustomerId = putLockStatusRequest.CustomerId
            };

            _mapper.Map<PutCustomerRequest>(putLockStatusRequest)
                .Returns(putCustomerRequest);

            _syncCustomerCommand.Execute(putCustomerRequest, getResponseCustomerProfile)
                .Returns(new PutCustomerResponse
                {
                    HasMadeSyncRequest = false
                });

            _customersClientProxy.GetCustomerProfile(customerId)
                .Returns(getResponseCustomerProfile);

            _putLockStatusCommand.Execute(putLockStatusRequest, getResponseCustomerProfile)
                .Throws(new AggregateException(new ServiceUnavailableException("Test Message")));

            var task = async () =>
            {
                await _creditLockServiceCustomerManager.PutLockStatus(putLockStatusRequest);
            };

            task.Should()
                .Throw<ServiceUnavailableException>()
                .WithMessage("Test Message");

            _putLockStatusCommand.Received(1).Execute(putLockStatusRequest, getResponseCustomerProfile);

            _mapper.Received(1).Map<PutCustomerRequest>(putLockStatusRequest);

            _syncCustomerCommand.Received(1).Execute(putCustomerRequest, getResponseCustomerProfile);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.PutLockStatus.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.PutLockStatus.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            return Task.CompletedTask;
        }

        [Fact]
        public Task ValidCustomerId_PutLockStatus_WithSync_OktaException_Fails()
        {
            const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

            var putLockStatusRequest = new PutLockStatusRequest
            {
                CustomerId = customerId,
                LockStatus = true
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = customerId
            };

            var putCustomerRequest = new PutCustomerRequest
            {
                CustomerId = putLockStatusRequest.CustomerId
            };

            _mapper.Map<PutCustomerRequest>(putLockStatusRequest)
                .Returns(putCustomerRequest);

            _syncCustomerCommand.Execute(putCustomerRequest, getResponseCustomerProfile)
                .Returns(new PutCustomerResponse
                {
                    HasMadeSyncRequest = false
                });

            _customersClientProxy.GetCustomerProfile(customerId)
                .Returns(getResponseCustomerProfile);

            _putLockStatusCommand.Execute(putLockStatusRequest, getResponseCustomerProfile)
                .Throws(new AggregateException(new OktaException("Test Message")));

            var task = async () =>
            {
                await _creditLockServiceCustomerManager.PutLockStatus(putLockStatusRequest);
            };

            task.Should()
                .Throw<OktaException>()
                .WithMessage("Test Message");

            _putLockStatusCommand.Received(1).Execute(putLockStatusRequest, getResponseCustomerProfile);

            _mapper.Received(1).Map<PutCustomerRequest>(putLockStatusRequest);

            _syncCustomerCommand.Received(1).Execute(putCustomerRequest, getResponseCustomerProfile);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.PutLockStatus.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.PutLockStatus.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            return Task.CompletedTask;
        }

        [Fact]
        public Task ValidCustomerId_PutLockStatus_WithoutSync_DownstreamBadResponseException_Fails()
        {
            const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

            var putLockStatusRequest = new PutLockStatusRequest
            {
                CustomerId = customerId,
                LockStatus = false
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = customerId
            };

            _customersClientProxy.GetCustomerProfile(customerId)
                .Returns(getResponseCustomerProfile);

            _putLockStatusCommand.Execute(putLockStatusRequest, getResponseCustomerProfile)
                .Throws(new AggregateException(new DownstreamBadResponseException("Test Message")));

            var task = async () =>
            {
                await _creditLockServiceCustomerManager.PutLockStatus(putLockStatusRequest);
            };

            task.Should()
                .Throw<DownstreamBadResponseException>()
                .WithMessage("Test Message");

            _putLockStatusCommand.Received(1).Execute(putLockStatusRequest, getResponseCustomerProfile);

            _mapper.DidNotReceive().Map<PutCustomerRequest>(Arg.Any<PutLockStatusRequest>());

            _syncCustomerCommand.DidNotReceive().Execute(Arg.Any<PutCustomerRequest>(), Arg.Any<GetResponseCustomerProfile>());

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.PutLockStatus.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.PutLockStatus.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            return Task.CompletedTask;
        }

        [Fact]
        public Task ValidCustomerId_PutLockStatus_WithSync_CustomerNotFoundException_Fails()
        {
            const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

            var putLockStatusRequest = new PutLockStatusRequest
            {
                CustomerId = customerId,
                LockStatus = true
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = customerId
            };

            var putCustomerRequest = new PutCustomerRequest
            {
                CustomerId = putLockStatusRequest.CustomerId
            };

            _mapper.Map<PutCustomerRequest>(putLockStatusRequest)
                .Returns(putCustomerRequest);

            _syncCustomerCommand.Execute(putCustomerRequest, getResponseCustomerProfile)
                .Returns(new PutCustomerResponse
                {
                    HasMadeSyncRequest = false
                });

            _customersClientProxy.GetCustomerProfile(customerId)
                .Returns(getResponseCustomerProfile);

            _putLockStatusCommand.Execute(putLockStatusRequest, getResponseCustomerProfile)
                .Throws(new AggregateException(new CustomerNotFoundException("Test Message")));

            var task = async () =>
            {
                await _creditLockServiceCustomerManager.PutLockStatus(putLockStatusRequest);
            };

            task.Should()
                .Throw<CustomerNotFoundException>()
                .WithMessage("Test Message");

            _putLockStatusCommand.Received(1).Execute(putLockStatusRequest, getResponseCustomerProfile);

            _mapper.Received(1).Map<PutCustomerRequest>(putLockStatusRequest);

            _syncCustomerCommand.Received(1).Execute(putCustomerRequest, getResponseCustomerProfile);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.PutLockStatus.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.PutLockStatus.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            return Task.CompletedTask;
        }

        [Fact]
        public Task ValidCustomerId_PutLockStatus_WithSync_CustomerProfileNotFoundException_Fails()
        {
            const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

            var putLockStatusRequest = new PutLockStatusRequest
            {
                CustomerId = customerId,
                LockStatus = true
            };

            _customersClientProxy.GetCustomerProfile(customerId)
                .ReturnsNull();

            var task = async () =>
            {
                await _creditLockServiceCustomerManager.PutLockStatus(putLockStatusRequest);
            };

            task.Should()
                .Throw<CustomerProfileNotFoundException>()
                .WithMessage($"{customerId} customer profile not found");

            _putLockStatusCommand.DidNotReceive().Execute(Arg.Any<PutLockStatusRequest>(), Arg.Any<GetResponseCustomerProfile>());

            _mapper.DidNotReceive().Map<PutCustomerRequest>(Arg.Any<PutLockStatusRequest>());

            _syncCustomerCommand.DidNotReceive().Execute(Arg.Any<PutCustomerRequest>(), Arg.Any<GetResponseCustomerProfile>());

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.PutLockStatus.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.PutLockStatus.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            return Task.CompletedTask;
        }
    }

    public class DeleteCustomerManager : CreditLockServiceCustomerManagerTests
    {
        public static IEnumerable<object[]> PutLockStatusLogInformationMessages()
        {
            yield return new object[]
            {
                LogEventNames.CreditLockServiceCustomerManager.DeleteCustomer.Enter
            };

            yield return new object[]
            {
                LogEventNames.CreditLockServiceCustomerManager.DeleteCustomer.Exit
            };
        }

        [Theory]
        [MemberData(nameof(PutLockStatusLogInformationMessages))]
        public async Task HappyPathInformationLogged(string loggerMessage)
        {
            var deleteCustomerRequest = new DeleteCustomerRequest
            {
                CustomerId = "a69e102d-d776-490a-a0a1-dfe25c791df9"
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = deleteCustomerRequest.CustomerId
            };

            _customersClientProxy.GetCustomerProfile(deleteCustomerRequest.CustomerId)
                .Returns(getResponseCustomerProfile);

            await _creditLockServiceCustomerManager.DeleteCustomer(deleteCustomerRequest);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(loggerMessage)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public void DeleteCustomer_RequestNull_ThrowsArgumentNullException()
        {
            var task = async () => { await _creditLockServiceCustomerManager.DeleteCustomer(null); };

            task.Should()
                .Throw<ArgumentNullException>()
                .Where(x => x.ParamName == "deleteCustomerRequest");

            _deleteCustomerCommand.DidNotReceive().Execute(Arg.Any<DeleteCustomerRequest>(), Arg.Any<GetResponseCustomerProfile>());

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.DeleteCustomer.Enter)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.DeleteCustomer.Exit)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Theory]
        [InlineData(null)]
        [InlineData("")]
        [InlineData("      ")]
        public void DeleteCustomerRequestCustomerIdNull_ThrowsArgumentNullException(string customerId)
        {
            var deleteCustomerRequest = new DeleteCustomerRequest
            {
                CustomerId = customerId
            };

            var task = async () => { await _creditLockServiceCustomerManager.DeleteCustomer(deleteCustomerRequest); };

            task.Should()
                .Throw<ArgumentException>()
                .WithMessage("CustomerId cannot be null or whitespace (Parameter 'deleteCustomerRequest')");

            _deleteCustomerCommand.DidNotReceive().Execute(Arg.Any<DeleteCustomerRequest>(), Arg.Any<GetResponseCustomerProfile>());

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.DeleteCustomer.Enter)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.DeleteCustomer.Exit)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public async Task ValidCustomerId_DeleteCustomerRequests_Success()
        {
            const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

            var deleteCustomerRequest = new DeleteCustomerRequest
            {
                CustomerId = customerId
            };

            await _creditLockServiceCustomerManager.DeleteCustomer(deleteCustomerRequest);

            _deleteCustomerCommand.Received(1).Execute(deleteCustomerRequest, null);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.DeleteCustomer.Enter)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.DeleteCustomer.Exit)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public void DeleteCustomer_ValidCustomer_DownstreamMaintenance_ThrowException()
        {
            const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

            var deleteCustomerRequest = new DeleteCustomerRequest
            {
                CustomerId = customerId
            };

            _deleteCustomerCommand.Execute(deleteCustomerRequest, null)
                .Throws(new AggregateException(new DownstreamMaintenanceException("Test Message")));

            var task = async () => { await _creditLockServiceCustomerManager.DeleteCustomer(deleteCustomerRequest); };

            task.Should()
                .Throw<DownstreamMaintenanceException>()
                .WithMessage("Test Message");

            _deleteCustomerCommand.Received(1).Execute(deleteCustomerRequest, null);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.DeleteCustomer.Enter)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.DeleteCustomer.Exit)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public void DeleteCustomer_ValidCustomer_HttpServiceRequestException_ThrowException()
        {
            const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

            var deleteCustomerRequest = new DeleteCustomerRequest
            {
                CustomerId = customerId
            };

            _deleteCustomerCommand.Execute(deleteCustomerRequest, null)
                .Throws(new AggregateException(new HttpServiceRequestException("Test Message")));

            var task = async () => { await _creditLockServiceCustomerManager.DeleteCustomer(deleteCustomerRequest); };

            task.Should()
                .Throw<HttpServiceRequestException>()
                .WithMessage("Test Message");

            _deleteCustomerCommand.Received(1).Execute(deleteCustomerRequest, null);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.DeleteCustomer.Enter)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.DeleteCustomer.Exit)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public void DeleteCustomer_ValidCustomer_ServiceUnavailableException_ThrowException()
        {
            const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

            var deleteCustomerRequest = new DeleteCustomerRequest
            {
                CustomerId = customerId
            };

            _deleteCustomerCommand.Execute(deleteCustomerRequest, null)
                .Throws(new AggregateException(new ServiceUnavailableException("Test Message")));

            var task = async () => { await _creditLockServiceCustomerManager.DeleteCustomer(deleteCustomerRequest); };

            task.Should()
                .Throw<ServiceUnavailableException>()
                .WithMessage("Test Message");

            _deleteCustomerCommand.Received(1).Execute(deleteCustomerRequest, null);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.DeleteCustomer.Enter)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.DeleteCustomer.Exit)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public void DeleteCustomer_ValidCustomer_TaskCanceledException_ThrowException()
        {
            const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

            var deleteCustomerRequest = new DeleteCustomerRequest
            {
                CustomerId = customerId
            };

            _deleteCustomerCommand.Execute(deleteCustomerRequest, null)
                .Throws(new AggregateException(new TaskCanceledException("Test Message")));

            var task = async () => { await _creditLockServiceCustomerManager.DeleteCustomer(deleteCustomerRequest); };

            task.Should()
                .Throw<TaskCanceledException>()
                .WithMessage("A task was canceled.");

            _deleteCustomerCommand.Received(1).Execute(deleteCustomerRequest, null);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.DeleteCustomer.Enter)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.DeleteCustomer.Exit)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public void DeleteCustomer_ValidCustomer_CustomerNotFoundException_ThrowException()
        {
            const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

            var deleteCustomerRequest = new DeleteCustomerRequest
            {
                CustomerId = customerId
            };

            _deleteCustomerCommand.Execute(deleteCustomerRequest, null)
                .Throws(new AggregateException(new CustomerNotFoundException("Test Message")));

            var task = async () => { await _creditLockServiceCustomerManager.DeleteCustomer(deleteCustomerRequest); };

            task.Should()
                .Throw<CustomerNotFoundException>()
                .WithMessage("Test Message");

            _deleteCustomerCommand.Received(1).Execute(deleteCustomerRequest, null);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.DeleteCustomer.Enter)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.DeleteCustomer.Exit)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public void DeleteCustomer_ValidCustomer_OktaTokenNullException_ThrowException()
        {
            const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

            var deleteCustomerRequest = new DeleteCustomerRequest
            {
                CustomerId = customerId
            };

            _deleteCustomerCommand.Execute(deleteCustomerRequest, null)
                .Throws(new AggregateException(new OktaTokenNullException("Test Message")));

            var task = async () => { await _creditLockServiceCustomerManager.DeleteCustomer(deleteCustomerRequest); };

            task.Should()
                .Throw<OktaTokenNullException>()
                .WithMessage("Test Message");

            _deleteCustomerCommand.Received(1).Execute(deleteCustomerRequest, null);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.DeleteCustomer.Enter)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.DeleteCustomer.Exit)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public void DeleteCustomer_ValidCustomer_OktaException_ThrowException()
        {
            const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

            var deleteCustomerRequest = new DeleteCustomerRequest
            {
                CustomerId = customerId
            };

            _deleteCustomerCommand.Execute(deleteCustomerRequest, null)
                .Throws(new AggregateException(new OktaException("Test Message")));

            var task = async () => { await _creditLockServiceCustomerManager.DeleteCustomer(deleteCustomerRequest); };

            task.Should()
                .Throw<OktaException>()
                .WithMessage("Test Message");

            _deleteCustomerCommand.Received(1).Execute(deleteCustomerRequest, null);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.DeleteCustomer.Enter)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.DeleteCustomer.Exit)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public void DeleteCustomer_ValidCustomer_UnhandledException_ThrowException()
        {
            const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

            var deleteCustomerRequest = new DeleteCustomerRequest
            {
                CustomerId = customerId
            };

            _deleteCustomerCommand.Execute(deleteCustomerRequest, null)
                .Throws(new AggregateException(new Exception("Test Message")));

            var task = async () => { await _creditLockServiceCustomerManager.DeleteCustomer(deleteCustomerRequest); };

            task.Should()
                .Throw<Exception>()
                .WithMessage("Test Message");

            _deleteCustomerCommand.Received(1).Execute(deleteCustomerRequest, null);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.DeleteCustomer.Enter)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.DeleteCustomer.Exit)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }
    }

    public class DeactivateInstantAlertCustomerManager : CreditLockServiceCustomerManagerTests
    {
        public static IEnumerable<object[]> DeactivateInstantAlertLogInformationMessages()
        {
            yield return new object[]
            {
                LogEventNames.CreditLockServiceCustomerManager.DeactivateInstantAlert.Enter
            };

            yield return new object[]
            {
                LogEventNames.CreditLockServiceCustomerManager.DeactivateInstantAlert.Exit
            };
        }

        [Theory]
        [MemberData(nameof(DeactivateInstantAlertLogInformationMessages))]
        public async Task HappyPathInformationLogged(string loggerMessage)
        {
            var deactivateInstantAlert = new PostDeactivateInstantAlertRequest
            {
                CustomerId = "a69e102d-d776-490a-a0a1-dfe25c791df9"
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = deactivateInstantAlert.CustomerId
            };

            _customersClientProxy.GetCustomerProfile(deactivateInstantAlert.CustomerId)
                .Returns(getResponseCustomerProfile);

            await _creditLockServiceCustomerManager.DeactivateInstantAlert(deactivateInstantAlert);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(loggerMessage)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public void DeactivateInstantAlert_RequestNull_ThrowsArgumentNullException()
        {
            var task = async () => { await _creditLockServiceCustomerManager.DeactivateInstantAlert(null); };

            task.Should()
                .Throw<ArgumentNullException>()
                .Where(x => x.ParamName == "postDeactivateInstantAlertRequest");

            _deactivateInstantAlertCommand.DidNotReceive().Execute(Arg.Any<PostDeactivateInstantAlertRequest>(), Arg.Any<GetResponseCustomerProfile>());

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.DeactivateInstantAlert.Enter)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.DeactivateInstantAlert.Exit)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Theory]
        [InlineData(null)]
        [InlineData("")]
        [InlineData("      ")]
        public void DeactivateInstantAlertRequestCustomerIdNull_ThrowsArgumentNullException(string customerId)
        {
            var deactivateInstantAlert = new PostDeactivateInstantAlertRequest
            {
                CustomerId = customerId
            };

            var task = async () => { await _creditLockServiceCustomerManager.DeactivateInstantAlert(deactivateInstantAlert); };

            task.Should()
                .Throw<ArgumentException>()
                .WithMessage("CustomerId cannot be null or whitespace (Parameter 'postDeactivateInstantAlertRequest')");

            _deactivateInstantAlertCommand.DidNotReceive().Execute(Arg.Any<PostDeactivateInstantAlertRequest>(), Arg.Any<GetResponseCustomerProfile>());

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.DeactivateInstantAlert.Enter)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.DeactivateInstantAlert.Exit)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public async Task ValidCustomerId_DeactivateInstantAlert_Success()
        {
            var deactivateInstantAlertRequest = new PostDeactivateInstantAlertRequest
            {
                CustomerId = "a69e102d-d776-490a-a0a1-dfe25c791df9"
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = deactivateInstantAlertRequest.CustomerId
            };

            _customersClientProxy.GetCustomerProfile(deactivateInstantAlertRequest.CustomerId)
                .Returns(getResponseCustomerProfile);

            await _creditLockServiceCustomerManager.DeactivateInstantAlert(deactivateInstantAlertRequest);

            _deactivateInstantAlertCommand.Received(1).Execute(deactivateInstantAlertRequest, getResponseCustomerProfile);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.DeactivateInstantAlert.Enter)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.DeactivateInstantAlert.Exit)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public void ValidCustomerId_DeactivateInstantAlert_GetThrowsOktaTokenNullException_Fails()
        {
            var deactivateInstantAlertRequest = new PostDeactivateInstantAlertRequest
            {
                CustomerId = "a69e102d-d776-490a-a0a1-dfe25c791df9"
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = deactivateInstantAlertRequest.CustomerId
            };

            _customersClientProxy.GetCustomerProfile(deactivateInstantAlertRequest.CustomerId)
                .Returns(getResponseCustomerProfile);

            _deactivateInstantAlertCommand.Execute(deactivateInstantAlertRequest, getResponseCustomerProfile)
                .Throws(new AggregateException(new OktaTokenNullException("Test OktaTokenNullException Message")));

            var task = async () => { await _creditLockServiceCustomerManager.DeactivateInstantAlert(deactivateInstantAlertRequest); };

            task.Should()
                .Throw<OktaTokenNullException>()
                .WithMessage("Test OktaTokenNullException Message");

            _deactivateInstantAlertCommand.Received(1).Execute(deactivateInstantAlertRequest, getResponseCustomerProfile);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.DeactivateInstantAlert.Enter)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.DeactivateInstantAlert.Exit)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public void ValidCustomerId_DeactivateInstantAlert_TaskCanceledException_Fails()
        {
            var deactivateInstantAlertRequest = new PostDeactivateInstantAlertRequest
            {
                CustomerId = "a69e102d-d776-490a-a0a1-dfe25c791df9"
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = deactivateInstantAlertRequest.CustomerId
            };

            _customersClientProxy.GetCustomerProfile(deactivateInstantAlertRequest.CustomerId)
                .Returns(getResponseCustomerProfile);

            _deactivateInstantAlertCommand.Execute(deactivateInstantAlertRequest, getResponseCustomerProfile)
                .Throws(new AggregateException(new TaskCanceledException()));

            var task = async () => { await _creditLockServiceCustomerManager.DeactivateInstantAlert(deactivateInstantAlertRequest); };

            task.Should()
                .Throw<TaskCanceledException>()
                .WithMessage("A task was canceled.");

            _deactivateInstantAlertCommand.Received(1).Execute(deactivateInstantAlertRequest, getResponseCustomerProfile);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.DeactivateInstantAlert.Enter)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.DeactivateInstantAlert.Exit)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public void ValidCustomerId_DeactivateInstantAlert_HttpServiceRequestException_Fails()
        {
            var deactivateInstantAlertRequest = new PostDeactivateInstantAlertRequest
            {
                CustomerId = "a69e102d-d776-490a-a0a1-dfe25c791df9"
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = deactivateInstantAlertRequest.CustomerId
            };

            _customersClientProxy.GetCustomerProfile(deactivateInstantAlertRequest.CustomerId)
                .Returns(getResponseCustomerProfile);

            _deactivateInstantAlertCommand.Execute(deactivateInstantAlertRequest, getResponseCustomerProfile)
                .Throws(new AggregateException(new HttpServiceRequestException("Test Message")));

            var task = async () => { await _creditLockServiceCustomerManager.DeactivateInstantAlert(deactivateInstantAlertRequest); };

            task.Should()
                .Throw<HttpServiceRequestException>()
                .WithMessage("Test Message");

            _deactivateInstantAlertCommand.Received(1).Execute(deactivateInstantAlertRequest, getResponseCustomerProfile);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.DeactivateInstantAlert.Enter)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.DeactivateInstantAlert.Exit)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public void ValidCustomerId_DeactivateInstantAlert_DownstreamMaintenanceException_Fails()
        {
            var deactivateInstantAlertRequest = new PostDeactivateInstantAlertRequest
            {
                CustomerId = "a69e102d-d776-490a-a0a1-dfe25c791df9"
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = deactivateInstantAlertRequest.CustomerId
            };

            _customersClientProxy.GetCustomerProfile(deactivateInstantAlertRequest.CustomerId)
                .Returns(getResponseCustomerProfile);

            _deactivateInstantAlertCommand.Execute(deactivateInstantAlertRequest, getResponseCustomerProfile)
                .Throws(new AggregateException(new DownstreamMaintenanceException("Test Message")));

            var task = async () => { await _creditLockServiceCustomerManager.DeactivateInstantAlert(deactivateInstantAlertRequest); };

            task.Should()
                .Throw<DownstreamMaintenanceException>()
                .WithMessage("Test Message");

            _deactivateInstantAlertCommand.Received(1).Execute(deactivateInstantAlertRequest, getResponseCustomerProfile);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.DeactivateInstantAlert.Enter)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.DeactivateInstantAlert.Exit)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public void ValidCustomerId_DeactivateInstantAlert_ServiceUnavailableException_Fails()
        {
            var deactivateInstantAlertRequest = new PostDeactivateInstantAlertRequest
            {
                CustomerId = "a69e102d-d776-490a-a0a1-dfe25c791df9"
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = deactivateInstantAlertRequest.CustomerId
            };

            _customersClientProxy.GetCustomerProfile(deactivateInstantAlertRequest.CustomerId)
                .Returns(getResponseCustomerProfile);

            _deactivateInstantAlertCommand.Execute(deactivateInstantAlertRequest, getResponseCustomerProfile)
                .Throws(new AggregateException(new ServiceUnavailableException("Test Message")));

            var task = async () => { await _creditLockServiceCustomerManager.DeactivateInstantAlert(deactivateInstantAlertRequest); };

            task.Should()
                .Throw<ServiceUnavailableException>()
                .WithMessage("Test Message");

            _deactivateInstantAlertCommand.Received(1).Execute(deactivateInstantAlertRequest, getResponseCustomerProfile);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.DeactivateInstantAlert.Enter)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.DeactivateInstantAlert.Exit)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public void ValidCustomerId_DeactivateInstantAlert_OktaException_Fails()
        {
            var deactivateInstantAlertRequest = new PostDeactivateInstantAlertRequest
            {
                CustomerId = "a69e102d-d776-490a-a0a1-dfe25c791df9"
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = deactivateInstantAlertRequest.CustomerId
            };

            _customersClientProxy.GetCustomerProfile(deactivateInstantAlertRequest.CustomerId)
                .Returns(getResponseCustomerProfile);

            _deactivateInstantAlertCommand.Execute(deactivateInstantAlertRequest, getResponseCustomerProfile)
                .Throws(new AggregateException(new OktaException("Test Message")));

            var task = async () => { await _creditLockServiceCustomerManager.DeactivateInstantAlert(deactivateInstantAlertRequest); };

            task.Should()
                .Throw<OktaException>()
                .WithMessage("Test Message");

            _deactivateInstantAlertCommand.Received(1).Execute(deactivateInstantAlertRequest, getResponseCustomerProfile);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.DeactivateInstantAlert.Enter)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.DeactivateInstantAlert.Exit)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public void ValidCustomerId_DeactivateInstantAlert_DownstreamBadResponseException_Fails()
        {
            var deactivateInstantAlertRequest = new PostDeactivateInstantAlertRequest
            {
                CustomerId = "a69e102d-d776-490a-a0a1-dfe25c791df9"
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = deactivateInstantAlertRequest.CustomerId
            };

            _customersClientProxy.GetCustomerProfile(deactivateInstantAlertRequest.CustomerId)
                .Returns(getResponseCustomerProfile);

            _deactivateInstantAlertCommand.Execute(deactivateInstantAlertRequest, getResponseCustomerProfile)
                .Throws(new AggregateException(new DownstreamBadResponseException("Test Message")));

            var task = async () => { await _creditLockServiceCustomerManager.DeactivateInstantAlert(deactivateInstantAlertRequest); };

            task.Should()
                .Throw<DownstreamBadResponseException>()
                .WithMessage("Test Message");

            _deactivateInstantAlertCommand.Received(1).Execute(deactivateInstantAlertRequest, getResponseCustomerProfile);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.DeactivateInstantAlert.Enter)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.DeactivateInstantAlert.Exit)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public void ValidCustomerId_DeactivateInstantAlert_CustomerNotFoundException_Fails()
        {
            var deactivateInstantAlertRequest = new PostDeactivateInstantAlertRequest
            {
                CustomerId = "a69e102d-d776-490a-a0a1-dfe25c791df9"
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = deactivateInstantAlertRequest.CustomerId
            };

            _customersClientProxy.GetCustomerProfile(deactivateInstantAlertRequest.CustomerId)
                .Returns(getResponseCustomerProfile);

            _deactivateInstantAlertCommand.Execute(deactivateInstantAlertRequest, getResponseCustomerProfile)
                .Throws(new AggregateException(new CustomerNotFoundException("Test Message")));

            var task = async () => { await _creditLockServiceCustomerManager.DeactivateInstantAlert(deactivateInstantAlertRequest); };

            task.Should()
                .Throw<CustomerNotFoundException>()
                .WithMessage("Test Message");

            _deactivateInstantAlertCommand.Received(1).Execute(deactivateInstantAlertRequest, getResponseCustomerProfile);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.DeactivateInstantAlert.Enter)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.DeactivateInstantAlert.Exit)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public void ValidCustomerId_DeactivateInstantAlert_CustomerProfileNotFoundException_Fails()
        {
            const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

            var deactivateInstantAlertRequest = new PostDeactivateInstantAlertRequest
            {
                CustomerId = customerId
            };

            _customersClientProxy.GetCustomerProfile(customerId)
                .ReturnsNull();

            var task = async () => { await _creditLockServiceCustomerManager.DeactivateInstantAlert(deactivateInstantAlertRequest); };

            task.Should()
                .Throw<CustomerProfileNotFoundException>()
                .WithMessage($"{customerId} customer profile not found");

            _deactivateInstantAlertCommand.DidNotReceive().Execute(Arg.Any<PostDeactivateInstantAlertRequest>(), Arg.Any<GetResponseCustomerProfile>());

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.DeactivateInstantAlert.Enter)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.DeactivateInstantAlert.Exit)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }
    }

    public class UpdateCustomerManager : CreditLockServiceCustomerManagerTests
    {
        public static IEnumerable<object[]> UpdateLogInformationMessages()
        {
            yield return new object[]
            {
                LogEventNames.CreditLockServiceCustomerManager.Update.Enter
            };

            yield return new object[]
            {
                LogEventNames.CreditLockServiceCustomerManager.Update.Exit
            };
        }

        [Theory]
        [MemberData(nameof(UpdateLogInformationMessages))]
        public async Task HappyPathInformationLogged(string loggerMessage)
        {
            const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

            var putCustomerRequest = new PutCustomerRequest
            {
                CustomerId = customerId
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = customerId
            };

            _customersClientProxy.GetCustomerProfile(customerId)
                .Returns(getResponseCustomerProfile);

            _syncCustomerCommand.Execute(putCustomerRequest, getResponseCustomerProfile).Returns(new PutCustomerResponse
            {
                HasMadeSyncRequest = true
            });

            await _creditLockServiceCustomerManager.UpdateCustomer(putCustomerRequest);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(loggerMessage)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public void UpdateCustomer_RequestNull_ThrowsArgumentNullException()
        {
            var task = async () => { await _creditLockServiceCustomerManager.UpdateCustomer(null); };

            task.Should()
                .Throw<ArgumentNullException>()
                .Where(x => x.ParamName == "putCustomerRequest");

            _syncCustomerCommand.DidNotReceive().Execute(Arg.Any<PutCustomerRequest>(), Arg.Any<GetResponseCustomerProfile>());
        }

        [Theory]
        [InlineData(null)]
        [InlineData("")]
        [InlineData("      ")]
        public void UpdateCustomerIdNull_ThrowsArgumentNullException(string customerId)
        {
            var putCustomerRequest = new PutCustomerRequest
            {
                CustomerId = customerId
            };

            var task = async () => { await _creditLockServiceCustomerManager.UpdateCustomer(putCustomerRequest); };

            task.Should()
                .Throw<ArgumentException>()
                .WithMessage("CustomerId cannot be null or whitespace (Parameter 'putCustomerRequest')");

            _syncCustomerCommand.DidNotReceive().Execute(Arg.Any<PutCustomerRequest>(), Arg.Any<GetResponseCustomerProfile>());

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Update.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Update.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public async Task ValidCustomerId_Update_Success()
        {
            const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

            var putCustomerRequest = new PutCustomerRequest
            {
                CustomerId = customerId
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = customerId
            };

            _customersClientProxy.GetCustomerProfile(customerId)
                .Returns(getResponseCustomerProfile);

            _syncCustomerCommand.Execute(putCustomerRequest, getResponseCustomerProfile).Returns(new PutCustomerResponse
            {
                HasMadeSyncRequest = true
            });

            await _creditLockServiceCustomerManager.UpdateCustomer(putCustomerRequest);

            _syncCustomerCommand.Received(1).Execute(putCustomerRequest, getResponseCustomerProfile);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Update.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Update.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public void ValidCustomerId_UpdateCustomer_CustomerProfileNotFoundException_Fails()
        {
            const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

            var putCustomerRequest = new PutCustomerRequest
            {
                CustomerId = customerId
            };

            _customersClientProxy.GetCustomerProfile(customerId)
                .ReturnsNull();

            var task = async () => { await _creditLockServiceCustomerManager.UpdateCustomer(putCustomerRequest); };

            task.Should()
                .Throw<CustomerProfileNotFoundException>()
                .WithMessage($"{customerId} customer profile not found");

            _syncCustomerCommand.DidNotReceive().Execute(Arg.Any<PutCustomerRequest>(), Arg.Any<GetResponseCustomerProfile>());

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Update.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Update.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public void ValidCustomerId_UpdateCustomer_OktaTokenNullException_Fails()
        {
            const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

            var putCustomerRequest = new PutCustomerRequest
            {
                CustomerId = customerId
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = customerId
            };

            _customersClientProxy.GetCustomerProfile(customerId)
                .Returns(getResponseCustomerProfile);

            _syncCustomerCommand.Execute(putCustomerRequest, getResponseCustomerProfile)
                .Throws(new AggregateException(new OktaTokenNullException()));

            var task = async () => { await _creditLockServiceCustomerManager.UpdateCustomer(putCustomerRequest); };

            task.Should()
                .Throw<OktaTokenNullException>();

            _syncCustomerCommand.Received(1).Execute(Arg.Any<PutCustomerRequest>(), Arg.Any<GetResponseCustomerProfile>());

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Update.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Update.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public void ValidCustomerId_UpdateCustomer_DownstreamMaintenanceException_Fails()
        {
            const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

            var putCustomerRequest = new PutCustomerRequest
            {
                CustomerId = customerId
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = customerId
            };

            _customersClientProxy.GetCustomerProfile(customerId)
                .Returns(getResponseCustomerProfile);

            _syncCustomerCommand.Execute(putCustomerRequest, getResponseCustomerProfile)
                .Throws(new AggregateException(new DownstreamMaintenanceException()));

            var task = async () => { await _creditLockServiceCustomerManager.UpdateCustomer(putCustomerRequest); };

            task.Should()
                .Throw<DownstreamMaintenanceException>();

            _syncCustomerCommand.Received(1).Execute(Arg.Any<PutCustomerRequest>(), Arg.Any<GetResponseCustomerProfile>());

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Update.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Update.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public void ValidCustomerId_UpdateCustomer_DownstreamBadResponseException_Fails()
        {
            const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

            var putCustomerRequest = new PutCustomerRequest
            {
                CustomerId = customerId
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = customerId
            };

            _customersClientProxy.GetCustomerProfile(customerId)
                .Returns(getResponseCustomerProfile);

            _syncCustomerCommand.Execute(putCustomerRequest, getResponseCustomerProfile)
                .Throws(new AggregateException(new DownstreamBadResponseException()));

            var task = async () => { await _creditLockServiceCustomerManager.UpdateCustomer(putCustomerRequest); };

            task.Should()
                .Throw<DownstreamBadResponseException>();

            _syncCustomerCommand.Received(1).Execute(Arg.Any<PutCustomerRequest>(), Arg.Any<GetResponseCustomerProfile>());

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Update.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Update.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public void ValidCustomerId_UpdateCustomer_HttpServiceRequestException_Fails()
        {
            const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

            var putCustomerRequest = new PutCustomerRequest
            {
                CustomerId = customerId
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = customerId
            };

            _customersClientProxy.GetCustomerProfile(customerId)
                .Returns(getResponseCustomerProfile);

            _syncCustomerCommand.Execute(putCustomerRequest, getResponseCustomerProfile)
                .Throws(new AggregateException(new HttpServiceRequestException()));

            var task = async () => { await _creditLockServiceCustomerManager.UpdateCustomer(putCustomerRequest); };

            task.Should()
                .Throw<HttpServiceRequestException>();

            _syncCustomerCommand.Received(1).Execute(Arg.Any<PutCustomerRequest>(), Arg.Any<GetResponseCustomerProfile>());

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Update.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Update.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public void ValidCustomerId_UpdateCustomer_ServiceUnavailableException_Fails()
        {
            const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

            var putCustomerRequest = new PutCustomerRequest
            {
                CustomerId = customerId
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = customerId
            };

            _customersClientProxy.GetCustomerProfile(customerId)
                .Returns(getResponseCustomerProfile);

            _syncCustomerCommand.Execute(putCustomerRequest, getResponseCustomerProfile)
                .Throws(new AggregateException(new ServiceUnavailableException()));

            var task = async () => { await _creditLockServiceCustomerManager.UpdateCustomer(putCustomerRequest); };

            task.Should()
                .Throw<ServiceUnavailableException>();

            _syncCustomerCommand.Received(1).Execute(Arg.Any<PutCustomerRequest>(), Arg.Any<GetResponseCustomerProfile>());

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Update.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Update.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public void ValidCustomerId_UpdateCustomer_TaskCanceledException_Fails()
        {
            const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

            var putCustomerRequest = new PutCustomerRequest
            {
                CustomerId = customerId
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = customerId
            };

            _customersClientProxy.GetCustomerProfile(customerId)
                .Returns(getResponseCustomerProfile);

            _syncCustomerCommand.Execute(putCustomerRequest, getResponseCustomerProfile)
                .Throws(new AggregateException(new TaskCanceledException()));

            var task = async () => { await _creditLockServiceCustomerManager.UpdateCustomer(putCustomerRequest); };

            task.Should()
                .Throw<TaskCanceledException>();

            _syncCustomerCommand.Received(1).Execute(Arg.Any<PutCustomerRequest>(), Arg.Any<GetResponseCustomerProfile>());

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Update.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Update.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public void ValidCustomerId_UpdateCustomer_OktaException_Fails()
        {
            const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

            var putCustomerRequest = new PutCustomerRequest
            {
                CustomerId = customerId
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = customerId
            };

            _customersClientProxy.GetCustomerProfile(customerId)
                .Returns(getResponseCustomerProfile);

            _syncCustomerCommand.Execute(putCustomerRequest, getResponseCustomerProfile)
                .Throws(new AggregateException(new OktaException()));

            var task = async () => { await _creditLockServiceCustomerManager.UpdateCustomer(putCustomerRequest); };

            task.Should()
                .Throw<OktaException>();

            _syncCustomerCommand.Received(1).Execute(Arg.Any<PutCustomerRequest>(), Arg.Any<GetResponseCustomerProfile>());

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Update.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Update.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public void ValidCustomerId_UpdateCustomer_Exception_Fails()
        {
            const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

            var putCustomerRequest = new PutCustomerRequest
            {
                CustomerId = customerId
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = customerId
            };

            _customersClientProxy.GetCustomerProfile(customerId)
                .Returns(getResponseCustomerProfile);

            _syncCustomerCommand.Execute(putCustomerRequest, getResponseCustomerProfile)
                .Throws(new AggregateException(new Exception()));

            var task = async () => { await _creditLockServiceCustomerManager.UpdateCustomer(putCustomerRequest); };

            task.Should()
                .Throw<Exception>();

            _syncCustomerCommand.Received(1).Execute(Arg.Any<PutCustomerRequest>(), Arg.Any<GetResponseCustomerProfile>());

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Update.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Update.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public async Task ValidCustomerId_UpdateCustomer_NoRequestMade_Success()
        {
            const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

            var putCustomerRequest = new PutCustomerRequest
            {
                CustomerId = customerId
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = customerId
            };

            _customersClientProxy.GetCustomerProfile(customerId)
                .Returns(getResponseCustomerProfile);

            _syncCustomerCommand.Execute(putCustomerRequest, getResponseCustomerProfile).Returns(new PutCustomerResponse
            {
                HasMadeSyncRequest = false
            });

            await _creditLockServiceCustomerManager.UpdateCustomer(putCustomerRequest);

            _syncCustomerCommand.Received(1).Execute(putCustomerRequest, getResponseCustomerProfile);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Update.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Sync.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(), Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.Update.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }
    }

    public class ActivateInstantAlertCustomerManager : CreditLockServiceCustomerManagerTests
    {
        public static IEnumerable<object[]> ActivateInstantAlertLogInformationMessages()
        {
            yield return new object[]
            {
                LogEventNames.CreditLockServiceCustomerManager.ActivateInstantAlert.Enter
            };

            yield return new object[]
            {
                LogEventNames.CreditLockServiceCustomerManager.ActivateInstantAlert.Exit
            };
        }

        [Theory]
        [MemberData(nameof(ActivateInstantAlertLogInformationMessages))]
        public async Task HappyPathInformationLogged(string loggerMessage)
        {
            var activateInstantAlert = new PostActivateInstantAlertRequest
            {
                CustomerId = "a69e102d-d776-490a-a0a1-dfe25c791df9"
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = activateInstantAlert.CustomerId
            };

            _customersClientProxy.GetCustomerProfile(activateInstantAlert.CustomerId)
                .Returns(getResponseCustomerProfile);

            await _creditLockServiceCustomerManager.ActivateInstantAlert(activateInstantAlert);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(loggerMessage)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public void ActivateInstantAlert_RequestNull_ThrowsArgumentNullException()
        {
            var task = async () => { await _creditLockServiceCustomerManager.ActivateInstantAlert(null); };

            task.Should()
                .Throw<ArgumentNullException>()
                .Where(x => x.ParamName == "postActivateInstantAlertRequest");

            _activateInstantAlertCommand.DidNotReceive().Execute(Arg.Any<PostActivateInstantAlertRequest>(), Arg.Any<GetResponseCustomerProfile>());

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.ActivateInstantAlert.Enter)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.ActivateInstantAlert.Exit)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Theory]
        [InlineData(null)]
        [InlineData("")]
        [InlineData("      ")]
        public void ActivateInstantAlertRequestCustomerIdNull_ThrowsArgumentNullException(string customerId)
        {
            var activateInstantAlert = new PostActivateInstantAlertRequest
            {
                CustomerId = customerId
            };

            var task = async () => { await _creditLockServiceCustomerManager.ActivateInstantAlert(activateInstantAlert); };

            task.Should()
                .Throw<ArgumentException>()
                .WithMessage("CustomerId cannot be null or whitespace (Parameter 'postActivateInstantAlertRequest')");

            _activateInstantAlertCommand.DidNotReceive().Execute(Arg.Any<PostActivateInstantAlertRequest>(), Arg.Any<GetResponseCustomerProfile>());

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.ActivateInstantAlert.Enter)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.ActivateInstantAlert.Exit)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public async Task ValidCustomerId_ActivateInstantAlert_Success()
        {
            var activateInstantAlertRequest = new PostActivateInstantAlertRequest
            {
                CustomerId = "a69e102d-d776-490a-a0a1-dfe25c791df9"
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = activateInstantAlertRequest.CustomerId
            };

            _customersClientProxy.GetCustomerProfile(activateInstantAlertRequest.CustomerId)
                .Returns(getResponseCustomerProfile);

            await _creditLockServiceCustomerManager.ActivateInstantAlert(activateInstantAlertRequest);

            _activateInstantAlertCommand.Received(1).Execute(activateInstantAlertRequest, getResponseCustomerProfile);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.ActivateInstantAlert.Enter)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.ActivateInstantAlert.Exit)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public void ValidCustomerId_ActivateInstantAlert_GetThrowsOktaTokenNullException_Fails()
        {
            var activateInstantAlertRequest = new PostActivateInstantAlertRequest
            {
                CustomerId = "a69e102d-d776-490a-a0a1-dfe25c791df9"
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = activateInstantAlertRequest.CustomerId
            };

            _customersClientProxy.GetCustomerProfile(activateInstantAlertRequest.CustomerId)
                .Returns(getResponseCustomerProfile);

            _activateInstantAlertCommand.Execute(activateInstantAlertRequest, getResponseCustomerProfile)
                .Throws(new AggregateException(new OktaTokenNullException("Test OktaTokenNullException Message")));

            var task = async () => { await _creditLockServiceCustomerManager.ActivateInstantAlert(activateInstantAlertRequest); };

            task.Should()
                .Throw<OktaTokenNullException>()
                .WithMessage("Test OktaTokenNullException Message");

            _activateInstantAlertCommand.Received(1).Execute(activateInstantAlertRequest, getResponseCustomerProfile);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.ActivateInstantAlert.Enter)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.ActivateInstantAlert.Exit)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public void ValidCustomerId_ActivateInstantAlert_TaskCanceledException_Fails()
        {
            var activateInstantAlertRequest = new PostActivateInstantAlertRequest
            {
                CustomerId = "a69e102d-d776-490a-a0a1-dfe25c791df9"
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = activateInstantAlertRequest.CustomerId
            };

            _customersClientProxy.GetCustomerProfile(activateInstantAlertRequest.CustomerId)
                .Returns(getResponseCustomerProfile);

            _activateInstantAlertCommand.Execute(activateInstantAlertRequest, getResponseCustomerProfile)
                .Throws(new AggregateException(new TaskCanceledException()));

            var task = async () => { await _creditLockServiceCustomerManager.ActivateInstantAlert(activateInstantAlertRequest); };

            task.Should()
                .Throw<TaskCanceledException>()
                .WithMessage("A task was canceled.");

            _activateInstantAlertCommand.Received(1).Execute(activateInstantAlertRequest, getResponseCustomerProfile);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.ActivateInstantAlert.Enter)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.ActivateInstantAlert.Exit)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public void ValidCustomerId_ActivateInstantAlert_HttpServiceRequestException_Fails()
        {
            var activateInstantAlertRequest = new PostActivateInstantAlertRequest
            {
                CustomerId = "a69e102d-d776-490a-a0a1-dfe25c791df9"
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = activateInstantAlertRequest.CustomerId
            };

            _customersClientProxy.GetCustomerProfile(activateInstantAlertRequest.CustomerId)
                .Returns(getResponseCustomerProfile);

            _activateInstantAlertCommand.Execute(activateInstantAlertRequest, getResponseCustomerProfile)
                .Throws(new AggregateException(new HttpServiceRequestException("Test Message")));

            var task = async () => { await _creditLockServiceCustomerManager.ActivateInstantAlert(activateInstantAlertRequest); };

            task.Should()
                .Throw<HttpServiceRequestException>()
                .WithMessage("Test Message");

            _activateInstantAlertCommand.Received(1).Execute(activateInstantAlertRequest, getResponseCustomerProfile);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.ActivateInstantAlert.Enter)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.ActivateInstantAlert.Exit)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public void ValidCustomerId_ActivateInstantAlert_DownstreamMaintenanceException_Fails()
        {
            var activateInstantAlertRequest = new PostActivateInstantAlertRequest
            {
                CustomerId = "a69e102d-d776-490a-a0a1-dfe25c791df9"
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = activateInstantAlertRequest.CustomerId
            };

            _customersClientProxy.GetCustomerProfile(activateInstantAlertRequest.CustomerId)
                .Returns(getResponseCustomerProfile);

            _activateInstantAlertCommand.Execute(activateInstantAlertRequest, getResponseCustomerProfile)
                .Throws(new AggregateException(new DownstreamMaintenanceException("Test Message")));

            var task = async () => { await _creditLockServiceCustomerManager.ActivateInstantAlert(activateInstantAlertRequest); };

            task.Should()
                .Throw<DownstreamMaintenanceException>()
                .WithMessage("Test Message");

            _activateInstantAlertCommand.Received(1).Execute(activateInstantAlertRequest, getResponseCustomerProfile);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.ActivateInstantAlert.Enter)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.ActivateInstantAlert.Exit)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public void ValidCustomerId_ActivateInstantAlert_ServiceUnavailableException_Fails()
        {
            var activateInstantAlertRequest = new PostActivateInstantAlertRequest
            {
                CustomerId = "a69e102d-d776-490a-a0a1-dfe25c791df9"
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = activateInstantAlertRequest.CustomerId
            };

            _customersClientProxy.GetCustomerProfile(activateInstantAlertRequest.CustomerId)
                .Returns(getResponseCustomerProfile);

            _activateInstantAlertCommand.Execute(activateInstantAlertRequest, getResponseCustomerProfile)
                .Throws(new AggregateException(new ServiceUnavailableException("Test Message")));

            var task = async () => { await _creditLockServiceCustomerManager.ActivateInstantAlert(activateInstantAlertRequest); };

            task.Should()
                .Throw<ServiceUnavailableException>()
                .WithMessage("Test Message");

            _activateInstantAlertCommand.Received(1).Execute(activateInstantAlertRequest, getResponseCustomerProfile);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.ActivateInstantAlert.Enter)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.ActivateInstantAlert.Exit)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public void ValidCustomerId_ActivateInstantAlert_OktaException_Fails()
        {
            var activateInstantAlertRequest = new PostActivateInstantAlertRequest
            {
                CustomerId = "a69e102d-d776-490a-a0a1-dfe25c791df9"
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = activateInstantAlertRequest.CustomerId
            };

            _customersClientProxy.GetCustomerProfile(activateInstantAlertRequest.CustomerId)
                .Returns(getResponseCustomerProfile);

            _activateInstantAlertCommand.Execute(activateInstantAlertRequest, getResponseCustomerProfile)
                .Throws(new AggregateException(new OktaException("Test Message")));

            var task = async () => { await _creditLockServiceCustomerManager.ActivateInstantAlert(activateInstantAlertRequest); };

            task.Should()
                .Throw<OktaException>()
                .WithMessage("Test Message");

            _activateInstantAlertCommand.Received(1).Execute(activateInstantAlertRequest, getResponseCustomerProfile);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.ActivateInstantAlert.Enter)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.ActivateInstantAlert.Exit)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public void ValidCustomerId_ActivateInstantAlert_DownstreamBadResponseException_Fails()
        {
            var activateInstantAlertRequest = new PostActivateInstantAlertRequest
            {
                CustomerId = "a69e102d-d776-490a-a0a1-dfe25c791df9"
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = activateInstantAlertRequest.CustomerId
            };

            _customersClientProxy.GetCustomerProfile(activateInstantAlertRequest.CustomerId)
                .Returns(getResponseCustomerProfile);

            _activateInstantAlertCommand.Execute(activateInstantAlertRequest, getResponseCustomerProfile)
                .Throws(new AggregateException(new DownstreamBadResponseException("Test Message")));

            var task = async () => { await _creditLockServiceCustomerManager.ActivateInstantAlert(activateInstantAlertRequest); };

            task.Should()
                .Throw<DownstreamBadResponseException>()
                .WithMessage("Test Message");

            _activateInstantAlertCommand.Received(1).Execute(activateInstantAlertRequest, getResponseCustomerProfile);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.ActivateInstantAlert.Enter)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.ActivateInstantAlert.Exit)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public void ValidCustomerId_ActivateInstantAlert_CustomerNotFoundException_Fails()
        {
            var activateInstantAlertRequest = new PostActivateInstantAlertRequest
            {
                CustomerId = "a69e102d-d776-490a-a0a1-dfe25c791df9"
            };

            var getResponseCustomerProfile = new GetResponseCustomerProfile
            {
                CustomerId = activateInstantAlertRequest.CustomerId
            };

            _customersClientProxy.GetCustomerProfile(activateInstantAlertRequest.CustomerId)
                .Returns(getResponseCustomerProfile);

            _activateInstantAlertCommand.Execute(activateInstantAlertRequest, getResponseCustomerProfile)
                .Throws(new AggregateException(new CustomerNotFoundException("Test Message")));

            var task = async () => { await _creditLockServiceCustomerManager.ActivateInstantAlert(activateInstantAlertRequest); };

            task.Should()
                .Throw<CustomerNotFoundException>()
                .WithMessage("Test Message");

            _activateInstantAlertCommand.Received(1).Execute(activateInstantAlertRequest, getResponseCustomerProfile);

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.ActivateInstantAlert.Enter)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.ActivateInstantAlert.Exit)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }

        [Fact]
        public void ValidCustomerId_ActivateInstantAlert_CustomerProfileNotFoundException_Fails()
        {
            const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

            var activateInstantAlertRequest = new PostActivateInstantAlertRequest
            {
                CustomerId = customerId
            };

            _customersClientProxy.GetCustomerProfile(customerId)
                .ReturnsNull();

            var task = async () => { await _creditLockServiceCustomerManager.ActivateInstantAlert(activateInstantAlertRequest); };

            task.Should()
                .Throw<CustomerProfileNotFoundException>()
                .WithMessage($"{customerId} customer profile not found");

            _activateInstantAlertCommand.DidNotReceive().Execute(Arg.Any<PostActivateInstantAlertRequest>(), Arg.Any<GetResponseCustomerProfile>());

            _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.ActivateInstantAlert.Enter)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

            _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreditLockServiceCustomerManager.ActivateInstantAlert.Exit)), null,
                Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
        }
    }
}