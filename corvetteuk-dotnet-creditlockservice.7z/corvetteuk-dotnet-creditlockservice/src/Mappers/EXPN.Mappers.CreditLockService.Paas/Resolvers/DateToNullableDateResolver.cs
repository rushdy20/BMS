﻿using AutoMapper;
using System;

namespace EXPN.Mappers.CreditLockService.Paas.Resolvers
{
    public class DateToNullableDateResolver : IMemberValueResolver<object, object, DateTime, DateTime?>
    {
        public DateTime? Resolve(
            object source,
            object destination,
            DateTime sourceMember,
            DateTime? destMember,
            ResolutionContext context)
        {
            return sourceMember == destMember ? null : destMember;
        }
    }
}