﻿using EXPN.BusinessLayer.CreditLockService.Binders;
using EXPN.BusinessLayer.CreditLockService.Exceptions;
using FluentAssertions;
using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using Xunit;

namespace EXPN.UnitTest.CreditLockService.BusinessLayer.Exceptions
{
    public class NoBenefitExceptionTests
    {
        [Fact]
        public void DefaultConstructor_CreatesException()
        {
            var exception = new NoBenefitException(null, null);

            exception.Message.Should().Be("Exception of type 'EXPN.BusinessLayer.CreditLockService.Exceptions.NoBenefitException' was thrown.");
        }

        public static IEnumerable<object[]> SingleParams()
        {
            yield return new object[]
            {
                string.Empty
            };

            yield return new object[]
            {
                "test message"
            };
        }

        [Theory]
        [MemberData(nameof(SingleParams))]
        public void SingleParamConstructor_CreatesException(string message)
        {
            var exception = new NoBenefitException(message, "X999");

            exception.Message.Should().Be(message);
        }

        public static IEnumerable<object[]> DoubleParams()
        {
            yield return new object[]
            {
                null,
                null,
                "Exception of type 'EXPN.BusinessLayer.CreditLockService.Exceptions.NoBenefitException' was thrown."
            };

            yield return new object[]
            {
                string.Empty,
                string.Empty,
                string.Empty
            };

            yield return new object[]
            {
                "test message",
                "ABC123",
                "test message"
            };

            yield return new object[]
            {
                "test message 2",
                "X999",
                "test message 2"
            };
        }

        [Theory]
        [MemberData(nameof(DoubleParams))]
        public void DoubleParamConstructor_CreatesException(string message, string benefitsRequested, string expectedMessage)
        {
            var exception = new NoBenefitException(message, benefitsRequested);

            exception.Message.Should().Be(expectedMessage);
            exception.BenefitsRequested.Should().Be(benefitsRequested);
        }

        [Fact]
        public void Serialization_CreatesException()
        {
            const string expectedMsg = "Test";
            var ex = new NoBenefitException(expectedMsg, "X999");

            var formatter = new BinaryFormatter
            {
                Binder = new CreditLockBusinessExceptionBinder()
            };

            using (var s = new MemoryStream())
            {
                formatter.Serialize(s, ex);
                s.Position = 0;
                ex = formatter.Deserialize(s) as NoBenefitException;
            }

            ex?.Message.Should().Be(expectedMsg);
        }
    }

}