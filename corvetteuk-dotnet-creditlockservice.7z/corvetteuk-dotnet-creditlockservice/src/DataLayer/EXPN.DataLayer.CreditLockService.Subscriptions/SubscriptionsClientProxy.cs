﻿using Experian.AWS.Logging.Extensions;
using Experian.HttpClient.Services.Subscriptions.Internal.GET;
using Experian.HttpClient.Services.Subscriptions.Models.Internal;
using EXPN.DataLayer.CreditLockService.Common.Exceptions;
using EXPN.DataLayer.CreditLockService.Subscriptions.Constants;
using Microsoft.Extensions.Logging;

namespace EXPN.DataLayer.CreditLockService.Subscriptions;

public class SubscriptionsClientProxy : ISubscriptionsClientProxy
{
    private readonly ILogger<SubscriptionsClientProxy> _logger;
    private readonly IGetSubscription _getSubscription;

    public SubscriptionsClientProxy(ILogger<SubscriptionsClientProxy> logger, IGetSubscription getSubscription)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _getSubscription = getSubscription ?? throw new ArgumentNullException(nameof(getSubscription));
    }

    public async Task<Subscription> GetSubscriptionsAsync()
    {
        _logger.LogAsInformation(LogEventNames.SubscriptionClientProxy.GetSubscriptionsAsync.Start);

        var response = await _getSubscription.GetAsync();

        if (response == null)
            throw new BenefitsInvalidOperationException("Upstream service subscriptions returned no data.");

        return response;
    }
}