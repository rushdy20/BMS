﻿using System.Threading.Tasks;
using EXPN.Models.CreditLockService.Internal.Get.Response;

namespace EXPN.DataLayer.CreditLockService.Customers
{
    public interface ICustomersClientProxy
    {
        Task<GetResponseCustomerProfile> GetCustomerProfile(string customerId);
    }
}