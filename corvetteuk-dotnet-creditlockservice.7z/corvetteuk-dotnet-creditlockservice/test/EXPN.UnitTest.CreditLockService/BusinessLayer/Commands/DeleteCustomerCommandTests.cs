﻿using AutoMapper;
using EXPN.BusinessLayer.CreditLockService.Commands;
using EXPN.BusinessLayer.CreditLockService.Constants;
using EXPN.DataLayer.CreditLockService.Paas.HttpClient;
using EXPN.Models.CreditLockService.Internal.Delete.Request;
using EXPN.Models.CreditLockService.Internal.Delete.Response;
using EXPN.Models.CreditLockService.Internal.Get.Response;
using FluentAssertions;
using Microsoft.Extensions.Logging;
using NSubstitute;
using NSubstitute.ExceptionExtensions;
using System;
using System.Collections.Generic;
using Xunit;
using PaaSRequest = EXPN.Models.CreditLockService.Paas.Delete.Request;

namespace EXPN.UnitTest.CreditLockService.BusinessLayer.Commands
{
    public class DeleteCustomerCommandTests
    {
        private readonly ICreditLockPaasClient _creditLockPaaSClient;
        private readonly ILogger<DeleteCustomerCommand<DeleteCustomerRequest, DeleteCustomerResponse>> _logger;
        private readonly IMapper _mapper;

        private readonly ICommand<DeleteCustomerRequest, DeleteCustomerResponse> _deleteCustomerCommand;

        public DeleteCustomerCommandTests()
        {
            _creditLockPaaSClient = Substitute.For<ICreditLockPaasClient>();
            _logger = Substitute.For<ILogger<DeleteCustomerCommand<DeleteCustomerRequest, DeleteCustomerResponse>>>();
            _mapper = Substitute.For<IMapper>();

            _deleteCustomerCommand = new DeleteCustomerCommand<DeleteCustomerRequest, DeleteCustomerResponse>(_creditLockPaaSClient, _logger, _mapper);
        }

        public class Constructor
        {
            public static IEnumerable<object[]> NullParameters()
            {
                yield return new object[]
                {
                    null,
                    Substitute.For<ILogger<DeleteCustomerCommand<DeleteCustomerRequest, DeleteCustomerResponse>>>(),
                    Substitute.For<IMapper>(),
                    "creditLockPaasClient"
                };

                yield return new object[]
                {
                    Substitute.For<ICreditLockPaasClient>(),
                    null,
                    Substitute.For<IMapper>(),
                    "logger"
                };

                yield return new object[]
                {
                    Substitute.For<ICreditLockPaasClient>(),
                    Substitute.For<ILogger<DeleteCustomerCommand<DeleteCustomerRequest, DeleteCustomerResponse>>>(),
                    null,
                    "mapper"
                };
            }

            [Theory]
            [MemberData(nameof(NullParameters))]
            public void NullRequiredConstructorParameter_ThrowsArgumentNullException(
                ICreditLockPaasClient paasHttpClient,
                ILogger<DeleteCustomerCommand<DeleteCustomerRequest, DeleteCustomerResponse>> logger,
                IMapper mapper,
                string expectedErrorParameter)
            {
                Action action = () => 
                {
                    new DeleteCustomerCommand<DeleteCustomerRequest, DeleteCustomerResponse>(paasHttpClient, logger, mapper);
                };

                action.Should().Throw<ArgumentNullException>()
                    .Where(x => x.ParamName == expectedErrorParameter);
            }

            [Fact]
            public void Id_IsCorrect()
            {
                new DeleteCustomerCommand<DeleteCustomerRequest, DeleteCustomerResponse>(
                    Substitute.For<ICreditLockPaasClient>(),
                    Substitute.For<ILogger<DeleteCustomerCommand<DeleteCustomerRequest, DeleteCustomerResponse>>>(),
                    Substitute.For<IMapper>()).Id.Should().Be("DELETE CUSTOMER");
            }

            public class Execute : DeleteCustomerCommandTests
            {
                public static IEnumerable<object[]> LogInformationMessages()
                {
                    yield return new object[]
                    {
                        LogEventNames.DeleteCustomerCommand.Execute.Enter
                    };

                    yield return new object[]
                    {
                        LogEventNames.DeleteCustomerCommand.Execute.Exit
                    };
                }

                [Theory]
                [MemberData(nameof(LogInformationMessages))]
                public void HappyPathInformationLogged(string loggerMessage)
                {
                    const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

                    var deleteCustomerRequest = new DeleteCustomerRequest
                    {
                        CustomerId = customerId
                    };

                    var getResponseCustomerProfile = new GetResponseCustomerProfile
                    {
                        CustomerId = customerId,
                        IconRef = "ABC"
                    };

                    var paasDeleteCustomerRequest = new PaaSRequest.DeleteCustomerRequest
                    {
                        CustomerRef = "ABC"
                    };

                    _mapper.Map<PaaSRequest.DeleteCustomerRequest>(getResponseCustomerProfile)
                        .Returns(paasDeleteCustomerRequest);

                    _deleteCustomerCommand.Execute(deleteCustomerRequest, getResponseCustomerProfile);

                    _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                        Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(loggerMessage)), null,
                        Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
                }

                [Fact]
                public void ExecutePutLockStatusRequestNull_ThrowsArgumentNullException()
                {
                    Action action = () => { _deleteCustomerCommand.Execute(null, null); };

                    action.Should().Throw<ArgumentNullException>()
                        .Where(x => x.ParamName == "request");
                }

                [Theory]
                [InlineData(null)]
                [InlineData("")]
                [InlineData("     ")]
                public void ExecutePutLockRequestInvalidCustomerId_ThrowsArgumentException(string customerId)
                {
                    var deleteCustomerRequest = new DeleteCustomerRequest
                    {
                        CustomerId = customerId
                    };

                    Action action = () =>
                    {
                        _deleteCustomerCommand.Execute(deleteCustomerRequest, new GetResponseCustomerProfile());
                    };

                    action.Should().Throw<ArgumentException>()
                        .Where(x => x.Message == "CustomerId cannot be null or whitespace (Parameter 'request')");
                }

                [Fact]
                public void ValidRequest_Execute_HappyPath_Success()
                {
                    const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

                    var deleteCustomerRequest = new DeleteCustomerRequest
                    {
                        CustomerId = customerId,
                        CustomerNumber ="1234567896"
                    };
                    
                    var paasDeleteCustomerRequest = new PaaSRequest.DeleteCustomerRequest
                    {
                        CustomerRef = "1234567896"
                    };
                    
                    _mapper.Map<PaaSRequest.DeleteCustomerRequest>(deleteCustomerRequest)
                        .Returns(paasDeleteCustomerRequest);

                    _deleteCustomerCommand.Execute(deleteCustomerRequest, null);

                    _mapper.Received(1).Map<PaaSRequest.DeleteCustomerRequest>(deleteCustomerRequest);

                    _creditLockPaaSClient.Received(1).Delete(paasDeleteCustomerRequest);

                    _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                        Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.DeleteCustomerCommand.Execute.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                    _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                        Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.DeleteCustomerCommand.Execute.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
                }

                [Fact]
                public void ValidRequest_Execute_ClientThrowsOutOfMemoryException_Fails()
                {
                    const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

                    var deleteCustomerRequest = new DeleteCustomerRequest
                    {
                        CustomerId = customerId,
                        CustomerNumber ="1234567896"
                    };

                    var expectedEx = new OutOfMemoryException("Test Exception Message");                

                    var paasDeleteCustomerRequest = new PaaSRequest.DeleteCustomerRequest
                    {
                        CustomerRef = "1234567896"
                    };

                    _mapper.Map<PaaSRequest.DeleteCustomerRequest>(deleteCustomerRequest)
                        .Returns(paasDeleteCustomerRequest);

                    _creditLockPaaSClient.Delete(paasDeleteCustomerRequest)
                        .Throws(expectedEx);

                    Action action = () =>
                    {
                        _deleteCustomerCommand.Execute(deleteCustomerRequest, null);
                    };

                    action.Should().Throw<OutOfMemoryException>()
                        .Where(x => x.Message == expectedEx.Message);

                    _mapper.Received(1).Map<PaaSRequest.DeleteCustomerRequest>(deleteCustomerRequest);

                    _creditLockPaaSClient.Received(1).Delete(paasDeleteCustomerRequest);

                    _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                        Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.DeleteCustomerCommand.Execute.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                    _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                        Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.DeleteCustomerCommand.Execute.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
                }
            }
        }
    }
}