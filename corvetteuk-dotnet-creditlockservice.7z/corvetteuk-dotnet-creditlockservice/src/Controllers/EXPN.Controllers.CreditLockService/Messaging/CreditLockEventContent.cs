﻿using System;

namespace EXPN.Controllers.CreditLockService.Messaging
{
    public class CreditLockEventContent
    {
        public string RequestType { get; set; }
        public System.DateTime RequestDt { get; set; }
        public string SalesforceUserId { get; set; }
        public string ResponseStatusCode { get; set; }
        public string ResponseStatusDescription { get; set; }
    }
}