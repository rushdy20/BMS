﻿namespace EXPN.DataLayer.CreditLockService.Paas.Constants
{
    public struct LogEventKeys
    {
        public const string CustomerId = "CustomerId";
        public const string StatusCode = "StatusCode";
        public const string Content = "Content";
        public const string Context = "Context";
        public const string IconRef = "IconRef";
    }
}