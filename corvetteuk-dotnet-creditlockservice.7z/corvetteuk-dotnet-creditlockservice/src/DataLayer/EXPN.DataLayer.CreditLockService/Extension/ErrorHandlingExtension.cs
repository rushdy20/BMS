﻿using EXPN.DataLayer.CreditLockService.Common.Exceptions;
using System.Net;

namespace EXPN.DataLayer.CreditLockService.Paas.Extension
{
    public static class ErrorHandlingExtension
    {
        private const int DownstreamMaintenanceStatusCode = 561;
        private const int DownstreamBadResponseStatusCode = 562;
        private const int DownstreamAuthenticationExceptionStatusCode = 563;

        public static void CheckForCommonError(this HttpStatusCode statusCode)
        {
            switch (statusCode)
            {
                case HttpStatusCode.Conflict:
                    throw new CustomerPostRequestConflictException();
                case HttpStatusCode.ServiceUnavailable:
                    throw new ServiceUnavailableException();
                case (HttpStatusCode)DownstreamMaintenanceStatusCode:
                    throw new DownstreamMaintenanceException();
                case (HttpStatusCode)DownstreamBadResponseStatusCode:
                    throw new DownstreamBadResponseException();
                case HttpStatusCode.BadRequest:
                    throw new RequestBodyNullException();
                case HttpStatusCode.NotFound:
                    throw new CustomerNotFoundException();
                case (HttpStatusCode)DownstreamAuthenticationExceptionStatusCode:
                    throw new DownstreamAuthenticationException();
                default:
                    throw new CustomerPostRequestException();
            }
        }
    }
}
