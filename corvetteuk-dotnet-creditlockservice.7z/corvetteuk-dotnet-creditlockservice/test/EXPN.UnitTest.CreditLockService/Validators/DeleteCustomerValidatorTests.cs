﻿using System.Collections.Generic;
using System.Linq;
using EXPN.Models.CreditLockService.External.Delete.Request;
using EXPN.Validators.CreditLockService.Delete;
using FluentAssertions;
using FluentValidation;
using NSubstitute;
using Xunit;
using FluentValidation.Results;

namespace EXPN.UnitTest.CreditLockService.Validators
{
  public class DeleteCustomerValidatorTests
    {
        private readonly IValidator<DeleteEventBody> _deleteEventBodyValidator;

        public DeleteCustomerValidatorTests()
        {
            _deleteEventBodyValidator = Substitute.For<IValidator<DeleteEventBody>>();

            _deleteEventBodyValidator.Validate(Arg.Any<ValidationContext<DeleteEventBody>>())
                .Returns(new ValidationResult());
        }

        public static IEnumerable<object[]> PostSubscriptionRequestData()
        {
            yield return new object[]
            {
                new DeleteCustomerRequest
                {
                    Body = new DeleteEventBody
                    {
                        CustomerNumber ="abc"
                    }                    
                },
                false,
                "'Customer Id' must not be empty."
            };

            yield return new object[]
            {
                new DeleteCustomerRequest
                {
                    CustomerId = string.Empty,
                    Body = new DeleteEventBody
                    {
                        CustomerNumber ="abc"
                    }
                },
                false,
                "'Customer Id' must not be empty."
            };

            yield return new object[]
            {
                new DeleteCustomerRequest
                {
                    CustomerId = string.Empty.PadLeft(1),
                    Body = new DeleteEventBody
                    {
                        CustomerNumber ="abc"
                    }
                },
                false,
                "'Customer Id' must not be empty."
            };

            yield return new object[]
            {
                new DeleteCustomerRequest
                {
                    CustomerId = "Test",
                    Body = new DeleteEventBody
                    {
                        CustomerNumber ="abc"
                    }
                },
                false,
                "'CustomerId' is not in valid format"
            };

            yield return new object[]
            {
                new DeleteCustomerRequest
                {
                    CustomerId = "7741adf8-266c-4ff5-84ea-e0bfd40e2da4",
                    Body = new DeleteEventBody
                    {
                        CustomerNumber ="abc"
                    }
                },
                true,
                null,
            };
        }

        [Theory]
        [MemberData(nameof(PostSubscriptionRequestData))]
        public void DeleteCustomerRequest_ValidRequest_ShouldBeSameAsExpected(DeleteCustomerRequest deleteCustomerRequest, bool expected, string errorMessage)
        {
            var result = new DeleteCustomerRequestValidator(_deleteEventBodyValidator)
                .Validate(deleteCustomerRequest);

            if (expected)
            {
                result.IsValid.Should().BeTrue();
                result.Errors.Should().HaveCount(0);
            }
            else
            {
                result.IsValid.Should().BeFalse();
                result.Errors.Should().HaveCount(1);
                result.Errors.Select(x => x.ErrorMessage).FirstOrDefault().Should().BeEquivalentTo(errorMessage);
            }
        }
    }
}