﻿using EXPN.DataLayer.CreditLockService.Common.Binders;
using Newtonsoft.Json;

namespace EXPN.UnitTest.CreditLockService.Common.Extension;

public static class ExceptionSerialization
{
    public static TDeserialize SerializeAndDeserialize<TDeserialize>(this TDeserialize ex)
    {
        var jsonSerialized = JsonConvert.SerializeObject(ex, Formatting.Indented, new JsonSerializerSettings
        {
            TypeNameHandling = TypeNameHandling.Objects,
            SerializationBinder = new CreditLockCommonExceptionsBinder()
        });

        return JsonConvert.DeserializeObject<TDeserialize>(jsonSerialized);
    }
}