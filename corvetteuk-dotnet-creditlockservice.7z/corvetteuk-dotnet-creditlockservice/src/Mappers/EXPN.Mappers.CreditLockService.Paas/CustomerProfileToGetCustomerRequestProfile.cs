﻿using AutoMapper;
using EXPN.Models.CreditLockService.Internal.Get.Response;
using EXPN.Models.CreditLockService.Paas.Get.Request;

namespace EXPN.Mappers.CreditLockService.Paas
{
    public class CustomerProfileToGetCustomerRequestProfile : Profile
    {
        public CustomerProfileToGetCustomerRequestProfile()
        {
            CreateMap<GetResponseCustomerProfile, GetCustomerRequest>(MemberList.None)
                .ForMember(d => d.CustomerRef, m => m.MapFrom(s => s.CustomerRef))
                .ForMember(d => d.CustomerId, m => m.MapFrom(s => s.CustomerId));
        }
    }
}