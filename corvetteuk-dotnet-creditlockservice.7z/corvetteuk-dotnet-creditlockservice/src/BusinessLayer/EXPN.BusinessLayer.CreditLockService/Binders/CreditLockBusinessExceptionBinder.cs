﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Reflection;
using System.Runtime.Serialization;

namespace EXPN.BusinessLayer.CreditLockService.Binders;

[ExcludeFromCodeCoverage]
public sealed class CreditLockBusinessExceptionBinder : SerializationBinder
{
    public override Type BindToType(string assemblyName, string typeName)
    {
        return Assembly.Load(assemblyName).GetType(typeName);
    }
}