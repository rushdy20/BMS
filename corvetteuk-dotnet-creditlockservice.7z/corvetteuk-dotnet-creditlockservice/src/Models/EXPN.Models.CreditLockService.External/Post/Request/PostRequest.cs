﻿using System.Diagnostics.CodeAnalysis;
using Microsoft.AspNetCore.Mvc;

namespace EXPN.Models.CreditLockService.External.Post.Request
{
    [ExcludeFromCodeCoverage]
    public class PostRequest
    {
        [FromHeader(Name = "x-customerId")]
        public string CustomerId { get; set; }
    }
}