﻿namespace EXPN.Models.CreditLockService.Internal.Put.Request
{
    public class PutCustomerRequest
    {
        public string CustomerId { get; set; }
    }
}