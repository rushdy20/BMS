using EXPN.BusinessLayer.CreditLockService.Commands;
using EXPN.Models.CreditLockService.Internal;
using EXPN.Models.CreditLockService.Internal.Get.Response;
using Microsoft.Extensions.DependencyInjection;
using System.Diagnostics.CodeAnalysis;
using EXPN.Models.CreditLockService.Internal.Delete.Request;
using EXPN.Models.CreditLockService.Internal.Delete.Response;
using EXPN.Models.CreditLockService.Internal.Get.Request;
using EXPN.Models.CreditLockService.Internal.Post.Request;
using EXPN.Models.CreditLockService.Internal.Post.Response;
using EXPN.Models.CreditLockService.Internal.Put.Request;
using EXPN.Models.CreditLockService.Internal.Put.Response;

namespace EXPN.BusinessLayer.CreditLockService
{
    [ExcludeFromCodeCoverage]
    public static class BusinessLayerModule
    {
        public static IServiceCollection AddBusinessLayerModule(this IServiceCollection services)
        {
            services
                .AddScoped<IBenefitChecker, BenefitChecker>()
                .AddScoped<ICreditLockServiceCustomerManager, CreditLockServiceCustomerManager>()
                .AddScoped<ICommand<CustomerRequest, PostCustomerResponse>, CreateCustomerCommand<CustomerRequest, PostCustomerResponse>>()
                .AddScoped<ICommand<GetCustomerRequest, GetCustomerResponse>, GetCustomerCommand<GetCustomerRequest, GetCustomerResponse>>()
                .AddScoped<ICommand<PutLockStatusRequest, PutLockStatusResponse>, PutLockStatusCommand<PutLockStatusRequest, PutLockStatusResponse>>()
                .AddScoped<ICommand<DeleteCustomerRequest, DeleteCustomerResponse>, DeleteCustomerCommand<DeleteCustomerRequest, DeleteCustomerResponse>>()
                .AddScoped<ICommand<PostDeactivateInstantAlertRequest, PostDeactivateInstantAlertResponse>,DeactivateInstantAlertCommand<PostDeactivateInstantAlertRequest, PostDeactivateInstantAlertResponse>>()
                .AddScoped<ICommand<PutCustomerRequest, PutCustomerResponse>, SyncCustomerCommand<PutCustomerRequest, PutCustomerResponse>>()
                .AddScoped<ICommand<PostActivateInstantAlertRequest, PostActivateInstantAlertResponse>,ActivateInstantAlertCommand<PostActivateInstantAlertRequest, PostActivateInstantAlertResponse>>();

            return services;
        }
    }
}