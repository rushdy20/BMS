﻿using System.Diagnostics.CodeAnalysis;
using EXPN.Models.CreditLockService.Internal.Get.Response;
using EXPN.Models.CreditLockService.Paas.Put.Request;

namespace EXPN.Models.CreditLockService.Internal.Post
{
    [ExcludeFromCodeCoverage]
    public class PostResponseCustomerSubscription
    {
        public GetResponseCustomerProfile GetResponseCustomerProfile { get; set; }
        public GetCustomerResponse GetCustomerResponsePaas { get; set; }
        public PutCustomerRequest PutRequestPaasCustomer { get; set; }
    }
}