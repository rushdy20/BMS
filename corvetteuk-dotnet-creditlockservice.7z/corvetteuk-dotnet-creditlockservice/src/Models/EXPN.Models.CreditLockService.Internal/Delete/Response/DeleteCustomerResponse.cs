﻿
namespace EXPN.Models.CreditLockService.Internal.Delete.Response
{
  public  class DeleteCustomerResponse
    {
        public string CustomerId { get; set; }
    }
}
