﻿using System.Diagnostics.CodeAnalysis;

namespace EXPN.Models.CreditLockService.Internal.Put.Response
{
    [ExcludeFromCodeCoverage]
    public class PutCustomerResponse
    {
        public bool HasMadeSyncRequest { get; set; }
    }
}