﻿using System;
using System.Runtime.Serialization;

namespace EXPN.DataLayer.CreditLockService.Common.Exceptions
{
    [Serializable]
    public class OktaException : Exception
    {
        protected OktaException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }

        public OktaException()
        {
        }

        public OktaException(string message)
            : base(message)
        {
        }

        public OktaException(string message, Exception innerException)
            : base(message, innerException)
        {
        }
    }
}