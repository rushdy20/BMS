﻿using System.Diagnostics.CodeAnalysis;
using AutoMapper;
using EXPN.Models.CreditLockService.External.Put.Request;
using EXPN.Models.CreditLockService.Internal.Put.Request;

namespace EXPN.Mappers.CreditLockService.Internal
{
    [ExcludeFromCodeCoverage]
    public class PutAgentLockStatusRequestToPutLockStatusRequestProfile : Profile
    {
        public PutAgentLockStatusRequestToPutLockStatusRequestProfile()
        {
            CreateMap<PutStatusAgentRequest, PutLockStatusRequest>()
                .ForMember(d => d.CustomerId, m => m.MapFrom(s => s.CustomerId))
                .ForMember(d => d.SalesForceUserId, opt => opt.Ignore())
                .ForMember(d => d.LockStatus, opt => opt.Ignore());
        }
    }
}