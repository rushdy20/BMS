﻿using System;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace EXPN.IntegrationTest.CreditLockService.Utility.MessageHandlers
{
    public class DynamicHttpMessagesHandler : DelegatingHandler
    {
        private static HttpResponseMessage[] _fakeResponses;
        private static int _currentIndex;

        public static HttpResponseMessage[] TestResponses
        {
            get => _fakeResponses;
            set
            {
                _fakeResponses = value;
                _currentIndex = 0;
            }
        }

        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            _currentIndex++;

            if (_currentIndex > _fakeResponses.Length)
            {
                throw new InvalidOperationException();
            }

            return await Task.FromResult(_fakeResponses[_currentIndex - 1]);
        }
    }
}