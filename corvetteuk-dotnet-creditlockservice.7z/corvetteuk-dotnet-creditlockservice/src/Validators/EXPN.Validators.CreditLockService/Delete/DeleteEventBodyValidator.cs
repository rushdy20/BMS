﻿using FluentValidation;
using EXPN.Models.CreditLockService.External.Delete.Request;

namespace EXPN.Validators.CreditLockService.Delete
{
    public class DeleteEventBodyValidator : AbstractValidator<DeleteEventBody>
    {
        public DeleteEventBodyValidator()
        {
            RuleFor(x => x)
                .NotNull()
                .WithName(nameof(DeleteEventBody))
                .DependentRules(() =>
                {
                    RuleFor(instance => instance.CustomerNumber)
                    .Cascade(CascadeMode.StopOnFirstFailure)
                    .NotEmpty()
                    .WithMessage("'{PropertyName}' should not be null");                   
                });
        }
    }
}