using AutoMapper;
using Experian.AWS.Logging.Extensions;
using Experian.ResponseModels;
using EXPN.BusinessLayer.CreditLockService;
using EXPN.BusinessLayer.CreditLockService.Exceptions;
using EXPN.Controllers.CreditLockService.Constants;
using EXPN.Controllers.CreditLockService.DateTime;
using EXPN.Controllers.CreditLockService.Messaging;
using EXPN.DataLayer.CreditLockService.Common.Exceptions;
using EXPN.Models.CreditLockService.External.Delete.Request;
using EXPN.Models.CreditLockService.External.Post.Request;
using EXPN.Models.CreditLockService.Internal;
using EXPN.Models.CreditLockService.Internal.Put.Request;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using InternalModel = EXPN.Models.CreditLockService.Internal.Delete.Request;
using LogEventNames = EXPN.Controllers.CreditLockService.Constants.LogEventNames;

namespace EXPN.Controllers.CreditLockService
{
    [ApiController]
    [Route("internal/creditlock")]
    public class InternalCreditLockController : AuditControllerBase
    {
        private readonly ILogger<InternalCreditLockController> _logger;
        private readonly ICreditLockServiceCustomerManager _customerManager;
        private readonly IMapper _mapper;

        private const string LogContext = "Context";
        private const int DownstreamMaintenanceStatusCode = 561;
        private const int DownstreamBadRequestStatusCode = 562;
        private const int DownstreamAuthenticationExceptionStatusCode = 563;

        public InternalCreditLockController(
            ILogger<InternalCreditLockController> logger,
            ICreditLockServiceCustomerManager customerManager,
            IMessaging messaging,
            IDateTime dateTime,
            IMapper mapper) : base(messaging, dateTime)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _customerManager = customerManager ?? throw new ArgumentNullException(nameof(customerManager));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        }

        [HttpPost]
        [Route("activate")]
        [ProducesResponseType(typeof(StatusCodeResult), (int)HttpStatusCode.NoContent)]
        [ProducesResponseType(typeof(StatusCodeResult), (int)HttpStatusCode.NotFound)]
        public async Task<IActionResult> ActivateAsync(PostRequest postRequest)
        {
            const string requestType = "ACTIVATE_CREDITLOCK";

            try
            {
                _logger.LogAsInformation(LogEventNames.InternalCreditLockController.Activate.Invoked);

                if (!ModelState.IsValid)
                {
                    _logger.LogAsWarning(LogEventNames.InternalCreditLockController.Activate.ModelStateFailed);

                    await RaiseEvent(requestType, (int)HttpStatusCode.BadRequest, "Bad Request");

                    return new ErrorResponseBuilder()
                        .WithStatusCode(HttpStatusCode.BadRequest)
                        .WithModelStateDictionary(ModelState)
                        .Build();
                }

                await _customerManager.ActivateAsync(_mapper.Map<CustomerRequest>(postRequest));

                await _customerManager.PutLockStatus(_mapper.Map<PutLockStatusRequest>(postRequest));

                await RaiseEvent(requestType, (int)HttpStatusCode.NoContent, "Success");

                _logger.LogAsInformation(LogEventNames.InternalCreditLockController.Activate.Complete);

                return new ApiResult(HttpStatusCode.NoContent, null);
            }
            catch (OktaTokenNullException ex)
            {
                _logger.LogAsError(LogEventNames.InternalCreditLockController.Activate.OktaTokenNullException,
                    new Dictionary<string, object>
                        { { LogContext, new { ErrorMessage = ex.Message, Exception = ex } } });

                await RaiseEvent(requestType, (int)HttpStatusCode.BadGateway, "Bad Gateway");

                return new ErrorResponseBuilder()
                    .WithStatusCode(HttpStatusCode.BadGateway)
                    .Build();
            }
            catch (OktaException ex)
            {
                _logger.LogAsError(LogEventNames.InternalCreditLockController.Activate.OktaTokenException,
                    new Dictionary<string, object>
                        { { LogContext, new { ErrorMessage = ex.Message, Exception = ex } } });

                await RaiseEvent(requestType, (int)HttpStatusCode.BadGateway, "Bad Gateway");

                return new ErrorResponseBuilder()
                    .WithStatusCode(HttpStatusCode.BadGateway)
                    .Build();
            }
            catch (CustomerProfileNotFoundException ex)
            {
                _logger.LogAsError(LogEventNames.InternalCreditLockController.Activate.CustomerProfileNotFoundException,
                    new Dictionary<string, object>
                        { { LogContext, new { ErrorMessage = ex.Message, Exception = ex } } });

                await RaiseEvent(requestType, (int)HttpStatusCode.NotFound, "Corvette Customer Profile is not found");

                return new ErrorResponseBuilder()
                    .WithStatusCode(HttpStatusCode.NotFound)
                    .Build();
            }
            catch (DownstreamMaintenanceException)
            {
                _logger.LogAsInformation(LogEventNames.InternalCreditLockController.Activate.DownstreamMaintenanceException);

                await RaiseEvent(requestType, DownstreamMaintenanceStatusCode, "Downstream Service Unavailable - mainframe down for scheduled maintenance");

                return new ErrorResponseBuilder()
                    .WithStatusCode(DownstreamMaintenanceStatusCode)
                    .Build();
            }
            catch (HttpServiceRequestException ex)
            {
                _logger.LogAsError(LogEventNames.InternalCreditLockController.Activate.HttpServiceRequestException,
                    new Dictionary<string, object>
                    {
                        {
                            LogContext, new { ErrorMessage = ex.Message, Exception = ex.GetBaseException() }
                        }
                    });

                await RaiseEvent(requestType, (int)HttpStatusCode.InternalServerError, "Internal Server Error");

                return new ErrorResponseBuilder()
                    .WithStatusCode(HttpStatusCode.InternalServerError)
                    .Build();
            }
            catch (ServiceTaskCanceledException ex)
            {
                _logger.LogAsError(LogEventNames.InternalCreditLockController.Activate.ServiceTaskCanceledException,
                    new Dictionary<string, object>
                        { { LogContext, new { ErrorMessage = ex.Message, Exception = ex } } });

                await RaiseEvent(requestType, MessageConstants.DownstreamTimeoutStatusCode, MessageConstants.DownstreamTimeout);

                return new ErrorResponseBuilder()
                    .WithStatusCode(MessageConstants.DownstreamTimeoutStatusCode)
                    .Build();
            }
            catch (ServiceUnavailableException ex)
            {
                _logger.LogAsError(LogEventNames.InternalCreditLockController.Activate.ServiceUnavailableException,
                    new Dictionary<string, object>
                        { { LogContext, new { ErrorMessage = ex.Message, Exception = ex } } });

                await RaiseEvent(requestType, (int)HttpStatusCode.ServiceUnavailable, "Service Unavailable");

                return new ErrorResponseBuilder()
                    .WithStatusCode(HttpStatusCode.ServiceUnavailable)
                    .Build();
            }
            catch (DownstreamBadResponseException ex)
            {
                _logger.LogAsError(LogEventNames.InternalCreditLockController.Activate.DownstreamBadResponse,
                    new Dictionary<string, object>
                        { { LogContext, new { ErrorMessage = ex.Message, Exception = ex } } });

                await RaiseEvent(requestType, DownstreamBadRequestStatusCode, "Downstream Bad Request");

                return new ErrorResponseBuilder()
                    .WithStatusCode(DownstreamBadRequestStatusCode)
                    .Build();
            }
            catch (SyncCustomerPinningException)
            {
                _logger.LogAsInformation(LogEventNames.InternalCreditLockController.Activate.SyncCustomerPinningException);

                await RaiseEvent(requestType, (int)HttpStatusCode.Conflict, "Conflict - customer waiting to be pinned or pinning in process");

                return new ErrorResponseBuilder()
                    .WithStatusCode(HttpStatusCode.Conflict)
                    .Build();
            }
            catch (DownstreamAuthenticationException)
            {
                _logger.LogAsError(LogEventNames.InternalCreditLockController.Activate.DownstreamAuthenticationException);

                await RaiseEvent(requestType, DownstreamAuthenticationExceptionStatusCode, MessageConstants.DownstreamAuthenticationFailed);

                return new ErrorResponseBuilder()
                    .WithStatusCode(DownstreamAuthenticationExceptionStatusCode)
                    .Build();
            }
            catch (Exception ex)
            {
                _logger.LogAsError(LogEventNames.InternalCreditLockController.Activate.UnhandledException,
                    new Dictionary<string, object> { { LogContext, new { Exception = ex } } });

                await RaiseEvent(requestType, (int)HttpStatusCode.InternalServerError, "Internal Server Error");

                return new ErrorResponseBuilder()
                    .WithStatusCode((int)HttpStatusCode.InternalServerError)
                    .Build();
            }
        }

        [HttpPost]
        [Route("deactivate")]
        [ProducesResponseType(typeof(StatusCodeResult), (int)HttpStatusCode.NoContent)]
        [ProducesResponseType(typeof(StatusCodeResult), (int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> DeactivateAsync(PostRequest postRequest)
        {
            const string requestType = "DEACTIVATE_CREDITLOCK";

            try
            {
                _logger.LogAsInformation(LogEventNames.InternalCreditLockController.Deactivate.Invoked);

                if (!ModelState.IsValid)
                {
                    _logger.LogAsWarning(LogEventNames.InternalCreditLockController.Deactivate.ModelStateFailed);

                    await RaiseEvent(requestType, (int)HttpStatusCode.BadRequest, "Bad Request");

                    return new ErrorResponseBuilder()
                        .WithStatusCode(HttpStatusCode.BadRequest)
                        .WithModelStateDictionary(ModelState)
                        .Build();
                }

                var internalRequest = _mapper.Map<PutLockStatusRequest>(postRequest);

                await _customerManager.PutLockStatus(internalRequest);

                await RaiseEvent(requestType, (int)HttpStatusCode.NoContent, "Success");

                _logger.LogAsInformation(LogEventNames.InternalCreditLockController.Deactivate.Complete);

                return new ApiResult(HttpStatusCode.NoContent, null);
            }
            catch (CustomerProfileNotFoundException ex)
            {
                _logger.LogAsError(LogEventNames.InternalCreditLockController.Deactivate.CustomerProfileNotFoundException,
                    new Dictionary<string, object> { { LogContext, new { ErrorMessage = ex.Message, Exception = ex } } });

                await RaiseEvent(requestType, (int)HttpStatusCode.InternalServerError, "Internal Server Error");

                return new ErrorResponseBuilder()
                    .WithStatusCode(HttpStatusCode.InternalServerError)
                    .Build();
            }
            catch (CustomerNotFoundException)
            {
                _logger.LogAsInformation(LogEventNames.InternalCreditLockController.Deactivate.CustomerNotFoundException);

                await RaiseEvent(requestType, (int)HttpStatusCode.NoContent, "VIP Customer is Not Found");

                return new ApiResult(HttpStatusCode.NoContent, null);
            }
            catch (OktaTokenNullException ex)
            {
                _logger.LogAsError(LogEventNames.InternalCreditLockController.Deactivate.OktaTokenNullException,
                    new Dictionary<string, object> { { LogContext, new { ErrorMessage = ex.Message, Exception = ex } } });

                await RaiseEvent(requestType, (int)HttpStatusCode.BadGateway, "Bad Gateway");

                return new ErrorResponseBuilder()
                    .WithStatusCode(HttpStatusCode.BadGateway)
                    .Build();
            }
            catch (OktaException ex)
            {
                _logger.LogAsError(LogEventNames.InternalCreditLockController.Deactivate.OktaTokenException,
                    new Dictionary<string, object> { { LogContext, new { ErrorMessage = ex.Message, Exception = ex } } });

                await RaiseEvent(requestType, (int)HttpStatusCode.BadGateway, "Bad Gateway");

                return new ErrorResponseBuilder()
                    .WithStatusCode(HttpStatusCode.BadGateway)
                    .Build();
            }
            catch (HttpServiceRequestException ex)
            {
                _logger.LogAsError(LogEventNames.InternalCreditLockController.Deactivate.HttpServiceRequestException,
                    new Dictionary<string, object>
                    {
                        {
                            LogContext, new { ErrorMessage = ex.Message, Exception = ex.GetBaseException() }
                        }
                    });

                await RaiseEvent(requestType, (int)HttpStatusCode.InternalServerError, "Internal Server Error");

                return new ErrorResponseBuilder()
                    .WithStatusCode(HttpStatusCode.InternalServerError)
                    .Build();
            }
            catch (ServiceTaskCanceledException ex)
            {
                _logger.LogAsError(LogEventNames.InternalCreditLockController.Deactivate.ServiceTaskCanceledException,
                    new Dictionary<string, object>
                        { { LogContext, new { ErrorMessage = ex.Message, Exception = ex } } });

                await RaiseEvent(requestType, MessageConstants.DownstreamTimeoutStatusCode, MessageConstants.DownstreamTimeout);

                return new ErrorResponseBuilder()
                    .WithStatusCode(MessageConstants.DownstreamTimeoutStatusCode)
                    .Build();
            }
            catch (ServiceUnavailableException ex)
            {
                _logger.LogAsError(LogEventNames.InternalCreditLockController.Deactivate.ServiceUnavailableException,
                    new Dictionary<string, object>
                        { { LogContext, new { ErrorMessage = ex.Message, Exception = ex } } });

                await RaiseEvent(requestType, (int)HttpStatusCode.ServiceUnavailable, "Service Unavailable");

                return new ErrorResponseBuilder()
                    .WithStatusCode(HttpStatusCode.ServiceUnavailable)
                    .Build();
            }
            catch (DownstreamMaintenanceException)
            {
                _logger.LogAsInformation(LogEventNames.InternalCreditLockController.Deactivate.DownstreamMaintenanceException);

                await RaiseEvent(requestType, DownstreamMaintenanceStatusCode, "Downstream Service Unavailable - mainframe down for scheduled maintenance");

                return new ErrorResponseBuilder()
                    .WithStatusCode(DownstreamMaintenanceStatusCode)
                    .Build();
            }
            catch (DownstreamAuthenticationException)
            {
                _logger.LogAsError(LogEventNames.InternalCreditLockController.Deactivate.DownstreamAuthenticationException);

                await RaiseEvent(requestType, DownstreamAuthenticationExceptionStatusCode, MessageConstants.DownstreamAuthenticationFailed);

                return new ErrorResponseBuilder()
                    .WithStatusCode(DownstreamAuthenticationExceptionStatusCode)
                    .Build();
            }
            catch (Exception ex)
            {
                _logger.LogAsError(LogEventNames.InternalCreditLockController.Deactivate.UnhandledException,
                    new Dictionary<string, object> { { LogContext, new { Exception = ex } } });

                await RaiseEvent(requestType, (int)HttpStatusCode.InternalServerError, "Internal Server Error");

                return new ErrorResponseBuilder()
                    .WithStatusCode((int)HttpStatusCode.InternalServerError)
                    .Build();
            }
        }

        [HttpPost]
        [Route("delete")]
        [ProducesResponseType(typeof(StatusCodeResult), (int)HttpStatusCode.NoContent)]
        public async Task<IActionResult> DeleteAsync(DeleteCustomerRequest deleteCustomerRequest)
        {
            const string requestType = "DELETE_CUSTOMER";

            try
            {
                _logger.LogAsInformation(LogEventNames.InternalCreditLockController.CustomerDelete.Invoked);

                if (!ModelState.IsValid)
                {
                    _logger.LogAsInformation(LogEventNames.InternalCreditLockController.CustomerDelete.ModelStateFailed);

                    await RaiseEvent(requestType, (int)HttpStatusCode.BadRequest, "Bad Request");

                    return new ErrorResponseBuilder()
                        .WithStatusCode(HttpStatusCode.BadRequest)
                        .WithModelStateDictionary(ModelState)
                        .Build();
                }

                await _customerManager.DeleteCustomer(_mapper.Map<InternalModel.DeleteCustomerRequest>(deleteCustomerRequest));

                await RaiseEvent(requestType, (int)HttpStatusCode.NoContent, "Success");

                _logger.LogAsInformation(LogEventNames.InternalCreditLockController.CustomerDelete.Complete);

                return new ApiResult(HttpStatusCode.NoContent, null);
            }
            catch (DownstreamMaintenanceException)
            {
                _logger.LogAsInformation(LogEventNames.InternalCreditLockController.CustomerDelete.DownstreamMaintenanceException);

                await RaiseEvent(requestType, DownstreamMaintenanceStatusCode, "Downstream Service Unavailable - mainframe down for scheduled maintenance");

                return new ErrorResponseBuilder()
                    .WithStatusCode(DownstreamMaintenanceStatusCode)
                    .Build();
            }
            catch (HttpServiceRequestException ex)
            {
                _logger.LogAsError(LogEventNames.InternalCreditLockController.CustomerDelete.HttpServiceRequestException,
                    new Dictionary<string, object>
                    {
                        {
                            LogContext, new { ErrorMessage = ex.Message, Exception = ex.GetBaseException() }
                        }
                    });

                await RaiseEvent(requestType, (int)HttpStatusCode.InternalServerError, "Internal Server Error");

                return new ErrorResponseBuilder()
                    .WithStatusCode(HttpStatusCode.InternalServerError)
                    .Build();
            }
            catch (ServiceTaskCanceledException ex)
            {
                _logger.LogAsError(LogEventNames.InternalCreditLockController.CustomerDelete.ServiceTaskCanceledException,
                    new Dictionary<string, object> { { LogContext, new { ErrorMessage = ex.Message, Exception = ex } } });

                await RaiseEvent(requestType, MessageConstants.DownstreamTimeoutStatusCode, MessageConstants.DownstreamTimeout);

                return new ErrorResponseBuilder()
                    .WithStatusCode(MessageConstants.DownstreamTimeoutStatusCode)
                    .Build();
            }
            catch (ServiceUnavailableException ex)
            {
                _logger.LogAsError(LogEventNames.InternalCreditLockController.CustomerDelete.ServiceUnavailableException,
                    new Dictionary<string, object> { { LogContext, new { ErrorMessage = ex.Message, Exception = ex } } });

                await RaiseEvent(requestType, (int)HttpStatusCode.ServiceUnavailable, "Service Unavailable");

                return new ErrorResponseBuilder()
                    .WithStatusCode(HttpStatusCode.ServiceUnavailable)
                    .Build();
            }
            catch (CustomerNotFoundException ex)
            {
                _logger.LogAsError(LogEventNames.InternalCreditLockController.CustomerDelete.CustomerNotFoundException,
                    new Dictionary<string, object> { { LogContext, new { ErrorMessage = ex.Message, Exception = ex } } });

                await RaiseEvent(requestType, (int)HttpStatusCode.NotFound, "VIP Customer is Not Found");

                return new ErrorResponseBuilder()
                    .WithStatusCode(HttpStatusCode.NotFound)
                    .Build();
            }
            catch (CustomerProfileNotFoundException ex)
            {
                _logger.LogAsError(LogEventNames.InternalCreditLockController.CustomerDelete.CustomerProfileNotFoundException,
                    new Dictionary<string, object> { { LogContext, new { ErrorMessage = ex.Message, Exception = ex } } });

                await RaiseEvent(requestType, (int)HttpStatusCode.InternalServerError, "Internal Server Error");

                return new ErrorResponseBuilder()
                    .WithStatusCode(HttpStatusCode.InternalServerError)
                    .Build();
            }
            catch (OktaTokenNullException ex)
            {
                _logger.LogAsError(LogEventNames.InternalCreditLockController.CustomerDelete.OktaTokenNullException,
                    new Dictionary<string, object> { { LogContext, new { ErrorMessage = ex.Message, Exception = ex } } });

                await RaiseEvent(requestType, (int)HttpStatusCode.BadGateway, "Bad Gateway");

                return new ErrorResponseBuilder()
                    .WithStatusCode(HttpStatusCode.BadGateway)
                    .Build();
            }
            catch (DownstreamAuthenticationException)
            {
                _logger.LogAsError(LogEventNames.InternalCreditLockController.CustomerDelete.DownstreamAuthenticationException);

                await RaiseEvent(requestType, DownstreamAuthenticationExceptionStatusCode, MessageConstants.DownstreamAuthenticationFailed);

                return new ErrorResponseBuilder()
                    .WithStatusCode(DownstreamAuthenticationExceptionStatusCode)
                    .Build();
            }
            catch (OktaException ex)
            {
                _logger.LogAsError(LogEventNames.InternalCreditLockController.CustomerDelete.OktaTokenException,
                    new Dictionary<string, object> { { LogContext, new { ErrorMessage = ex.Message, Exception = ex } } });

                await RaiseEvent(requestType, (int)HttpStatusCode.BadGateway, "Bad Gateway");

                return new ErrorResponseBuilder()
                    .WithStatusCode(HttpStatusCode.BadGateway)
                    .Build();
            }
            catch (Exception ex)
            {
                _logger.LogAsError(LogEventNames.InternalCreditLockController.CustomerDelete.UnhandledException,
                    new Dictionary<string, object> { { LogContext, new { Exception = ex } } });

                await RaiseEvent(requestType, (int)HttpStatusCode.InternalServerError, "Internal Server Error");

                return new ErrorResponseBuilder()
                    .WithStatusCode((int)HttpStatusCode.InternalServerError)
                    .Build();
            }
        }

        [HttpPost]
        [Route("customerupdate")]
        [ProducesResponseType(typeof(StatusCodeResult), (int)HttpStatusCode.NoContent)]
        public async Task<IActionResult> UpdateAsync(PostRequest postRequest)
        {
            const string requestType = "UPDATE_CUSTOMER";

            try
            {
                _logger.LogAsInformation(LogEventNames.InternalCreditLockController.CustomerUpdate.Invoked);

                if (!ModelState.IsValid)
                {
                    _logger.LogAsInformation(LogEventNames.InternalCreditLockController.CustomerUpdate.ModelStateFailed);

                    await RaiseEvent(requestType, (int)HttpStatusCode.BadRequest, "Bad Request");

                    return new ErrorResponseBuilder()
                        .WithStatusCode(HttpStatusCode.BadRequest)
                        .WithModelStateDictionary(ModelState)
                        .Build();
                }

                await _customerManager.UpdateCustomer(_mapper.Map<PutCustomerRequest>(postRequest));

                await RaiseEvent(requestType, (int)HttpStatusCode.NoContent, "Success");

                _logger.LogAsInformation(LogEventNames.InternalCreditLockController.CustomerUpdate.Complete);

                return new ApiResult(HttpStatusCode.NoContent, null);
            }
            catch (OktaTokenNullException ex)
            {
                _logger.LogAsError(LogEventNames.InternalCreditLockController.CustomerUpdate.OktaTokenNullException,
                    new Dictionary<string, object> { { LogContext, new { ErrorMessage = ex.Message, Exception = ex } } });

                await RaiseEvent(requestType, (int)HttpStatusCode.BadGateway, "Bad Gateway");

                return new ErrorResponseBuilder()
                    .WithStatusCode(HttpStatusCode.BadGateway)
                    .Build();
            }
            catch (OktaException ex)
            {
                _logger.LogAsError(LogEventNames.InternalCreditLockController.CustomerUpdate.OktaTokenException,
                    new Dictionary<string, object> { { LogContext, new { ErrorMessage = ex.Message, Exception = ex } } });

                await RaiseEvent(requestType, (int)HttpStatusCode.BadGateway, "Bad Gateway");

                return new ErrorResponseBuilder()
                    .WithStatusCode(HttpStatusCode.BadGateway)
                    .Build();
            }
            catch (CustomerProfileNotFoundException ex)
            {
                _logger.LogAsError(LogEventNames.InternalCreditLockController.CustomerUpdate.CustomerProfileNotFoundException,
                    new Dictionary<string, object> { { LogContext, new { ErrorMessage = ex.Message, Exception = ex } } });

                await RaiseEvent(requestType, (int)HttpStatusCode.InternalServerError, "Internal Server Error");

                return new ErrorResponseBuilder()
                    .WithStatusCode(HttpStatusCode.InternalServerError)
                    .Build();
            }
            catch (DownstreamMaintenanceException)
            {
                _logger.LogAsInformation(LogEventNames.InternalCreditLockController.CustomerUpdate.DownstreamMaintenanceException);

                await RaiseEvent(requestType, DownstreamMaintenanceStatusCode, "Downstream Service Unavailable - mainframe down for scheduled maintenance");

                return new ErrorResponseBuilder()
                    .WithStatusCode(DownstreamMaintenanceStatusCode)
                    .Build();
            }

            catch (HttpServiceRequestException ex)
            {
                _logger.LogAsError(LogEventNames.InternalCreditLockController.CustomerUpdate.HttpServiceRequestException,
                    new Dictionary<string, object>
                    {
                        {
                            LogContext, new { ErrorMessage = ex.Message, Exception = ex.GetBaseException() }
                        }
                    });

                await RaiseEvent(requestType, (int)HttpStatusCode.InternalServerError, "Internal Server Error");

                return new ErrorResponseBuilder()
                    .WithStatusCode(HttpStatusCode.InternalServerError)
                    .Build();
            }
            catch (ServiceTaskCanceledException ex)
            {
                _logger.LogAsError(LogEventNames.InternalCreditLockController.CustomerUpdate.ServiceTaskCanceledException,
                    new Dictionary<string, object> { { LogContext, new { ErrorMessage = ex.Message, Exception = ex } } });

                await RaiseEvent(requestType, MessageConstants.DownstreamTimeoutStatusCode, MessageConstants.DownstreamTimeout);

                return new ErrorResponseBuilder()
                    .WithStatusCode(MessageConstants.DownstreamTimeoutStatusCode)
                    .Build();
            }
            catch (ServiceUnavailableException ex)
            {
                _logger.LogAsError(LogEventNames.InternalCreditLockController.CustomerUpdate.ServiceUnavailableException,
                    new Dictionary<string, object> { { LogContext, new { ErrorMessage = ex.Message, Exception = ex } } });

                await RaiseEvent(requestType, (int)HttpStatusCode.ServiceUnavailable, "Service Unavailable");

                return new ErrorResponseBuilder()
                    .WithStatusCode(HttpStatusCode.ServiceUnavailable)
                    .Build();
            }
            catch (DownstreamBadResponseException ex)
            {
                _logger.LogAsError(LogEventNames.InternalCreditLockController.CustomerUpdate.DownstreamBadResponse,
                    new Dictionary<string, object> { { LogContext, new { ErrorMessage = ex.Message, Exception = ex } } });

                await RaiseEvent(requestType, (int)HttpStatusCode.NotFound, "Downstream Bad Request");

                return new ErrorResponseBuilder()
                    .WithStatusCode(DownstreamBadRequestStatusCode)
                    .Build();
            }
            catch (CustomerNotFoundException)
            {
                _logger.LogAsInformation(LogEventNames.InternalCreditLockController.CustomerUpdate.CustomerNotFoundException);

                await RaiseEvent(requestType, (int)HttpStatusCode.NoContent, "VIP Customer is Not Found");

                return new ApiResult(HttpStatusCode.NoContent, null);
            }
            catch (SyncCustomerPinningException)
            {
                _logger.LogAsInformation(LogEventNames.InternalCreditLockController.CustomerUpdate.SyncCustomerPinningException);

                await RaiseEvent(requestType, (int)HttpStatusCode.Conflict, "Conflict - customer waiting to be pinned or pinning in process");

                return new ErrorResponseBuilder()
                    .WithStatusCode(HttpStatusCode.Conflict)
                    .Build();
            }
            catch (DownstreamAuthenticationException)
            {
                _logger.LogAsError(LogEventNames.InternalCreditLockController.CustomerUpdate.DownstreamAuthenticationException);

                await RaiseEvent(requestType, DownstreamAuthenticationExceptionStatusCode, MessageConstants.DownstreamAuthenticationFailed);

                return new ErrorResponseBuilder()
                    .WithStatusCode(DownstreamAuthenticationExceptionStatusCode)
                    .Build();
            }
            catch (Exception ex)
            {
                _logger.LogAsError(LogEventNames.InternalCreditLockController.CustomerUpdate.UnhandledException,
                    new Dictionary<string, object> { { LogContext, new { Exception = ex } } });

                await RaiseEvent(requestType, (int)HttpStatusCode.InternalServerError, "Internal Server Error");

                return new ErrorResponseBuilder()
                    .WithStatusCode((int)HttpStatusCode.InternalServerError)
                    .Build();
            }
        }
    }
}