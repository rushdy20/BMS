﻿using AutoMapper;
using Experian.AWS.Logging.Extensions;
using EXPN.BusinessLayer.CreditLockService.Constants;
using EXPN.DataLayer.CreditLockService.Paas.HttpClient;
using EXPN.Models.CreditLockService.Internal;
using EXPN.Models.CreditLockService.Internal.Get.Response;
using EXPN.Models.CreditLockService.Internal.Post.Response;
using EXPN.Models.CreditLockService.Paas.Post.Request;
using Microsoft.Extensions.Logging;
using System;

namespace EXPN.BusinessLayer.CreditLockService.Commands
{
    public class CreateCustomerCommand<TRequest, TResponse> : ICommand<TRequest, TResponse>
        where TRequest : CustomerRequest
        where TResponse : PostCustomerResponse
    {
        private readonly ICreditLockPaasClient _creditLockPaasClient;
        private readonly ILogger<CreateCustomerCommand<TRequest, TResponse>> _logger;
        private readonly IMapper _mapper;

        public CreateCustomerCommand(
            ICreditLockPaasClient creditLockPaasClient, 
            ILogger<CreateCustomerCommand<TRequest, TResponse>> logger,
            IMapper mapper)
        {
            _creditLockPaasClient = creditLockPaasClient ?? throw new ArgumentNullException(nameof(creditLockPaasClient));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        }

        public string Id => "CUSTOMER-CREATE";

        public TResponse Execute(TRequest request, GetResponseCustomerProfile customerProfile)
        {
            _logger.LogAsInformation(LogEventNames.CreateCustomerCommand.Execute.Enter);

            if (request == null)
                throw new ArgumentNullException(nameof(request));
            
            if (customerProfile == null)
                throw new ArgumentNullException(nameof(customerProfile));

            if (string.IsNullOrWhiteSpace(request.CustomerId))
                throw new ArgumentException($"{nameof(request.CustomerId)} cannot be null or whitespace", nameof(request));

            var postCustomerRequest = _mapper.Map<PostCustomerRequest>(customerProfile);

            _creditLockPaasClient.Post(postCustomerRequest).Wait();

            _logger.LogAsInformation(LogEventNames.CreateCustomerCommand.Execute.Exit);

            return (TResponse) new PostCustomerResponse
            {
                CustomerProfile = customerProfile,
                PaaSRequest = postCustomerRequest
            };
        }
    }
}