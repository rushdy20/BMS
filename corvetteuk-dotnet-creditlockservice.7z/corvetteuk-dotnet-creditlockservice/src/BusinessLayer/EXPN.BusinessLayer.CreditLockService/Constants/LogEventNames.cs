﻿namespace EXPN.BusinessLayer.CreditLockService.Constants
{
    public struct LogEventNames
    {
        public struct BenefitChecker
        {
            public struct EnsureValidBenefitAsync
            {
                public const string Start = "EnsureValidBenefitAsync_Start";
            }
        }

        public struct CreditLockServiceCustomerManager
        {
            public struct Activate
            {
                public const string Enter = "CreditLockServiceCustomerManager_Activate_Enter";
                public const string Exit = "CreditLockServiceCustomerManager_Activate_Exit";
            }

            public struct Delete
            {
                public const string Enter = "CreditLockServiceCustomerManager_Delete_Enter";
                public const string Exit = "CreditLockServiceCustomerManager_Delete_Exit";
            }

            public struct Sync
            {
                public const string Enter = "CreditLockServiceCustomerManager_Sync_Enter";
                public const string Exit = "CreditLockServiceCustomerManager_Sync_Exit";
            }

            public struct Update
            {
                public const string Enter = "CreditLockServiceCustomerManager_Update_Enter";
                public const string Exit = "CreditLockServiceCustomerManager_Update_Exit";
            }

            public struct GetCustomer
            {
                public const string Enter = "CreditLockServiceCustomerManager_GetCustomer_Enter";
                public const string Exit = "CreditLockServiceCustomerManager_GetCustomer_Exit";
            }

            public struct PutLockStatus
            {
                public const string Enter = "CreditLockServiceCustomerManager_PutLockStatus_Enter";
                public const string Exit = "CreditLockServiceCustomerManager_PutLockStatus_Exit";
            }

            public struct DeleteCustomer
            {
                public const string Enter = "CreditLockServiceCustomerManager_DeleteCustomer_Enter";
                public const string Exit = "CreditLockServiceCustomerManager_DeleteCustomer_Exit";
            }

            public struct DeactivateInstantAlert
            {
                public const string Enter = "CreditLockServiceCustomerManager_PutLockStatus_Enter";
                public const string Exit = "CreditLockServiceCustomerManager_PutLockStatus_Exit";
            }

            public struct ActivateInstantAlert
            {
                public const string Enter = "CreditLockServiceCustomerManager_ActivateInstantAlert_Enter";
                public const string Exit = "CreditLockServiceCustomerManager_ActivateInstantAlert_Exit";
            }
        }

        public struct CreateCustomerCommand
        {
            public struct Execute
            {
                public const string Enter = "CreateCustomerCommand_Execute_Enter";
                public const string Exit = "CreateCustomerCommand_Execute_Exit";
            }
        }

        public struct GetCustomerCommand
        {
            public struct Execute
            {
                public const string Enter = "GetCustomerCommand_Execute_Enter";
                public const string Exit = "GetCustomerCommand_Execute_Exit";
            }
        }

        public struct PutLockStatusCommand
        {
            public struct Execute
            {
                public const string Enter = "PutLockStatusCommand_Execute_Enter";
                public const string Exit = "PutLockStatusCommand_Execute_Exit";
            }
        }

        public struct DeleteCustomerCommand
        {
            public struct Execute
            {
                public const string Enter = "DeleteCustomerCommand_Execute_Enter";
                public const string Exit = "DeleteCustomerCommand_Execute_Exit";
            }
        }

        public struct SyncCustomerCommand
        {
            public struct Execute
            {
                public const string Enter = "SyncCustomerCommand_Execute_Enter";
                public const string NoChanges = "SyncCustomerCommand_Execute_NoChanges";
                public const string HasChanges = "SyncCustomerCommand_Execute_HasChanges";
                public const string Exit = "SyncCustomerCommand_Execute_Exit";
            }
        }

        public struct DeactivateInstantAlertCommand
        {
            public struct Execute
            {
                public const string Enter = "DeactivateInstantAlertCommand_Execute_Enter";
                public const string Exit = "DeactivateInstantAlertCommand_Execute_Exit";
            }
        }

        public struct ActivateInstantAlertCommand
        {
            public struct Execute
            {
                public const string Enter = "ActivateInstantAlertCommand_Execute_Enter";
                public const string Exit = "ActivateInstantAlertCommand_Execute_Exit";
            }
        }
    }
}