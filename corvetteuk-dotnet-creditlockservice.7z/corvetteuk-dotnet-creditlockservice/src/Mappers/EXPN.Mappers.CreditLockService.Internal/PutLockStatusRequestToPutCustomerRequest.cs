﻿using AutoMapper;
using EXPN.Models.CreditLockService.Internal.Put.Request;
using System.Diagnostics.CodeAnalysis;

namespace EXPN.Mappers.CreditLockService.Internal
{
    [ExcludeFromCodeCoverage]
    public class PutLockStatusRequestToPutCustomerRequest : Profile
    {
        public PutLockStatusRequestToPutCustomerRequest()
        {
            CreateMap<PutLockStatusRequest, PutCustomerRequest>();
        }
    }
}