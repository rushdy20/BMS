﻿using EXPN.Models.CreditLockService.External.Delete.Request;
using EXPN.Models.CreditLockService.External.Get.Customer.Request;
using EXPN.Models.CreditLockService.External.Post.Request;
using EXPN.Models.CreditLockService.External.Put.Request;
using EXPN.Validators.CreditLockService.Delete;
using EXPN.Validators.CreditLockService.Get;
using EXPN.Validators.CreditLockService.Post;
using EXPN.Validators.CreditLockService.Put;
using EXPN.Validators.CreditLockService.Put.Customer;
using FluentValidation;
using Microsoft.Extensions.DependencyInjection;

namespace EXPN.Validators.CreditLockService
{
    public static class ValidatorsModule
    {
        public static IServiceCollection RegisterValidatorsModule(this IServiceCollection services)
        {
            services.AddTransient<IValidator<PutStatusRequestBody>, PutStatusRequestBodyValidator>();
            services.AddTransient<IValidator<PutStatusRequest>, PutStatusRequestValidator>();
            services.AddTransient<IValidator<GetStatusRequest>, GetStatusRequestModelValidator>();
            services.AddTransient<IValidator<PostRequest>, PostSubscriptionRequestValidator>();
            services.AddTransient<IValidator<DeleteCustomerRequest>, DeleteCustomerRequestValidator>();
            services.AddTransient<IValidator<PutStatusAgentRequestBody>, PutLockStatusAgentRequestBodyValidator>();
            services.AddTransient<IValidator<PutStatusAgentRequest>, PutStatusAgentRequestValidator>();
            services.AddTransient<IValidator<DeleteEventBody>, DeleteEventBodyValidator>();
            return services;
        }
    }
}