﻿using Experian.HttpClient.Services.Customers.Models.External;
using System;
using System.Collections.Generic;
using System.Linq;

namespace EXPN.Mappers.CreditLockService.Internal.Extensions
{
    public static class Utility
    {
        public static string TrimToSize(this string fieldContent, int length)
        {
            var trimmedField = fieldContent?.Trim();

            return trimmedField?.Substring(0, Math.Min(trimmedField.Length, length));
        }

        public static IEnumerable<AddressModel> TakeOnlylastNineNonOverseasAddress(IEnumerable<AddressModel> profileAddress)
        {
            var validAddresses = RemoveAddressWithNullOrEmptyPostcode(profileAddress)
                        ?.Where(
                        x => (x.ToDt.HasValue && x.ToDt.Value != default) || x.FromDt != default)
                        .ToList();

            return validAddresses?.Where(a => !a.Abroad).Take(9).ToList();
        }

        private static IEnumerable<AddressModel> RemoveAddressWithNullOrEmptyPostcode(IEnumerable<AddressModel> profileAddress)
        {
            return profileAddress.Where(a => !string.IsNullOrEmpty(a.PostCode?.Trim())).ToList();
        }
    }
}