﻿using System.Diagnostics.CodeAnalysis;
using Microsoft.Extensions.DependencyInjection;

namespace EXPN.Controllers.CreditLockService.Messaging
{
    [ExcludeFromCodeCoverage]
    public static class MessagingModule
    {
        public static IServiceCollection AddMessagingModule(this IServiceCollection services)
        {
            services
                .AddScoped<IMessaging, Controllers.CreditLockService.Messaging.Messaging>()
                .AddScoped<ITopicRetriever, TopicRetriever>();

            return services;
        }
    }
}