﻿using System.Threading.Tasks;

namespace EXPN.DataLayer.CreditLockService.Paas
{
    public interface ISecretsManager
    {
        Task<T> GetSecretAsync<T>(string key);
        Task<string> GetSecretAsync(string key);
    }
}