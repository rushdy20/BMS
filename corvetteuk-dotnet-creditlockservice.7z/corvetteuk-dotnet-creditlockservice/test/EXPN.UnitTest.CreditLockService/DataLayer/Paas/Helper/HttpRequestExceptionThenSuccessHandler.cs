﻿using System.IO;
using System.Net.Http;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace EXPN.UnitTest.CreditLockService.DataLayer.Paas.Helper
{
    public class HttpRequestExceptionThenSuccessHandler : DelegatingHandler
    {
        private int HandlerCount = 0;

        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            HandlerCount++;

            if (HandlerCount == 1)
                throw new HttpRequestException("Test Message", new IOException("Base Message"));

            return Task.FromResult(new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.NoContent,
                Content = new StringContent("test", Encoding.UTF8, "application/json")
            });
        }
    }
}