﻿
using Newtonsoft.Json;

namespace EXPN.Models.CreditLockService.Paas.Delete.Request
{
 public class DeleteCustomerRequest
    {
        public string CustomerRef { get; set; }

        [JsonIgnore]
        public string CustomerId { get; set; }
    }
}
