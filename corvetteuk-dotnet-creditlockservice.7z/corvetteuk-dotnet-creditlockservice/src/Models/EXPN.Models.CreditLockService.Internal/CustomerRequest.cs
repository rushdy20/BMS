﻿namespace EXPN.Models.CreditLockService.Internal
{
    public class CustomerRequest
    {
        public string CustomerId { get; set; }
    }
}