﻿using AutoMapper;
using EXPN.Models.CreditLockService.Internal;
using EXPN.Models.CreditLockService.Paas;

namespace EXPN.Mappers.CreditLockService.Paas
{
    public class SecretsManagerDataToOktaAuthCredentialProfile : Profile
    {
        public SecretsManagerDataToOktaAuthCredentialProfile()
        {
            CreateMap<SecretsManagerData, OktaAuthCredentials>();
        }
    }
}