﻿namespace EXPN.Controllers.CreditLockService.Constants
{
    public struct MessageConstants
    {
        public const int DownstreamTimeoutStatusCode = 564;
        public const string DownstreamTimeout = "Downstream-Service-Timeout";
        public const string DownstreamAuthenticationFailed = "Downstream Service Authentication Failed";
    }
}