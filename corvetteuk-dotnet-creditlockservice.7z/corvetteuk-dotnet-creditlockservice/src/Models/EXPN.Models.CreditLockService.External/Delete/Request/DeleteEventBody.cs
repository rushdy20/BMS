﻿using System.Diagnostics.CodeAnalysis;

namespace EXPN.Models.CreditLockService.External.Delete.Request
{
    [ExcludeFromCodeCoverage]
    public  class DeleteEventBody
    {
        public string CustomerId { get; set; }
        public string CustomerNumber { get; set; }
        public string IdpRefId { get; set; }
        public string TenantId { get; set; }
    }
}