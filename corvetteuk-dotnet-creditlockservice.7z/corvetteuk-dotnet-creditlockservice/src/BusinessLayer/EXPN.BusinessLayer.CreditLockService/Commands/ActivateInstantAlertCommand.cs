﻿using System;
using AutoMapper;
using Experian.AWS.Logging.Extensions;
using EXPN.BusinessLayer.CreditLockService.Constants;
using EXPN.DataLayer.CreditLockService.Paas.HttpClient;
using EXPN.Models.CreditLockService.Internal.Get.Response;
using EXPN.Models.CreditLockService.Internal.Post.Request;
using EXPN.Models.CreditLockService.Internal.Post.Response;
using EXPN.Models.CreditLockService.Paas.PutAlertStatus.Request;
using Microsoft.Extensions.Logging;

namespace EXPN.BusinessLayer.CreditLockService.Commands
{
  public  class ActivateInstantAlertCommand<TRequest, TResponse> : ICommand<TRequest, TResponse>
      where TRequest : PostActivateInstantAlertRequest
      where TResponse : PostActivateInstantAlertResponse
    {
        private readonly ICreditLockPaasClient _creditLockPaasClient;
        private readonly ILogger<ActivateInstantAlertCommand<TRequest, TResponse>> _logger;
        private readonly IMapper _mapper;

        public ActivateInstantAlertCommand(
            ICreditLockPaasClient creditLockPaasClient,
            ILogger<ActivateInstantAlertCommand<TRequest, TResponse>> logger,
            IMapper mapper)
        {
            _creditLockPaasClient = creditLockPaasClient ?? throw new ArgumentNullException(nameof(creditLockPaasClient));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        }

        public string Id => "ACTIVATE-INSTANT-ALERT";

        public TResponse Execute(TRequest request, GetResponseCustomerProfile customerProfile)
        {
            _logger.LogAsInformation(LogEventNames.ActivateInstantAlertCommand.Execute.Enter);

            if (request == null)
                throw new ArgumentNullException(nameof(request));

            if (customerProfile == null)
                throw new ArgumentNullException(nameof(customerProfile));

            if (string.IsNullOrWhiteSpace(request.CustomerId))
                throw new ArgumentException($"{nameof(request.CustomerId)} cannot be null or whitespace", nameof(request));

            var activateInstantAlertRequest = _mapper.Map<PostActivateInstantAlertRequest>(customerProfile);

            var paasPutAlertStatusRequest = _mapper.Map<PutAlertStatusRequest>(activateInstantAlertRequest);

            _creditLockPaasClient.PutAlertStatus(paasPutAlertStatusRequest).Wait();

            _logger.LogAsInformation(LogEventNames.ActivateInstantAlertCommand.Execute.Exit);

            return (TResponse)new PostActivateInstantAlertResponse
            {
                LockStatus = paasPutAlertStatusRequest.Status
            };
        }
    }
}
