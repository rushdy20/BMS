﻿using System;
using System.Collections.Generic;
using AutoMapper;
using Experian.AWS.Logging.Extensions;
using EXPN.BusinessLayer.CreditLockService.Commands;
using EXPN.BusinessLayer.CreditLockService.Constants;
using EXPN.BusinessLayer.CreditLockService.Exceptions;
using EXPN.BusinessLayer.CreditLockService.Extension;
using EXPN.DataLayer.CreditLockService.Paas.HttpClient;
using EXPN.Models.CreditLockService.Internal.Get.Response;
using EXPN.Models.CreditLockService.Internal.Put.Request;
using EXPN.Models.CreditLockService.Internal.Put.Response;
using EXPN.Models.CreditLockService.Paas;
using FluentAssertions;
using Microsoft.Extensions.Logging;
using NSubstitute;
using Xunit;
using PaaSPutRequest = EXPN.Models.CreditLockService.Paas.Put.Request;
using PaaSRequest = EXPN.Models.CreditLockService.Paas.Get.Request;

namespace EXPN.UnitTest.CreditLockService.BusinessLayer.Commands
{
    public class SyncCustomerCommandTests
    {
        private readonly ICreditLockPaasClient _creditLockPaaSClient;
        private readonly ILogger<SyncCustomerCommand<PutCustomerRequest, PutCustomerResponse>> _logger;
        private readonly IMapper _mapper;

        private readonly ICommand<PutCustomerRequest, PutCustomerResponse> _syncCustomerCommand;

        public SyncCustomerCommandTests()
        {
            _creditLockPaaSClient = Substitute.For<ICreditLockPaasClient>();
            _logger = Substitute.For<ILogger<SyncCustomerCommand<PutCustomerRequest, PutCustomerResponse>>>();
            _mapper = Substitute.For<IMapper>();
            _syncCustomerCommand = new SyncCustomerCommand<PutCustomerRequest, PutCustomerResponse>(_creditLockPaaSClient, _logger, _mapper);
        }

        public class Constructor
        {
            public static IEnumerable<object[]> NullParameters()
            {
                yield return new object[]
                {
                    null,
                    Substitute.For<ILogger<SyncCustomerCommand<PutCustomerRequest, PutCustomerResponse>>>(),
                    Substitute.For<IMapper>(),
                    "creditLockPaasClient"
                };

                yield return new object[]
                {
                    Substitute.For<ICreditLockPaasClient>(),
                    null,
                    Substitute.For<IMapper>(),
                    "logger"
                };

                yield return new object[]
                {
                    Substitute.For<ICreditLockPaasClient>(),
                    Substitute.For<ILogger<SyncCustomerCommand<PutCustomerRequest, PutCustomerResponse>>>(),
                    null,
                    "mapper"
                };
            }

            [Theory]
            [MemberData(nameof(NullParameters))]
            public void NullRequiredConstructorParameter_ThrowsArgumentNullException(
                ICreditLockPaasClient paasHttpClient,
                ILogger<SyncCustomerCommand<PutCustomerRequest, PutCustomerResponse>> logger,
                IMapper mapper,
                string expectedErrorParameter)
            {
                Action action = () => { new SyncCustomerCommand<PutCustomerRequest, PutCustomerResponse>(paasHttpClient, logger, mapper); };

                action.Should().Throw<ArgumentNullException>()
                    .Where(x => x.ParamName == expectedErrorParameter);
            }

            [Fact]
            public void Id_IsCorrect()
            {
                new SyncCustomerCommand<PutCustomerRequest, PutCustomerResponse>(
                    Substitute.For<ICreditLockPaasClient>(),
                    Substitute.For<ILogger<SyncCustomerCommand<PutCustomerRequest, PutCustomerResponse>>>(),
                    Substitute.For<IMapper>()).Id.Should().Be("CUSTOMER-SYNC");
            }
        }

        public class Execute : SyncCustomerCommandTests
        {
            public static IEnumerable<object[]> LogInformationMessages()
            {
                yield return new object[]
                {
                    LogEventNames.SyncCustomerCommand.Execute.Enter
                };

                yield return new object[]
                {
                    LogEventNames.SyncCustomerCommand.Execute.Exit
                };
            }

            [Theory]
            [MemberData(nameof(LogInformationMessages))]
            public void HappyPathInformationLogged(string loggerMessage)
            {
                const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

                var getResponseCustomerProfile = new GetResponseCustomerProfile
                {
                    CustomerId = customerId,
                    CustomerRef = "customerRef"
                };

                var paasGetCustomerRequest = new PaaSRequest.GetCustomerRequest
                {
                    CustomerRef = "customerRef"
                };

                var getCustomerResponse = new GetCustomerResponse
                {
                    Addresses = new List<GetResponsePaasAddressResponse>()
                };

                var paasPutCustomerRequest = new PaaSPutRequest.PutCustomerRequest
                {
                    IconRef = "ABC",
                    Name = new CustomerName
                    {
                        FirstName = "changed"
                    },
                    AddressesToAdd = new List<PaaSPutRequest.PutCustomerAddressRequest>(),
                    AddressesToDelete = new List<string>()
                };

                var putCustomerRequest = new PutCustomerRequest
                {
                    CustomerId = customerId
                };

                var getCustomerPaasResponse = new Models.CreditLockService.Paas.Get.Response.GetCustomerResponse
                {
                    LockStatus = "ON"
                };

                _mapper.Map<PaaSRequest.GetCustomerRequest>(getResponseCustomerProfile)
                    .Returns(paasGetCustomerRequest);

                _mapper.Map<GetResponseCustomerProfile, PaaSPutRequest.PutCustomerRequest>(getResponseCustomerProfile)
                    .Returns(paasPutCustomerRequest);

                _mapper.Map<GetCustomerResponse>(getCustomerPaasResponse)
                    .Returns(getCustomerResponse);

                _creditLockPaaSClient.GetPaasCustomerAsync(paasGetCustomerRequest)
                    .Returns(getCustomerPaasResponse);

                _mapper.Map<GetResponseCustomerProfile, GetCustomerResponse, PaaSPutRequest.PutCustomerRequest>(getResponseCustomerProfile, getCustomerResponse)
                    .Returns(paasPutCustomerRequest);

                _syncCustomerCommand.Execute(putCustomerRequest, getResponseCustomerProfile);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(loggerMessage)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public void ExecuteSyncCustomerCommandRequestNull_ThrowsArgumentNullException()
            {
                Action action = () => { _syncCustomerCommand.Execute(null, null); };

                action.Should().Throw<ArgumentNullException>()
                    .Where(x => x.ParamName == "request");
            }

            [Fact]
            public void ExecuteSyncCustomerCommandCustomerProfileNull_ThrowsArgumentNullException()
            {
                Action action = () => { _syncCustomerCommand.Execute(new PutCustomerRequest(), null); };

                action.Should().Throw<ArgumentNullException>()
                    .Where(x => x.ParamName == "customerProfile");
            }

            [Theory]
            [InlineData(null)]
            [InlineData("")]
            [InlineData("     ")]
            public void ExecuteSyncCustomerCommandRequestInvalidCustomerId_ThrowsArgumentException(string customerId)
            {
                var putCustomerRequest = new PutCustomerRequest
                {
                    CustomerId = customerId
                };

                Action action = () => { _syncCustomerCommand.Execute(putCustomerRequest, new GetResponseCustomerProfile()); };

                action.Should().Throw<ArgumentException>()
                    .Where(x => x.Message == "CustomerId cannot be null or whitespace (Parameter 'request')");
            }

            public static IEnumerable<object[]> PinnedAddresses()
            {
                yield return new object[]
                {
                    null
                };

                yield return new object[]
                {
                    new List<GetResponsePaasAddressResponse>()
                };

                yield return new object[]
                {
                    new List<GetResponsePaasAddressResponse>
                    {
                        new GetResponsePaasAddressResponse
                        {
                            PinStatus = "3"
                        }
                    }
                };

                yield return new object[]
                {
                    new List<GetResponsePaasAddressResponse>
                    {
                        new GetResponsePaasAddressResponse
                        {
                            PinStatus = "4"
                        }
                    }
                };

                yield return new object[]
                {
                    new List<GetResponsePaasAddressResponse>
                    {
                        new GetResponsePaasAddressResponse
                        {
                            PinStatus = "D"
                        }
                    }
                };

                yield return new object[]
                {
                    new List<GetResponsePaasAddressResponse>
                    {
                        new GetResponsePaasAddressResponse
                        {
                            PinStatus = "P"
                        }
                    }
                };

                yield return new object[]
                {
                    new List<GetResponsePaasAddressResponse>
                    {
                        new GetResponsePaasAddressResponse
                        {
                            PinStatus = "E"
                        }
                    }
                };

                yield return new object[]
                {
                    new List<GetResponsePaasAddressResponse>
                    {
                        new GetResponsePaasAddressResponse
                        {
                            PinStatus = "3"
                        },
                        new GetResponsePaasAddressResponse
                        {
                            PinStatus = "4"
                        }
                    }
                };

                yield return new object[]
                {
                    new List<GetResponsePaasAddressResponse>
                    {
                        new GetResponsePaasAddressResponse
                        {
                            PinStatus = "3"
                        },
                        new GetResponsePaasAddressResponse
                        {
                            PinStatus = "4"
                        },
                        new GetResponsePaasAddressResponse
                        {
                            PinStatus = "D"
                        }
                    }
                };
            }

            [Theory]
            [MemberData(nameof(PinnedAddresses))]
            public void ValidRequest_Execute_WithChanges_Success(IEnumerable<GetResponsePaasAddressResponse> getResponsePaasAddressResponses)
            {
                const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

                var getResponseCustomerProfile = new GetResponseCustomerProfile
                {
                    CustomerId = customerId,
                    CustomerRef = "customerRef"
                };

                var paasGetCustomerRequest = new PaaSRequest.GetCustomerRequest
                {
                    CustomerRef = "customerRef"
                };

                var getCustomerResponse = new GetCustomerResponse
                {
                    Addresses = getResponsePaasAddressResponses
                };

                var paasPutCustomerRequest = new PaaSPutRequest.PutCustomerRequest
                {
                    IconRef = "ABC",
                    Name = new CustomerName
                    {
                        FirstName = "changed"
                    },
                    AddressesToAdd = new List<PaaSPutRequest.PutCustomerAddressRequest>(),
                    AddressesToDelete = new List<string>()
                };

                var putCustomerRequest = new PutCustomerRequest
                {
                    CustomerId = customerId
                };

                var getCustomerPaasResponse = new Models.CreditLockService.Paas.Get.Response.GetCustomerResponse
                {
                    LockStatus = "ON"
                };

                _mapper.Map<PaaSRequest.GetCustomerRequest>(getResponseCustomerProfile)
                    .Returns(paasGetCustomerRequest);

                _mapper.Map<GetResponseCustomerProfile, PaaSPutRequest.PutCustomerRequest>(getResponseCustomerProfile)
                    .Returns(paasPutCustomerRequest);

                _mapper.Map<GetCustomerResponse>(getCustomerPaasResponse)
                    .Returns(getCustomerResponse);

                _creditLockPaaSClient.GetPaasCustomerAsync(paasGetCustomerRequest)
                    .Returns(getCustomerPaasResponse);

                _mapper.Map<GetResponseCustomerProfile, GetCustomerResponse, PaaSPutRequest.PutCustomerRequest>(getResponseCustomerProfile, getCustomerResponse)
                    .Returns(paasPutCustomerRequest);

                _syncCustomerCommand.Execute(putCustomerRequest, getResponseCustomerProfile);

                _mapper.Received(1).Map<PaaSRequest.GetCustomerRequest>(getResponseCustomerProfile);
                _mapper.Received(1).Map<GetCustomerResponse>(getCustomerPaasResponse);

                _creditLockPaaSClient.Received(1).Put(paasPutCustomerRequest);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.SyncCustomerCommand.Execute.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.SyncCustomerCommand.Execute.HasChanges)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.SyncCustomerCommand.Execute.NoChanges)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.SyncCustomerCommand.Execute.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public void ValidRequest_Execute_WithoutChanges_Success()
            {
                const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

                var getResponseCustomerProfile = new GetResponseCustomerProfile
                {
                    CustomerId = customerId,
                    CustomerRef = "customerRef"
                };

                var paasGetCustomerRequest = new PaaSRequest.GetCustomerRequest
                {
                    CustomerRef = "customerRef"
                };

                var getCustomerResponse = new GetCustomerResponse
                {
                    Addresses = new List<GetResponsePaasAddressResponse>()
                };

                var paasPutCustomerRequest = new PaaSPutRequest.PutCustomerRequest();

                var putCustomerRequest = new PutCustomerRequest
                {
                    CustomerId = customerId
                };

                var getCustomerPaasResponse = new Models.CreditLockService.Paas.Get.Response.GetCustomerResponse
                {
                    LockStatus = "ON"
                };

                _mapper.Map<PaaSRequest.GetCustomerRequest>(getResponseCustomerProfile)
                    .Returns(paasGetCustomerRequest);

                _mapper.Map<GetResponseCustomerProfile, PaaSPutRequest.PutCustomerRequest>(getResponseCustomerProfile)
                    .Returns(paasPutCustomerRequest);

                _mapper.Map<GetCustomerResponse>(getCustomerPaasResponse)
                    .Returns(getCustomerResponse);

                _creditLockPaaSClient.GetPaasCustomerAsync(paasGetCustomerRequest)
                    .Returns(getCustomerPaasResponse);

                _mapper.Map<GetResponseCustomerProfile, GetCustomerResponse, PaaSPutRequest.PutCustomerRequest>(getResponseCustomerProfile, getCustomerResponse)
                    .Returns(paasPutCustomerRequest);

                _syncCustomerCommand.Execute(putCustomerRequest, getResponseCustomerProfile);

                _mapper.Received(1).Map<PaaSRequest.GetCustomerRequest>(getResponseCustomerProfile);
                _mapper.Received(1).Map<GetCustomerResponse>(getCustomerPaasResponse);

                _creditLockPaaSClient.DidNotReceive().Put(paasPutCustomerRequest);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.SyncCustomerCommand.Execute.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.SyncCustomerCommand.Execute.HasChanges)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.SyncCustomerCommand.Execute.NoChanges)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.SyncCustomerCommand.Execute.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            public static IEnumerable<object[]> UnpinnedAddresses()
            {
                yield return new object[]
                {
                    new List<GetResponsePaasAddressResponse>
                    {
                        new GetResponsePaasAddressResponse
                        {
                            PinStatus = "N"
                        }
                    }
                };

                yield return new object[]
                {
                    new List<GetResponsePaasAddressResponse>
                    {
                        new GetResponsePaasAddressResponse
                        {
                            PinStatus = "0"
                        }
                    }
                };

                yield return new object[]
                {
                    new List<GetResponsePaasAddressResponse>
                    {
                        new GetResponsePaasAddressResponse
                        {
                            PinStatus = "1"
                        }
                    }
                };

                yield return new object[]
                {
                    new List<GetResponsePaasAddressResponse>
                    {
                        new GetResponsePaasAddressResponse
                        {
                            PinStatus = "2"
                        }
                    }
                };

                yield return new object[]
                {
                    new List<GetResponsePaasAddressResponse>
                    {
                        new GetResponsePaasAddressResponse
                        {
                            PinStatus = "N"
                        },
                        new GetResponsePaasAddressResponse
                        {
                            PinStatus = "N"
                        }
                    }
                };

                yield return new object[]
                {
                    new List<GetResponsePaasAddressResponse>
                    {
                        new GetResponsePaasAddressResponse
                        {
                            PinStatus = "0"
                        },
                        new GetResponsePaasAddressResponse
                        {
                            PinStatus = "1"
                        },
                        new GetResponsePaasAddressResponse
                        {
                            PinStatus = "2"
                        }
                    }
                };

                yield return new object[]
                {
                    new List<GetResponsePaasAddressResponse>
                    {
                        new GetResponsePaasAddressResponse
                        {
                            PinStatus = "3"
                        },
                        new GetResponsePaasAddressResponse
                        {
                            PinStatus = "4"
                        },
                        new GetResponsePaasAddressResponse
                        {
                            PinStatus = "N"
                        }
                    }
                };

                yield return new object[]
                {
                    new List<GetResponsePaasAddressResponse>
                    {
                        new GetResponsePaasAddressResponse
                        {
                            PinStatus = "3"
                        },
                        new GetResponsePaasAddressResponse
                        {
                            PinStatus = "4"
                        },
                        new GetResponsePaasAddressResponse
                        {
                            PinStatus = "0"
                        }
                    }
                };

                yield return new object[]
                {
                    new List<GetResponsePaasAddressResponse>
                    {
                        new GetResponsePaasAddressResponse
                        {
                            PinStatus = "3"
                        },
                        new GetResponsePaasAddressResponse
                        {
                            PinStatus = "1"
                        },
                        new GetResponsePaasAddressResponse
                        {
                            PinStatus = "4"
                        }
                    }
                };

                yield return new object[]
                {
                    new List<GetResponsePaasAddressResponse>
                    {
                        new GetResponsePaasAddressResponse
                        {
                            PinStatus = "2"
                        },
                        new GetResponsePaasAddressResponse
                        {
                            PinStatus = "3"
                        },
                        new GetResponsePaasAddressResponse
                        {
                            PinStatus = "4"
                        }
                    }
                };
            }
            
            [Theory]
            [MemberData(nameof(UnpinnedAddresses))]
            public void ValidRequest_Execute_AddressesPinning_ThrowsSyncCustomerPinningException(IEnumerable<GetResponsePaasAddressResponse> getResponsePaasAddressResponses)
            {
                const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

                var getResponseCustomerProfile = new GetResponseCustomerProfile
                {
                    CustomerId = customerId,
                    CustomerRef = "customerRef"
                };

                var paasGetCustomerRequest = new PaaSRequest.GetCustomerRequest
                {
                    CustomerRef = "customerRef"
                };

                var getCustomerResponse = new GetCustomerResponse
                {
                    Addresses = getResponsePaasAddressResponses
                };

                var paasPutCustomerRequest = new PaaSPutRequest.PutCustomerRequest
                {
                    IconRef = "ABC",
                    Name = new CustomerName
                    {
                        FirstName = "changed"
                    }
                };

                var putCustomerRequest = new PutCustomerRequest
                {
                    CustomerId = customerId
                };

                var getCustomerPaasResponse = new Models.CreditLockService.Paas.Get.Response.GetCustomerResponse
                {
                    LockStatus = "ON"
                };

                _mapper.Map<PaaSRequest.GetCustomerRequest>(getResponseCustomerProfile)
                    .Returns(paasGetCustomerRequest);

                _mapper.Map<GetResponseCustomerProfile, PaaSPutRequest.PutCustomerRequest>(getResponseCustomerProfile)
                    .Returns(paasPutCustomerRequest);

                _mapper.Map<GetCustomerResponse>(getCustomerPaasResponse)
                    .Returns(getCustomerResponse);

                _creditLockPaaSClient.GetPaasCustomerAsync(paasGetCustomerRequest)
                    .Returns(getCustomerPaasResponse);

                _mapper.Map<GetResponseCustomerProfile, GetCustomerResponse, PaaSPutRequest.PutCustomerRequest>(getResponseCustomerProfile, getCustomerResponse)
                    .Returns(paasPutCustomerRequest);

                Action action = () =>
                {
                    _syncCustomerCommand.Execute(putCustomerRequest, getResponseCustomerProfile);
                };

                action.Should().Throw<SyncCustomerPinningException>();

                _mapper.Received(1).Map<PaaSRequest.GetCustomerRequest>(getResponseCustomerProfile);
                _mapper.Received(1).Map<GetCustomerResponse>(getCustomerPaasResponse);

                _creditLockPaaSClient.DidNotReceive().Put(paasPutCustomerRequest);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.SyncCustomerCommand.Execute.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.SyncCustomerCommand.Execute.HasChanges)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.SyncCustomerCommand.Execute.NoChanges)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.SyncCustomerCommand.Execute.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }
        }
    }
}