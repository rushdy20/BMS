using Microsoft.AspNetCore.Hosting;
using System.IO;
using Microsoft.AspNetCore.TestHost;
using Microsoft.Extensions.Hosting;

namespace EXPN.IntegrationTest.CreditLockService.Utility
{
    public static class WebHostBuilderExtensions
    {
        public static IHostBuilder UseIntegrationTestSettings(this HostBuilder webHostBuilder)
        {
            return webHostBuilder
                .ConfigureWebHost(webHost =>
                {
                    webHost.UseTestServer();
                    webHost.UseEnvironment("Integration");
                    webHost.UseContentRoot(Path.Combine(SolutionFileSystem.Root, "src", "ServiceHost"));
                    webHost.UseStartup<TestStartup>();
                });
        }
    }
}
