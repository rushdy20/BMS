﻿using Newtonsoft.Json.Serialization;
using System;
using System.Reflection;
using System.Runtime.Serialization;

namespace EXPN.DataLayer.CreditLockService.Common.Binders
{
    public sealed class CreditLockCommonExceptionsBinder : ISerializationBinder
    {

        public void BindToName(Type serializedType, out string assemblyName, out string typeName)
        {

            if (!(serializedType.FullName == "EXPN.DataLayer.CreditLockService.Common.Exceptions.OktaException" ||
                 serializedType.FullName == "EXPN.DataLayer.CreditLockService.Common.Exceptions.OktaTokenNullException" ||
                 serializedType.FullName == "EXPN.DataLayer.CreditLockService.Common.Exceptions.OktaCredentialsEndpointNullException" ||
                 serializedType.FullName == "EXPN.DataLayer.CreditLockService.Common.Exceptions.CustomerGetRequestException" ||
                 serializedType.FullName == "EXPN.DataLayer.CreditLockService.Common.Exceptions.CustomerPostRequestConflictException" ||
                 serializedType.FullName == "EXPN.DataLayer.CreditLockService.Common.Exceptions.CustomerPostRequestException" ||
                 serializedType.FullName == "EXPN.DataLayer.CreditLockService.Common.Exceptions.CustomerPutRequestException" ||
                 serializedType.FullName == "EXPN.DataLayer.CreditLockService.Common.Exceptions.RequestBodyNullException" ||
                 serializedType.FullName == "EXPN.DataLayer.CreditLockService.Common.Exceptions.CustomerDeleteRequestException" ||
                 serializedType.FullName == "EXPN.DataLayer.CreditLockService.Common.Exceptions.LockStatusGetRequestException" ||
                 serializedType.FullName == "EXPN.DataLayer.CreditLockService.Common.Exceptions.CustomerProfileNotFoundException" ||
                 serializedType.FullName == "EXPN.DataLayer.CreditLockService.Common.Exceptions.DownstreamMaintenanceException" ||
                 serializedType.FullName == "EXPN.DataLayer.CreditLockService.Common.Exceptions.HttpServiceRequestException" ||
                 serializedType.FullName == "EXPN.DataLayer.CreditLockService.Common.Exceptions.ServiceTaskCanceledException" ||
                 serializedType.FullName == "EXPN.DataLayer.CreditLockService.Common.Exceptions.ServiceUnavailableException" ||
                 serializedType.FullName == "EXPN.DataLayer.CreditLockService.Common.Exceptions.DownstreamBadResponseException" ||
                 serializedType.FullName == "EXPN.DataLayer.CreditLockService.Common.Exceptions.CustomerNotFoundException" ||
                 serializedType.FullName == "EXPN.DataLayer.CreditLockService.Common.Exceptions.DownstreamAuthenticationException" ||
                 serializedType.FullName == "EXPN.DataLayer.CreditLockService.Common.Exceptions.BenefitsInvalidOperationException" ||
                 serializedType.FullName == "EXPN.DataLayer.CreditLockService.Common.Exceptions.LockStatusPutRequestException"))
            {
                throw new SerializationException($"{serializedType.FullName} is not a recognized type");
            }
            typeName = serializedType.FullName;
            assemblyName = serializedType.AssemblyQualifiedName;
        }

        public Type BindToType(string assemblyName, string typeName)
        {
            if (!(typeName == "EXPN.DataLayer.CreditLockService.Common.Exceptions.OktaException" ||
                  typeName == "EXPN.DataLayer.CreditLockService.Common.Exceptions.OktaTokenNullException" ||
                  typeName == "EXPN.DataLayer.CreditLockService.Common.Exceptions.OktaCredentialsEndpointNullException" ||
                  typeName == "EXPN.DataLayer.CreditLockService.Common.Exceptions.CustomerGetRequestException" ||
                  typeName == "EXPN.DataLayer.CreditLockService.Common.Exceptions.CustomerPostRequestConflictException" ||
                  typeName == "EXPN.DataLayer.CreditLockService.Common.Exceptions.CustomerPostRequestException" ||
                  typeName == "EXPN.DataLayer.CreditLockService.Common.Exceptions.CustomerPutRequestException" ||
                  typeName == "EXPN.DataLayer.CreditLockService.Common.Exceptions.RequestBodyNullException" ||
                  typeName == "EXPN.DataLayer.CreditLockService.Common.Exceptions.CustomerDeleteRequestException" ||
                  typeName == "EXPN.DataLayer.CreditLockService.Common.Exceptions.LockStatusGetRequestException" ||
                  typeName == "EXPN.DataLayer.CreditLockService.Common.Exceptions.CustomerProfileNotFoundException" ||
                  typeName == "EXPN.DataLayer.CreditLockService.Common.Exceptions.DownstreamMaintenanceException" ||
                  typeName == "EXPN.DataLayer.CreditLockService.Common.Exceptions.HttpServiceRequestException" ||
                  typeName == "EXPN.DataLayer.CreditLockService.Common.Exceptions.ServiceTaskCanceledException" ||
                  typeName == "EXPN.DataLayer.CreditLockService.Common.Exceptions.ServiceUnavailableException" ||
                  typeName == "EXPN.DataLayer.CreditLockService.Common.Exceptions.DownstreamBadResponseException" ||
                  typeName == "EXPN.DataLayer.CreditLockService.Common.Exceptions.CustomerNotFoundException" ||
                  typeName == "EXPN.DataLayer.CreditLockService.Common.Exceptions.DownstreamAuthenticationException" ||
                  typeName == "EXPN.DataLayer.CreditLockService.Common.Exceptions.BenefitsInvalidOperationException" ||
                  typeName == "EXPN.DataLayer.CreditLockService.Common.Exceptions.LockStatusPutRequestException"))
            {
                throw new SerializationException($"{typeName} is not a recognized type");
            }
            return Assembly.Load(assemblyName).GetType(typeName);
        }
    }
}