﻿using System;
using System.Runtime.Serialization;

namespace EXPN.DataLayer.CreditLockService.Common.Exceptions
{
    [Serializable]
    public class OktaCredentialsEndpointNullException : Exception
    {
        protected OktaCredentialsEndpointNullException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }

        public OktaCredentialsEndpointNullException()
        {
        }

        public OktaCredentialsEndpointNullException(string message)
            : base(message)
        {
        }

        public OktaCredentialsEndpointNullException(string message, Exception innerException)
            : base(message, innerException)
        {
        }
    }
}