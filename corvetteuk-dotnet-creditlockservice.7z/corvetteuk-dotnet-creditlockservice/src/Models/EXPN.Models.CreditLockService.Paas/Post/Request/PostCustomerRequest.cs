﻿using System.Collections.Generic;

namespace EXPN.Models.CreditLockService.Paas.Post.Request
{
    public class PostCustomerRequest : Customer
    {
        public IEnumerable<Address> Addresses { get; set; }
    }
}