﻿using EXPN.Models.CreditLockService.External.Delete.Request;
using EXPN.Validators.CreditLockService.Delete;
using System.Collections.Generic;
using System.Linq;
using FluentAssertions;
using Xunit;

namespace EXPN.UnitTest.CreditLockService.Validators
{
    public class DeleteEventBodyValidatorTests
    {
        public static IEnumerable<object[]> DeleteEventBodyData()
        {
            yield return new object[]
            {
                new DeleteEventBody
                {
                    CustomerNumber = string.Empty
                },
                false,
                "'Customer Number' should not be null"
            };

            yield return new object[]
            {
                new DeleteEventBody
                {
                    CustomerNumber = string.Empty.PadLeft(2)
                },
                false,
                "'Customer Number' should not be null"
            };

            yield return new object[]
            {
                new DeleteEventBody
                {
                    CustomerNumber = "test customerId"
                },
                true,
                null
            };          
        }

        [Theory]
        [MemberData(nameof(DeleteEventBodyData))]
        public void DeleteEventBodyValidator_ValidRequest_ShouldBeSameAsExpected(DeleteEventBody deleteEventBodyRequest, bool expected, string errorMessage)
        {
            var result = new DeleteEventBodyValidator()
                .Validate(deleteEventBodyRequest);

            if (expected)
            {
                result.IsValid.Should().BeTrue();
                result.Errors.Should().HaveCount(0);
            }
            else
            {
                result.IsValid.Should().BeFalse();
                result.Errors.Should().HaveCount(1);
                result.Errors.Select(x => x.ErrorMessage).FirstOrDefault().Should().BeEquivalentTo(errorMessage);
            }
        }
    }
}