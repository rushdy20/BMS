﻿using Amazon.SimpleNotificationService;
using Amazon.SimpleNotificationService.Model;
using Experian.Events.MessageBuilder;
using EXPN.Controllers.CreditLockService.Messaging;
using FluentAssertions;
using Microsoft.Extensions.Logging;
using NSubstitute;
using NSubstitute.ExceptionExtensions;
using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using EXPN.Controllers.CreditLockService.Constants;
using Xunit;

namespace EXPN.UnitTest.CreditLockService.BusinessLayer.Messaging
{
    public class MessagingTests
    {
        private readonly IAmazonSimpleNotificationService _sns;
        private readonly IMessageBuilder _messageBuilder;
        private readonly ITopicRetriever _topicRetriever;
        private readonly ILogger<EXPN.Controllers.CreditLockService.Messaging.Messaging> _logger;

        private readonly IMessaging _messaging;

        public MessagingTests()
        {
            _sns = Substitute.For<IAmazonSimpleNotificationService>();
            _messageBuilder = Substitute.For<IMessageBuilder>();
            _topicRetriever = Substitute.For<ITopicRetriever>();
            _logger = Substitute.For<ILogger<EXPN.Controllers.CreditLockService.Messaging.Messaging>>();

            _messaging =
                new EXPN.Controllers.CreditLockService.Messaging.Messaging(_sns, _messageBuilder, _topicRetriever,
                    _logger);
        }

        public class Constructor
        {
            public static IEnumerable<object[]> NullParameters()
            {
                yield return new object[]
                {
                    null,
                    Substitute.For<IMessageBuilder>(),
                    Substitute.For<ITopicRetriever>(),
                    Substitute.For<ILogger<EXPN.Controllers.CreditLockService.Messaging.Messaging>>(),
                    "sns"
                };

                yield return new object[]
                {
                    Substitute.For<IAmazonSimpleNotificationService>(),
                    null,
                    Substitute.For<ITopicRetriever>(),
                    Substitute.For<ILogger<EXPN.Controllers.CreditLockService.Messaging.Messaging>>(),
                    "messageBuilder"
                };

                yield return new object[]
                {
                    Substitute.For<IAmazonSimpleNotificationService>(),
                    Substitute.For<IMessageBuilder>(),
                    null,
                    Substitute.For<ILogger<EXPN.Controllers.CreditLockService.Messaging.Messaging>>(),
                    "topicRetriever"
                };

                yield return new object[]
                {
                    Substitute.For<IAmazonSimpleNotificationService>(),
                    Substitute.For<IMessageBuilder>(),
                    Substitute.For<ITopicRetriever>(),
                    null,
                    "logger"
                };
            }

            [Theory]
            [MemberData(nameof(NullParameters))]
            public void NullRequiredConstructorParameter_ThrowsArgumentNullException(
                IAmazonSimpleNotificationService sns,
                IMessageBuilder messageBuilder,
                ITopicRetriever topicRetriever,
                ILogger<EXPN.Controllers.CreditLockService.Messaging.Messaging> logger,
                string expectedErrorParameter)
            {
                Action action = () =>
                {
                    new EXPN.Controllers.CreditLockService.Messaging.Messaging(sns, messageBuilder,
                        topicRetriever, logger);
                };

                action.Should().Throw<ArgumentNullException>()
                    .Where(x => x.ParamName == expectedErrorParameter);
            }
        }

        public class PublishEventAsync : MessagingTests
        {
            public static IEnumerable<object[]> LogInformationMessagesEnumerable()
            {
                yield return new object[]
                {
                    LogEventNames.Messaging.PublishEventAsync.Enter
                };

                yield return new object[]
                {
                    LogEventNames.Messaging.PublishEventAsync.Exit
                };
            }

            [Theory]
            [MemberData(nameof(LogInformationMessagesEnumerable))]
            public async Task HappyPathInformationLogged(string loggerMessage)
            {
                const string eventName = "EventName";
                const string eventMessage = "EventMessage";

                var creditLockEventContent = new CreditLockEventContent();

                _messageBuilder.Build(creditLockEventContent)
                    .Returns(eventMessage);

                _sns.PublishAsync(_topicRetriever.GetTopicPhysicalId(eventName), eventMessage)
                    .Returns(new PublishResponse());
                
                await _messaging.PublishEventAsync(eventName, creditLockEventContent);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(loggerMessage)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public void PublishEventAsync_EventContentNull_ThrowsArgumentNullException()
            {
                Func<Task> task = async () => { await _messaging.PublishEventAsync("EventName", null); };

                task.Should().Throw<ArgumentNullException>()
                    .Where(x => x.ParamName == "creditLockEventContent");
            }

            public static IEnumerable<object[]> EventNameArgsEnumerable()
            {
                yield return new object[]
                {
                    null
                };

                yield return new object[]
                {
                    string.Empty
                };

                yield return new object[]
                {
                    string.Empty.PadLeft(100)
                };
            }

            [Theory]
            [MemberData(nameof(EventNameArgsEnumerable))]
            public void PublishEventAsync_EventNameInvalid_ThrowsArgumentException(string eventName)
            {
                Func<Task> task = async () => { await _messaging.PublishEventAsync(eventName, new CreditLockEventContent()); };

                task.Should().Throw<ArgumentException>()
                    .Where(x => x.Message == "eventName cannot be null or whitespace (Parameter 'eventName')" && x.ParamName == "eventName");
            }

            [Fact]
            public async Task ValidParameters_PublishEventAsync_HappyPath_Success()
            {
                const string eventName = "EventName";
                const string eventMessage = "EventMessage";

                var creditLockEventContent = new CreditLockEventContent();

                _messageBuilder.Build(creditLockEventContent)
                    .Returns(eventMessage);

                var publishResponse = new PublishResponse
                {
                    HttpStatusCode = HttpStatusCode.OK,
                    MessageId = "MessageId"
                };

                _sns.PublishAsync(_topicRetriever.GetTopicPhysicalId(eventName), eventMessage)
                    .Returns(publishResponse);

                await _messaging.PublishEventAsync(eventName, creditLockEventContent);

                await _messageBuilder.Received(1).Build(creditLockEventContent);
                await _sns.Received(1).PublishAsync(_topicRetriever.GetTopicPhysicalId(eventName), eventMessage);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.Messaging.PublishEventAsync.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.Messaging.PublishEventAsync.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            public static IEnumerable<object[]> EventMessageArgsEnumerable()
            {
                yield return new object[]
                {
                    null
                };

                yield return new object[]
                {
                    string.Empty
                };

                yield return new object[]
                {
                    string.Empty.PadLeft(100)
                };
            }

            [Theory]
            [MemberData(nameof(EventMessageArgsEnumerable))]
            public async Task PublishEventAsync_EventMessageReturnedIsInvalid_ThrowsInvalidOperationException(string eventMessage)
            {
                var creditLockEventContent = new CreditLockEventContent();

                _messageBuilder.Build(creditLockEventContent)
                    .Returns(eventMessage);

                Func<Task> task = async () => { await _messaging.PublishEventAsync("eventName", creditLockEventContent); };
                
                task.Should().Throw<InvalidOperationException>()
                    .Where(x => x.Message == "eventMessage cannot be null or whitespace");

                await _messageBuilder.Received(1).Build(creditLockEventContent);
                await _sns.DidNotReceive().PublishAsync(Arg.Any<string>(), Arg.Any<string>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.Messaging.PublishEventAsync.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.Messaging.PublishEventAsync.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }


            [Fact]
            public async Task ValidParameters_PublishEventAsync_ThrowsException()
            {
                const string eventName = "EventName";
                const string eventMessage = "EventMessage";

                var creditLockEventContent = new CreditLockEventContent();

                var expectedEx = new OutOfMemoryException("Test Message");

                _messageBuilder.Build(creditLockEventContent)
                    .Returns(eventMessage);

                _sns.PublishAsync(_topicRetriever.GetTopicPhysicalId(eventName), eventMessage)
                    .Throws(expectedEx);

                Func<Task> task = async () => { await _messaging.PublishEventAsync(eventName, creditLockEventContent); };

                task.Should().Throw<OutOfMemoryException>()
                    .Where(x => x.Message == expectedEx.Message);

                await _messageBuilder.Received(1).Build(creditLockEventContent);
                await _sns.Received(1).PublishAsync(_topicRetriever.GetTopicPhysicalId(eventName), eventMessage);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.Messaging.PublishEventAsync.Enter)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.Messaging.PublishEventAsync.Exit)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

        }
    }
}