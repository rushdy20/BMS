﻿using AutoMapper;
using EXPN.Models.CreditLockService.Internal.Get.Response;
using System.Diagnostics.CodeAnalysis;
using PaasModel = EXPN.Models.CreditLockService.Paas.PutLockStatus.Request;

namespace EXPN.Mappers.CreditLockService.Paas
{
    [ExcludeFromCodeCoverage]
    public class CustomerProfileToPutLockStatusRequestProfile : Profile
    {
        public CustomerProfileToPutLockStatusRequestProfile()
        {
            CreateMap<GetResponseCustomerProfile, PaasModel.PutLockStatusRequest>(MemberList.None)
                .ForMember(d => d.CustomerRef, m => m.MapFrom(s => s.CustomerRef))
                .ForMember(d => d.Status, m => m.MapFrom(s => "N"))
                .ForMember(d => d.CustomerId, m => m.MapFrom(s => s.CustomerId));
        }
    }
}