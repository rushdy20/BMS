﻿using System;
using EXPN.Models.CreditLockService.External.Put.Request;
using FluentValidation;

namespace EXPN.Validators.CreditLockService.Put.Customer
{
    public class PutStatusRequestValidator : AbstractValidator<PutStatusRequest>
    {
        public PutStatusRequestValidator(IValidator<PutStatusRequestBody> externalPubRequestBodyValidator)
        {
            if (externalPubRequestBodyValidator == null)
                throw new ArgumentNullException(nameof(externalPubRequestBodyValidator));

            RuleFor(x => x)
                .NotNull()
                .WithName(nameof(PutStatusRequest))
                .DependentRules(() =>
                {
                    RuleFor(instance => instance.CustomerId)
                        .Cascade(CascadeMode.StopOnFirstFailure)
                        .NotEmpty()
                        .Must(x => Guid.TryParse(x, out _))
                        .WithMessage("'CustomerId' is not in valid format.");

                    RuleFor(instance => instance.Body)
                        .Cascade(CascadeMode.StopOnFirstFailure)
                        .NotNull()
                        .SetValidator(externalPubRequestBodyValidator);
                });
        }

        protected override void EnsureInstanceNotNull(object instanceToValidate)
        {
            // v6.4  of FluentValidation causes Validators to reject null input, instead of allowing NotNull() to handle it. 
            // This implements the suggested workaround by the library author - https://github.com/JeremySkinner/FluentValidation/issues/486
        }
    }
}