﻿using AutoMapper;
using EXPN.BusinessLayer.CreditLockService.Commands;
using EXPN.BusinessLayer.CreditLockService.Constants;
using EXPN.DataLayer.CreditLockService.Paas.HttpClient;
using EXPN.Models.CreditLockService.Internal;
using EXPN.Models.CreditLockService.Internal.Get.Response;
using EXPN.Models.CreditLockService.Internal.Post.Response;
using EXPN.Models.CreditLockService.Paas.Post.Request;
using FluentAssertions;
using Microsoft.Extensions.Logging;
using NSubstitute;
using NSubstitute.ExceptionExtensions;
using System;
using System.Collections.Generic;
using Xunit;

namespace EXPN.UnitTest.CreditLockService.BusinessLayer.Commands
{
    public class CreateCustomerCommandTests
    {
        private readonly ICreditLockPaasClient _creditLockPaaSClient;
        private readonly ILogger<CreateCustomerCommand<CustomerRequest, PostCustomerResponse>> _logger;
        private readonly IMapper _mapper;

        private readonly ICommand<CustomerRequest, PostCustomerResponse> _createCustomerCommand;

        public CreateCustomerCommandTests()
        {
            _creditLockPaaSClient = Substitute.For<ICreditLockPaasClient>();
            _logger = Substitute.For<ILogger<CreateCustomerCommand<CustomerRequest, PostCustomerResponse>>>();
            _mapper = Substitute.For<IMapper>();
            _createCustomerCommand = Substitute.For<ICommand<CustomerRequest, PostCustomerResponse>>();

            _createCustomerCommand = new CreateCustomerCommand<CustomerRequest, PostCustomerResponse>(_creditLockPaaSClient, _logger, _mapper);
        }

        public class Constructor
        {
            public static IEnumerable<object[]> NullParameters()
            {
                yield return new object[]
                {
                    null,
                    Substitute.For<ILogger<CreateCustomerCommand<CustomerRequest, PostCustomerResponse>>>(),
                    Substitute.For<IMapper>(),
                    "creditLockPaasClient"
                };

                yield return new object[]
                {
                    Substitute.For<ICreditLockPaasClient>(),
                    null,
                    Substitute.For<IMapper>(),
                    "logger"
                };

                yield return new object[]
                {
                    Substitute.For<ICreditLockPaasClient>(),
                    Substitute.For<ILogger<CreateCustomerCommand<CustomerRequest, PostCustomerResponse>>>(),
                    null,
                    "mapper"
                };
            }

            [Theory]
            [MemberData(nameof(NullParameters))]
            public void NullRequiredConstructorParameter_ThrowsArgumentNullException(
                ICreditLockPaasClient paaSHttpClient,
                ILogger<CreateCustomerCommand<CustomerRequest, PostCustomerResponse>> logger,
                IMapper mapper,
                string expectedErrorParameter)
            {
                Action action = () => { new CreateCustomerCommand<CustomerRequest, PostCustomerResponse>
                    (paaSHttpClient, logger, mapper); };

                action.Should().Throw<ArgumentNullException>()
                    .Where(x => x.ParamName == expectedErrorParameter);
            }

            [Fact]
            public void Id_IsCorrect()
            {
                new CreateCustomerCommand<CustomerRequest, PostCustomerResponse>(
                    Substitute.For<ICreditLockPaasClient>(),
                    Substitute.For<ILogger<CreateCustomerCommand<CustomerRequest, PostCustomerResponse>>>(),
                    Substitute.For<IMapper>()).Id.Should().Be("CUSTOMER-CREATE");
            }
        }

        public class Execute : CreateCustomerCommandTests
        {
            public static IEnumerable<object[]> LogInformationMessages()
            {
                yield return new object[]
                {
                    LogEventNames.CreateCustomerCommand.Execute.Enter
                };

                yield return new object[]
                {
                    LogEventNames.CreateCustomerCommand.Execute.Exit
                };
            }

            [Theory]
            [MemberData(nameof(LogInformationMessages))]
            public void HappyPathInformationLogged(string loggerMessage)
            {
                const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

                var getResponseCustomerProfile = new GetResponseCustomerProfile
                {
                    CustomerId = customerId
                };

                var postCustomerRequest = new PostCustomerRequest
                {
                    CustomerId = customerId
                };

                _mapper.Map<PostCustomerRequest>(getResponseCustomerProfile)
                    .Returns(postCustomerRequest);

                var customerRequest = new CustomerRequest
                {
                    CustomerId = customerId
                };

                _createCustomerCommand.Execute(customerRequest, getResponseCustomerProfile);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(loggerMessage)), null,
                    Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public void ExecuteCustomerRequestNull_ThrowsArgumentNullException()
            {
                Action action = () => { _createCustomerCommand.Execute(null, null); };

                action.Should().Throw<ArgumentNullException>()
                    .Where(x => x.ParamName == "request");
            }

            [Fact]
            public void ExecuteCustomerProfileNull_ThrowsArgumentNullException()
            {
                Action action = () => { _createCustomerCommand.Execute(new CustomerRequest(), null); };

                action.Should().Throw<ArgumentNullException>()
                    .Where(x => x.ParamName == "customerProfile");
            }

            public static IEnumerable<object[]> CustomerRequestArgumentException()
            {
                yield return new object[]
                {
                    new CustomerRequest
                    {
                        CustomerId = null
                    }
                };

                yield return new object[]
                {
                    new CustomerRequest
                    {
                        CustomerId = string.Empty
                    }
                };

                yield return new object[]
                {
                    new CustomerRequest
                    {
                        CustomerId = string.Empty.PadLeft(10)
                    }
                };
            }

            [Theory]
            [MemberData(nameof(CustomerRequestArgumentException))]
            public void ExecuteCustomerRequestInvalid_ThrowsArgumentNullException(CustomerRequest customerRequest)
            {
                Action action = () =>
                {
                    _createCustomerCommand.Execute(customerRequest, new GetResponseCustomerProfile());
                };

                action.Should().Throw<ArgumentException>()
                    .Where(x => x.Message == "CustomerId cannot be null or whitespace (Parameter 'request')");
            }

            [Fact]
            public void ValidCustomerId_Execute_HappyPath_Success()
            {
                const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

                var getResponseCustomerProfile = new GetResponseCustomerProfile
                {
                    CustomerId = customerId
                };

                var customerRequest = new CustomerRequest
                {
                    CustomerId = customerId
                };

                var postCustomerRequest = new PostCustomerRequest
                {
                    CustomerId = customerId
                };

                _mapper.Map<PostCustomerRequest>(getResponseCustomerProfile)
                    .Returns(postCustomerRequest);

                _createCustomerCommand.Execute(customerRequest, getResponseCustomerProfile);

                _mapper.Received(1).Map<PostCustomerRequest>(getResponseCustomerProfile);
                _creditLockPaaSClient.Received(1).Post(postCustomerRequest);

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreateCustomerCommand.Execute.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreateCustomerCommand.Execute.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }

            [Fact]
            public void ValidCustomerId_Execute_ThrowsOutOfMemoryException()
            {
                const string customerId = "a69e102d-d776-490a-a0a1-dfe25c791df9";

                var expectedEx = new OutOfMemoryException("Test Exception Message");

                var getResponseCustomerProfile = new GetResponseCustomerProfile
                {
                    CustomerId = customerId
                };

                var customerRequest = new CustomerRequest
                {
                    CustomerId = customerId
                };

                _mapper.Map<PostCustomerRequest>(getResponseCustomerProfile)
                    .Throws(expectedEx);

                Action action = () =>
                {
                    _createCustomerCommand.Execute(customerRequest, getResponseCustomerProfile);
                };

                action.Should().Throw<OutOfMemoryException>()
                    .Where(x => x.Message == expectedEx.Message);

                _mapper.Received(1).Map<PostCustomerRequest>(getResponseCustomerProfile);
                _creditLockPaaSClient.DidNotReceive().Post(Arg.Any<PostCustomerRequest>());

                _logger.Received(1).Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreateCustomerCommand.Execute.Enter)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());

                _logger.DidNotReceive().Log(LogLevel.Information, Arg.Any<EventId>(),
                    Arg.Is<Dictionary<string, object>>(o => o.ContainsValue(LogEventNames.CreateCustomerCommand.Execute.Exit)), null, Arg.Any<Func<Dictionary<string, object>, Exception, string>>());
            }
        }
    }
}