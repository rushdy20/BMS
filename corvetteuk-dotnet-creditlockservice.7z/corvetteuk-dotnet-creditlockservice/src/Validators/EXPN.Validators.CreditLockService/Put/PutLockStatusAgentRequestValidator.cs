﻿using System;
using EXPN.Models.CreditLockService.External.Put.Request;
using FluentValidation;

namespace EXPN.Validators.CreditLockService.Put
{
    public class PutStatusAgentRequestValidator : AbstractValidator<PutStatusAgentRequest>
    {
        public PutStatusAgentRequestValidator(IValidator<PutStatusAgentRequestBody> requestBodyValidator)
        {
            if (requestBodyValidator == null)
                throw new ArgumentNullException(nameof(requestBodyValidator));

            RuleFor(x => x)
                .NotNull()
                .WithName(nameof(PutStatusAgentRequest))
                .DependentRules(() =>
                {
                    RuleFor(instance => instance.CustomerId)
                        .Cascade(CascadeMode.StopOnFirstFailure)
                        .NotEmpty()
                        .Must(x => Guid.TryParse(x, out _))
                        .WithMessage("'CustomerId' is not in valid format.");

                    RuleFor(instance => instance.Body)
                        .Cascade(CascadeMode.StopOnFirstFailure)
                        .NotEmpty()
                        .SetValidator(requestBodyValidator);
                });
        }
    }
}