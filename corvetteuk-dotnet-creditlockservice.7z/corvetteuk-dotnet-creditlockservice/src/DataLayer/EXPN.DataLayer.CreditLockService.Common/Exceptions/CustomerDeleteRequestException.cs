﻿using System;
using System.Runtime.Serialization;

namespace EXPN.DataLayer.CreditLockService.Common.Exceptions
{
    [Serializable]
    public class CustomerDeleteRequestException : Exception
    {
        protected CustomerDeleteRequestException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }

        public CustomerDeleteRequestException()
        {
        }

        public CustomerDeleteRequestException(string message)
            : base(message)
        {
        }

        public CustomerDeleteRequestException(string message, Exception innerException)
            : base(message, innerException)
        {
        }
    }
}