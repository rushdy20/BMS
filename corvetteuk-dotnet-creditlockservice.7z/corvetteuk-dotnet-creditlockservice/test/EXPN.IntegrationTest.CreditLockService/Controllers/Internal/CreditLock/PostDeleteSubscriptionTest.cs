﻿using System.Collections.Generic;
using System.Net;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using EXPN.DataLayer.CreditLockService.Paas.HttpClient;
using EXPN.IntegrationTest.CreditLockService.Utility;
using FluentAssertions;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Newtonsoft.Json.Linq;
using Xunit;

namespace EXPN.IntegrationTest.CreditLockService.Controllers.Internal.CreditLock
{
    public class PostDeleteSubscriptionTest
    {
        private readonly IHostBuilder _hostBuilder;

        public PostDeleteSubscriptionTest()
        {
            _hostBuilder = new HostBuilder()
                .UseIntegrationTestSettings()
                .ConfigureServices(s =>
                    s.AddHttpClient<ICreditLockPaasClient, CreditLockPaasClient>(c =>
                    {
                        c.DefaultRequestHeaders
                            .Accept
                            .Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    }).AddHttpMessageHandler<MockPaasHttpClientHandler>());
        }

        public static IEnumerable<object[]> GetReportData()
        {
            yield return new object[]            {
                "not a valid id",
                "{\"customerNumber\":\"6234701\",\"customerId\":\"testcustomerId\",\"idpRefId\": \"testIdRefId\",\"tenantId\":\"testTenentId\"}",
                (HttpStatusCode) 400,
                "{\"fieldErrors\": {\"CustomerId\": \"'CustomerId' is not in valid format\"},\"status\": 400,\"message\": null}"
            };

            yield return new object[]
            {
                "4b1f51c5-e902-4efb-8366-816e29e788e7",
                "{\"customerNumber\":\"6234701\",\"customerId\":\"testcustomerId\",\"idpRefId\": \"testIdRefId\",\"tenantId\":\"testTenentId\"}",
                (HttpStatusCode) 204,
                null,

            };

            yield return new object[]
            {
                "4a1f51c5-e902-4efb-8366-816e29e78561",
                "{\"customerNumber\":\"1234561\",\"customerId\":\"testcustomerId\",\"idpRefId\": \"testIdRefId\",\"tenantId\":\"testTenentId\"}",
                (HttpStatusCode) 561,
                "{\"fieldErrors\":{},\"status\":561,\"message\":null}"
            };

            yield return new object[]
            {
                "4a1f51c5-e902-4efb-8400-816e29e78999",
                 "{\"customerNumber\":\"9992000\",\"customerId\":\"testcustomerId\",\"idpRefId\": \"testIdRefId\",\"tenantId\":\"testTenentId\"}",
                (HttpStatusCode) 563,
                "{\"fieldErrors\": {},\"status\": 563,\"message\": null}"
            };

            yield return new object[]
            {
                "4a1f51c5-e902-4efb-8366-816e29e78503",
                "{\"customerNumber\":\"1234503\",\"customerId\":\"testcustomerId\",\"idpRefId\": \"testIdRefId\",\"tenantId\":\"testTenentId\"}",
                 (HttpStatusCode) 503,
                "{\"fieldErrors\":{},\"status\":503,\"message\":null}"
            };

            yield return new object[]
            {
                "4a1f51c5-e902-4efb-8366-816e29e78404",
                "{\"customerNumber\":\"12345404\",\"customerId\":\"testcustomerId\",\"idpRefId\": \"testIdRefId\",\"tenantId\":\"testTenentId\"}",
                (HttpStatusCode) 404,
                "{\"fieldErrors\":{},\"status\":404,\"message\":null}"
            };
            yield return new object[]
            {
                "4a1f51c5-e902-5efb-8366-816e29e78561",
                "{\"customerNumber\":\"\",\"customerId\":\"testcustomerId\",\"idpRefId\": \"testIdRefId\",\"tenantId\":\"testTenentId\"}",
                (HttpStatusCode) 400,
                "{\"fieldErrors\":{\"body.customerNumber\": \"'Customer Number' should not be null\"},\"status\":400,\"message\":null}"
            };
        }

        [Theory]
        [MemberData(nameof(GetReportData))]
        public async Task PostDeleteSubscription_ResponseExpectedStatusCode(string customerId,string body, HttpStatusCode expectedStatusCode, string expectedServiceResponseJsonStr)
        {
            const string endPoint = "/internal/creditlock/delete";

            var actualServiceResponse = await CommonIntegrationFunctions.DeleteRequest(endPoint,body, customerId, _hostBuilder);
            actualServiceResponse.StatusCode.Should().Be(expectedStatusCode);

            if (expectedServiceResponseJsonStr != null)
            {
                var actualServiceResponseJsonStr = await actualServiceResponse.Content.ReadAsStringAsync();

                JToken.DeepEquals(JObject.Parse(actualServiceResponseJsonStr),
                    JObject.Parse(expectedServiceResponseJsonStr)).Should().BeTrue();
            }
        }
    }
}