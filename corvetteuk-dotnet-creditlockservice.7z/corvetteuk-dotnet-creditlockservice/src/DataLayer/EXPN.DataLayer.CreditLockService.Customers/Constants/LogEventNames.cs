﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EXPN.DataLayer.CreditLockService.Customers.Constants
{
    public class LogEventNames
    {
        public struct Customers
        {
            public struct GetCustomerProfile
            {
                public const string CustomerNotFound = "GetCustomerProfile_CustomerNotFound";
                public const string BadRequest = "GetCustomerProfile_BadRequest";
                public const string UnsuccessfulRequest = "GetCustomerProfile_UnsuccessfulRequest";
                public const string RequestException = "GetCustomerProfile_RequestException";
            }
        }
    }
}