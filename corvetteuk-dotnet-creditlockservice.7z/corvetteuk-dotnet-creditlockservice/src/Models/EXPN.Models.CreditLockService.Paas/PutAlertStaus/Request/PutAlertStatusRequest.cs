﻿using System.Diagnostics.CodeAnalysis;
using Newtonsoft.Json;

namespace EXPN.Models.CreditLockService.Paas.PutAlertStatus.Request
{
    [ExcludeFromCodeCoverage]
    public class PutAlertStatusRequest
    {
        [JsonIgnore]
        public string CustomerRef { get; set; }

        [JsonIgnore]
        public string CustomerId { get; set; }

        [JsonProperty]
        public string Status { get; set; }
    }
}