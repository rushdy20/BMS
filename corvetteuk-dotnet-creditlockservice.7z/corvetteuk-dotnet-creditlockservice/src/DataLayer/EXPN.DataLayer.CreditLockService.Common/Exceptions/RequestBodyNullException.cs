﻿using System;
using System.Runtime.Serialization;

namespace EXPN.DataLayer.CreditLockService.Common.Exceptions
{
    [Serializable]
    public class RequestBodyNullException : Exception
    {
        protected RequestBodyNullException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }

        public RequestBodyNullException()
        {
        }

        public RequestBodyNullException(string message)
            : base(message)
        {
        }

        public RequestBodyNullException(string message, Exception innerException)
            : base(message, innerException)
        {
        }
    }
}