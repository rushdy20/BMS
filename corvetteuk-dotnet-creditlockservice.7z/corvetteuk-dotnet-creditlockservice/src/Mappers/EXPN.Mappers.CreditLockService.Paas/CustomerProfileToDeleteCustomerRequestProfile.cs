﻿using AutoMapper;
using InternalModel = EXPN.Models.CreditLockService.Internal.Delete.Request;
using PaaSRequest = EXPN.Models.CreditLockService.Paas.Delete.Request;

namespace EXPN.Mappers.CreditLockService.Paas
{
    public class CustomerProfileToDeleteCustomerRequestProfile : Profile
    {
        public CustomerProfileToDeleteCustomerRequestProfile()
        {
            CreateMap<InternalModel.DeleteCustomerRequest, PaaSRequest.DeleteCustomerRequest>(MemberList.None)
                .ForMember(d => d.CustomerRef, m => m.MapFrom(s => s.CustomerNumber))
                .ForMember(d => d.CustomerId, m => m.MapFrom(s => s.CustomerId));
        }
    }
}